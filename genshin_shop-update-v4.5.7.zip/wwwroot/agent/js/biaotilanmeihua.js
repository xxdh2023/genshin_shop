function 标题栏美化(name,event,event1,event2){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 标题栏美化(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
    this.名称 = name;
    this.lefttext = null;
    this.righttext = null;
    this.leftimg = null;
    this.rightimg = null;
    this.bjk = null;
    
        //组件命令：
	this.置左侧文字=function(text,textsize,textcolor) {
		if(textsize==""){
			textsize="20px";
		}
		if(this.lefttext == null){
            this.lefttext=document.createElement("button");
            var titlebar= document.getElementById("标题栏1");
            var H1node=titlebar.getElementsByTagName("H1");
            titlebar.insertBefore(this.lefttext,H1node[0]);            
    	}
	    this.lefttext.className="mui-btn mui-btn-link mui-pull-left";
		this.lefttext.innerHTML=text;
		this.lefttext.style.cssText="font-size:"+textsize+";color:"+textcolor+"";
		this.lefttext.index="0";
	}

	this.置右侧文字=function(text,textsize,textcolor) {
		if(textsize==""){
			textsize="20px";
		}
		if(this.righttext==null){
            this.righttext=document.createElement("button");
            var titlebar = document.getElementById("标题栏1");
            //titlebar.insertBefore(righttext,titlebar.children[2]);
            var H1node=titlebar.getElementsByTagName("H1");
            titlebar.insertBefore(this.righttext,H1node[0]);	            
		}
	    this.righttext.className="mui-btn mui-btn-link mui-pull-right";
		this.righttext.innerHTML=text;
		this.righttext.style.cssText="font-size:"+textsize+";color:"+textcolor+"";
		this.righttext.index="1";
	}
	
    this.置左侧图片=function(imgsrc,imgheight,imgwidth,imgradius) {
        if(this.leftimg == null){
            this.leftimg = document.createElement("a");
            var titlebar= document.getElementById("标题栏1");
            var H1node=titlebar.getElementsByTagName("H1");
            titlebar.insertBefore(this.leftimg,H1node[0]);			
        }
		this.leftimg.className="mui-icon mui-pull-left header-img";
		this.leftimg.index="0";
		this.leftimg.style.cssText="padding-top:0px;margin-top:"+parseInt((45-Number(imgheight.substr(0,imgheight.length-2)))/2)+"px";
		this.leftimg.innerHTML="<img src='"+imgsrc+"' style='width:"+imgwidth+";height:"+imgheight+";border-radius:"+imgradius+";'>"
	}   
	
	this.置右侧图片=function(imgsrc,imgheight,imgwidth,imgradius) {
        if(this.rightimg == null){
		    this.rightimg = document.createElement("a");
            var titlebar= document.getElementById("标题栏1");
            var H1node=titlebar.getElementsByTagName("H1");
            titlebar.insertBefore(this.rightimg,H1node[0]);		    
		}
		this.rightimg.className="mui-icon mui-pull-right header-img";
		this.rightimg.index="1";
		this.rightimg.style.cssText="padding-top:0px;margin-top:"+parseInt((45-Number(imgheight.substr(0,imgheight.length-2)))/2)+"px";
		this.rightimg.innerHTML="<img src='"+imgsrc+"' style='width:"+imgwidth+";height:"+imgheight+";border-radius:"+imgradius+";'>"
	}
	
	this.添加编辑框=function(placehd,bjkwidth,bgcolor,radius,llogo){
        if(this.bjk == null){
            this.bjk = document.createElement("a");
            var titlebar= document.getElementById("标题栏1");
            var H1node=titlebar.getElementsByTagName("H1")[0];
            H1node.innerHTML="";
            H1node.style.backgroundColor="transparent";	
            H1node.appendChild(this.bjk);
		}
		this.bjk.className="header-search";
		if(llogo!=""){
	    	this.bjk.innerHTML="<input type='text' placeholder='"+placehd+"' readonly='readonly' style='width:"+bjkwidth+"; border-radius:"+radius+"; padding-left:40px;background: url("+llogo+") no-repeat 5px center "+bgcolor+";background-color:"+bgcolor+"'>";
		}else{
			this.bjk.innerHTML="<input type='text' placeholder='"+placehd+"' readonly='readonly' style='width:"+bjkwidth+"; border-radius:"+radius+"; background-color:"+bgcolor+"'>";
		}
	}
	
	this.置编辑框宽度=function(bjkwidth){
        if(this.bjk != null){
            var titlebar= document.getElementById("标题栏1");
            this.bjk=titlebar.getElementsByTagName("input")[0];
            this.bjk.style.width=bjkwidth;
		}
	}	

	this.置编辑框内容=function(bjkvalue){
        if(this.bjk != null){
            var titlebar= document.getElementById("标题栏1");
            this.bjk=titlebar.getElementsByTagName("input")[0];
            this.bjk.value=bjkvalue;
		}
	}

	this.取编辑框内容=function(){
        if(this.bjk != null){
            var titlebar= document.getElementById("标题栏1");
            this.bjk=titlebar.getElementsByTagName("input")[0];
            return this.bjk.value;
		}else{
            return "";
		}
	}
	
	this.置标题栏透明=function(){
		var titlebar= document.getElementById("标题栏1");
		titlebar.style.backgroundColor="transparent";
	}

	this.去标题栏阴影=function(){
		var titlebar= document.getElementById("标题栏1");
		titlebar.style.boxShadow="none";
	}

	this.去导航栏阴影=function(){
		var titlebar= document.getElementById("导航栏1");
		titlebar.style.boxShadow="none";
	}
	
    //组件事件
    if(event!=null){
		mui(".mui-bar").on("tap", "button", function() {
			event(Number(this.index));
        });       	
    }	
		
	if(event1!=null){
		mui(".mui-bar").on("tap", ".header-img", function() {
			var index = this.getAttribute("index");  
            var img = this.getElementsByTagName("img");
            var image = img[0].getAttribute("src"); 
			event1(Number(this.index),image);
        });       	
     }
		
	if(event2!=null){
		mui(".mui-bar").on("tap", ".header-search", function() {
			event2();
        });       	
    }
}