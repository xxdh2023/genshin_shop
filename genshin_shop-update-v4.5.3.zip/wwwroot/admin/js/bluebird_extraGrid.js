    function 高级表格(name,event1,event2,event3,event4,event5,event6){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 高级表格(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;

            // 自定义模块，引入soulTable模块,文档地址https://saodiyang.gitee.io/layui-soul-table/#/zh-CN/component/basic/drag
            layui.config({
                base: 'js/ext/',   // 模块目录
                version: 'v1.6.4'
            }).extend({             // 模块别名
                soulTable: 'soulTable'
            });  
		
		var haveXilakuang = false; //是否有下拉框
		
        //组件命令：
        this.初始化 = function (heigh,pag,toolba,total,jiaoti){	
            layui.use(["table","soulTable","form"],function () {
                var table = layui.table;//table文档地址：https://www.bejson.com/doc/layui/doc/modules/table.html
                var soulTable = layui.soulTable;
                var form = layui.form;
				var d =null;
				var param = {}; 
				if(toolba==true){
				    param = {  //注意,这里不能使用this.名称,只能使用name
                        height: heigh, //设置高度500 "500px" "auto"
						drag: false, // 关闭soulTable的拖拽列功能
                        page: pag, //是否开启分页
                        toolbar:"#" + name + "_toolbar1", // 显示顶部工具栏
                        totalRow:total,//显示底部合计行
                        even:jiaoti,//显示交替行背景色						
                        done: function(res, page, count){
                            d = res.data;
                            soulTable.render(this);
                        }						
                    };				
				}else{
				    param = {  //注意,这里不能使用this.名称,只能使用name
                        height: heigh, //设置高度500 "500px" "auto"
						drag: false, // 关闭soulTable的拖拽列功能
                        page: pag, //是否开启分页
                        toolbar:"",//不显示顶部工具栏
                        totalRow:total,//显示底部合计行
                        even:jiaoti,//显示交替行背景色							
                        done: function(res, page, count){
                            d = res.data;
                            soulTable.render(this);
                        }						
                    };					
				}
                table.init(name + "_filter", param);
				//console.log(table);
				//layer.alert("测试");
				
                //监听工具条被单击
                table.on("toolbar(" + name + "_filter)", function(obj){ //注：toolbar表示是表格顶部的工具栏,括号里的内容是table原始容器的属性lay-filter="对应的值"
                    //console.log(obj);
                    // 获取当前表格被选中的记录对象，返回数据
                    //var checkStatus = table.checkStatus(obj.config.id);
					//console.log(obj.config.id);//高级表格1
                    //console.log(checkStatus);
                    // 获取事件名，执行对应的代码
                    var eventName = obj.event; //lay-event：toolbar1_0
                    //console.log(eventName);
					if(event1!=null){
					    var arrs = eventName.split("_");
					    event1(Number(arrs[1]));//工具栏按钮被单击事件
					}
                    /*switch (eventName) {
                        case "getCheckData":
                            // 获取被选中的数组
                            var arr = checkStatus.data;
                            // 将数组解析成字符串
                            layer.alert(JSON.stringify(arr));
                            break;
                        case "getCheckLength":
                            var arr = checkStatus.data;
                            layer.msg("选中了"+arr.length+"条记录");
                            break;
                        case "isAll":
                            //通过isall属性判断是否全选
                            var flag = checkStatus.isAll;
                            var str = flag?"全选":"未全选";
                            layer.msg(str);
                            break;
                        case "LAYTABLE_COLS":
                            layer.alert('列名按钮被单击');
                            break;                    
                        case "LAYTABLE_EXPORT":
                            layer.alert('导出按钮被单击');
                            break;
                        case "LAYTABLE_PRINT":
                            layer.alert('打印按钮被单击');
                            break; 
                    }*/
                }); 

                //监听工具条2（操作栏）被单击
                table.on("tool(" + name + "_filter)", function(obj){ //注：tool表示是单元行里的工具栏，括号里的内容是table原始容器的属性lay-filter="对应的值"
                    //console.log(obj);
                    // 获取事件名，执行对应的代码
                    var eventName = obj.event; //lay-event：toolbar2_0
                    //console.log(eventName);
					if(event2!=null){
					    var arrs = eventName.split("_");
						var rowIndex = obj.tr.attr("data-index");
					    event2(Number(arrs[1]),rowIndex,obj.data);//操作栏按钮被单击事件
					}
                }); 
				
				
				window.getSelectData = function (){//取选中数据
                    var selectData = table.checkStatus(name);//obj.config.id
				    return selectData.data;
                }

				window.getIsAll = function (){//是否全选
                   var selectData = table.checkStatus(name);//obj.config.id
				   return selectData.isAll;
                }

				window.setCheckStatus = function (index,status){//设置选择框状态
					d[index]["LAY_CHECKED"]=status;
                } 

				window.getCheckStatus = function (index){//获取选择框状态
				    if(d[index]["LAY_CHECKED"]==true){
					    return true;
					}else{
					    return false;
					}
                } 
                
				//监听选择框被单击
				/*table.on("checkbox(" + name + "_filter)", function(obj){
                    console.log(obj.checked); //当前是否选中状态
                    console.log(obj.data); //选中行的相关数据
                    console.log(obj.type); //如果触发的是全选，则为：all，如果触发的是单选，则为：one
                    console.log(table.checkStatus(name + "_filter)").data); // 获取表格中选中行的数据
                });*/
				
				//监听表格行被单击
				table.on("row(" + name + "_filter)", function(obj){
				    //console.log(obj.data);
					//console.log(obj.tr.attr("data-index"));
					if(event3!=null){
					    var rowIndex = Number(obj.tr.attr("data-index"));
					    event3(rowIndex,obj.data);
					}
				});
				
				//监听单元格被编辑
                table.on("edit(" + name + "_filter)", function(obj){ //注：edit是单元格被编辑事件名，括号里的内容是table原始容器的属性lay-filter="对应的值"
                    var rowIndex = Number(obj.tr.attr("data-index"));//被编辑单元格所在行
					//console.log(rowIndex);
					//console.log(obj.field); //被编辑单元格所在列
                    //console.log(obj.value); //被编辑后的数据
                    //console.log(obj.data); //所在行的所有数据
					if(event4!=null){
					    event4(rowIndex,obj.field,obj.value,obj.data);
					}
                });					

                //监听开关操作
                form.on("switch(" + name + "_开关)", function(obj){
                    //console.log(this.value + '：'+ this.name + '：'+ obj.elem.checked);
					if(event5!=null){
					    event5(this.value,this.name,obj.elem.checked);
					}					
                });	
                
                //设置下拉框默认选中项为当前单元格的内容
				if(haveXilakuang){
                    $ = layui.$;
                    var divForm = $("#" + name).next();  // 获取表格，参数是表格的id
                    var tableCache = table.cache[name];  // 获取表格缓存数据，参数也是表格的id
                    var trJqs = divForm.find(".layui-table-body tr");  // 获取表格body下的所有tr标签
                    trJqs.each(function () {  // 遍历每个tr标签
                        var trJq = $(this);  // 获得当前遍历的tr标签
                        var dataIndex = trJq.attr("data-index");  // 得到当前数据行的data-index，即为第几行数据
                        trJq.find("td").each(function () {  // 遍历tr标签下的每一个td标签
                            var tdJq = $(this);  // 获得当前遍历的td标签
                            var fieldName = tdJq.attr("data-field");  // 获得当前td标签的字段名
                            var selectJq = tdJq.find("dl");  // 获得当前td标签下的dl标签，也就是select标签
                            if (selectJq.length == 1) {  // 判断select标签是否存在
                                var value = tableCache[dataIndex][fieldName];//单元格数据
                                var select = "dd[lay-value=" + value + "]";
                                tdJq.find("dl").find(select).click();// 查找点击，选中指定数据
                            }
                        });
                    });
                    form.render("select");  // 重新加载select表单
                }
				
				//监听下拉框被单击
                form.on("select(" + name + "_下拉框)", function (data) {   //里面的参数为select的lay-filter
                    var tableCache = table.cache[name]; // 获得数据表格的缓存数据
                    var  value = data.value; // 得到下拉列表改变后的value值
                    var  field = data.othis.parents('td').attr('data-field'); // 获得下拉列表的父级td标签的字段名称
                    var  dataIndex = parseInt(data.othis.parents('tr').attr('data-index')); // 获得变化的下拉列表所在的行index
                    var  oldValue = tableCache[dataIndex][field];  // 获得数据表格中该行的缓存数据
                    if (oldValue != value) {  // 判断数据是否发生了变化
                        tableCache[dataIndex][field] = value;  // 将修改后的数据更新到数据表格的缓存数据中
                        //console.log("下拉框被选择",dataIndex,field,oldValue,value);
                        if(event6!=null){
                            event6(dataIndex,field,oldValue,value);
                        }						
                    }
                });
				
				/*window.Select_delateAll = function (ziduan){//清空下拉框项目，参数为字段名称
                    $ = layui.$;
                    var divForm = $("#" + name).next();  // 获取表格，参数是表格的id
                    var trJqs = divForm.find(".layui-table-body tr");  // 获取表格body下的所有tr标签
                    trJqs.each(function () {  // 遍历每个tr标签
                        var trJq = $(this);  // 获得当前遍历的tr标签
                        var select = trJq.find("td[data-field=" + ziduan + "]").find("select")[0];//找到指定字段列的下拉框
                        while(select.hasChildNodes()){
                            select.removeChild(select.firstChild);
                        }
                    });
                    form.render("select");  // 重新加载select表单
				}*/

				/*window.Select_addItem = function (ziduan,value,title){//添加下拉框项目
                    $ = layui.$;
                    var divForm = $("#" + name).next();  // 获取表格，参数是表格的id
                    var trJqs = divForm.find(".layui-table-body tr");  // 获取表格body下的所有tr标签
                    trJqs.each(function () {  // 遍历每个tr标签
                        var trJq = $(this);  // 获得当前遍历的tr标签
                        var option = document.createElement("option");
                        option.setAttribute("value", value);
                        option.innerHTML = title;
                        trJq.find("td[data-field=" + "address" + "]").find("select")[0].appendChild(option);
                    });
                    form.render("select");  // 重新加载select表单
				}*/

				window.Select_setItem = function (id,html){//重置下拉框项目
                    var scr = document.getElementById(id);
                    scr.innerHTML = html;
				}
				
            });
        } 
        
        //组件命令：
        this.添加列 = function (field,value,width,checkbox,sort,toolbar,fixed,hide,totalRow,totalRowText,edit,shaixuan){
           //var tr = document.getElementById(this.名称).getElementsByTagName("thead")[0].childNodes[0];
		   var tr = document.getElementById(this.名称).getElementsByTagName("tr")[0];
		   var th = document.createElement("th");
		   var data = {"field":field,"width":width};
		   if(checkbox==true){
		   	  data.checkbox=true;
		   }
		   if(sort==true){
		   	  data.sort=true;
		   }
		   if(shaixuan==true){
		      data.filter=true;
		   }
		   if(toolbar==true){
		   	  data.toolbar="#" + this.名称 + "_toolbar2";
		   }
		   if(fixed==true){
		      data.fixed="left";
		   } 
		   if(hide==true){
		   	  data.hide=true;
		   }
		   if(totalRow==true){
		   	  data.totalRow=true;
		   }
		   if(totalRowText){
		   	  data.totalRowText=totalRowText;
		   }
		   if(edit==true){
		   	  data.edit="text";
		   }	   
		   th.setAttribute("lay-data",JSON.stringify(data)); 
		   th.innerText = value;
		   //console.log(th);
		   tr.appendChild(th);
        }  

        //组件命令：
        this.添加列_开关 = function (field,value,width,kaiguan){
           //var tr = document.getElementById(this.名称).getElementsByTagName("thead")[0].childNodes[0];
		   var tr = document.getElementById(this.名称).getElementsByTagName("tr")[0];
		   var th = document.createElement("th");
		   var data = {"field":field,"width":width};
           data.templet="#"+kaiguan;	   
		   th.setAttribute("lay-data",JSON.stringify(data)); 
		   th.innerText = value;
		   tr.appendChild(th);
        }  

        //组件命令：
        this.添加列_下拉框 = function (field,value,width,xialakuang){
           //var tr = document.getElementById(this.名称).getElementsByTagName("thead")[0].childNodes[0];
		   var tr = document.getElementById(this.名称).getElementsByTagName("tr")[0];
		   var th = document.createElement("th");
		   var data = {"field":field,"width":width};
           data.templet="#"+xialakuang;	   
		   th.setAttribute("lay-data",JSON.stringify(data)); 
		   th.innerText = value;
		   tr.appendChild(th);
		   haveXilakuang = true;
        } 
        /*
        //组件命令：
        this.清空下拉框项目 = function (ziduan){
            Select_delateAll(ziduan);
        }

        //组件命令：
        this.添加下拉框项目 = function (ziduan,value,title){
            Select_addItem(ziduan,value,title);
        }
        */
        //组件命令：
        this.置下拉框项目 = function (id,html){
            Select_setItem(id,html);
        }        
        
        //组件命令：
        this.清空列 = function (){
            var tr = document.getElementById(this.名称).getElementsByTagName("tr")[0];
            while(tr.hasChildNodes()){
			    tr.removeChild(tr.firstChild);
			}	   
        } 

        //组件命令：
        this.置列数据 = function (value){
		   var thead = document.getElementById(this.名称).getElementsByTagName("thead")[0];
		   thead.innerHTML = value;
        }

        //组件命令：
        this.取列数据 = function (){
		   var thead = document.getElementById(this.名称).getElementsByTagName("thead")[0];
		   var str = thead.innerHTML;
		   var regExp = new RegExp("&quot;", "g");
		   str = str.replace(regExp, "'");
		   var regExp = new RegExp("\"", "g");
		   str = str.replace(regExp, "\\\"");	
		   return str;
        }

        //组件命令：
        this.添加行 = function (checkbox,array){
           var tbody = document.getElementById(this.名称).getElementsByTagName("tbody")[0];
		   var tr = document.createElement("tr");
		   var temp = "";
		   for(var i = 0;i < array.length; i++){
			   if(i == 0){
		           if(checkbox==true){
		               temp = "<td lay-data=\"{checkbox:true}\">"+array[0]+"</td>";
		           }else{
		               temp = "<td>"+array[0]+"</td>";
		           }			       
			   }else{
		           temp = temp + "\n" +"<td>"+array[i]+"</td>";
		       }
		   }
		   tr.innerHTML = temp;
		   tbody.appendChild(tr);		   
        } 

        //组件命令：
        this.删除行 = function (index){
            var tbody = document.getElementById(this.名称).getElementsByTagName("tbody")[0];
			var tr = tbody.childNodes;
			//console.log(tr);
			//console.log(tr.length);
			if(index<tr.length){
			    var tbody = tr[index].parentNode;
			    tbody.removeChild(tr[index]);
			}	   
        } 

        //组件命令：
        this.修改行 = function (index,index2,value){
            var tbody = document.getElementById(this.名称).getElementsByTagName("tbody")[0];
			var tr = tbody.childNodes;
			//console.log(tr);
			//console.log(tr.length);
			if(index<tr.length){
			    var td2 = tr[index].getElementsByTagName("td");
			    td2[index2].innerText=value;
			}	   
        } 

        //组件命令：
        this.清空行 = function (){
            var tbody = document.getElementById(this.名称).getElementsByTagName("tbody")[0];
            while(tbody.hasChildNodes()){
			    tbody.removeChild(tbody.firstChild);
			}	   
        } 

        //组件命令：
        this.取列索引 = function (ziduan){
            var ths = document.getElementById(this.名称).getElementsByTagName("th");
			var index = -1;
            for(var i=0;i<ths.length;i++){
			    var value = eval("("+ths[i].getAttribute("lay-data")+")");
			    if(value.field==ziduan){
				    index = i;
				    break;
				}
			}
			return index;
        } 

        //组件命令：
        this.添加工具栏按钮 = function (color,radius,value){
		   var div = document.getElementById(this.名称 + "_toolbar1");
		   var button = document.createElement("button");
		   var style = "layui-btn layui-btn-sm";
		   if(color==1){//蓝色
		       style=style+" layui-btn-normal"; 
		   }else if(color==2){//绿色
		       //style=style+" layui-btn-primary"; 
		   }else if(color==3){//黄色
			   style=style+" layui-btn-warm"; 
		   }else if(color==4){//红色
			   style=style+" layui-btn-danger";
		   }
		   if(radius==true){//圆角
		       style=style+" layui-btn-radius";
		   }
		   button.setAttribute("class",style);
           button.setAttribute("lay-event","toolbar1_"+(div.childNodes.length)); //监听按钮被单击事件
		   button.innerText = value;
		   div.appendChild(button);
        }  

        //组件命令：
        this.清空工具栏按钮 = function (){
            var div = document.getElementById(this.名称 + "_toolbar1");
            while(div.hasChildNodes()){
			    div.removeChild(div.firstChild);
			}	   
        } 

        //组件命令：
        this.添加操作栏按钮 = function (color,radius,value){
		   var div = document.getElementById(this.名称 + "_toolbar2");
		   var button = document.createElement("button");
		   var style = "layui-btn layui-btn-xs";
		   if(color==1){//蓝色
		       style=style+" layui-btn-normal"; 
		   }else if(color==2){//绿色
		       //style=style+" layui-btn-primary"; 
		   }else if(color==3){//黄色
			   style=style+" layui-btn-warm"; 
		   }else if(color==4){//红色
			   style=style+" layui-btn-danger";
		   }
		   if(radius==true){//圆角
		       style=style+" layui-btn-radius";
		   }
		   button.setAttribute("class",style);
           button.setAttribute("lay-event","toolbar2_"+(div.childNodes.length)); //监听按钮被单击事件
		   button.innerText = value;
		   div.appendChild(button);
        }  

        //组件命令：
        this.清空操作栏按钮 = function (){
            var div = document.getElementById(this.名称 + "_toolbar2");
            while(div.hasChildNodes()){
			    div.removeChild(div.firstChild);
			}	   
        } 
		
        //组件命令：
        this.取选中数据 = function (){
            return getSelectData();
        } 

        //组件命令：
        this.是否全选 = function (){
            return getIsAll();
        } 

        //组件命令：
        this.取行数 = function (){
            return document.getElementById(this.名称).getElementsByTagName("tbody")[0].childNodes.length;
        } 

        //组件命令：
        this.取指定行数据 = function (index){
            var tbody = document.getElementById(this.名称).getElementsByTagName("tbody")[0];
			var tr = tbody.childNodes;
			var temp = [];
			if(index<tr.length){
			    var td2 = tr[index].getElementsByTagName("td");
				for(var i=0;i<td2.length;i++){
					temp.push(td2[i].innerText);
				}
			}
			return temp;	
        } 

        //组件命令：
        this.置行选中状态 = function (index,status){
            $ = layui.$;
            let t = $(".layui-table tr[data-index="+index+"] input[type='checkbox']");
			if(status==true){
                t.prop("checked",true);
                t.next().addClass("layui-form-checked");			
			}else{
                t.prop("checked",false);
                t.next().removeClass("layui-form-checked");			
			}
            setCheckStatus(index,status);
        }

        //组件命令：
        this.取行选中状态 = function (index){
            return getCheckStatus(index);
        }

        //组件命令：
        this.禁止行 = function (index){
            //第index行复选框不可选
            $ = layui.$;
            let t = $(".layui-table tr[data-index="+index+"] input[type='checkbox']");
            t.prop("disabled",true);
            t.addClass("layui-btn-disabled");
            t.next().css("cursor","not-allowed");
            //置灰
            $(".layui-table tr[data-index="+index+"]").css("background-color","#E0E0E0");
            $(".layui-table tr[data-index="+index+"]").css("color","#9f9696");
        }

        //组件命令：
        this.置行颜色 = function (index,back,color){
            $ = layui.$;
            $(".layui-table tr[data-index="+index+"]").css("background-color",back);
            $(".layui-table tr[data-index="+index+"]").css("color",color);
        }
        
        //组件命令：
        /*this.置可视 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称);
                div.style.display="";//显示，也可以设置为block	                
            }else{
                var div = document.getElementById(this.名称);
                div.style.display="none"; //不占位隐藏               
            }
        } 
        
        //组件命令：
        this.置可视2 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称);
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称);
                div.style.visibility="hidden"; //占位隐藏               
            }
        }*/ 
        
    }