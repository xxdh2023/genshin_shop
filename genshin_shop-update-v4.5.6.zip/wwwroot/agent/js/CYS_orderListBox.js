function CYS订单列表框(name,e1,e2){
	var _this = this;
	var obj = document.getElementById(name);
	var group = obj.querySelector(".group");
	var itemArr = group.getElementsByClassName("item");
	
	
	this.添加项目 = function(img1,t1,t2,img2,title,desc,msg,btnStr,tag){
		var item = document.createElement("li");
		item.className = "item";
		item.index = itemArr.length;
		item.tag = tag;
		item.innerHTML = "<div class='top-bar'>\n"+
		"	<img class='head' src='"+img1+"'/>\n"+
		"	<div class='nike-bar'>\n"+
		"		<span class='nb-name'>"+t1+"</span>\n"+
		"		<span class='nb-state'>"+t2+"</span>\n"+
		"	</div>\n"+
		"</div>\n"+
		"<div class='container'>\n"+
		"	<img class='c-img' src='"+img2+"'/>\n"+
		"	<div class='c-content'>\n"+
		"		<div class='cc-title'>"+title+"</div>\n"+
		"		<div class='cc-desc'>"+desc+"</div>\n"+
		"		<div class='cc-msg'>"+msg+"</div>\n"+
		"	</div>\n"+
		"</div>\n"+
		"<div class='button-bar'>\n"+
		"	<button class='bb-btn'>"+btnStr+"</button>\n"+
		"</div>";
		group.appendChild(item);
	};
	
	this.取项目数 = function(){
		return itemArr.length;
	};
	
	this.删除项目 = function(index){
		group.removeChild(itemArr[index]);
		for(var i=0;i<itemArr.length;i++){
			itemArr[i].index = i;
		};
	};
	
	this.清空项目 = function(){
		group.innerHTML = "";
	};
	
	this.取头像 = function(index){
		return itemArr[index].querySelector(".head").src;
	};
	
	this.置头像 = function(index,str){
		itemArr[index].querySelector(".head").src = str;
	};
	
	this.取昵称 = function(index){
		return itemArr[index].querySelector(".nb-name").innerHTML;
	};
	
	this.置昵称 = function(index,str){
		itemArr[index].querySelector(".nb-name").innerHTML = str;
	};
	
	this.取交易状态 = function(index){
		return itemArr[index].querySelector(".nb-state").innerHTML;
	};
	
	this.置交易状态 = function(index,str){
		itemArr[index].querySelector(".nb-state").innerHTML = str;
	};
	
	this.取商品图片 = function(index){
		return itemArr[index].querySelector(".c-img").src;
	};
	
	this.置商品图片 = function(index,str){
		itemArr[index].querySelector(".c-img").src = str;
	};
	
	this.取商品标题 = function(index){
		return itemArr[index].querySelector(".cc-title").innerHTML;
	};
	
	this.置商品标题 = function(index,str){
		itemArr[index].querySelector(".cc-title").innerHTML = str;
	};
	
	this.取商品描述 = function(index){
		return itemArr[index].querySelector(".cc-desc").innerHTML;
	};
	
	this.置商品描述 = function(index,str){
		itemArr[index].querySelector(".cc-desc").innerHTML = str;
	};
	
	this.取商品信息 = function(index){
		return itemArr[index].querySelector(".cc-msg").innerHTML;
	};
	
	this.置商品信息 = function(index,str){
		itemArr[index].querySelector(".cc-msg").innerHTML = str;
	};
	
	this.取按钮标题 = function(index){
		return itemArr[index].querySelector(".bb-btn").innerHTML;
	};
	
	this.置按钮标题 = function(index,str){
		itemArr[index].querySelector(".bb-btn").innerHTML = str;
	};
	
	this.取标记 = function(index){
		return itemArr[index].tag;
	};
	
	this.置标记 = function(index,str){
		itemArr[index].tag = str;
	};
	
	
    this.置可视 = function (value){
        if(value==true){
            var div = document.getElementById(name);
            div.style.display="";//显示，也可以设置为block	                
        }else{
            var div = document.getElementById(name);
            div.style.display="none"; //不占位隐藏               
        }
    };
    
    this.置可视2 = function (value){
        if(value==true){
            var div = document.getElementById(name);
            div.style.visibility="visible";//显示	                
        }else{
            var div = document.getElementById(name);
            div.style.visibility="hidden"; //占位隐藏               
        }
    };
    
    mui("#"+name).on("tap",".group .item",function(e){
    	if(e.target.className == "bb-btn"){
    		e2(this.index);
    	}else{
    		e1(this.index);
    	};
    });
}