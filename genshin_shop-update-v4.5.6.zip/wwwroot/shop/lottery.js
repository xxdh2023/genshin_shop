mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 自由面板1 = new 自由面板("自由面板1","72px");
var div_list_pic = new 图片框("div_list_pic",null);
var div_list_title = new 标签("div_list_title",null);
var div_list_note = new 标签("div_list_note",null);
var div_list_btn = new 按钮("div_list_btn",null,null,null);
var div_lottery_grid = new 自由列表框("div_lottery_grid",null,div_lottery_grid_按钮被单击);
if(mui.os.plus){
    mui.plusReady(function() {
        抽奖_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        抽奖_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var m_json={}
var 导航索引= 0;
function 抽奖_创建完毕(){





	根地址 = HPtools1.取URL();
	导航栏初始化(1);

	标题栏美化1.去标题栏阴影();
	自由面板1.置可视(false);


	调整组件尺寸();
	m_post = 公用模块.生成提交数据(0, "lottery_draw_info", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/lottery", m_token);
	美化等待框1.默认等待框("正在交互","正在获取抽奖列表,请稍等......");
	时钟1.开始执行(200,false);
}
function 调整组件尺寸(){

	var width= 窗口操作.取窗口宽度();


	窗口操作.置组件宽度("div_list_title","" + 转换操作.到文本(width - 64 - 64 - 24) + "px");
	窗口操作.置组件宽度("div_list_note","" + 转换操作.到文本(width - 64 - 64 - 24)+ "px");
	窗口操作.置组件左边("div_list_btn","" + 转换操作.到文本(width - 64-20) + "px");

}
function 导航栏初始化(激活项目){
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-cart","商城","0",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-grech","抽奖","1",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-gift","福利","2",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-express","仓库","3",0);
	导航栏1.添加项目("mui-icon", "mui-icon-contact","我的","4",0);
	导航栏1.添加完毕();
	导航栏1.置激活项目背景色("#F2F2F2");
	导航栏1.置项目激活状态(0,false);
	导航栏1.置项目激活状态(1,false);
	导航栏1.置项目激活状态(2,false);
	导航栏1.置项目激活状态(3,false);
	导航栏1.置项目激活状态(4,false);
	导航栏1.置项目激活状态(激活项目,true);
	导航索引 = 激活项目;
}
function 导航栏1_项目被单击(项目标题,目标名称){
	var arr = ["shop","lottery","welfare","warehouse","user"];
	var 子卡索引=转换操作.到数值(目标名称);
	if(子卡索引 == 导航索引 ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(arr[子卡索引]+".html","");
	}
}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "lottery_draw_info" && json.model == "select" ){
				m_json = json;
				div_lottery_grid.清空项目();
				var str= "";
				while(i < json.results.length){
					if(json.results[i].lot_model < 1 ){
						str = "福利[一次性抽奖],";
					}else if(json.results[i].lot_model == 1 ){
						str = "福利[整点抽奖],";
					}else if(json.results[i].lot_model == 2 ){
						str = "福利[每日抽奖],";
					}else if(json.results[i].lot_model == 3 ){
						str = "福利[每周抽奖],";
					}else if(json.results[i].lot_model == 4 ){
						str = "特惠["+转换操作.到文本(json.results[i].lot_coin)+"平台币抽一次";
						if(json.results[i].lot_coin2 > 0 ){
							str = str + ","+转换操作.到文本(json.results[i].lot_coin2)+"平台币抽十次";
						}
						str = str + "],";
					}
					if(json.results[i].is_lottery < 1 ){
						str = str + "您可正常参与本抽奖.";
					}else{
						if(json.results[i].lot_model < 1 ){
							str = str + "您已抽奖.";
						}else if(json.results[i].lot_model < 4 ){
							str = str + "您已抽奖,请等待下个时段......";
						}else{
							str = str + "超值大奖正在等着您！";
						}
					}
					div_lottery_grid_添加项目(json.results[i].lot_pic, json.results[i].lot_name, str, "查看<br>抽奖", json.results[i].lot_id);
					i++
				}
			}
		}
	}
}

function div_lottery_grid_添加项目(项目图片, 项目标题, 项目内容, 按钮标题, 项目标记){
	div_list_pic.置图片(项目图片);
	div_list_pic.置圆角("100px");
	div_list_title.置标题(项目标题);
	div_list_note.置标题(项目内容);
	div_list_btn.置标题(按钮标题);

	div_lottery_grid.添加项目("自由面板1",true,项目标记);
}
function div_lottery_grid_按钮被单击(项目索引,按钮名称){
	if(m_json.results[项目索引].lot_model < 4 && m_json.results[项目索引].is_lottery > 0 ){
		仔仔弹出对话框1.错误("您已抽奖！");
		return;
	}
	window.location.href = "lotterystart.html?lot_id="+div_lottery_grid.取项目标记(项目索引);

}