(function (){ 
window["公用模块"] = {}
function 延时发起访问请求(网络操作, post, url, 毫秒延时, 超时时长, 增强协议头){
	var mypost = post;
	var myurl = url;
	var timeout = 0;
	var type= typeof 超时时长;
	if(type != "number" ){
		timeout = 50000;
	}else{
		timeout = 超时时长;
		if(timeout < 50000 ){
			timeout = 50000;
		}
	}
	if(毫秒延时 < 5 ){
		毫秒延时 = 5;
	}
	var method="post";
	if(mypost == "" ){
		method="get";
	}
	if(增强协议头 == true ){
		网络操作.置附加请求头({"Content-Type":"application/json","Content-Length":  "10000000"});
		网络操作.置附加请求头();
	}else{
		网络操作.置附加请求头({"Content-Type":"application/json"});
	}
	setTimeout(function() {
		网络操作.发送网络请求(myurl,method,"text",mypost,timeout);
	}, 毫秒延时);
}
function 文本显示处理(待处理的文本, 显示颜色, 字体大小){
	var 类型= typeof 字体大小;
	if(类型 == "number" ){
		if(字体大小 < 1 ){
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+";\">"+待处理的文本+"</p>";
		}else if(字体大小 < 5 ){
			字体大小 = 数学操作.取整数(9 + 字体大小 * 2);
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+"; font-size:"+String(字体大小)+"px;\">"+待处理的文本+"</p>";
		}else{
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+"; font-size:"+String(字体大小)+"px;\">"+待处理的文本+"</p>";
		}
	}else{
		return "<p class=\"inline_block\" style=\"color:"+显示颜色+";\">"+待处理的文本+"</p>";
	}

}
function 生成访问链接_后端(url,api_key, password){
	url = 文本操作.删首尾空(url);
	api_key = 文本操作.删首尾空(api_key);
	password = 文本操作.删首尾空(password);
	if(url == "" || api_key == "" ){
		return "";
	}
	var str= 文本操作.取文本右边(url,1);
	if(str != "/" && 文本操作.取文本左边(api_key,1) != "/" ){
		url = url + "/";
	}
	str= url + api_key;



	return str;
}


function 生成访问链接(url,api_key, token){
	url = 文本操作.删首尾空(url);
	api_key = 文本操作.删首尾空(api_key);
	token = 文本操作.删首尾空(token);
	if(url == "" || api_key == "" ){
		return "";
	}
	var str= 文本操作.取文本右边(url,1);
	if(str != "/" ){
		url = url + "/";
	}
	str= url + api_key + "?token="+token;
	return str;
}

function 编辑框格式化(待处理文本, 处理类型){
	var str= 文本操作.删首尾空(待处理文本);
	if(str == "" ){
		return "";
	}
	var int=文本操作.寻找文本(str,":");
	if(int > 0 ){
		str = 文本操作.取文本左边(str, int);
	}else if(int == 0 ){
	    return "";
	}
	if(处理类型 == false ){
		int = 转换操作.到数值(str);
		if(int < 1 || 转换操作.到文本(int) != str ){
			return "";
		}else{
		    return str;
		}
	}

	str=文本操作.子文本替换(str, "  "," ");
	str=文本操作.子文本替换(str, "  "," ");
	str=文本操作.子文本替换(str, "  "," ");
	str=文本操作.子文本替换(str, "  "," ");
	str=文本操作.子文本替换(str, "  "," ");
	var strs=文本操作.分割文本(str, " ");
	int = 数组操作.取成员数(strs);
	if(int != 3 ){
		return "";
	}
	strs[0] = 文本操作.删首尾空(strs[0]);
	strs[1] = 文本操作.删首尾空(strs[1]);
	strs[2] = 文本操作.删首尾空(strs[2]);
	if(公用模块.文本数字确认(strs[0]) == false || 公用模块.文本数字确认(strs[1]) == false || 公用模块.文本数字确认(strs[2]) == false ){
		return "";
	}
	return strs[0] + " " + strs[1] + " " + strs[2];
}

function 文本数字确认(要确认的文本){
	var int=文本操作.取文本长度(要确认的文本);
	if(int < 1 ){
		return false;
	}
	var s1=文本操作.取文本左边(要确认的文本,1);
	var arr=["1","2","3","4","5","6","7","8","9","-"];
	var i= 0;
	var 不是数字=true;
	while(i < 10){
		if(s1 == arr[i] ){
			不是数字=false;
			break;
		}
		i++
	}
	if(不是数字 == true ){
		return false;
	}
	int = int - 1;
	if(int < 1 ){
		return true;
	}
	var 有小数点=false;
	i = 0;
	不是数字 = false;
	while(i < int){
		s1 = 文本操作.取文本中间(要确认的文本,i + 1,1);
		if(s1 == "." ){
			if(有小数点 == true ){
				不是数字=true;
				break;
			}else{
			    有小数点 = true;
			}
		}else{
			if(s1 != "0" && s1 != "1"  && s1 != "2"  && s1 != "3"  && s1 != "4"  && s1 != "5"  && s1 != "6"  && s1 != "7"  && s1 != "8"  && s1 != "9" ){
				不是数字=true;
				break;
			}
		}
		i++
	}
	if(不是数字 == true ){
		return false;
	}else{
	    return true;
	}
}


function 弹出面板初始化计算(左边, 顶边或高度, 真高度动态假顶边动态){




	var 窗口高度= 窗口操作.取窗口高度();
	var 窗口宽度= 窗口操作.取窗口宽度();
	if(左边 < 0 ){
		窗口宽度 = 数学操作.取绝对值(左边);
		if(窗口宽度 > 窗口操作.取窗口宽度() ){
			窗口宽度 = 窗口操作.取窗口宽度();
		}
		左边 = (窗口操作.取窗口宽度() - 窗口宽度)/2;
	}else{
		窗口宽度 = 窗口操作.取窗口宽度()-左边*2;
	}
	var 顶边= 0;
	if(真高度动态假顶边动态 == true ){
		顶边 = 顶边或高度;
		窗口高度 = 窗口高度-顶边或高度 * 2;

	}else{
		顶边 = 窗口高度/2 - 顶边或高度/2;
		窗口高度 = 顶边或高度;
	}


	var ret = new Array();
	ret[0] = ""+左边+"px";
	ret[1] = ""+顶边+"px";
	ret[2] = ""+窗口宽度+"px";
	ret[3] = ""+窗口高度+"px";
	return ret;
}

function 生成提交数据(static, table, comm, model, num, level, 外部传入的数据, oper_login, oper_password){

	var 类型= typeof 外部传入的数据;
	var json= {}
	if(类型 == "string" ){
		外部传入的数据 = 文本操作.删首尾空(外部传入的数据);
		if(外部传入的数据 != "" ){
			if(文本操作.取文本左边(外部传入的数据,1) == "{" && 文本操作.取文本右边(外部传入的数据,1) == "}" ){
				json = 转换操作.文本转json(外部传入的数据);
			}else if(文本操作.取文本左边(外部传入的数据,1) == "[" && 文本操作.取文本右边(外部传入的数据,1) == "]" ){
				json = 转换操作.文本转json(外部传入的数据);
			}
		}
	}else if(类型 == "object" ){
		json = 转换操作.文本转json(转换操作.json转文本(外部传入的数据));
	}
	类型 = typeof json;
	if(类型 != "object" ){
		json = {}
	}


	json.static = static;
	json.table = table;
	json.comm = comm;
	json.model = model;
	json.num = num;
	json.level = level;
	类型 = typeof oper_login;
	if(类型 == "string" ){
		oper_login = 文本操作.删首尾空(oper_login);
		if(oper_login != "" ){
			json.oper_login = oper_login;
		}
	}
	类型 = typeof oper_password;
	if(类型 == "string" ){
		oper_password = 文本操作.删首尾空(oper_password);
		if(oper_password != "" ){
			json.oper_password = oper_password;
		}
	}
	return 转换操作.json转文本(json);
}

function 取空格文本(空格数量){
	var i= 0;
	var ret="";
	while(i <  空格数量){
		ret = ret + "&nbsp;";
		i++
	}
	return ret;
}

function 键代码是回车键(键代码){
	if(键代码 == 13 ){
		return true;
	}else{
		return false;
	}
}

function 打开小窗口(url, title, left, top, width, height){
	var feat= "height="+转换操作.到文本(height)+", width="+转换操作.到文本(width)+", top="+转换操作.到文本(top)+", left="+转换操作.到文本(left)+", toolbar=no, menubar=no,scrollbars=yes,resizable=no, location=no, status=no";
	var me= window.open(url, title, feat);
	return me;
}

function 居中打开小窗口(url, width, height){
	var w= 窗口操作.取窗口宽度();
	var h= 窗口操作.取窗口高度();
	if(width > w ){
		width = w;
	}
	if(height > h ){
		height = h;
	}
	var left= 0;
	var top= 0;
	if(w > width ){
		left = (w - width) / 2;
	}
	if(h > height ){
		top = (h - height) / 2;
	}
	var me= 打开小窗口(url,"",left, top, width, height);
	return me;
}

function 自由面板_调整(自由面板内组件名称, 组件左边, 组件宽度,设计时宽度, 实际窗口宽度){
	var arr = new Array();
	arr = 自由面板_坐标生成(组件左边,组件宽度,设计时宽度,实际窗口宽度);
	窗口操作.置组件左边(自由面板内组件名称,arr[0]);
	窗口操作.置组件宽度(自由面板内组件名称,arr[1]);
}


function 自由面板_坐标生成(组件左边, 组件宽度, 设计时宽度, 实际窗口宽度){
	var 系数 = 0;
	系数 = 组件左边 / 设计时宽度;
	var 实际左边="" + 数学操作.四舍五入(实际窗口宽度 * 系数, 0) + "px";
	系数 = 组件宽度 / 设计时宽度;
	var 实际宽度="" + 数学操作.四舍五入(实际窗口宽度 * 系数, 0) + "px";
	var arr = new Array();
	arr[0] = 实际左边;
	arr[1] = 实际宽度;
	return arr;
}

function 取编码和名称(待处理的文本, 分隔符号){
	var res = new Array();
	待处理的文本 = 文本操作.删首尾空(待处理的文本);
	res[0] = "";
	res[1] = "";
	if(待处理的文本 != "" ){
		var i= 文本操作.寻找文本(待处理的文本, 分隔符号);
		if(i < 1 ){
			res[1] = 待处理的文本;
		}else{
			res[0] = 文本操作.删首尾空(文本操作.取文本左边(待处理的文本, i));
			res[1] = 文本操作.删首尾空(文本操作.取文本右边(待处理的文本, 文本操作.取文本长度(待处理的文本)-i-文本操作.取文本长度(分隔符号)));
		}
	}
	return res;
}

function 生成脚本内容及显示名称(item_model, 原编码值, 原显示名称, num, level){
	var res = new Array();
	res[0] = "";
	res[1] = "";
	原编码值 = 文本操作.删首尾空(原编码值);
	原显示名称 = 文本操作.删首尾空(原显示名称);
	if(item_model == 7 ){
		if(num > 14 ){
			num = 14;
		}
		if(level > 200 ){
			level = 200;
		}
	}else if(item_model == 2 ){
		if(num > 6 ){
			num = 6;
		}
		if(level > 5 ){
			level = 5;
		}
	}
	var 数量= 转换操作.到文本(num);
	var 等级= 转换操作.到文本(level - 1);

	switch(item_model){
		case 0 :
			res[0] = "item add " + 原编码值 +" "+ 数量;
			res[1] = 原显示名称 + " +"+ 数量;
		break;
		case 1 :
			if(原编码值 == "203" ){
				res[0] = "mcoin " + 数量;
			}else{
				res[0] = "item add " + 原编码值 +" "+ 数量;
			}
			res[1] = 原显示名称 + " +"+ 数量;
		break;
		case 2 :
			if(level < 2 ){
				if(num < 1 ){
					res[0] = "equip add " + 原编码值;
					res[1] = 原显示名称 + " +1";
				}else{
					res[0] = "equip add " + 原编码值 + " 1 " + 数量;
					res[1] = 原显示名称 + "[突破"+数量+"级,精炼1阶] +1";
				}
			}else{
				if(num < 1 ){
					数量 = "1";
				}
				res[0] = "equip add " + 原编码值 + " 1 " + 数量 + " " + 等级;
				res[1] = 原显示名称 + "[突破"+数量+"级,精炼"+转换操作.到文本(level)+"阶] +1";
			}
		break;
		case 3 :
			res[0] = "avatar add " + 原编码值;
			res[1] = 原显示名称 + " <!>";
		break;
		case 4 :
			res[0] = "goto " + 原编码值;
			res[1] = "传送到："+原显示名称;
		break;
		case 5 :
			if(num > 0 ){
				res[0] = "quest accept " + 原编码值;
				res[1] = "接受任务："+原显示名称;
			}else{
				res[0] = "quest finish " + 原编码值;
				res[1] = "完成任务："+原显示名称;
			}
		break;
		case 6 :
			res[0] = "jump " + 原编码值;
			res[1] = "移动到："+原显示名称;
		break;
		case 7 :
			res[0] = "monster " + 原编码值 +" "+ 数量+" "+等级;
			res[1] = 原显示名称 + "["+等级+"级] +"+ 数量;
		break;
		case 8 :
			res[0] = 原编码值;
			res[1] = 原显示名称;
		break;
		case 9 :
			res[0] = 原编码值 +" "+ 数量;
			res[1] = 原显示名称 + " +"+ 数量;
		break;
	}
	return res;
}

function 生成明细查看摘要(password,model, table_id, table_value, table, table_colm, table_title, 补充查询条件){
	var res= "detail.html?model="+转换操作.到文本(model)+"&table_id="+table_id+"&table_value="+table_value;
	return res + "&table="+table + "&table_colm="+table_colm + "&table_title="+table_title+"&select_value="+补充查询条件;
}

function 签到日期转换(sign_day){
	switch(sign_day){
	case 0 :
		return "";
	break;
	case 1 :
		return "每月1号/周一";
	break;
	case 2 :
		return "每月2号/周二";
	break;
	case 3 :
		return "每月3号/周三";
	break;
	case 4 :
		return "每月4号/周四";
	break;
	case 5 :
		return "每月5号/周五";
	break;
	case 6 :
		return "每月6号/周六";
	break;
	case 7 :
		return "每月7号/周日";
	break;
	default :
		return "每月" + 转换操作.到文本(sign_day)+"号";
		break;
	}
}

function 高级表格_快速生成(是选择框, 隐藏列, 显示操作栏, 固定在左边){
	var arr = new Array();
	arr[0] = 是选择框;
	arr[1] = false;
	arr[2] = 显示操作栏;
	arr[3] = 固定在左边;
	arr[4] = 隐藏列;
	arr[5] = false;
	arr[6] = "";
	arr[7] = false;
	arr[8] = false;
	return arr;
}

function 是否为整数文本(待判断的文本, 允许负数, 允许首位是零){
	var type= typeof 待判断的文本;
	if(type == "string" ){
		待判断的文本 = 文本操作.删首尾空(待判断的文本);
		if(待判断的文本 == "" ){
			return false;
		}
	}else if(type == "number" ){
		待判断的文本 = 转换操作.到文本(待判断的文本);
	}else{
		return false;
	}
	var num= 文本操作.取文本长度(待判断的文本);
	var i= 0;
	while(i < num){
		var s1= 文本操作.取文本中间(待判断的文本,i,1);
		if(s1 == "1" || s1 == "2" || s1 == "3" || s1 == "4" || s1 == "5" || s1 == "6" || s1 == "7" || s1 == "8" || s1 == "9" ){

		}else{
			if(i < 1 ){
				if(s1 != "-" && s1 != "0" ){
					return false;
				}else if(s1 == "-" && 允许负数 == false ){
					return false;
				}else if(s1 == "0" && 允许首位是零 == false ){
					return false;
				}
			}else{
				if(s1 != "0" ){
					return false;
				}
			}
		}
		i++
	}
	return true;
}
function 网络错误翻译(返回信息){
	var str= 文本操作.删首尾空(返回信息);
	str = 文本操作.到小写(返回信息);
	if(str == "abort" ){
		return "server.fail";
	}else if(str == "error" ){
		return "ajax.fail";
	}else if(str == "timeout" ){
		return "ajax.timeout";
	}else{
		return 返回信息;
	}
}
function 取当前日期年月日(指定时间){
	var res= 转换操作.到文本(时间操作.取年(指定时间));
	var 月= 时间操作.取月(指定时间);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	var 日= 时间操作.取日(指定时间);
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	return res;
}

function 取端口(URL){
	URL = 文本操作.删首尾空(URL);
	if(URL == "" ){
		return 80;
	}
	var num= 文本操作.寻找文本(URL,":",6);
	if(num < 8 ){
		return 80;
	}
	var 结尾符= 文本操作.寻找文本(URL,"/",num+1);
	var str= "";
	if(结尾符 < 0 ){
		str = 文本操作.取文本右边(URL,文本操作.取文本长度(URL)-num-1);
	}else{
		str = 文本操作.取文本中间(URL,num+1,结尾符-num-1);
	}
	str = 转换操作.到数值(str);
	return str;
}

function 生成支付插件(){
	var plugin= [];
	plugin[0] = {"key": "epay", "value": "易支付(v1版)"}
	plugin[1] = {"key": "llspayment", "value": "乐力付"}
	return plugin;
}
window["公用模块"]["延时发起访问请求"]=延时发起访问请求;
window["公用模块"]["文本显示处理"]=文本显示处理;
window["公用模块"]["生成访问链接_后端"]=生成访问链接_后端;
window["公用模块"]["生成访问链接"]=生成访问链接;
window["公用模块"]["编辑框格式化"]=编辑框格式化;
window["公用模块"]["文本数字确认"]=文本数字确认;
window["公用模块"]["弹出面板初始化计算"]=弹出面板初始化计算;
window["公用模块"]["生成提交数据"]=生成提交数据;
window["公用模块"]["取空格文本"]=取空格文本;
window["公用模块"]["键代码是回车键"]=键代码是回车键;
window["公用模块"]["打开小窗口"]=打开小窗口;
window["公用模块"]["居中打开小窗口"]=居中打开小窗口;
window["公用模块"]["自由面板_调整"]=自由面板_调整;
window["公用模块"]["自由面板_坐标生成"]=自由面板_坐标生成;
window["公用模块"]["取编码和名称"]=取编码和名称;
window["公用模块"]["生成脚本内容及显示名称"]=生成脚本内容及显示名称;
window["公用模块"]["生成明细查看摘要"]=生成明细查看摘要;
window["公用模块"]["签到日期转换"]=签到日期转换;
window["公用模块"]["高级表格_快速生成"]=高级表格_快速生成;
window["公用模块"]["是否为整数文本"]=是否为整数文本;
window["公用模块"]["网络错误翻译"]=网络错误翻译;
window["公用模块"]["取当前日期年月日"]=取当前日期年月日;
window["公用模块"]["取端口"]=取端口;
window["公用模块"]["生成支付插件"]=生成支付插件;
})();