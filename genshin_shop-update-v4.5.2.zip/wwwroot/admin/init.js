mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
var 标签1 = new 标签("标签1",null);
var div_daily_time_lable = new 标签("div_daily_time_lable",null);
var 标签2 = new 标签("标签2",null);
var div_daily_time_btn = new 按钮("div_daily_time_btn",div_daily_time_btn_被单击,null,null);
var div_agent_re_scale_1_edit = new 编辑框("div_agent_re_scale_1_edit",null,null,null,null,null);
var 标签3 = new 标签("标签3",null);
var div_agent_re_scale_2_edit = new 编辑框("div_agent_re_scale_2_edit",null,null,null,null,null);
var 标签4 = new 标签("标签4",null);
var div_agent_re_scale_3_edit = new 编辑框("div_agent_re_scale_3_edit",null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var 标签6 = new 标签("标签6",null);
var div_invest_scale_edit = new 编辑框("div_invest_scale_edit",null,null,null,null,null);
var 标签10 = new 标签("标签10",null);
var 标签14 = new 标签("标签14",null);
var div_rebate_check = new 复选框("div_rebate_check",null);
var 标签8 = new 标签("标签8",null);
var div_play_invest_check = new 复选框("div_play_invest_check",null);
var 标签9 = new 标签("标签9",null);
var div_rebate_min_edit = new 编辑框("div_rebate_min_edit",null,null,null,null,null);
var 标签11 = new 标签("标签11",null);
var div_commission_edit = new 编辑框("div_commission_edit",null,null,null,null,null);
var 标签12 = new 标签("标签12",null);
var div_commission_min_edit = new 编辑框("div_commission_min_edit",null,null,null,null,null);
var 标签13 = new 标签("标签13",null);
var div_password_edit = new 编辑框("div_password_edit",null,null,null,null,null);
var div_game_ver = new 下拉框("div_game_ver",div_game_ver_表项被单击);
var 按钮_设置 = new 按钮("按钮_设置",按钮_设置_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        初始化_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        初始化_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var m_game_ver= "";


function 初始化_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	根地址 = HPtools1.取URL();
	CYS日期时间选择器1.初始化(2,2020,2099);
	if(m_password != "" ){
		div_invest_scale_edit.置可视(false);
		标签14.置可视(false);
		标签10.置可视(false);
		div_password_edit.置可视(false);
		标题栏1.置标题("设置提现开关");
		窗口操作.置窗口标题("设置提现开关");
		div_game_ver.置可视(false);
	}
	div_game_ver.添加项目("请选择游戏端版本......","");
	div_game_ver.添加项目("3.2版本的游戏端","3.2");
	div_game_ver.添加项目("3.4版本的游戏端","3.4");
}
function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(m_password == "" ){
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}
	}
}


function div_daily_time_btn_被单击(){
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var s= 转换操作.到文本(时);
	if(时 < 10 ){
		s = "0" + s;
	}
	var f= 转换操作.到文本(分);
	if(分 < 10 ){
		f = "0" + f;
	}
	div_daily_time_lable.置标题(s+":"+f+":00");
}
function 按钮_设置_被单击(){









	var agent_re_scale_1= 0;









	var agent_re_scale_2= 0;









	var agent_re_scale_3= 0;




	div_invest_scale_edit.置内容(文本操作.删首尾空(div_invest_scale_edit.取内容()));
	if(div_invest_scale_edit.取内容() == "" && m_password == "" ){
		仔仔弹出对话框1.错误("请设置：充值兑换比例");
		return;
	}
	var invest_scale= 转换操作.到数值(div_invest_scale_edit.取内容());
	if(invest_scale < 1 && m_password == "" ){
		仔仔弹出对话框1.错误("充值兑换比例设置有误！");
		return;
	}
	div_rebate_min_edit.置内容(文本操作.删首尾空(div_rebate_min_edit.取内容()));
	if(div_rebate_min_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请设置：最低提现金额");
		return;
	}
	var rebate_min= 转换操作.到数值(div_rebate_min_edit.取内容());
	if(rebate_min < 0 ){
		仔仔弹出对话框1.错误("最低提现金额有误！");
		return;
	}




	var rebate= 0;
	if(div_rebate_check.取选中状态() == true ){
		rebate = 1;
	}
	var play_invest= 0;
	if(div_play_invest_check.取选中状态() == true ){
		play_invest = 1;
	}
	div_commission_edit.置内容(文本操作.删首尾空(div_commission_edit.取内容()));
	if(div_commission_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请设置：提现手续费费率");
		return;
	}
	var commission= 转换操作.到数值(div_commission_edit.取内容());
	if(commission < 0 || commission > 1 ){
		仔仔弹出对话框1.错误("提现手续费费率设置有误！");
		return;
	}
	div_commission_min_edit.置内容(文本操作.删首尾空(div_commission_min_edit.取内容()));
	if(div_commission_min_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请设置：最低收取的提现手续费金额");
		return;
	}
	var commission_min= 转换操作.到数值(div_commission_min_edit.取内容());
	if(commission_min < 0 ){
		仔仔弹出对话框1.错误("最低收取的提现手续费金额有误！");
		return;
	}
	div_password_edit.置内容(文本操作.删首尾空(div_password_edit.取内容()));
	if(div_password_edit.取内容() == "" && m_password == "" ){
		仔仔弹出对话框1.错误("请输入校验密码！");
		return;
	}
	if(m_game_ver == "" && m_password == "" ){
		仔仔弹出对话框1.错误("请选择游戏端版本！");
		return;
	}
	var md5=加密操作1.取md5值(div_password_edit.取内容());
	var json= {}

	json.daily_time = "00:00:00";
	json.agent_re_scale_1 = agent_re_scale_1;
	json.agent_re_scale_2 = agent_re_scale_2;
	json.agent_re_scale_3 = agent_re_scale_3;
	json.invest_scale = invest_scale;
	json.rebate_min = rebate_min;

	json.rebate = rebate;
	json.play_invest = play_invest;
	json.commission = commission;
	json.commission_min = commission_min;
	json.password = "" + md5;
	json.game_ver = 转换操作.到数值(m_game_ver);
	m_post = 公用模块.生成提交数据(0, "", "", "" , 0, 0, json, "", "");
	if(m_password == "" ){
		m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init", "");
	}else{
		m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init-true", m_password);
	}
	美化等待框1.默认等待框("正在交互","正在初始化,请稍等......");
	时钟1.开始执行(200,false);
}


function div_game_ver_表项被单击(项目索引,项目标题,项目标记){
	m_game_ver = 项目标记;
}