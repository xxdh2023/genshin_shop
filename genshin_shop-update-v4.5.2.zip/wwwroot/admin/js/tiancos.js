function TCOS(name,getwebcode,getwebcode2,getwebcode3,getwebcode4,getwebcode5,getmysql,getflie,getflie_x,getflie_d,getflie_s,getflie_c,getzip){
	//初始化参数
	this.名称 = name;

	this.组件_置宽度 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
			div.style.width = value;
		}else{
			document.getElementById(app).style.width = value;
		}
	}

	this.组件_置高度 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
			div.style.height = value;
		}else{
			document.getElementById(app).style.height = value;
		}
	}

	this.组件_取宽度 = function (app,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
			return div.style.width;
		}else{
			return document.getElementById(app).style.width;
		}
	}

	this.组件_取高度 = function (app,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
			return div.style.height;
		}else{
			return document.getElementById(app).style.height;
		}
	}

	this.组件_置背景图 = function (app,value){
		document.getElementById(app).style.backgroundImage = 'url('+value+')';
	}

	this.组件_置背景图大小 = function (app,value){
		document.getElementById(app).style.backgroundSize = value;
	}

	this.组件_置背景透明度 = function (app,value){
		document.getElementById(app).style.opacity = value;
	}

	this.组件_置文字位置 = function (app,value){
		if(value==0){
			document.getElementById(app).style.textAlign = "left";
		}else if(value==1){
			document.getElementById(app).style.textAlign = "center";
		}else if(value==2){
			document.getElementById(app).style.textAlign = "right";
		}
	}

	this.组件_置圆角度 = function (app,value){
		document.getElementById(app).style.borderRadius = value;
	}

	this.组件_自定义边框 = function (app,value,value1){
		document.getElementById(app).style.borderColor = value;
		document.getElementById(app).style.borderWidth = value1;
	}

	this.组件_自定义颜色 = function (app,value,value1){
		document.getElementById(app).style.background = value;
		document.getElementById(app).style.color = value1;
	}

	this.组件_置字体大小 = function (app,value){
		document.getElementById(app).style.fontSize = value;
	}
	
	this.组件_取字体大小 = function (app){
		return document.getElementById(app).style.fontSize;
	}

	this.组件_取背景颜色 = function (app){
		return document.getElementById(app).style.background;
	}

	this.组件_取字体颜色 = function (app){
		return document.getElementById(app).style.color;
	}

	this.组件_置位置属性 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				div.style.position = value;
		}else{
			document.getElementById(app).style.position = value;
		}
	}

	this.组件_置提示内容 = function (app,value){
		var inp = $('#' + app);
    		inp.focus(function(){
      			$(this).attr('placeholder',value)
    		})
	}

	this.组件_置距离顶部 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				div.style.top = value;
		}else{
			document.getElementById(app).style.top = value;
		}
	}

	this.组件_置距离顶部2 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				div.style.marginTop = value;
		}else{
			document.getElementById(app).style.marginTop = value;
		}
	}

	this.组件_置横排 = function (app,mold){
		if(mold == true){
			document.getElementById(app).style.cssFloat ="left";
		}else{
			document.getElementById(app).style.cssFloat ="none";
			document.getElementById(app).style.width="100%";
			document.getElementById(app).style.marginTop="none";
		}
	}

	this.组件_取距离顶部 = function (app,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				return div.style.top;
		}else{
			return document.getElementById(app).style.top;
		}
	}

	this.组件_取距离顶部2 = function (app,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				return div.style.marginTop;
		}else{
			return document.getElementById(app).style.marginTop;
		}
	}

	this.组件_置距离左边 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				div.style.marginLeft = value;
		}else{
			document.getElementById(app).style.marginLeft = value;
		}
	}

	this.组件_取距离左边 = function (app,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				return div.style.marginLeft;
		}else{
			return document.getElementById(app).style.marginLeft;
		}
	}

	this.组件_置优先级 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				div.style.zIndex = value;
		}else{
			document.getElementById(app).style.zIndex = value;
		}
	}
	
	
	this.组件_取优先级 = function (app,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				return div.style.zIndex;
		}else{
			return document.getElementById(app).style.zIndex;
		}
	}
	
	this.组件_置停靠位置 = function (app,mold){
		if(mold == 0){
			document.getElementById(app).style.cssFloat = "left";
		}else if(mold == 1){
			document.getElementById(app).style.cssFloat = "none";
		}else if(mold == 2){
			document.getElementById(app).style.cssFloat = "right";
		}
	}
	
	this.组件_置阴影效果 = function (app,value1,value2,value3,value4,value5,value6,value7,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				div.style.boxShadow=value1+"px "+ value2 +"px " + value3+"px rgba(" +value4+", "+value5+", " + value6+", "+value7+ ")";
		}else{
			document.getElementById(app).style.boxShadow=value1+"px "+ value2 +"px " + value3+"px rgba(" +value4+", "+value5+", " + value6+", "+value7+ ")"; 
		}
	}
	
	this.组件_置倾斜效果 = function (app,value,mold){
		if(mold == true){
			var div = document.getElementById(app).parentNode;
				div.style.transform="rotate("+value+"deg)"; 
		}else{
			document.getElementById(app).style.transform="rotate("+value+"deg)"; 
		}
	}
	
	this.组件_ICON图标 = function (value){
		return '<span class="mui-icon mui-icon-'+value+'"></span>';
	}
	
	this.组件_字体图标 = function (value){
		return '<span class="mui-icon-extra mui-icon-extra-'+value+'"></span>';
	}
	
	this.组件_获取焦点 = function (app){
		document.getElementById(app).focus();
    }
	
	
	this.组件_文本反向 = function (app){
		document.getElementById(app).setAttribute("dir","rtl");
	}
	
	
	this.组件_置是否可用 = function (app,mold){
		if(mold == false){
			document.getElementById(app).disabled = true;
		}else{
			document.getElementById(app).disabled = false;
		}
    }
	
	
	this.组件_取是否可用 = function (app){
		var mold = document.getElementById(app).disabled;
		if(mold == false){
			return true;
		}else{
			return false;
		}
    }
	
	
	this.文本_只取数字 = function (value){
		return value.replace(/[^0-9]/ig,""); 
	}

	this.文本_只取汉字 = function (value){
		return value.replace(/[^\u4e00-\u9fa5]/gi,"");
	}

	this.文本_只取字母 = function (value){
		return value.replace(/[^\A-Za-z]/gi,""); 
	}

	this.文本_是否有空格 = function (value){
		if(value == ""){
			return false;
		}
		var badChar =" ";
		badChar += "　";
		for(var i=0;i<value.length;i++){
			var c = value.charAt(i);
			if(badChar.indexOf(c) > -1){
				return true;
			}
		}
		return false;
	}
	
	this.文本_取指定文本 = function (value,value1,value2){
		var pattern = new RegExp(value1 + "(.*?)" + value2,"g");
        var result = new Array(0);
        while (pattern.exec(value) != null){
                result.push(RegExp.$1);
        }
        return result[0];
	}
	
	this.文本_保留位数 = function (value,value1,mold){
		if(mold == true){
			return Math.round(Number(value)*100)/100;
		}else{
			return Math.floor(Number(value)*100)/100;
		}
	}
	
	this.文本_取汉字简拼 = function (value){
		return pinyin.getCamelChars(value);
	}
	
	this.文本_取汉字全拼 = function (value){
		return pinyin.getFullChars(value); 
	}
	
	this.文本_清除中文 = function (value){
		return value.replace(/[\u4E00-\u9FA5]/g,'');
    }
		
	this.文本_清除空格 = function (value){
		return value.replace(/[ ]/g,"");
    }
		
	this.文本_清除数字 = function (value){
		return value.replace(/\d+/g,'');
    }
		
	this.文本_清除特殊符号 = function (value){ 
		return value.replace(/[\（\）\~\!\_\+\-\=\[\]\|\\\/\,\.\·\！\￥\…\……\(\)\@\#\$\%\^\&\*\{\}\:\"\L\<\>\?]/g, '');
    }
		
	this.文本_清除英文字母 = function (value){
		return value.replace(/[a-zA-Z]/g,"");
    }
		
	this.文本_自定义正则 = function (value,value1){
		return value.replace(value1,"");
    }
	
	this.文本_取随机字符串 = function (min, type, max, mold){
    	var value = "",range = min,typ = null;
		var shuzi = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
		var zhimu = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
		var shumu = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9','a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    	
		if(type==''){
			typ = shumu;
		}else if(type==0){
			typ = shumu;
		}else if(type==1){
			typ = shuzi;
		}else if(type==2){
			typ = zhimu;
		}
		
		if(mold){
     		range = Math.round(Math.random() * (max-min)) + min;
   		}
   		for(var i=0; i<range; i++){
   			pos = Math.round(Math.random() * (typ.length-1));
        	value += typ[pos];
 		}
		
    	return value;
	}
	
	
	this.文本_取随机姓名 = function (){
        var familyNames = new Array(
                "赵",    "钱",    "孙",    "李",    "周",    "吴",    "郑",    "王",    "冯",    "陈",    
                "褚",    "卫",    "蒋",    "沈",    "韩",    "杨",    "朱",    "秦",    "尤",    "许",
                "何",    "吕",    "施",    "张",    "孔",    "曹",    "严",    "华",    "金",    "魏",    
                "陶",    "姜",    "戚",    "谢",    "邹",    "喻",    "柏",    "水",    "窦",    "章",
                "云",    "苏",    "潘",    "葛",    "奚",    "范",    "彭",    "郎",    "鲁",    "韦",    
                "昌",    "马",    "苗",    "凤",    "花",    "方",    "俞",    "任",    "袁",    "柳",
                "酆",    "鲍",    "史",    "唐",    "费",    "廉",    "岑",    "薛",    "雷",    "贺",    
                "倪",    "汤",    "滕",    "殷",    "罗",    "毕",    "郝",    "邬",    "安",    "常",
                "乐",    "于",    "时",    "傅",    "皮",    "卞",    "齐",    "康",    "伍",    "余",    
                "元",    "卜",    "顾",    "孟",    "平",    "黄",    "和",    "穆",    "萧",    "尹"
            );
        var givenNames =  new Array(
                "子璇", "淼", "国栋", "夫子", "瑞堂", "甜", "敏", "尚", "国贤", "贺祥", "晨涛", 
                "昊轩", "易轩", "益辰", "益帆", "益冉", "瑾春", "瑾昆", "春齐", "杨", "文昊", 
                "东东", "雄霖", "浩晨", "熙涵", "溶溶", "冰枫", "欣欣", "宜豪", "欣慧", "建政", 
                "美欣", "淑慧", "文轩", "文杰", "欣源", "忠林", "榕润", "欣汝", "慧嘉", "新建", 
                "建林", "亦菲", "林", "冰洁", "佳欣", "涵涵", "禹辰", "淳美", "泽惠", "伟洋", 
                "涵越", "润丽", "翔", "淑华", "晶莹", "凌晶", "苒溪", "雨涵", "嘉怡", "佳毅", 
                "子辰", "佳琪", "紫轩", "瑞辰", "昕蕊", "萌", "明远", "欣宜", "泽远", "欣怡", 
                "佳怡", "佳惠", "晨茜", "晨璐", "运昊", "汝鑫", "淑君", "晶滢", "润莎", "榕汕", 
                "佳钰", "佳玉", "晓庆", "一鸣", "语晨", "添池", "添昊", "雨泽", "雅晗", "雅涵", 
                "清妍", "诗悦", "嘉乐", "晨涵", "天赫", "玥傲", "佳昊", "天昊", "萌萌", "若萌", 
				"坤", "昆", "莹", "晴", "强", "方", "河","斌","彬","滨","蔷","羌"
            );
        
        var i = parseInt(10 * Math.random())*10 + parseInt(10 * Math.random());
        var j = parseInt(10 * Math.random())*10 + parseInt(10 * Math.random());
		
        return familyNames[i] + givenNames[j];
    }
	
	this.文本_取随机手机号 = function (){
		var tel = ["130", "131", "132", "133", "135", "137", "138", "170", "187", "189","177","178","188","185"];
        var i = parseInt(10 * Math.random());
		var prefix = tel[i];
		
        for (var j = 0; j < 8; j++) {
            prefix = prefix + Math.floor(Math.random() * 10);
        }
		
		return prefix;
	}
	
	this.文本_取随机身份证号 = function (value,value1){
        var coefficientArray = [ "7","9","10","5","8","4","2","1","6","3","7","9","10","5","8","4","2"];
        var lastNumberArray = [ "1","0","X","9","8","7","6","5","4","3","2"];
        var address = value;
        var birthday = value1;
        var s = Math.floor(Math.random()*10).toString() + Math.floor(Math.random()*10).toString() + Math.floor(Math.random()*10).toString();
        var array = (address + birthday + s).split("");   
        var total = 0;
        for(i in array){
            total = total + parseInt(array[i])*parseInt(coefficientArray[i]);
       	}       
        var lastNumber = lastNumberArray[parseInt(total%11)];
        var id_no_String = address + birthday + s + lastNumber;
		
		return id_no_String;
	}
	
	
	this.文本_数字千位符 = function (value){
		var value = (value || 0).toString(), result = '';
    	while (value.length > 3) {
    		result = ',' + value.slice(-3) + result;
			value = value.slice(0, value.length - 3);
		}
		if (value) { result = value + result; }
		return result;
   }
   
   this.文本_取字符数 = function (value){
		var len = 0;
    	for (var i = 0; i < val.length; i++) {
        	var a = value.charAt(i);
        	if (a.match(/[^\x00-\xff]/ig) != null) {
            	len += 2;
        	}
        	else {
            	len += 1;
        	}
    	}
    	return len;
	}
	
	this.文本_单引号 = function (){
			return "'";
    }
	
	this.文本_到大写 = function (value){
		return value.toUpperCase();
    }
	
	this.文本_到小写 = function (value){
		return value.toLowerCase();
    }
	
	this.文本_首字母大写 = function (value){
		return value.substring(0,1).toUpperCase() + value.substring(1);
    }
	
	this.文本_首字母小写 = function (value){
		return value.substring(0,1).toLowerCase() + value.substring(1);
    }
	
	this.文本_倒排文本 = function (value){
		var tmp = "";
    	for(var i = value.length - 1;i>=0;i--){
        	tmp += value.charAt(i);
    	}
    	return tmp;
    }
	
	this.文本_取出现几次 = function (value,value1,mold){
		var value2 = null;
		if(mold){
			value2 = eval("/"+value1+"/g");
		}else{
			value2 = eval("/"+value1+"/ig");
		}
		return value.match(value2).length;
    }
	
	this.文本_取字数 = function (value,mold){
		if(mold){
			return value.replace(/[\u0391-\uFFE5]/g,"aa").length;
		}else{
			return value.replace(/[\u0391-\uFFE5]/g,"a").length;
		}
    }
	
	this.文本_去除html标签  = function (value){
		if(value){
			return value.replace(/<[^<>]+?>/g,'');
		}else{
			return value;
		}
    }
	
	this.文本_普通字符转转义符  = function (value){
		if(value){
			return value.replace(/[<>&"]/g,function(c){return {'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c];});
		}else{
			return value;
		}
    }
	
	this.文本_转义符转普通字符  = function (value){
		if(value){
			var arrEntities={'lt':'<','gt':'>','nbsp':' ','amp':'&','quot':'"'};
			return value.replace(/&(lt|gt|nbsp|amp|quot);/ig,function(all,t){return arrEntities[t];});
		}else{
			return value;
		}
    }
	
	this.文本_nbsp转空格  = function (value){
		if(value){
			var arrEntities = {'nbsp' : ' '};
			return value.replace(/&(nbsp);/ig, function(all, t){return arrEntities[t]});
		}else{
			return value;
		}
    }
	
	this.文本_回车符转br标签  = function (value){
		if(value){
			return value.replace(/\r?\n/g,"<br />");
		}else{
			return value;
		}
    }
	
	this.文本_去除开头结尾换行  = function (value){
		if(value){
			str	=	value.replace(/((\s|&nbsp;)*\r?\n){3,}/g,"\r\n\r\n");
 			str	=	str.replace(/^((\s|&nbsp;)*\r?\n)+/g,'');
 			str	=	str.replace(/((\s|&nbsp;)*\r?\n)+$/g,'');
 			return str;
		}else{
			return value;
		}
    }
	
	this.文本_连续空格合并为一个空格  = function (value){
		if(value){
			return value.replace(/(\s|&nbsp;)+/g,' ');
		}else{
			return value;
		}
    }
	
	this.文本_按首字母排序 = function (value){
		value = value.split(",");
		value.sort(function(a,b){
			return a.localeCompare(b);
		})
		return value;
	}
	
	this.网络_取网页源码 = function (value,value1,value2,value3){
		mui.ajax(value, {
			crossDomain: true,
			type: 'get',                        
			headers: value3,
			dataType: value1,
			data: '',
			timeout: value2,
			success: function(response) {
				webcode(true,response,value1);
			},
			error: function(xhr,type,errorThrown) {
				webcode(false,type,value1);
			}
		});    
	}
	var webcode = function(mold,value1,value2) {
		if(getwebcode==null){
			return;
		} 
		if(mold==true){
			if (value2 === "json") {
				value1 = JSON.stringify(value1);
				} else if (value2 === "xml") {
				value1 = new XMLSerializer().serializeToString(value1);
			} 
		}
		getwebcode(mold,value1);
	};
	
	this.网络_取网页源码2 = function (value,value1,value2,value3){
		mui.ajax(value, {
			crossDomain: true,
			type: 'get',                        
			headers: value3,
			dataType: value1,
			data: '',
			timeout: value2,
			success: function(response) {
				webcode2(true,response,value1);
			},
			error: function(xhr,type,errorThrown) {
				webcode2(false,type,value1);
			}
		});    
	}
	var webcode2 = function(mold,value1,value2) {
		if(getwebcode2==null){
			return;
		} 
		if(mold==true){
			if (value2 === "json") {
				value1 = JSON.stringify(value1);
				} else if (value2 === "xml") {
				value1 = new XMLSerializer().serializeToString(value1);
			} 
		}
		getwebcode2(mold,value1);
	};
	
	
	this.网络_取网页源码3 = function (value,value1,value2,value3){
		mui.ajax(value, {
			crossDomain: true,
			type: 'get',                        
			headers: value3,
			dataType: value1,
			data: '',
			timeout: value2,
			success: function(response) {
				webcode3(true,response,value1);
			},
			error: function(xhr,type,errorThrown) {
				webcode3(false,type,value1);
			}
		});    
	}
	var webcode3 = function(mold,value1,value2) {
		if(getwebcode3==null){
			return;
		} 
		if(mold==true){
			if (value2 === "json") {
				value1 = JSON.stringify(value1);
				} else if (value2 === "xml") {
				value1 = new XMLSerializer().serializeToString(value1);
			} 
		}
		getwebcode3(mold,value1);
	};
	
	this.网络_取网页源码4 = function (value,value1,value2,value3){
		mui.ajax(value, {
			crossDomain: true,
			type: 'get',                        
			headers: value3,
			dataType: value1,
			data: '',
			timeout: value2,
			success: function(response) {
				webcode4(true,response,value1);
			},
			error: function(xhr,type,errorThrown) {
				webcode4(false,type,value1);
			}
		});    
	}
	var webcode4 = function(mold,value1,value2) {
		if(getwebcode4==null){
			return;
		} 
		if(mold==true){
			if (value2 === "json") {
				value1 = JSON.stringify(value1);
				} else if (value2 === "xml") {
				value1 = new XMLSerializer().serializeToString(value1);
			} 
		}
		getwebcode4(mold,value1);
	};
	
	this.网络_取网页源码5 = function (value,value1,value2,value3){
		mui.ajax(value, {
			crossDomain: true,
			type: 'get',                        
			headers: value3,
			dataType: value1,
			data: '',
			timeout: value2,
			success: function(response) {
				webcode5(true,response,value1);
			},
			error: function(xhr,type,errorThrown) {
				webcode5(false,type,value1);
			}
		});    
	}
	var webcode5 = function(mold,value1,value2) {
		if(getwebcode5==null){
			return;
		} 
		if(mold==true){
			if (value2 === "json") {
				value1 = JSON.stringify(value1);
				} else if (value2 === "xml") {
				value1 = new XMLSerializer().serializeToString(value1);
			} 
		}
		getwebcode5(mold,value1);
	};
	
	this.界面_角标CSS = function (app,mold,value,value1,value2,value3,value4,value5,value6,value7,value8,value9,value10,value11){
		//初始化默认参数
		var family = '"'+value10+'";';
		var righttop = "position: absolute;width:"+value3+";border-left: "+value3+" solid rgba(255,255,255,0.0);border-top: "+value3+" solid " + value1 + ";top: "+value8+"px;right: "+value9+"px;";
		var righttopfsze = "position: absolute;top: "+value6+"px;right: "+value7+"px;transform: rotate("+value4+"deg);color: " + value2 + ";font-size: "+value5+"px;font-family: "+family;
		
		var lefttop = "position: absolute;width:"+value3+";border-right: "+value3+" solid rgba(255,255,255,0.0);border-top: "+value3+" solid " + value1 + ";top: "+value8+"px;left: "+value9+"px;";
		var lefttopfsze = "position: absolute;top: "+value6+"px;left: "+value7+"px;transform: rotate("+value4+"deg);color: " + value2 + ";font-size: "+value5+"px;font-family: "+family;//-44
		
		var leftbottom = "position: absolute;width:"+value3+";border-right: "+value3+" solid rgba(255,255,255,0.0);border-bottom: "+value3+" solid " + value1 + ";bottom: "+value8+"px;left: "+value9+"px;";
		var leftbottomtopfsze = "position: absolute;bottom: "+value6+"px;left: "+value7+"px;transform: rotate("+value4+"deg);color: " + value2 + ";font-size: "+value5+"px;font-family: "+family;//224
		
		var rightbottom = "position: absolute;width:"+value3+";border-left: "+value3+" solid rgba(255,255,255,0.0);border-bottom: "+value3+" solid " + value1 + ";bottom: "+value8+"px;right: "+value9+"px;";
		var rightbottomtopfsze = "position: absolute;bottom: "+value6+"px;right: "+value7+"px;transform: rotate("+value4+"deg);color: " + value2 + ";font-size: "+value5+"px;font-family: "+family;
		
		var css = righttop;
		var css1 = righttopfsze;
		
		if(mold == 0){
			css = lefttop;
			css1 = lefttopfsze;
		}
		
		if(mold == 1){
			css = righttop;
			css1 = righttopfsze;
		}
		
		if(mold == 2){
			css = leftbottom;
			css1 = leftbottomtopfsze;
		}
		
		if(mold == 3){
			css = rightbottom;
			css1 = rightbottomtopfsze;
		}
		
		var html = "<div style='" + css + "'></div><div style='" + css1 + "'>" + value + "</div>";
		
		if(value11 == true){
			var inne = document.getElementById(app).parentNode.innerHTML;
			document.getElementById(app).parentNode.innerHTML = inne + html;
		}else{
			var inne = document.getElementById(app).innerHTML;
			document.getElementById(app).innerHTML = inne + html;
		}
	}
	
	this.时间_比较日期大小 = function (value, value1){
		if (value >= value1) { 
			value1.focus(); 
			return false; 
			} else{
			return true;
		} 
	}
	
	this.时间_时间戳转时间 = function (value){
		return new Date(parseInt(value) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
	}
	
	this.时间_取当前时间戳 = function (){
		return new Date().getTime();
	}
	
	this.时间_取现行时间 = function (){
		var date = new Date();
		var seperator1 = "-";
		var seperator2 = ":";
		var month = date.getMonth() + 1;
		var strDate = date.getDate();
		var getHours = date.getHours();
		var getMinutes = date.getMinutes();
		var getSeconds = date.getSeconds();
		if (month >= 1 && month <= 9) {
			month = "0" + month;
		}
		if (strDate >= 0 && strDate <= 9) {
			strDate = "0" + strDate;
		}
		if (getHours >= 0 && getHours <= 9) {
			getHours = "0" + getHours;
		}
		if (getMinutes >= 0 && getMinutes <= 9) {
			getMinutes = "0" + getMinutes;
		}
		if (getSeconds >= 0 && getSeconds <= 9) {
			getSeconds = "0" + getSeconds;
		}
		return date.getFullYear() + seperator1 + month + seperator1 + strDate + " " + getHours + seperator2 + getMinutes + seperator2 + getSeconds;
	}
	
	this.时间_取年份 = function (){
		return new Date().getFullYear();
	}
	
	this.时间_取月份 = function (){
		return new Date().getMonth() + 1;
	}
	
	this.时间_取日 = function (){
		return new Date().getDate();
	}
	
	this.时间_取小时 = function (){
		return new Date().getHours();
	}
	
	this.时间_取分钟 = function (){
		return new Date().getMinutes();
	}
	
	this.时间_取秒 = function (){
		return new Date().getSeconds();
	}
	
	this.时间_取毫秒 = function (){
		return new Date().getMilliseconds();
	}
	
	this.MySQL_查询数据 = function (urld,biao,zid,datas,fanhui){
		mui.ajax(urld, {
			crossDomain:true,
			type: 'post',
			dataType: fanhui,
			data: "lei=1&biao=" + biao + "&zid=" + zid + "&name=" + datas,
			timeout: 10000,
			success: function(response) {
				complete(true,response,fanhui);
			},
			error: function(xhr,type,errorThrown) {
				complete(false,type,fanhui);
			}
		});
	}
	
	this.MySQL_增加记录 = function (urld,biao,zid,datas,fanhui){
		mui.ajax(urld, {
			crossDomain:true,
			type: 'post',
			dataType: fanhui,
			data: "lei=3&biao=" + biao + "&zid=" + zid + "&name=" + datas,
			timeout: 10000,
			success: function(response) {
				complete(true,response,fanhui);
			},
			error: function(xhr,type,errorThrown) {
				complete(false,type,fanhui);
			}
		});
	}
	
	this.MySQL_修改数据 = function (urld,biao,zid,datas,uid,uname,fanhui){
		mui.ajax(urld, {
			crossDomain:true,
			type: 'post',
			dataType: fanhui,
			data: "lei=2&biao=" + biao + "&zid=" + zid + "&name=" + datas+"&uid=" + uid+"&uname=" + uname,
			timeout: 10000,
			success: function(response) {
				complete(true,response,fanhui);
			},
			error: function(xhr,type,errorThrown) {
				complete(false,type,fanhui);
			}
		});
	}
	
	this.MySQL_删除记录 = function (urld,biao,zid,datas,fanhui){
		mui.ajax(urld, {
			crossDomain:true,
			type: 'post',
			dataType: fanhui,
			data: "lei=4&biao=" + biao + "&zid=" + zid + "&name=" + datas,
			timeout: 10000,
			success: function(response) {
				complete(true,response,fanhui);
			},
			error: function(xhr,type,errorThrown) {
				complete(false,type,fanhui);
			}
		}); 
	}
	 
	this.MySQL_自定义 = function (urld,datas,fanhui){
		mui.ajax(urld, {
			crossDomain:true,
			type: 'post',
			dataType: fanhui,
			data: "lei=5&biao=" + datas,
			timeout: 10000,
			success: function(response) {
				complete(true,response,fanhui);
			},
			error: function(xhr,type,errorThrown) {
				complete(false,type,fanhui);
			}
		});
	}
	
	var complete = function(result,response,fanhui) {
		if(getmysql==null){
			return;
		} 
		if(result==true){
			if (fanhui === "json") {
				response = JSON.stringify(response);
				} else if (fanhui === "xml") {
				response = new XMLSerializer().serializeToString(response);
			}
		}
		getmysql(result,response); 
	};
	
	this.推送_创建本地消息 = function (msg,LocalMSG,title1){
		var myDate = new Date();
		var options = {
			cover:false,
			title:title1,
			when:myDate.toLocaleTimeString()
		};
		plus.push.createMessage( msg, LocalMSG, options );
	} 
	
	this.推送_消息监听 = function (){
		document.addEventListener( "plusready", function(){
			plus.push.addEventListener( "click", function ( msg ) {
				alert( "You clicked: " + msg.content ); 
			}, false ); 
		}, false );
	}
	
	this.推送_清空所有 = function (){
		plus.push.clear();
	}
	
	
	this.文件_创建文件 = function (sdurl,sdname){
		function plusReady(){}
		if(window.plus){
			plusReady();	
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
		plus.io.resolveLocalFileSystemURL(sdurl, function( entry ) {
			entry.getFile(sdname,{create: true},function(writer){
				eventflie(true,sdurl+sdname);
			}, function ( e ) {
				eventflie(false,e.message);
			});
		});
    }
	var eventflie = function(result,response) {
        getflie(result,response);
    };
	
	this.文件_写到文件 = function (sdurl,sdname){
		function plusReady(){}
		if(window.plus){
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
		plus.io.resolveLocalFileSystemURL(sdurl, function( entry ) {
			entry.createWriter( function ( writer ) {
				writer.seek( writer.length );
				writer.write(sdname);
				eventflie_x(true,sdurl);
			}, function ( e ) {
				eventflie_x(false,e.message);
			});
		});
    }
	var eventflie_x = function(result,response) {
        getflie_x(result,response);
    };

	this.文件_读取文件 = function (sdurl){
		function plusReady(){}
		if(window.plus){
			plusReady();	
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
		plus.io.resolveLocalFileSystemURL(sdurl, function( entry ) {
			entry.file( function(file){
				var fileReader = new plus.io.FileReader();
				fileReader.readAsText(file, 'utf-8');
				fileReader.onloadend = function(evt) {
					eventflie_d(true,evt.target.result,JSON.stringify(file));
				}
				//alert(file.size + '--' + file.name);
			} );
		}, function ( e ) {
			eventflie_d(false,e.message);
		});
    }
	var eventflie_d = function(result,response,file) {
        getflie_d(result,response,file);
    };
	
	this.文件_删除文件 = function (sdurl){
		function plusReady(){}
		if(window.plus){
			plusReady();	
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
		plus.io.resolveLocalFileSystemURL(sdurl, function( entry ) {
			entry.remove(function(entry){
				eventflie_s(true,sdurl);
			}, function ( e ) {
				eventflie_s(false,e.message);
			});
		});
    }
	var eventflie_s = function(result,response) {
        getflie_s(result,response);
    };
	
	this.文件_文件是否存在 = function (sdurl){
		function plusReady(){}
		if(window.plus){
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
		plus.io.resolveLocalFileSystemURL(sdurl, function( entry ) {
			eventflie_c(true);
		}, function ( e ) {
			eventflie_c(false);
		});
    }
	var eventflie_c = function(result) {
        getflie_c(result);
    };
	
	this.文件_保存图片或视频 = function (wenj){
		document.addEventListener( "plusready", onPlusReady, false );
		function onPlusReady() {}
		var r = null;
		plus.gallery.save( wenj, function () {
			alert( "保存文件到相册成功" );
		}, function () {
			alert( "保存文件失败" );
		});
    }
	
	this.文件_zip压缩 = function (wenj,lujin){
		var targetPath = wenj;
		var zipfile = lujin;
		plus.zip.compress(targetPath,zipfile,
		function() {
			eventzip(true);
		},function(error) {
			eventzip(false);
		});
	}
	
	this.文件_zip解压 = function (wenj,lujin){
      	var zipfile = wenj;
		var targetPath = lujin;
		plus.zip.decompress(zipfile, targetPath,
		function() {
			eventzip(true);
		},function(error) {
			eventzip(false);
		});
    }
	var eventzip = function(result) {
        getzip(result);
    };
	
	this.数组_随机排列 = function (value){
		if(value!=null){
	       value.sort(function(){ return 0.5 - Math.random() });
        }
	}
	
	this.数组_清空数组 = function (value){
		if(value!=null){
	       value.length = 0;
        }
	}
	
	this.数组_数组去重 = function (value){
		var result = [], hash = {};
		for (var i = 0, elem; (elem = value[i]) != null; i++) {
			if (!hash[elem]) {
				result.push(elem);
				hash[elem] = true;
			}
		}
		return result;
    }
	
	this.数组_截断数组 = function (value,sizea){
		if(value!=null){
	       value.length = sizea;
        }
		return value;
	}
	
	this.数组_获取大小值 = function (value,sizea){
		if(value!=null){
	      	if(sizea==1){
            	var value = Math.max.apply(Math,value); 
       		}else{
            	var value = Math.min.apply(Math,value);
        	}
        }
		return value;
	}
	
	this.命令_自定义CSS = function (pheight){
		var css = document.createElement('style');
			css.type = 'text/css';
			css.innerHTML = pheight;
		document.getElementsByTagName('HEAD').item(0).appendChild(css);
    }
	
	this.命令_取当前系统 = function (){
		return navigator.platform.toLowerCase();
	}
	
	this.命令_延迟执行 = function (value,time){
		setTimeout(value,time);
	}
	
	this.命令_四舍五入 = function (value){
		return Math.round(value); 
	}
	
	this.命令_信息框 = function (value){
		alert(value);
	}
	
	this.命令_设置状态栏背景颜色 = function (value){
		function plusReady(){
			plus.navigator.setStatusBarBackground(value);
		}
		if(window.plus){
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_获取状态栏背景颜色 = function (){
		function plusReady(){
			var rgb = plus.navigator.getStatusBarBackground();
			return rgb;
		}
		if(window.plus){
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_获取IMEI = function (){
		function plusReady(){}
		if(window.plus){
			return plus.device.imei;
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_获取IMSI = function (){
		function plusReady(){}
		if(window.plus){
			return plus.device.imsi;
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_获取设备型号 = function (){
		function plusReady(){}
		if(window.plus){
			return plus.device.model;
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_获取生产厂商 = function (){
		function plusReady(){}
		if(window.plus){
			return plus.device.vendor;
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_获取UUID = function (){
		function plusReady(){}
		if(window.plus){
			return plus.device.uuid;
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_蜂鸣声 = function (times){
		function plusReady(){}
		if(window.plus){
			plus.device.beep(times);
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_设备振动 = function (milliseconds){
		function plusReady(){}
		if(window.plus){
			plus.device.vibrate(milliseconds);
			plusReady();
		}else{
			document.addEventListener("plusready",plusReady,false);
		}
    }
	
	this.命令_刷新当前页面 = function (){
		window.location.reload();
    }
	
	this.命令_返回上页 = function (){
		window.history.go(-1);
    }

	this.命令_置剪切板 = function (value){
		if(mui.os.plus){
			if (plus.os.name == "Android") {
				var Context = plus.android.importClass("android.content.Context");
				var main = plus.android.runtimeMainActivity();
				var clip = main.getSystemService(Context.CLIPBOARD_SERVICE);
				plus.android.invoke(clip,"setText",value);
			}
			if (plus.os.name == "ios") {
				var UIPasteboard  = plus.ios.importClass("UIPasteboard");
				var generalPasteboard = UIPasteboard.generalPasteboard();
				generalPasteboard.plusCallMethod({setValue:value, forPasteboardType:"public.utf8-plain-text"});
			}
		}else{
    		var clipboard = new Clipboard(".mui-content", {
        		text: function() {
            		return value;
        		}
    		});				
		}
    }
	
	this.命令_取剪贴板 = function (){
		if (plus.os.name == "Android") {
			var Context = plus.android.importClass("android.content.Context");
			var main = plus.android.runtimeMainActivity();
			var clip = main.getSystemService(Context.CLIPBOARD_SERVICE);
			return plus.android.invoke(clip,"getText");
		}
		if (plus.os.name == "ios") {
			var UIPasteboard  = plus.ios.importClass("UIPasteboard");
			var generalPasteboard = UIPasteboard.generalPasteboard();
			var clip = generalPasteboard.plusCallMethod({valueForPasteboardType:"public.utf8-plain-text"});
			return clip;
		}
		if(!mui.os.plus){
			console.log("取剪贴板内容命令只能在手机APP中使用");
			return "";
		}
    }
	
	this.命令_获取MAC地址 = function (){
		var mac = "xxx-xxx-xxx-xxx";
		if (plus.os.name == "Android") {
			var Context = plus.android.importClass("android.content.Context");
			var WifiManager = plus.android.importClass("android.net.wifi.WifiManager");
			var wifiManager = plus.android.runtimeMainActivity().getSystemService(Context.WIFI_SERVICE);
			var WifiInfo = plus.android.importClass("android.net.wifi.WifiInfo");
			var wifiInfo = wifiManager.getConnectionInfo();
			mac = wifiInfo.getMacAddress();
		}
		return mac;
    }
	
	this.命令_获取内存信息 = function (){
		var memoryInfo = '';
		if (plus.os.name == "Android") {
			var Context = plus.android.importClass("android.content.Context");
			var ActivityManager = plus.android.importClass("android.app.ActivityManager");
			var mi = new ActivityManager.MemoryInfo();
			var activityService = plus.android.runtimeMainActivity().getSystemService(Context.ACTIVITY_SERVICE);
			activityService.getMemoryInfo(mi);
			memoryInfo = mi.plusGetAttribute("availMem");
		}
		return memoryInfo;
    }
	
	this.命令_获取内部总存储大小 = function (){
		var internalMemSize = 0;
		if (plus.os.name == "Android") {
			var environment = plus.android.importClass("android.os.Environment");
			var statFs = plus.android.importClass("android.os.StatFs");
        	var files = plus.android.importClass("java.io.File");
        	var Files = environment.getDataDirectory();
        	var StatFs = new statFs(Files.getPath());
        	var blockSize = parseFloat(StatFs.getBlockSize());
        	var blockCount = parseFloat(StatFs.getBlockCount());
        	internalMemSize = blockSize * blockCount;
		}
		return internalMemSize;
    }
	
	this.命令_比较两个金额大小 = function (value,value1){
		if (parseFloat(value) >= parseFloat(value1)) {
			value1.focus();
			return false; 
			} else{
			return true;
		}
	}
	
	
}

