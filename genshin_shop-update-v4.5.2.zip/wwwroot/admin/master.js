mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 面板1 = new 面板("面板1");
var 标签_会员账号 = new 标签("标签_会员账号",标签_会员账号_被单击);
var 标签_升级提示 = new 标签("标签_升级提示",标签_升级提示_被单击);
var 左侧分类导航1 = new 左侧分类导航("左侧分类导航1",左侧分类导航1_分类被单击,左侧分类导航1_子项被单击);
var HPtools1 = new HPtools("HPtools1");
var 加密操作1 = new 加密操作("加密操作1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var div_reset_popover = new 弹出面板("div_reset_popover",null,null);
var div_reset_password_old = new 编辑框("div_reset_password_old",null,null,null,null,null);
var div_reset_password = new 编辑框("div_reset_password",null,null,null,null,null);
var div_reset_password_ = new 编辑框("div_reset_password_",null,null,null,null,null);
var div_reset_btn = new 按钮("div_reset_btn",div_reset_btn_被单击,null,null);
var div_game_ver_popover = new 弹出面板("div_game_ver_popover",null,null);
var div_game_ver_lable = new 标签("div_game_ver_lable",null);
var div_game_ver_dropbox = new 下拉框("div_game_ver_dropbox",div_game_ver_dropbox_表项被单击);
var div_game_ver_btn = new 按钮("div_game_ver_btn",div_game_ver_btn_被单击,null,null);
var div_reservice_popover = new 弹出面板("div_reservice_popover",null,null);
var div_reservice_lable = new 标签("div_reservice_lable",null);
var div_reservice_edit = new 编辑框("div_reservice_edit",null,null,null,null,null);
var div_reservice_btn = new 按钮("div_reservice_btn",div_reservice_btn_被单击,null,null);
var 时钟_获取更新 = new 时钟("时钟_获取更新",时钟_获取更新_周期事件);
var 时钟_文字变色 = new 时钟("时钟_文字变色",时钟_文字变色_周期事件);
if(mui.os.plus){
    mui.plusReady(function() {
        管理系统_创建完毕();
        
    });
}else{
    window.onload=function(){ 
        管理系统_创建完毕();
        
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var m_game_ver= "";
var 集_项目索引= -1;



function 管理系统_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password异常,请重新登陆！"),"");
		return;
	}
	根地址 = HPtools1.取URL();
	弹出面板初始化();
	左侧导航初始化();

	时钟_获取更新.开始执行(30 * 60 * 1000, true);
	左侧分类导航1.切换窗口("notice.html",false,"password=" + m_password);
	获取会员信息(false);
}
function 获取会员信息(显示等待框){
	if(显示等待框 == true ){
		标签_会员账号.置标题("查询中......");
		m_post = "";
		m_url = 公用模块.生成访问链接_后端(根地址,"api/auth/auth","");
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		时钟1.开始执行(200,false);
	}else{
		网络操作1.置附加请求头({"Content-Type":"application/json"});
		var url= 公用模块.生成访问链接_后端(根地址,"api/auth/auth", "");
		网络操作1.发送网络请求(url,"get","text","",5000);
	}
}
function 弹出面板初始化(){


	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_reset_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_reset_password_old.置可视(true);
	div_reset_popover.添加组件("div_reset_password_old");
	div_reset_password.置可视(true);
	div_reset_popover.添加组件("div_reset_password");
	div_reset_password_.置可视(true);
	div_reset_popover.添加组件("div_reset_password_");
	div_reset_btn.置可视(true);
	div_reset_popover.添加组件("div_reset_btn");
	var rect = 公用模块.弹出面板初始化计算(50, 120, false);
	div_game_ver_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_game_ver_lable.置可视(true);
	div_game_ver_popover.添加组件("div_game_ver_lable");
	div_game_ver_dropbox.置可视(true);
	div_game_ver_popover.添加组件("div_game_ver_dropbox");
	div_game_ver_btn.置可视(true);
	div_game_ver_popover.添加组件("div_game_ver_btn");
	div_game_ver_dropbox.添加项目("请选择游戏端的版本......","");
	div_game_ver_dropbox.添加项目("MySQL+芒果库版本","3.2");
	div_game_ver_dropbox.添加项目("MySQL+MySQL版本","3.4");
	div_game_ver_dropbox.添加项目("MySQL+SQLite版本","3.6");
	var rect = 公用模块.弹出面板初始化计算(50, 160, false);
	div_reservice_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_reservice_lable.置可视(true);
	div_reservice_popover.添加组件("div_reservice_lable");
	div_reservice_edit.置可视(true);
	div_reservice_popover.添加组件("div_reservice_edit");
	div_reservice_btn.置可视(true);
	div_reservice_popover.添加组件("div_reservice_btn");
	div_reservice_edit.置只读模式(true);
	面板1.添加组件("标签_会员账号", "180px");
	面板1.添加组件("标签_升级提示", "320px");
}
function 左侧导航初始化(){
	左侧分类导航1.添加logo("images/erp.png","元神外建商城后台");

	左侧分类导航1.添加分类("images/home.png","基础档案");
	左侧分类导航1.添加子项(0,"资源档案管理");
	左侧分类导航1.添加子项(0,"GM脚本管理");
	左侧分类导航1.添加子项(0,"签到奖励管理");


	左侧分类导航1.添加分类("images/folder.png","营销管理");
	左侧分类导航1.添加子项(1,"商城管理");
	左侧分类导航1.添加子项(1,"抽奖管理");
	左侧分类导航1.添加子项(1,"VIP等级管理");

	左侧分类导航1.添加分类("images/plane.png","充值管理");
	左侧分类导航1.添加子项(2,"平台币CDK");
	左侧分类导航1.添加子项(2,"在线直充管理");

	左侧分类导航1.添加分类("images/edit.png","返佣管理");
	左侧分类导航1.添加子项(3,"提现操作");
	左侧分类导航1.添加子项(3,"返佣查询");

	左侧分类导航1.添加分类("images/edit.png","营收统计");
	左侧分类导航1.添加子项(4,"综合营收");
	左侧分类导航1.添加子项(4,"充值报表");
	左侧分类导航1.添加子项(4,"商城销售");
	左侧分类导航1.添加子项(4,"抽奖营收");

	左侧分类导航1.添加分类("images/edit.png","日志查看");
	左侧分类导航1.添加子项(5,"操作日志");
	左侧分类导航1.添加子项(5,"仓库日志");
	左侧分类导航1.添加子项(5,"充值校验");
	左侧分类导航1.添加子项(5,"充值回调日志");

	左侧分类导航1.添加分类("images/person.png","用户管理");
	左侧分类导航1.添加子项(6,"用户管理");
	左侧分类导航1.添加子项(6,"玩家绑定设置");

	左侧分类导航1.添加分类("images/edit.png","系统维护");
	左侧分类导航1.添加子项(7,"查看授权会员");
	左侧分类导航1.添加子项(7,"修改密码");
	左侧分类导航1.添加子项(7,"游戏服务器设置");
	左侧分类导航1.添加子项(7,"邮件服务器设置");
	左侧分类导航1.添加子项(7,"游戏端版本切换");
	左侧分类导航1.添加子项(7,"查看重启命令");
	左侧分类导航1.添加子项(7,"设置提现开关");
	左侧分类导航1.添加子项(7,"设置新特性");
	左侧分类导航1.添加子项(7,"数据清理");





	左侧分类导航1.添加分类("images/plane.png","在线公告");


}

function 左侧分类导航1_子项被单击(分类索引,子项索引){
	if(分类索引 == 0 ){
		switch(子项索引){
			case 0 :
				左侧分类导航1.切换窗口("iteminfo.html",false,"password=" + m_password);
			break;
			case 1 :
				左侧分类导航1.切换窗口("gmscript.html",false,"password=" + m_password);
			break;
			case 2 :
				左侧分类导航1.切换窗口("signinfo.html",false,"password=" + m_password);
			break;
		}
	}
	if(分类索引 == 1 ){
		switch(子项索引){
			case 0 :
				左侧分类导航1.切换窗口("shopinfo.html",false,"password=" + m_password);
			break;
			case 1 :
				左侧分类导航1.切换窗口("drawinfo.html",false,"password=" + m_password);
			break;
			case 2 :
				左侧分类导航1.切换窗口("gradeinfo.html",false,"password=" + m_password);
			break;
		}
	}
	if(分类索引 == 2 ){
		switch(子项索引){
			case 0 :
				左侧分类导航1.切换窗口("coincdk.html",false,"password=" + m_password);
			break;
			case 1 :
				左侧分类导航1.切换窗口("payinfo.html",false,"password=" + m_password);
			break;
		}
	}
	if(分类索引 == 3 ){
		switch(子项索引){
			case 0 :
				左侧分类导航1.切换窗口("cashinfo.html",false,"password=" + m_password);
			break;
			case 1 :
				左侧分类导航1.切换窗口("reportagent.html",false,"password=" + m_password);
			break;
		}
	}
	if(分类索引 == 4 ){
		switch(子项索引){
			case 0 :
				左侧分类导航1.切换窗口("reportcomp.html",false,"password=" + m_password);
			break;
			case 1 :
				左侧分类导航1.切换窗口("reportpay.html",false,"password=" + m_password);
			break;
			case 2 :
				左侧分类导航1.切换窗口("reportshop.html",false,"password=" + m_password);
			break;
			case 3 :
				左侧分类导航1.切换窗口("reportlottery.html",false,"password=" + m_password);

			break;
		}
	}
	if(分类索引 == 5 ){
		switch(子项索引){
			case 0 :
				左侧分类导航1.切换窗口("reportlog.html",false,"password=" + m_password);
			break;
			case 1 :
				左侧分类导航1.切换窗口("reportlogwarehouse.html",false,"password=" + m_password);
			break;
			case 2 :
				左侧分类导航1.切换窗口("reportlogcoin.html",false,"password=" + m_password);
			break;
			case 3 :
				左侧分类导航1.切换窗口("reportlognotify.html",false,"password=" + m_password);
			break;
		}
	}
	if(分类索引 == 6 ){
		switch(子项索引){
			case 0 :
				左侧分类导航1.切换窗口("operinfo.html",false,"password=" + m_password);
			break;
			case 1 :
				公用模块.居中打开小窗口("userbind.html?password="+m_password, 800, 600);

			break;
		}
	}
	if(分类索引 == 7 ){
		switch(子项索引){
			case 0 :
				获取会员信息(true);
			break;
			case 1 :
				div_reset_popover.显示();
			break;
			case 2 :
				左侧分类导航1.切换窗口("gameserver.html",false,"password=" + m_password);
			break;
			case 3 :
				左侧分类导航1.切换窗口("mailsmtp.html",false,"password=" + m_password);
			break;
			case 4 :
				m_post = "";
				m_url = 公用模块.生成访问链接_后端(根地址,"api/game/ver",m_password);
				美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
				时钟1.开始执行(200,false);
			break;
			case 5 :
				m_post = "";
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/path", m_password);
				美化等待框1.默认等待框("正在交互","正在生成,请稍等......");
				时钟1.开始执行(200,false);
			break;
			case 6 :
				公用模块.居中打开小窗口("init.html?password="+m_password, 800, 600);
			break;
			case 7 :
				公用模块.居中打开小窗口("init435.html?password="+m_password, 800, 600);
			break;
			case 8 :
				公用模块.居中打开小窗口("dataclear.html?password="+m_password, 800, 600);

			break;
		}
	}
	if(分类索引 == 8 ){






	}
}

function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			if(json.table == "auth" ){
				标签_会员账号.置标题("<p style=\"color: red\">点我注册绑定授权会员</p>");
				return;
			}
			if(json.table == "get-service-version" ){
				return;
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "auth" ){

			}else if(json.table == "reset" ){
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password修改成功！"),"");
			}else if(json.table == "game_ver" && json.model == "select" ){
				var str= "未知版本：" + String(json.msg);
				if(json.msg == 3.2 ){
					str = "MySQL+芒果库版本";
				}else if(json.msg == 3.4 ){
					str = "MySQL+MySQL版本";
				}else if(json.msg == 3.6 ){
					str = "MySQL+SQLite版本";
				}
				div_game_ver_lable.置标题("当前您的游戏端版本是："+str);
				div_game_ver_popover.显示();
			}else if(json.table == "game_ver" && json.model == "update" ){
				div_game_ver_popover.隐藏();
				仔仔弹出对话框1.成功("游戏端版本切换成功！");
			}else if(json.table == "server_path" ){
				var server_port= 公用模块.取端口(根地址);
				div_reservice_edit.置内容("cd "+json.msg+" && ./reservice "+转换操作.到文本(server_port));
				div_reservice_popover.显示();
			}else if(json.table == "auth_cdk" ){
				div_auth_popover.隐藏();
				if(json.model == "bind" ){
					仔仔弹出对话框1.成功("绑定成功,到期时间："+json.msg);
				}else{
					仔仔弹出对话框1.成功(json.msg);
				}
			}else if(json.table == "get-service-version" ){
				标签_升级提示.置可视(true);
				标签_升级提示.置标题("发现新版本："+json.msg+"，点我升级！");
				时钟_文字变色.开始执行(1000, true);
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			if(json.table == "auth" ){
				标签_会员账号.置标题("<p style=\"color: blue\">授权会员："+json.vip_info.vip_login+"</p>");
			}

		}
	}
}
function div_reset_btn_被单击(){
	div_reset_password_old.置内容(文本操作.删首尾空(div_reset_password_old.取内容()));
	if(div_reset_password_old.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入原密码");
		return;
	}
	div_reset_password.置内容(文本操作.删首尾空(div_reset_password.取内容()));
	if(div_reset_password.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入新密码");
		return;
	}
	div_reset_password_.置内容(文本操作.删首尾空(div_reset_password_.取内容()));
	if(div_reset_password.取内容() != div_reset_password_.取内容() ){
		仔仔弹出对话框1.错误("两次密码输入不一致");
		return;
	}
	var old= 加密操作1.取md5值(div_reset_password_old.取内容());
	old = "" + old;
	var pass= 加密操作1.取md5值(div_reset_password.取内容());
	pass = "" + pass;
	var json= {}
	json.old_password = old;
	json.new_password = pass;
	m_post = 公用模块.生成提交数据(0, "reset", "", "" , 1, 0,json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/reset", "");
	美化等待框1.默认等待框("正在交互","正在修改,请稍等......");
	时钟1.开始执行(200,false);
}
function div_game_ver_dropbox_表项被单击(项目索引,项目标题,项目标记){
	集_项目索引 = 项目索引;
	m_game_ver = 项目标记;
}
function div_game_ver_btn_被单击(){
	if(m_game_ver == "" ){
		仔仔弹出对话框1.错误("请选择要切换的游戏端版本");
		return;
	}
	if(HPtools1.询问框("是否将游戏端切换至："+div_game_ver_dropbox.取项目标题(集_项目索引)+"？注意：切换后必须重新设置：用户管理-玩家绑定设置！") == false ){
		return;
	}
	var json= {}
	json.game_ver = 转换操作.到数值(m_game_ver);
	m_post = 公用模块.生成提交数据(0, "game_ver", "", "update" , 1, 0,json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/game/ver", m_password);
	美化等待框1.默认等待框("正在交互","正在修改,请稍等......");
	时钟1.开始执行(200,false);
}
function div_reservice_btn_被单击(){
	HPtools1.置剪贴板内容(div_reservice_edit.取内容());
	仔仔弹出对话框1.提示("已操作复制！");
}
function 左侧分类导航1_分类被单击(分类索引){
	switch(分类索引){
		case 8 :
			左侧分类导航1.切换窗口("notice.html",false,"password=" + m_password);

		break;
	}
}

function 时钟_获取更新_周期事件(){
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	var url= 公用模块.生成访问链接_后端(根地址,"api/admin/get-service-version", "");
	网络操作1.发送网络请求(url,"get","text","",5000);
}
function 时钟_文字变色_周期事件(){
	var arrs = ["#000000", "#0000FF", "#9900FF", "#FF0000", "#FF00FF", "#CC0000", "#CC00FF", "#660000"];
	var i= 数学操作.取随机数(0, 数组操作.取成员数(arrs) - 1);
	标签_升级提示.置字体颜色(arrs[i]);
}
function 标签_升级提示_被单击(){
	公用模块.居中打开小窗口("update.html?password="+m_password, 800, 600);
}
function 标签_会员账号_被单击(){
	公用模块.居中打开小窗口("viplogin.html?password="+m_password, 480, 600);
}