    function 悬浮按钮(name,functionName){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 悬浮按钮(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;
        
        //组件命令：
        this.置标题 = function (newTitle){
            document.getElementById(this.名称).innerHTML=newTitle;
        } 

        //组件命令：
        this.到顶部 = function(e) {
  TweenMax.to(window, e, {
    scrollTo: 0,
    ease: Expo.easeInOut
  });
  var huojian = new TimelineLite();
  huojian.to("#"+this.名称, 1, {
      rotationY: 720,
      scale: 0.6,
      y: "+=40",
      ease: Power4.easeOut
    })
    .to("#"+this.名称, 1, {
      y: -1000,
      opacity: 0,
      ease: Power4.easeOut
    }, 0.6)
    .to("#"+this.名称, 1, {
      y: 0,
      rotationY: 0,
      opacity: 1,
      scale: 1,
      ease: Expo.easeOut,
      clearProps: "all"
    }, "1.4");
}
                
        //组件命令：
        this.取标题 = function (){
           return document.getElementById(this.名称).innerHTML;
        }  
        
        //组件命令：
        this.置可视 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="flex";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="none"; //不占位隐藏               
            }
        } 
        this.置按钮颜色 =  function (newTitle) {
             var element = document.getElementById(this.名称);
             element.style.backgroundColor = newTitle;
        } 
        
        this.置按钮圆角 =  function (newTitle) {
             var element = document.getElementById(this.名称);
             element.style.borderRadius = newTitle;
        } 
       
        this.置按钮透明度 =  function (newTitle) {
             var element = document.getElementById(this.名称);
             element.style.opacity = newTitle;
        } 
          
        this.置按钮宽高 =  function (kuan,gao) {
             var element = document.getElementById(this.名称);
             element.style.width = kuan;
			 element.style.height = gao;
        } 
        this.置按钮位置 =  function (gao,kuan) {
             var element = document.getElementById(this.名称);
             element.style.bottom = kuan;
			 element.style.right = gao;
        }           		        
        //组件命令：
        this.置可视2 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="hidden"; //占位隐藏               
            }
        } 
        
        //组件事件
        if(functionName!=null){
		    document.getElementById(this.名称).addEventListener("tap", function () {
					                functionName();//被单击事件
					            });       	
					        }
	}