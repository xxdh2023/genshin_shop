mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 编辑框1 = new 编辑框("编辑框1",null,编辑框1_按下某键,null,null,null);
var 按钮1 = new 按钮("按钮1",按钮1_被单击,null,null);
var 标签1 = new 标签("标签1",null);
var 编辑框2 = new 编辑框("编辑框2",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var 编辑框3 = new 编辑框("编辑框3",null,null,null,null,null);
var div_sn = new 标签("div_sn",null);
if(mui.os.plus){
    mui.plusReady(function() {
        主窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        主窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";


function 主窗口_创建完毕(){
	窗口操作.置窗口标题("后台登陆");
	var msg= 文本操作.删首尾空(窗口操作.取当前页面参数("msg"));
	if(msg != "" ){
		msg = 加密操作1.url解码(msg);
	}
	if(msg != "" ){
		仔仔弹出对话框1.提示(msg,1500000);
	}
	根地址 = HPtools1.取URL();
	编辑框2.置内容(根地址+"/agent/index.html");
	编辑框2.置只读模式(true);
	编辑框3.置内容(根地址+"/shop/index.html");
	编辑框3.置只读模式(true);
	MyCookie.setCookie("genshin-admin-token", "", 1);
	m_post = "";
	m_url = 公用模块.生成访问链接_后端(根地址, "api/auth/getSN", "");
	美化等待框1.默认等待框("正在交互","正在交互,请稍等......");
	时钟1.开始执行(200,false);
}
function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -2 ){
			窗口操作.切换窗口("init.html","");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			MyCookie.setCookie("genshin-admin-token", json.msg, 7*24*60*60);
			窗口操作.切换窗口("master.html","");
		}else if(json.static == 3 && json.msg != "" ){
			div_sn.置标题("version. " + json.msg);
		}
	}
}

function 编辑框1_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		登陆系统();
	}
}

function 按钮1_被单击(){
	登陆系统();
}

function 登陆系统(){
	编辑框1.置内容(文本操作.删首尾空(编辑框1.取内容()));
	if(编辑框1.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入密码！");
		return;
	}
	var md5= 加密操作1.取md5值(编辑框1.取内容());
	var json= {}
	m_password = "" + md5;
	json.password = m_password;
	m_post = 公用模块.生成提交数据(0, "", "", "" , 0, 0, json, "", "");
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/login", "");
	美化等待框1.默认等待框("正在交互","正在登陆,请稍等......");
	时钟1.开始执行(200,false);
}