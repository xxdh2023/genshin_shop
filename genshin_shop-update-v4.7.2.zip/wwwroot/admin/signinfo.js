mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 自由面板1 = new 自由面板("自由面板1","54px");
var 自由面板_标签 = new 标签("自由面板_标签",null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",null,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        签到奖励表_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        签到奖励表_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";

function 签到奖励表_创建完毕(){
	根地址 = HPtools1.取URL();
	调整组件尺寸();
	高级表格初始化();
	查询数据();
}
function 调整组件尺寸(){
	var width= 窗口操作.取窗口宽度();
	公用模块.自由面板_调整("自由面板_标签", 110, 100, 800,width);
	公用模块.自由面板_调整("自由面板_编辑框_条件", 214, 400, 800,width);
	公用模块.自由面板_调整("自由面板_按钮_查询", 622, 100, 800,width);
	公用模块.自由面板_调整("自由面板_按钮_添加", 6, 100, 800,width);
}

function 高级表格初始化(){
	高级表格1.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",220,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("sign_id","编码",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("sign_name","名称",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("sign_type","类型",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("sign_free","是否为平台福利",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("sign_clear","是否允许背包清理",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("sign_note","简介",240,false,false,false,false,false,false,"",false,false);
	高级表格1.初始化("auto",true,true,false,true);
}


function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "item_sign_info" ){
				高级表格1.删除行(转换操作.到数值(json.comm));
				高级表格1.初始化("auto",true,true,false,true);
				仔仔弹出对话框1.成功("删除成功！");


			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "item_sign_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "删除";
						arr[3] = json.results[i].sign_id;
						arr[4] = json.results[i].sign_name;
						arr[5] = "每天签到";
						switch(json.results[i].sign_type){
							case 1 :
								arr[5] = "按周签到";
							break;
							case 2 :
								arr[5] = "按月签到";
							break;
						}
						arr[6] = "否";
						arr[7] = "-";
						if(json.results[i].sign_free > 0 ){
							arr[6] = "是";
							if(json.results[i].sign_clear < 1 ){
								arr[7] = "否";
							}else{
								arr[7] = "是";
							}
						}
						arr[8] = json.results[i].sign_note;
						高级表格1.添加行(false,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(2,false,"编辑");
					高级表格1.添加操作栏按钮(3,false,"查看明细脚本");
					高级表格1.添加操作栏按钮(4,false,"删除");
					高级表格1.初始化("auto",true,true,false,true);
				}



			}




		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	m_post = 公用模块.生成提交数据(0, "item_sign_info", value, "" , 1, 0);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}

function 按钮_底部_被单击(){
	m_post = 公用模块.生成提交数据(0, "item_sign_info", value, "" , page+1, 0);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	时钟1.开始执行(200,false);
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
		case 0 :
			公用模块.居中打开小窗口("signinfone.html?ID="+转换操作.到文本(_id), 800, 600);
		break;
		case 1 :

			var url= "";
			url = 公用模块.生成明细查看摘要(m_password, 0, "sign_id", 行数据["sign_id"], "item_sign_info_detail", "sign_day,sign_value,sign_detail", "第几天,显示名称,内部脚本", 加密操作1.base64加密("  order by sign_day"));

			公用模块.居中打开小窗口(url, 800, 600);
		break;
		case 2 :

			if(HPtools1.询问框("是否删除？") == true ){
				var json= {}
				json.sign_id = 行数据["sign_id"];
				m_post = 公用模块.生成提交数据(_id, "item_sign_info", ""+行索引, "delete" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
				美化等待框1.默认等待框("正在交互","正在删除,请稍等......");
				时钟1.开始执行(200,false);
			}
		break;
	}

}

function 自由面板_按钮_添加_被单击(){
	公用模块.居中打开小窗口("signinfone.html?ID=0", 800, 600);
}