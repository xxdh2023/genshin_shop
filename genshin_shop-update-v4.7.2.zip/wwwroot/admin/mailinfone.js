mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签8 = new 标签("标签8",null);
var div_mail_server = new 下拉框("div_mail_server",null);
var 标签1 = new 标签("标签1",null);
var div_mail_title = new 编辑框("div_mail_title",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var div_mail_content = new 编辑框("div_mail_content",null,null,null,null,null);
var 标签3 = new 标签("标签3",null);
var div_mail_item = new 编辑框("div_mail_item",null,null,null,null,null);
var 标签4 = new 标签("标签4",null);
var 标签5 = new 标签("标签5",null);
var div_mail_sender = new 编辑框("div_mail_sender",null,null,null,null,null);
var 标签6 = new 标签("标签6",null);
var div_mail_time = new 编辑框("div_mail_time",null,null,null,null,null);
var 面板1 = new 面板("面板1");
var div_mail_one = new 单选框("div_mail_one",div_mail_one_被单击);
var div_mail_all = new 单选框("div_mail_all",div_mail_all_被单击);
var div_one_panel = new 面板("div_one_panel");
var div_one_dropbox = new 下拉框("div_one_dropbox",null);
var div_mail_account = new 编辑框("div_mail_account",null,null,null,null,null);
var div_all_old = new 单选框("div_all_old",null);
var div_all_new = new 单选框("div_all_new",null);
var div_all_all = new 单选框("div_all_all",null);
var 标签7 = new 标签("标签7",null);
var 面板2 = new 面板("面板2");
var 按钮_新增 = new 按钮("按钮_新增",按钮_新增_被单击,null,null);
var 按钮_保存 = new 按钮("按钮_保存",按钮_保存_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        发送游戏邮件_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        发送游戏邮件_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;




function 发送游戏邮件_创建完毕(){
	根地址 = HPtools1.取URL();
	界面初始化();
	var id = 文本操作.删首尾空(窗口操作.取当前页面参数("id"));
	if(id == "" ){
		ID = 0;
	}else{
		id = 数学操作.取整数(转换操作.到数值(id));
		if(id < 0 ){
			id = 0;
		}
		ID = id;
	}
	div_mail_sender.置内容("天理");
	m_post = 公用模块.生成提交数据(0, "gameserver_info_simple", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 界面初始化(){
	面板1.添加组件("div_mail_one", "1");
	面板1.添加组件("div_mail_all", "1");
	div_mail_one.置分组("A");
	div_mail_one.置选中状态(true);
	div_mail_all.置分组("A");
	div_one_panel.添加组件("div_one_dropbox", "1");
	div_one_panel.添加组件("div_mail_account", "3");
	div_all_old.置分组("B");
	div_all_new.置分组("B");
	div_all_all.置分组("B");
	div_all_all.置选中状态(true);
	div_one_dropbox.清空项目();
	div_one_dropbox.添加项目("商城账号", "shop");
	div_one_dropbox.添加项目("游戏账号", "game");
	div_one_dropbox.添加项目("游戏UID", "uid");
	div_one_dropbox.置现行选中项(0);
	面板2.添加组件("按钮_新增","1");
	面板2.添加组件("按钮_保存","2");

}
function 切换邮件类型(is_one){
	if(is_one == true ){
		div_one_panel.置可视(true);
		div_all_old.置可视(false);
		div_all_new.置可视(false);
		div_all_all.置可视(false);
	}else{
		div_one_panel.置可视(false);
		div_all_old.置可视(true);
		div_all_new.置可视(true);
		div_all_all.置可视(true);
	}
}
function 新增操作(){
	div_mail_title.置内容("");
	div_mail_content.置内容("");
	div_mail_item.置内容("");
	div_mail_time.置内容("");
	div_mail_account.置内容("");
	if(div_mail_server.取项目总数() > 0 ){
		div_mail_server.置现行选中项(0);
	}
}
function 按钮_新增_被单击(){
	if(HPtools1.询问框("是否新增？") == false ){
		return;
	}
	ID = 0;
	新增操作();
}
function 查询档案(){
	if(ID < 1 ){
		return;
	}
	m_post = 公用模块.生成提交数据(ID, "game_mail_info_one", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			ID = json.msg;
			仔仔弹出对话框1.成功("保存成功！");
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "gameserver_info_simple" ){
				div_mail_server.清空项目();
				div_mail_server.添加项目("请选择区服", 0);
				while(i<json.resutls.length){
					div_mail_server.添加项目(json.resutls[i].game_name, json.resutls[i].ID);
					i++
				}
				div_mail_server.置现行选中项(0);
				查询档案();
				return;
			}
			新增操作();
			div_mail_title.置内容(json.resutls.mail_title);
			div_mail_content.置内容(json.resutls.mail_content);
			div_mail_item.置内容(json.resutls.mail_item);
			div_mail_sender.置内容(json.resutls.mail_sender);
			div_mail_time.置内容(json.resutls.mail_time);
			var is_one = true;
			if(json.resutls.mail_type > 0 ){
				is_one = false;
			}
			切换邮件类型(is_one);
			while(i<div_one_dropbox.取项目总数()){
				if(div_one_dropbox.取项目标记(i) == json.resutls.mail_one_model ){
					div_one_dropbox.置现行选中项(i);
					break;
				}
				i++
			}
			i=0;
			while(i<div_mail_server.取项目总数()){
				if(转换操作.到数值(div_mail_server.取项目标记(i)) == json.resutls.server_id ){
					div_mail_server.置现行选中项(i);
					break;
				}
				i++
			}
			div_mail_one.置选中状态(false);
			div_mail_all.置选中状态(false);
			if(json.resutls.mail_type < 1 ){
				div_mail_one.置选中状态(true);
			}else{
				div_mail_all.置选中状态(true);
			}
			div_mail_account.置内容(json.resutls.mail_one_account);
			div_all_old.置选中状态(false);
			div_all_new.置选中状态(false);
			div_all_all.置选中状态(false);

			if(json.resutls.mail_all_model < 1 ){
				div_all_old.置选中状态(true);
			}else if(json.resutls.mail_all_model == 1 ){
				div_all_new.置选中状态(true);
			}else{
				div_all_all.置选中状态(true);
			}


		}
	}
}
function div_mail_one_被单击(){
	切换邮件类型(true);
}
function div_mail_all_被单击(){
	切换邮件类型(false);
}
function 按钮_保存_被单击(){
	var json = {}
	var server_id = 0;
	if(div_mail_server.取项目总数() > 0 ){
		server_id = 转换操作.到数值(div_mail_server.取项目标记(div_mail_server.取现行选中项()));
	}
	if(server_id< 1 ){
		仔仔弹出对话框1.错误("请选择发送区服！");
		return;
	}
	json.server_id = server_id;
	div_mail_title.置内容(文本操作.删首尾空(div_mail_title.取内容()));
	if(div_mail_title.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入邮件标题！");
		return;
	}
	json.mail_title = div_mail_title.取内容();
	div_mail_content.置内容(文本操作.删首尾空(div_mail_content.取内容()));
	if(div_mail_content.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入邮件内容！");
		return;
	}
	json.mail_content = div_mail_content.取内容();
	div_mail_item.置内容(文本操作.删首尾空(div_mail_item.取内容()));
	json.mail_item = div_mail_item.取内容();
	div_mail_sender.置内容(文本操作.删首尾空(div_mail_sender.取内容()));
	if(div_mail_sender.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入发送人！");
		return;
	}
	json.mail_sender = div_mail_sender.取内容();
	div_mail_time.置内容(文本操作.删首尾空(div_mail_time.取内容()));
	if(div_mail_time.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入邮件到期时间！");
		return;
	}
	json.mail_time = div_mail_time.取内容();
	var msg = "本次发送的是：";
	json.mail_type = 0;
	if(div_mail_all.取选中状态() == true ){
		json.mail_type = 1;
		msg = msg + "全服邮件";
	}else{
		div_mail_account.置内容(文本操作.删首尾空(div_mail_account.取内容()));
		if(div_mail_account.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入"+div_one_dropbox.取项目标题(div_one_dropbox.取现行选中项()) +"的值！");
			return;
		}
		msg = msg + "单人邮件";
	}
	msg = msg + "\n\n到期时间：" + json.mail_time;
	msg = msg + "\n\n是否继续？";
	json.mail_one_model = div_one_dropbox.取项目标记(div_one_dropbox.取现行选中项());
	json.mail_one_account = div_mail_account.取内容();
	json.mail_all_model = 0;
	if(div_all_new.取选中状态() == true ){
		json.mail_all_model = 1;
	}else if(div_all_all.取选中状态() == true ){
		json.mail_all_model = 2;
	}
	if(HPtools1.询问框(msg) == false ){
		return;
	}
	if(ID < 1 ){
		m_post = 公用模块.生成提交数据(ID, "game_mail_info", "", "insert" , 0, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert",m_password);
	}else{
		m_post = 公用模块.生成提交数据(ID, "game_mail_info", "", "update" , 0, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update",m_password);
	}
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}