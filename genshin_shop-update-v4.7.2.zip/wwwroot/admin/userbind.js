mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 标签1 = new 标签("标签1",null);
var 标签4 = new 标签("标签4",null);
var div_mysql_host = new 编辑框("div_mysql_host",null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var div_mysql_port = new 编辑框("div_mysql_port",null,null,null,null,null);
var 标签6 = new 标签("标签6",null);
var div_mysql_account = new 编辑框("div_mysql_account",null,null,null,null,null);
var 标签7 = new 标签("标签7",null);
var div_mysql_password = new 编辑框("div_mysql_password",null,null,null,null,null);
var 标签8 = new 标签("标签8",null);
var div_mysql_database_user = new 编辑框("div_mysql_database_user",null,null,null,null,null);
var 标签9 = new 标签("标签9",null);
var div_mysql_database_config = new 编辑框("div_mysql_database_config",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var 标签3 = new 标签("标签3",null);
var 标签10 = new 标签("标签10",null);
var div_mongodb_host = new 编辑框("div_mongodb_host",null,null,null,null,null);
var 标签11 = new 标签("标签11",null);
var div_mongodb_port = new 编辑框("div_mongodb_port",null,null,null,null,null);
var 标签12 = new 标签("标签12",null);
var div_mongodb_account = new 编辑框("div_mongodb_account",null,null,null,null,null);
var 标签13 = new 标签("标签13",null);
var div_mongodb_password = new 编辑框("div_mongodb_password",null,null,null,null,null);
var 标签14 = new 标签("标签14",null);
var div_mongodb_database = new 编辑框("div_mongodb_database",null,null,null,null,null);
var div_save_btns = new 按钮组("div_save_btns",div_save_btns_被单击);
var 时钟_延时显示信息框 = new 时钟("时钟_延时显示信息框",时钟_延时显示信息框_周期事件);
if(mui.os.plus){
    mui.plusReady(function() {
        玩家绑定设置_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        玩家绑定设置_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var msg= "";





function 玩家绑定设置_创建完毕(){
	根地址 = HPtools1.取URL();
	m_post = 公用模块.生成提交数据(0, "user_bind", "", "select" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/user_bind", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "user_bind" && json.model == "mysql_test" ){
				msg = json.msg;
				时钟_延时显示信息框.开始执行(20,false);
			}else if(json.table == "user_bind" && json.model == "mongo_test" ){
				msg = json.msg;
				时钟_延时显示信息框.开始执行(20,false);
			}else{
				仔仔弹出对话框1.错误(json.msg);
			}
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功("保存成功");
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "user_bind" ){
				div_mysql_host.置内容(json.results.mysql.host);
				div_mysql_port.置内容();
				if(json.results.mysql.port > 0 ){
					div_mysql_port.置内容(""+json.results.mysql.port);
				}
				div_mysql_account.置内容(json.results.mysql.account);
				div_mysql_password.置内容(json.results.mysql.password);
				div_mysql_database_user.置内容(json.results.mysql.user);
				div_mysql_database_config.置内容(json.results.mysql.config);
				div_mongodb_host.置内容(json.results.mongo.host);
				div_mongodb_port.置内容();
				if(json.results.mongo.port > 0 ){
					div_mongodb_port.置内容(""+json.results.mongo.port);
				}
				div_mongodb_account.置内容(json.results.mongo.account);
				div_mongodb_password.置内容(json.results.mongo.password);
				div_mongodb_database.置内容(json.results.mongo.database);
			}
		}
	}
}

function div_save_btns_被单击(按钮索引){
	switch(按钮索引){
	case 0 :
		保存参数();
	break;
	case 1 :
		m_post = 公用模块.生成提交数据(0, "user_bind", "", "mysql_test" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/user_bind", m_password);
		美化等待框1.默认等待框("正在交互","正在验证MySQL参数,请稍等......");
		时钟1.开始执行(200,false);
	break;
	case 2 :
		m_post = 公用模块.生成提交数据(0, "user_bind", "", "mongo_test" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/user_bind", m_password);
		美化等待框1.默认等待框("正在交互","正在验证游戏账号对应的数据库参数,请稍等......");
		时钟1.开始执行(200,false);
		break;
	}
}
function 保存参数(){
	div_mysql_host.置内容(文本操作.删首尾空(div_mysql_host.取内容()));
	if(div_mysql_host.取内容() == "" ){
		仔仔弹出对话框1.错误("MySQL数据库IP地址无效");
		return;
	}
	div_mysql_port.置内容(文本操作.删首尾空(div_mysql_port.取内容()));
	if(div_mysql_port.取内容() == "" ){
		仔仔弹出对话框1.错误("MySQL数据库端口无效");
		return;
	}
	var mysql_port= 转换操作.到数值(div_mysql_port.取内容());
	if(mysql_port < 1 ){
		仔仔弹出对话框1.错误("MySQL数据库端口无效");
		return;
	}
	div_mysql_account.置内容(文本操作.删首尾空(div_mysql_account.取内容()));
	if(div_mysql_account.取内容() == "" ){
		仔仔弹出对话框1.错误("MySQL数据库访问账号无效");
		return;
	}
	div_mysql_password.置内容(文本操作.删首尾空(div_mysql_password.取内容()));
	if(div_mysql_password.取内容() == "" ){
		仔仔弹出对话框1.错误("MySQL数据库访问密码无效");
		return;
	}
	div_mysql_database_user.置内容(文本操作.删首尾空(div_mysql_database_user.取内容()));
	if(div_mysql_database_user.取内容() == "" ){
		仔仔弹出对话框1.错误("MySQL数据库用户数据库名无效");
		return;
	}
	div_mysql_database_config.置内容(文本操作.删首尾空(div_mysql_database_config.取内容()));
	if(div_mysql_database_config.取内容() == "" ){
		仔仔弹出对话框1.错误("MySQL数据库config数据库名无效");
		return;
	}
	div_mongodb_host.置内容(文本操作.删首尾空(div_mongodb_host.取内容()));
	if(div_mongodb_host.取内容() == "" ){
		仔仔弹出对话框1.错误("数据库【host】参数无效！");
		return;
	}
	div_mongodb_port.置内容(文本操作.删首尾空(div_mongodb_port.取内容()));




	var mongodb_port= 转换操作.到数值(div_mongodb_port.取内容());




	div_mongodb_account.置内容(文本操作.删首尾空(div_mongodb_account.取内容()));
	div_mongodb_password.置内容(文本操作.删首尾空(div_mongodb_password.取内容()));
	div_mongodb_database.置内容(文本操作.删首尾空(div_mongodb_database.取内容()));
	if(div_mongodb_database.取内容() == "" ){
		仔仔弹出对话框1.错误("数据库名称/账号表名称无效");
		return;
	}
	if(HPtools1.询问框("保存时不做参数校验,请保存后测试是否正常！\n\n是否继续？") == false ){
		return;
	}
	var json= {}
	json.mysql = {}
	json.mysql.host = div_mysql_host.取内容();
	json.mysql.port = mysql_port;
	json.mysql.account = div_mysql_account.取内容();
	json.mysql.password = div_mysql_password.取内容();
	json.mysql.user = div_mysql_database_user.取内容();
	json.mysql.config = div_mysql_database_config.取内容();
	json.mongo = {}
	json.mongo.host = div_mongodb_host.取内容();
	json.mongo.port = mongodb_port;
	json.mongo.account = div_mongodb_account.取内容();
	json.mongo.password = div_mongodb_password.取内容();
	json.mongo.database = div_mongodb_database.取内容();
	m_post = 公用模块.生成提交数据(0, "user_bind", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/user_bind", m_password);
	美化等待框1.默认等待框("正在交互","正在保存,请稍等......");
	时钟1.开始执行(200,false);
}
function 时钟_延时显示信息框_周期事件(){
	HPtools1.信息框(msg);
}