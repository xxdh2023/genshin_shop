mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 面板1 = new 面板("面板1");
var 按钮_刷新 = new 按钮("按钮_刷新",按钮_刷新_被单击,null,null);
var 列表框1 = new 列表框("列表框1",false,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        支付方式档案_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        支付方式档案_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";

function 支付方式档案_创建完毕(){
	根地址 = HPtools1.取URL();
	面板1.添加组件("按钮_刷新", "140px");
	刷新档案();
}

function 刷新档案(){
	列表框1.清空项目();
	m_post = 公用模块.生成提交数据(0, "newpay_pay_type_info", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/select",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "newpay_pay_type_info" ){
				while(i<json.results.length){
					添加列表(json.results[i]);
					i++
				}
			}
		}
	}
}

function 添加列表(result){
	var str = 公用模块.文本显示处理("支付方式：" + result.type_name, "#FF00FF", 3);

	列表框1.添加项目2(str, 转换操作.json转文本(result), "", "");

}
function 按钮_刷新_被单击(){
	刷新档案();
}