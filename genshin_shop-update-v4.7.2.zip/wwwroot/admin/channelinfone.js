mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签1 = new 标签("标签1",null);
var edit_channel_name = new 编辑框("edit_channel_name",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var dropbox_channel_plugin = new 下拉框("dropbox_channel_plugin",null);
var 标签3 = new 标签("标签3",null);
var dropbox_currency_id = new 下拉框("dropbox_currency_id",null);
var 面板1 = new 面板("面板1");
var 标签4 = new 标签("标签4",null);
var 标签5 = new 标签("标签5",null);
var 面板2 = new 面板("面板2");
var edit_pay_min = new 编辑框("edit_pay_min",null,null,null,null,null);
var edit_pay_max = new 编辑框("edit_pay_max",null,null,null,null,null);
var 标签11 = new 标签("标签11",null);
var 标签6 = new 标签("标签6",null);
var dropbox_channel_method = new 下拉框("dropbox_channel_method",null);
var 标签7 = new 标签("标签7",null);
var edit_channel_submit = new 编辑框("edit_channel_submit",null,null,null,null,null);
var 标签8 = new 标签("标签8",null);
var edit_channel_config = new 编辑框("edit_channel_config",null,null,null,null,null);
var 面板3 = new 面板("面板3");
var 按钮_保存 = new 按钮("按钮_保存",按钮_保存_被单击,null,null);
var 按钮_说明 = new 按钮("按钮_说明",按钮_说明_被单击,null,null);
var 标签9 = new 标签("标签9",null);
var 按钮_支付方式 = new 按钮("按钮_支付方式",按钮_支付方式_被单击,null,null);
var 列表框1 = new 列表框("列表框1",false,null,列表框1_按钮被单击);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签_弹出 = new 标签("标签_弹出",null);
var dropbox_pay_type = new 下拉框("dropbox_pay_type",null);
var 按钮_添加 = new 按钮("按钮_添加",按钮_添加_被单击,null,null);
var 标签12 = new 标签("标签12",null);
var 按钮_代付 = new 按钮("按钮_代付",按钮_代付_被单击,null,null);
var 标签_结尾 = new 标签("标签_结尾",null);
if(mui.os.plus){
    mui.plusReady(function() {
        支付通道编辑_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        支付通道编辑_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;

function 支付通道编辑_创建完毕(){
	根地址 = HPtools1.取URL();
	var id = 窗口操作.取当前页面参数("id");
	if(id == "" ){
		ID = 0;
	}else{
		id = 数学操作.取整数(转换操作.到数值(id));
		if(id < 0 ){
			id = 0;
		}
		ID = id;
	}
	弹出面板初始化();
	界面初始化();
	查询档案();

}
function 界面初始化(){
	插件填充();
	dropbox_channel_method.清空项目();
	dropbox_channel_method.添加项目("POST");
	dropbox_channel_method.添加项目("GET");
	dropbox_channel_method.置现行选中项(0);
	dropbox_currency_id.添加项目("正在刷新......", -1);
	面板1.添加组件("标签4", "1");
	面板1.添加组件("标签5", "1");
	面板2.添加组件("edit_pay_min", "1");
	面板2.添加组件("edit_pay_max", "1");
	面板3.添加组件("按钮_保存", "2");
	面板3.添加组件("按钮_说明", "1");


}
function 弹出面板初始化(){

	var rect = 公用模块.弹出面板初始化计算(50, 140, false);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板1.添加组件("标签_弹出");
	弹出面板1.添加组件("dropbox_pay_type");
	弹出面板1.添加组件("按钮_添加");

}
function 查询档案(){
	m_post = 公用模块.生成提交数据(ID, "newpay_channel_info_one", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/select",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 新增操作(){
	edit_channel_name.置内容("");
	dropbox_channel_plugin.置现行选中项(0);
	dropbox_currency_id.置现行选中项(0);
	edit_pay_min.置内容("");
	edit_pay_max.置内容("");
	dropbox_channel_method.置现行选中项(0);
	edit_channel_submit.置内容("");
	edit_channel_config.置内容("");
	列表框1.清空项目();


}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			币种填充(json.currency);
			支付方式填充(json.pay_type);
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "newpay_channel_info" ){
				if(json.model == "insert" ){
					ID = json.msg;
				}
			}
			if(json.table == "newpay_channel_info_type" ){
				查询档案();
			}
			仔仔弹出对话框1.成功("保存成功！");
		}else if(json.static == 2 ){
			var i= 0;
			币种填充(json.currency);
			支付方式填充(json.pay_type);
			初始化赋值(json.result, json.result_type);

		}
	}
}
function 插件填充(){
	var plugin = 公用模块.生成支付插件();
	dropbox_channel_plugin.清空项目();
	dropbox_channel_plugin.添加项目("请选择插件.....", "");
	var i=0;
	while(i<plugin.length){
		dropbox_channel_plugin.添加项目(plugin[i].value+" ("+plugin[i].key+")", plugin[i].key);
		i++
	}
	dropbox_channel_plugin.置现行选中项(0);
}
function 币种填充(currency){
	if(currency == null ){
		return;
	}
	dropbox_currency_id.清空项目();
	dropbox_currency_id.添加项目("请选择币种......", -1);
	var i=0;
	while(i<currency.length){
		dropbox_currency_id.添加项目(currency[i].cur_name+" ("+currency[i].cur_symbol+")", currency[i].ID);
		i++
	}
	dropbox_currency_id.置现行选中项(0);
}
function 支付方式填充(pay_type){
	if(pay_type == null ){
		return;
	}
	dropbox_pay_type.清空项目();
	dropbox_pay_type.添加项目("请选择支付方式......", "");
	var i=0;
	while(i<pay_type.length){
		dropbox_pay_type.添加项目(pay_type[i].type_name+" ("+pay_type[i].type_id+")", pay_type[i].type_id);
		i++
	}
	dropbox_pay_type.置现行选中项(0);

}
function 初始化赋值(result, result_type){
	新增操作();
	if(result == null ){
		return;
	}
	edit_channel_name.置内容(result.channel_name);
	var i=0;
	while(i<dropbox_channel_plugin.取项目总数()){
		if(dropbox_channel_plugin.取项目标记(i) == result.channel_plugin ){
			dropbox_channel_plugin.置现行选中项(i);
			break;
		}
		i++
	}
	i=0;
	while(i<dropbox_currency_id.取项目总数()){
		if(转换操作.到数值(dropbox_currency_id.取项目标记(i)) == result.currency_id ){
			dropbox_currency_id.置现行选中项(i);
			break;
		}
		i++
	}
	edit_pay_min.置内容(result.pay_min);
	edit_pay_max.置内容(result.pay_max);
	if(result.channel_method == "POST" ){
		dropbox_channel_method.置现行选中项(0);
	}else{
		dropbox_channel_method.置现行选中项(1);
	}
	edit_channel_submit.置内容(result.channel_submit);
	edit_channel_config.置内容(result.channel_config);
	i=0;
	while(i<result_type.length){
		列表框1.添加项目2(result_type[i].type_name,result_type[i].ID,"mui-btn mui-btn-danger","删除");
		i++
	}

}
function 按钮_保存_被单击(){
	edit_channel_name.置内容(文本操作.删首尾空(edit_channel_name.取内容()));
	if(edit_channel_name.取内容() == "" ){
		仔仔弹出对话框1.错误("支付通道名称无效！");
		return;
	}
	var channel_plugin = dropbox_channel_plugin.取项目标记(dropbox_channel_plugin.取现行选中项());
	if(channel_plugin == "" ){
		仔仔弹出对话框1.错误("请选择：支付通道插件！");
		return;
	}
	var currency_id = 转换操作.到数值(dropbox_currency_id.取项目标记(dropbox_currency_id.取现行选中项()));
	if(currency_id < 0 ){
		仔仔弹出对话框1.错误("请选择：币种！");
		return;
	}
	edit_pay_min.置内容(文本操作.删首尾空(edit_pay_min.取内容()));
	var pay_min = 0;
	if(edit_pay_min.取内容() != "" ){
		pay_min = 转换操作.到数值(edit_pay_min.取内容());
	}
	edit_pay_max.置内容(文本操作.删首尾空(edit_pay_max.取内容()));
	var pay_max = 0;
	if(edit_pay_max.取内容() != "" ){
		pay_max = 转换操作.到数值(edit_pay_max.取内容());
	}
	edit_channel_submit.置内容(文本操作.删首尾空(edit_channel_submit.取内容()));
	if(edit_channel_submit.取内容() == "" ){
		仔仔弹出对话框1.错误("接口地址无效！");
		return;
	}
	edit_channel_config.置内容(文本操作.删首尾空(edit_channel_config.取内容()));
	if(edit_channel_config.取内容() == "" ){
		仔仔弹出对话框1.错误("接口配置无效！");
		return;
	}


	var json= {}
	json.channel_name = edit_channel_name.取内容();
	json.channel_plugin = channel_plugin;
	json.currency_id = currency_id;
	json.pay_min = pay_min;
	json.pay_max = pay_max;
	json.channel_method = dropbox_channel_method.取项目标题(dropbox_channel_method.取现行选中项());
	json.channel_submit = edit_channel_submit.取内容();
	json.channel_config = edit_channel_config.取内容();

	if(ID < 1 ){
		m_post = 公用模块.生成提交数据(0, "newpay_channel_info", "", "insert" , 0, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/insert",m_password);
	}else{
		m_post = 公用模块.生成提交数据(ID, "newpay_channel_info", "", "update" , 0, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/update",m_password);
	}
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);


}
function 按钮_说明_被单击(){
	HPtools1.打开网页("/newpay/channelconfig.html");
}
function 按钮_支付方式_被单击(){
	if(ID < 1 ){
		仔仔弹出对话框1.错误("请先保存！");
		return;
	}
	dropbox_pay_type.置现行选中项(0);
	弹出面板1.显示();
}
function 按钮_添加_被单击(){
	if(ID < 1 ){
		仔仔弹出对话框1.错误("请先保存！");
		return;
	}
	var type_id = dropbox_pay_type.取项目标记(dropbox_pay_type.取现行选中项());
	if(type_id == "" ){
		仔仔弹出对话框1.错误("请选择支付方式！");
		return;
	}
	弹出面板1.隐藏();
	var json = {"type_id": type_id}
	m_post = 公用模块.生成提交数据(ID, "newpay_channel_info_type", "", "insert" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/insert",m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 列表框1_按钮被单击(项目索引){
	if(HPtools1.询问框("是否删除支付方式：" + 列表框1.取项目标题(项目索引)) == false ){
		return;
	}
	var _id= 转换操作.到数值(列表框1.取项目标记(项目索引));
	m_post = 公用模块.生成提交数据(_id, "newpay_channel_info_type", "", "delete" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/delete",m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 按钮_代付_被单击(){
	if(ID < 1 ){
		仔仔弹出对话框1.错误("请先保存！");
		return;
	}
	var currency_id = 转换操作.到数值(dropbox_currency_id.取项目标记(dropbox_currency_id.取现行选中项()));
	if(currency_id < 0 ){
		仔仔弹出对话框1.错误("请选择：币种！");
		return;
	}
	var plugin= dropbox_channel_plugin.取项目标记(dropbox_channel_plugin.取现行选中项());

	if(plugin == "llspayment" ){
		var type_list = [{"key":"10", "value": "银行出款"}, {"key":"7g", "value": "钱包出款"}];
		var bank_num = [];
		bank_num[0] = {"key": "36000002", "value": "BRI"}
		bank_num[1] = {"key": "36000003", "value": "BNI"}
		bank_num[2] = {"key": "36000006", "value": "CIMB"}
		bank_num[3] = {"key": "36000007", "value": "PERMATA"}
		弹出代付操作页面(plugin, currency_id, type_list, "必填", "必填", bank_num, "必填", "必填", "必填", "单位：分,这里需要输入整数！代付10元需输入1000");


	}else{
		仔仔弹出对话框1.错误("该插件无此功能！");
	}


}

function 弹出代付操作页面(plugin, currency_id, type_list, acc_name, acc_num, bank_num_list, bank_name, phone, email, amount){
	// plugin: 插件名称;
	// currency_id: 币种档案ID;
	// type_list: 代付出款类型, list 格式, 如果是 [],代表隐藏此参数的选择, 单个元素：{"key": "10", "value": "银行出款"}
	// acc_name: 收款人姓名编辑框提示内容,非字符串代表隐藏此参数的输入;
	// acc_num: 银行卡号编辑框提示内容,非字符串代表隐藏此参数的输入;
	// bank_num_list: 银联号,list 格式, 如果是 [],代表隐藏此参数的选择, 单个元素：{"key": "36000002", "value": "BRI"}
	// bank_name: 银行名称编辑框提示内容,非字符串代表隐藏此参数的输入;
	// phone: 手机号编辑框提示内容,非字符串代表隐藏此参数的输入;
	// email: 电子邮箱编辑框提示内容,非字符串代表隐藏此参数的输入;
	// amount: 代付金额编辑框提示内容,非字符串不会隐藏此参数的输入;
	if(typeof amount != "string" ){
		amount = "";
	}
	amount = 文本操作.删首尾空(amount);
	if(typeof type_list != "object" ){
		type_list = [];
	}
	var url = "/admin/channelpayment.html?plugin=" + plugin + "&currency=" + currency_id + "&id=" + ID;
	url = url + "&type_list=" + 加密操作1.url编码(转换操作.json转文本(type_list));
	if(typeof acc_name == "string" ){
		url = url + "&acc_name=" + 加密操作1.url编码(acc_name);
	}
	if(typeof acc_num == "string" ){
		url = url + "&acc_num=" + 加密操作1.url编码(acc_num);
	}
	amount = 文本操作.删首尾空(amount);
	if(typeof bank_num_list != "object" ){
		bank_num_list = [];
	}
	url = url + "&bank_num=" + 加密操作1.url编码(转换操作.json转文本(bank_num_list));
	if(typeof bank_name == "string" ){
		url = url + "&bank_name=" + 加密操作1.url编码(bank_name);
	}
	if(typeof phone == "string" ){
		url = url + "&phone=" + 加密操作1.url编码(phone);
	}
	if(typeof email == "string" ){
		url = url + "&email=" + 加密操作1.url编码(email);
	}
	if(typeof amount == "string" ){
		url = url + "&amount=" + 加密操作1.url编码(amount);
	}
	window.open(url);

}