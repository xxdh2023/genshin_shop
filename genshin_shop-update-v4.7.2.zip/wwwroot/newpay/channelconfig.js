mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 标签1 = new 标签("标签1",null);
var 标签_文档 = new 标签("标签_文档",null);
if(mui.os.plus){
    mui.plusReady(function() {
        说明文档_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        说明文档_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

function 说明文档_创建完毕(){
	标签_文档.置标题(生成说明文档());
}

function 生成说明文档(){
	var title = "通用说明：请求方式、请求接口地址 需与三方接口文档一致;";
	title = title + "<br><br><br>支付插件：易支付(v1版)";
	title = title + "<br><br>可用币种：人民币, 支付方式：收银台、微信支付、支付宝;";
	title = title + "<br><br>请求接口地址：以 submit.php 结尾的页面跳转地址;";
	title = title + "<br><br>接口配置示例：{\"pid\": \"1000\", \"key\": \"Y3CpcOE5mxgZ8LryXEHajfnQBGnEumh1\", ";
	title = title + "\"sitename\":\"\"};";
	title = title + "<br><br>接口配置说明：pid ==> 商户ID, key ==> 商户密钥, sitename ==> 可空,与三方接口一致;";

	title = title + "<br><br><br>支付插件：乐力付";
	title = title + "<br><br>可用币种：印尼盾, 支付方式：VA Bank (网银支付)、QRIS (扫码付)、DANA H5 (H5支付);";
	title = title + "<br><br>接口配置示例：{\"mackeyid\": \"921002030300000\", \"mak\": \"5c0dc7aa03ec2f51e00647ca57622ec6\"};";
	title = title + "<br><br>接口配置说明：mackeyid ==> 商户macKeyId, mak ==> 依照开发文档中的：1.4.2 签名机制, 是MAK码生成的值;";


	return title;
}