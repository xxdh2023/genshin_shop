mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 时钟1 = new 时钟("时钟1",null);
var 网络操作1 = new 网络操作("网络操作1",null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var div_head_panel = new 面板("div_head_panel");
var div_register_title = new 标签("div_register_title",null);
var div_register_close = new 图片框("div_register_close",div_register_close_被单击);
var div_pay_lable_1 = new 标签("div_pay_lable_1",null);
var div_pay_model = new 按钮组("div_pay_model",div_pay_model_被单击);
var div_pay_lable_2 = new 标签("div_pay_lable_2",null);
var div_pay_btns_1 = new 按钮组("div_pay_btns_1",div_pay_btns_1_被单击);
var div_pay_btns_2 = new 按钮组("div_pay_btns_2",div_pay_btns_2_被单击);
var div_pay_btns_3 = new 按钮组("div_pay_btns_3",div_pay_btns_3_被单击);
var div_pay_btns_4 = new 按钮组("div_pay_btns_4",div_pay_btns_4_被单击);
var div_pay_btn_cdk = new 按钮("div_pay_btn_cdk",div_pay_btn_cdk_被单击,null,null);
var div_pay_test_btn = new 按钮("div_pay_test_btn",div_pay_test_btn_被单击,null,null);
var div_pay_test_btn2 = new 按钮("div_pay_test_btn2",div_pay_test_btn2_被单击,null,null);
var div_pay_id = new 标签("div_pay_id",null);
var HK蓝鸟1 = new HK蓝鸟("HK蓝鸟1");
if(mui.os.plus){
    mui.plusReady(function() {
        平台币充值_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        平台币充值_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var pay_model="alipay";
var submit_model= 1;
var is_test= false;
var invest_scale= 1;
var submit_model= 1;
var pay_proportion= 1;
var pay_id= "";
var mask_id= "coinpay";

function 平台币充值_创建完毕(){
	根地址 = HPtools1.取URL();
	var int= 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("test")));
	if(int == 1 ){
		is_test = true;
	}
	生成界面();
	弹出面板初始化();
	invest_scale = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("invest")));
	pay_id = 文本操作.删首尾空(窗口操作.取当前页面参数("id"));
	submit_model = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("model")));
	pay_proportion = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("proportion")));
	if(invest_scale <= 0 || pay_id == "" || submit_model <= 0 || pay_proportion <= 0 ){
		window.parent.显示提示消息("非法调用",false);
		window.parent.关闭充值遮罩及等待框();
		关闭本窗口();
	}
	发起后渲染充值按钮();
	div_pay_id.置标题(pay_id);
	if (!window.parent.我的信息查询) {div_pay_lable_1.置标题("<br>您的平台不足！"+div_pay_lable_1.取标题())}
	window.parent.关闭充值遮罩及等待框();
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_pay_model.置样式(0,"mui-btn mui-btn-success");

	if(is_test == true ){
		div_pay_test_btn.置可视(true);
		div_pay_test_btn2.置可视(true);
	}
}
function 生成界面(){
	var 窗口宽度= 窗口操作.取窗口宽度();
	div_head_panel.置高度("40px");
	div_head_panel.添加组件("div_register_title","100%");
	HK蓝鸟1.设置属性("div_register_title","[定位:绝对定位]");
	div_head_panel.添加组件("div_register_close","24px");

	HK蓝鸟1.设置属性("div_register_close","[定位:绝对定位][左边:"+转换操作.到文本(窗口宽度-10-50)+"px][顶边:8px]");
	div_register_close.置圆角("6px");
}
function 发起后渲染充值按钮(){
	if(pay_proportion < 1 ){
		pay_proportion = 1;
	}
	var str= "";
	if(pay_proportion > 1 ){
		str = "[限时优惠：充赠比"+转换操作.到文本(pay_proportion)+"倍]";
	}
	if(submit_model < 10 ){
		div_pay_lable_1.置可视(true);
		div_pay_model.置可视(true);
	}else{
		div_pay_lable_1.置可视(false);
		div_pay_model.置可视(false);
	}
	div_pay_lable_2.置标题("确认要充值的金额：" + str);
	div_pay_btns_1.置标题(0, "充值6元 → "+转换操作.到文本(6*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_1.置标题(1, "充值18元 → "+转换操作.到文本(18*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_2.置标题(0, "充值58元 → "+转换操作.到文本(58*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_2.置标题(1, "充值98元 → "+转换操作.到文本(98*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_3.置标题(0, "充值198元 → "+转换操作.到文本(198*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_3.置标题(1, "充值328元 → "+转换操作.到文本(328*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_4.置标题(0, "充值648元 → "+转换操作.到文本(648*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_4.置标题(1, "充值1000元 → "+转换操作.到文本(1000*pay_proportion*invest_scale)+"平台币");
}

function div_pay_model_被单击(按钮索引){
	div_pay_model.置样式(0,"mui-btn");
	div_pay_model.置样式(1,"mui-btn");
	div_pay_model.置样式(按钮索引,"mui-btn mui-btn-success");
	pay_model = "alipay";
	if(按钮索引 == 1 ){
		pay_model = "wxpay";
	}
}

function div_pay_btns_1_被单击(按钮索引){
	var amount= 6;
	if(按钮索引 > 0 ){
		amount = 18;
	}
	通用发起真实充值(amount);
}
function div_pay_btns_2_被单击(按钮索引){
	var amount= 58;
	if(按钮索引 > 0 ){
		amount = 98;
	}
	通用发起真实充值(amount);
}
function div_pay_btns_3_被单击(按钮索引){
	var amount= 198;
	if(按钮索引 > 0 ){
		amount = 328;
	}
	通用发起真实充值(amount);
}
function div_pay_btns_4_被单击(按钮索引){
	var amount= 648;
	if(按钮索引 > 0 ){
		amount = 1000;
	}
	通用发起真实充值(amount);
}
function div_pay_btn_cdk_被单击(){
	window.parent.延时_打开兑换窗口(100);
	关闭本窗口();
}

function div_pay_test_btn_被单击(){
	通用发起真实充值(0.1);
}
function div_pay_test_btn2_被单击(){
	var str= HPtools1.输入框("请输入要充值的金额");
	str = 文本操作.删首尾空(str);
	if(str == "" ){
		return;
	}
	var num= 转换操作.到数值(str);
	if(num <= 0 ){
		仔仔弹出对话框1.错误("充值金额不能为0！");
		return;
	}
	通用发起真实充值(num);
}
function 通用发起真实充值(amount){
	公用模块.发起真实充值操作(amount, m_token, submit_model, pay_model, 仔仔弹出对话框1);
	if (window.parent.我的信息查询) {window.parent.显示提示消息("付款成功后,刷新本页面查看余额.",true)}
	else {window.parent.显示提示消息("付款成功后,请继续操作.",true)}

	关闭本窗口();
}
function 关闭本窗口(){
	window.parent.postMessage("close_" + mask_id, window.location.origin);
}
function div_register_close_被单击(){
	关闭本窗口();
}