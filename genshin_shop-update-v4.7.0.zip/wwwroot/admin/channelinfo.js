mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        支付通道管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        支付通道管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;

function 支付通道管理_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password异常,请重新登陆！"),"");
		return;
	}
	根地址 = HPtools1.取URL();
	高级表格初始化();
	刷新档案();

}

function 高级表格初始化(){
	高级表格1.添加列("xz","",0,false,false,false,false,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",260,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("channel_plugin","支付插件",160,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("cur_name","币种",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("channel_name","通道名称",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("channel_status","状态",60,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("channel_submit","请求地址",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_min","最小付款金额",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_max","最大付款金额",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_type","关联支付方式",180,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("channel_config","配置参数",300,false,false,false,false,false,false,"",false,false);

	高级表格1.添加工具栏按钮(2,false,"刷新列表");
	高级表格1.添加工具栏按钮(4,true,"添加支付通道");

	高级表格1.初始化("auto",true,true,false,true);
}

function 刷新档案(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	m_post = 公用模块.生成提交数据(0, "newpay_channel_info", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/select",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			刷新档案();
			仔仔弹出对话框1.成功("操作成功！");
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "newpay_channel_info" ){
				while(i<json.results.length){
					高级表格_添加行(json.results[i]);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(2,false,"修改");
				高级表格1.添加操作栏按钮(1,false,"启用");
				高级表格1.添加操作栏按钮(4,false,"维护");
				高级表格1.添加操作栏按钮(3,false,"删除");
				高级表格1.添加操作栏按钮(2,false,"复制");
				高级表格1.初始化("auto",true,true,false,true);
			}
		}
	}
}

function 高级表格1_工具栏按钮被单击(按钮索引){
	if(按钮索引 < 1 ){
		刷新档案();
	}else if(按钮索引 == 1 ){
		WebDialog.show({
			title: "支付通道",
			url: "channelinfone.html?password="+m_password+"&id=0",
			width: "90%",
			height: "90%",
			showClose: true,
			escapeClose: true,
			timeout: 15000,
			loadingText: "正在加载 {{progress}}%",
		});

	}
}

function 高级表格_添加行(result){
	var arr = new Array();
	var plugin = 公用模块.生成支付插件();
	arr[0] = "";
	arr[1] = result.ID;
	arr[2] = "";
	arr[3] = "unknown";
	var i=0;
	while(i<plugin.length){
		if(plugin[i].key == result.channel_plugin ){
			arr[3] = plugin[i].value;
			break;
		}
		i++
	}
	arr[4] = result.cur_name;
	arr[5] = result.channel_name;
	arr[6] = "正常";
	if(result.channel_status < 1 ){
		arr[6] = "维护";
	}
	arr[7] = result.channel_submit;
	arr[8] = result.pay_min;
	arr[9] = result.pay_max;
	arr[10] = result.type_name;
	arr[11] = result.channel_config;
	高级表格1.添加行(true,arr);

}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
		case 0 :
			WebDialog.show({
				title: "支付通道",
				url: "channelinfone.html?password="+m_password+"&id="+String(_id),
				width: "90%",
				height: "90%",
				showClose: true,
				escapeClose: true,
				timeout: 15000,
				loadingText: "正在加载 {{progress}}%",
			});
		break;
		case 1 :
			修改通道状态(_id, 1);
		break;
		case 2 :
			修改通道状态(_id, 0);
		break;
		case 3 :
			if(HPtools1.询问框("是否删除此支付通道？") == false ){
				return;
			}
			m_post = 公用模块.生成提交数据(_id, "newpay_channel_info", "", "delete" , 0, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/delete",m_password);
			美化等待框1.默认等待框("正在交互","请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
		break;
		case 4 :
			if(HPtools1.询问框("是否复制此支付通道？") == false ){
				return;
			}
			m_post = 公用模块.生成提交数据(_id, "newpay_channel_info_copy", "", "insert" , 0, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/insert",m_password);
			美化等待框1.默认等待框("正在交互","请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
		break;
	}
}

function 修改通道状态(_id, channel_status){
	var str = "维护";
	if(channel_status > 0 ){
		str = "正常";
	}
	if(HPtools1.询问框("是否将此支付通道状态修改为："+str) == false ){
		return;
	}
	m_post = 公用模块.生成提交数据(_id, "newpay_channel_info_static", "", "update" , 0, 0, {"channel_status": channel_status});
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/update",m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);

}