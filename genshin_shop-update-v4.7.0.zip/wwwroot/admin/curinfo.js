mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 面板1 = new 面板("面板1");
var 按钮组_添加 = new 按钮组("按钮组_添加",按钮组_添加_被单击);
var 列表框1 = new 列表框("列表框1",true,列表框1_表项被单击,列表框1_按钮被单击);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签1 = new 标签("标签1",null);
var edit_cur_name = new 编辑框("edit_cur_name",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var edit_cur_symbol = new 编辑框("edit_cur_symbol",null,null,null,null,null);
var 标签3 = new 标签("标签3",null);
var edit_cur_rate = new 编辑框("edit_cur_rate",null,null,null,null,null);
var 标签4 = new 标签("标签4",null);
var 按钮_保存 = new 按钮("按钮_保存",按钮_保存_被单击,null,null);
var 标签5 = new 标签("标签5",null);
if(mui.os.plus){
    mui.plusReady(function() {
        币种档案_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        币种档案_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";

var ID= -1;

function 币种档案_创建完毕(){
	弹出面板初始化();
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password异常,请重新登陆！"),"");
		return;
	}
	根地址 = HPtools1.取URL();
	面板1.添加组件("按钮组_添加", "300px");
	按钮组_添加.置样式(1, "mui-btn mui-btn-royal");
	刷新档案();


}
function 弹出面板初始化(){

	var rect = 公用模块.弹出面板初始化计算(50, 320, false);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板1.添加组件("标签1");
	弹出面板1.添加组件("edit_cur_name");
	弹出面板1.添加组件("标签2");
	弹出面板1.添加组件("edit_cur_symbol");
	弹出面板1.添加组件("标签3");
	弹出面板1.添加组件("edit_cur_rate");
	弹出面板1.添加组件("标签4");
	弹出面板1.添加组件("按钮_保存");
	弹出面板1.添加组件("标签5");


}
function 刷新档案(){
	列表框1.清空项目();
	m_post = 公用模块.生成提交数据(0, "newpay_currency_info", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/select",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			弹出面板1.隐藏();
			刷新档案();
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "newpay_currency_info" ){
				while(i<json.results.length){
					添加列表(json.results[i]);
					i++
				}
			}
		}
	}
}
function 新增档案(){
	edit_cur_name.置内容("");
	edit_cur_rate.置内容("");
	edit_cur_symbol.置内容("");
}
function 添加列表(result){
	var str = 公用模块.文本显示处理("币种名称：" + result.cur_name, "#FF00FF", 3);
	str = str + 公用模块.文本显示处理("币种符号：" + result.cur_symbol, "#000000", 3);
	if(result.ID < 1 ){
		str = str + 公用模块.文本显示处理("锚定法币", "#FF0000", 3);
	}else{
		str = str + 公用模块.文本显示处理("法币汇率：" + String(result.cur_rate) + " 比 1 (人民币)", "#FF00FF", 3);
	}
	列表框1.添加项目2(str, 转换操作.json转文本(result), "mui-btn mui-btn-primary", "编辑");
}
function 按钮组_添加_被单击(按钮索引){
	if(按钮索引 < 1 ){
		刷新档案();
	}else{
		ID = -1;
		新增档案();
		弹出面板1.显示();
	}
}
function 按钮_保存_被单击(){
	if(ID == 0 ){
		仔仔弹出对话框1.错误("锚定法币不允许修改！");
		return;
	}

	edit_cur_name.置内容(文本操作.删首尾空(edit_cur_name.取内容()));
	edit_cur_rate.置内容(文本操作.删首尾空(edit_cur_rate.取内容()));
	edit_cur_symbol.置内容(文本操作.删首尾空(edit_cur_symbol.取内容()));

	if(edit_cur_name.取内容() == "" ){
		仔仔弹出对话框1.错误("币种名称不能为空！");
		return;
	}
	if(edit_cur_symbol.取内容() == "" ){
		仔仔弹出对话框1.错误("币种符号不能为空！");
		return;
	}
	if(edit_cur_rate.取内容() == "" ){
		仔仔弹出对话框1.错误("法币汇率不能为空！");
		return;
	}
	var cur_rate= 转换操作.到数值(edit_cur_rate.取内容());
	if(cur_rate <= 0 ){
		仔仔弹出对话框1.错误("法币汇率必须大于0！");
		return;
	}
	var json= {"cur_name": edit_cur_name.取内容(), "cur_symbol": edit_cur_symbol.取内容(), "cur_rate": cur_rate}
	m_post = 公用模块.生成提交数据(ID, "newpay_currency_info", "", "" , 0, 0, json);
	if(ID < 1 ){
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/insert",m_password);
	}else{
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/update",m_password);
	}
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);


}
function 列表框1_表项被单击(项目索引,项目标题,项目标记){
	var json = 转换操作.文本转json(项目标记);
	if(json.ID < 1 ){
		仔仔弹出对话框1.错误("锚定法币不允许删除！");
		return;
	}
	if(HPtools1.询问框("是否删除币种："+json.cur_name+"？") == false ){
		return;
	}

	m_post = 公用模块.生成提交数据(json.ID, "newpay_currency_info", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/delete",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);


}
function 列表框1_按钮被单击(项目索引){
	var json = 转换操作.文本转json(列表框1.取项目标记(项目索引));
	if(json.ID < 1 ){
		仔仔弹出对话框1.错误("锚定法币不允许编辑！");
		return;
	}
	ID = json.ID;
	新增档案();
	edit_cur_name.置内容(json.cur_name);
	edit_cur_symbol.置内容(json.cur_symbol);
	edit_cur_rate.置内容(json.cur_rate);
	弹出面板1.显示();


}