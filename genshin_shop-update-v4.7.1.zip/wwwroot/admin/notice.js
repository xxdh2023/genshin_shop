mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 自由面板1 = new 自由面板("自由面板1","60px");
var 标签1 = new 标签("标签1",null);
var 自由面板2 = new 自由面板("自由面板2","50px");
var 编辑框1 = new 编辑框("编辑框1",null,null,null,null,null);
var 列表框1 = new 列表框("列表框1",false,null,null);
var 标签4 = new 标签("标签4",null);
var 编辑框2 = new 编辑框("编辑框2",null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var 编辑框3 = new 编辑框("编辑框3",null,null,null,null,null);
var 自由面板3 = new 自由面板("自由面板3","44px");
var 标签2 = new 标签("标签2",null);
var 按钮_查看日志 = new 按钮("按钮_查看日志",按钮_查看日志_被单击,null,null);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签6 = new 标签("标签6",null);
var CYS索引列表框1 = new CYS索引列表框("CYS索引列表框1",null);
var 按钮_刷新 = new 按钮("按钮_刷新",按钮_刷新_被单击,null,null);
var 按钮_加群 = new 按钮("按钮_加群",按钮_加群_被单击,null,null);
var 按钮_升级 = new 按钮("按钮_升级",按钮_升级_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        公告窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        公告窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_password="";
var m_post= "";
var m_url= "";


function 公告窗口_创建完毕(){
	窗口操作.置组件高度("标签1", "40px");
	窗口操作.置组件高度("标签2", "60px");
	编辑框1.置只读模式(true);
	编辑框2.置内容(HPtools1.取URL()+"/agent/index.html");
	编辑框2.置只读模式(true);
	编辑框3.置内容(HPtools1.取URL()+"/shop/index.html");
	编辑框3.置只读模式(true);
	var rect = 公用模块.弹出面板初始化计算(20,80,true);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板1.添加组件("标签6");
	弹出面板1.添加组件("CYS索引列表框1");
	m_post = "";
	列表框1.清空项目();
	m_url = 公用模块.生成访问链接_后端(HPtools1.取URL(),"api/admin/notice", m_password);
	美化等待框1.默认等待框("正在交互","正在获取,请稍等......");
	时钟1.开始执行(10,false);
}
function 时钟1_周期事件(){


	底层_发送网络请求(60000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			标签2.置标题("<br>最新版本："+json.comm+",&nbsp;&nbsp;&nbsp;&nbsp;本地版本："+json.model);
			if(转换操作.到数值(文本操作.子文本替换(json.comm,"\\.","")) > 转换操作.到数值(文本操作.子文本替换(json.model,"\\.","")) ){
				按钮_升级.置可视(true);
			}else{
				按钮_升级.置可视(false);
			}
			var data = 文本操作.分割文本(json.msg,"\r\n");
			var i=0;
			var str = "";
			while(i < data.length){
				str = 文本操作.删首尾空(data[i]);
				if(str != "" ){
					列表框1.添加项目2(str, "", "" ,"");
				}
				i++
			}
			json.msg=""+文本操作.子文本替换(json.msg,"\\n", "\n");

			编辑框1.置内容(json.msg);
			var i= 0;
			var v= 0;
			CYS索引列表框1.清空();
			while(i<json._id.logs.length){
				v=0;
				CYS索引列表框1.添加分组(json._id.logs[i].title);
				if(json._id.logs[i].values != null ){
					while(v < json._id.logs[i].values.length){
						if(json._id.logs[i].values[v] != "" ){
							CYS索引列表框1.添加项目(i, json._id.logs[i].values[v]);
						}
						v++
					}
				}
				i++
			}
			按钮_查看日志.置可视(true);
		}
	}
}
function 按钮_查看日志_被单击(){
	弹出面板1.显示();
}
function 按钮_刷新_被单击(){
	m_post = "";
	m_url = 公用模块.生成访问链接_后端(HPtools1.取URL(),"api/admin/notice", m_password);
	美化等待框1.默认等待框("正在交互","正在获取,请稍等......");
	时钟1.开始执行(200,false);
}
function 按钮_加群_被单击(){

}
function 按钮_升级_被单击(){
	公用模块.居中打开小窗口("update.html", 800, 600);

}