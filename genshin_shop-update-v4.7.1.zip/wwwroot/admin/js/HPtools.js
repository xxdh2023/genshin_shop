    function HPtools(name){   
        this.名称 = name;
        this.拨打电话 = function (str){
            if(str!=null){
				window.location.href = "tel:"+ str;
			}
        } 
		this.调试输出=function(str){
		console.log(str);
		}
		this.置剪贴板内容 = function(neirong){
			if(mui.os.plus){
				if (plus.os.name == "Android") {//
					var Context = plus.android.importClass("android.content.Context");
					var main = plus.android.runtimeMainActivity();
					var clip = main.getSystemService(Context.CLIPBOARD_SERVICE);
					plus.android.invoke(clip,"setText",neirong);
				}else{//
					var UIPasteboard  = plus.ios.importClass("UIPasteboard");
					var generalPasteboard = UIPasteboard.generalPasteboard();
					generalPasteboard.plusCallMethod({setValue:neirong, forPasteboardType:"public.utf8-plain-text"});
				}			
			}else{//window
                copyToClipboard(neirong);
			}
		}

		function copyToClipboard(s){
   			if(window.clipboardData){
      			window.clipboardData.setData("text",s);
   			}else{
      			(function(s){
         			document.oncopy=function(e){
            		e.clipboardData.setData("text",s);
            		e.preventDefault();
            		document.oncopy=null;
         		}
      		})(s);
      			document.execCommand("Copy");
   			}
		}
        this.取剪贴板内容 = function (){
			if(!mui.os.plus){//window
				if(window.clipboardData){
      			    return window.clipboardData.getData("text");//只有IE可用
   			    }else{
				    console.log("当前浏览器无效！");
				    return "";
				}
			}
			if (plus.os.name == "Android") {
				var Context = plus.android.importClass("android.content.Context");
				var main = plus.android.runtimeMainActivity();
				var clip = main.getSystemService(Context.CLIPBOARD_SERVICE);
				return plus.android.invoke(clip,"getText");
			}else{
				var UIPasteboard  = plus.ios.importClass("UIPasteboard");
				var generalPasteboard = UIPasteboard.generalPasteboard();
				var clip = generalPasteboard.plusCallMethod({valueForPasteboardType:"public.utf8-plain-text"});
				return clip;
			}           
        }  
       
		this.取md5 = function (str) {
			if(str!=null){
				return CryptoJS.MD5(str);
			}else{
				return "";
			}
		}
		this.aes加密=function(str,key){
		     if(str!=null){
			      return CryptoJS.AES.encrypt(str,key);
			 }else{
				  return "";
			 }
		}
        this.aes解密=function(str,key){
		     if(str!=null){
			 	  var result = CryptoJS.AES.decrypt(str,key).toString(CryptoJS.enc.Utf8);
			      return result;
			 }else{
				  return "";
			 }
		}
		this.base64加密=function(str){
		     if(str!=null){
				var str2 = CryptoJS.enc.Utf8.parse(str);
		    	return CryptoJS.enc.Base64.stringify(str2);
			 }else{
				  return "";
			 }
		}
        this.base64解密=function(str,key){
		     if(str!=null){
			 	  var result = CryptoJS.enc.Base64.parse(str,key).toString(CryptoJS.enc.Utf8);
			      return result;
			 }else{
				  return "";
			 }
		}
		this.置Cookie=function(key,value,day){
			var exp = new Date();
			exp.setTime(exp.getTime() + day*24*60*60*1000);
			document.cookie = key + "="+ escape (value) + ";expires=" + exp.toGMTString();
		}
		this.取Cookie=function(key){
		var getCookie = document.cookie.replace(/[ ]/g,"");
        var arrCookie = getCookie.split(";")
        var tips="";
        for(var i=0;i<arrCookie.length;i++){
            var arr=arrCookie[i].split("=");
            if(key==arr[0]){
                tips=arr[1];
                break;
            }
		}
		return tips;
		}
		this.删Cookie=function(key){
		var exp = new Date();
		exp.setTime(exp.getTime() - 1);
		var cval=this.取Cookie(name);
		if(cval!=null)
		document.cookie= name + "="+cval+";expires="+exp.toGMTString();
		}
		this.关闭页面=function(){
			window.opener=null;
			window.open(" ",'_self');
 			window.close();
		}
		this.信息框= function (msg){alert(msg);}
		this.询问框= function (msg){return confirm(msg);}
		this.输入框= function (msg,defmsg){return prompt(msg,defmsg);}
		this.弹出提示 = function (msg){mui.toast(msg);}
		this.显示等待框= function (msg){
            if(mui.os.plus){
                try{
                    plus.nativeUI.showWaiting(msg);
                }catch(e){
                    console.log("'显示等待框'命令只能在手机中运行");
                }                
            }else{
                this.mytoast = document.createElement("div");
                this.mytoast.classList.add("mui-toast-container");
                this.mytoast.style.bottom = "200px";
                this.mytoast.innerHTML = "<div class=\"mui-toast-message\"><a class=\"mui-icon mui-spinner\"></a><br>" + msg + "</div>";
                document.body.appendChild(this.mytoast);   
                this.mytoast.classList.add("mui-active");           
            }           
        }
		this.关闭等待框= function (){
            if(mui.os.plus){
                try{
                    plus.nativeUI.closeWaiting();
                }catch(e){
                    console.log("'关闭等待框'命令只能在手机中运行");
                }  
            }else{
                if(this.mytoast!=null){
                    this.mytoast.classList.remove("mui-active");
                    this.mytoast.parentNode.removeChild(this.mytoast);
                    this.mytoast = null;
                }
            }              
        }
		this.取URL=function(bool){
		    var url=location.href;
		    var int=url.indexOf("/", 8);
		    if(int > 0){url=url.substring(0,int);}
		    if(bool==true){
			    var str=url.replace("///","//");
			    int=str.indexOf("//", 0);
			    if(int<=0){return url;}else
			    {
			    url=str.substring(int+2,str.length);
			    return url;
			    }
		    }
		    else{return url;}
		}
		this.usc2转ansi = function (str){
		    return unescape(str.replace(/\\u/g,"%u"));
		}
		this.ansi转usc2 = function (str){
		var temp = "",rs = "";  
			for( var i=0 , len = str.length; i < len; i++ ){  
   			 temp = str.charCodeAt(i).toString(16);  
   			 rs  += "\\u"+ new Array(5-temp.length).join("0") + temp;  
			}  
			return rs;
		}
		this.文件下载=function(url,file_name){
		if(file_name==null || file_name==''){file_name=new Date.getTime()+'.'+ url.replace(/(.*\.)/, '');}else{file_name=file_name+'';}
		var save_link = document.createElementNS("http://www.w3.org/1999/xhtml", "a");
			save_link.href = url;
			save_link.download = file_name;
			save_link.target='_blank';
			var ev = document.createEvent("MouseEvents");
			ev.initMouseEvent("click", true, false, window, 0, 0, 0, 0, 0, false, false, true, false, 0, null);
		save_link.dispatchEvent(ev);
		}
		this.取毫秒数=function(){
			var ret=new Date;
			return ret.getTime();
		}
		this.打开网页=function(url){
		if(url !=null || url !=''){window.open(url);}
		}
		this.换行符=function(type){
		if(type==null || type==0){return "\n";}else{return "<br>";}
		}
    }