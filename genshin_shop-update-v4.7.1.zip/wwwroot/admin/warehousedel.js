mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签1 = new 标签("标签1",null);
var 编辑框_玩家 = new 编辑框("编辑框_玩家",null,null,null,null,null);
var 面板1 = new 面板("面板1");
var 编辑框_条件 = new 编辑框("编辑框_条件",null,null,null,null,null);
var 按钮_查询 = new 按钮("按钮_查询",按钮_查询_被单击,null,null);
var 面板2 = new 面板("面板2");
var 按钮_删除 = new 按钮("按钮_删除",按钮_删除_被单击,null,null);
var 按钮_取消选择 = new 按钮("按钮_取消选择",按钮_取消选择_被单击,null,null);
var 悬浮按钮1 = new 悬浮按钮("悬浮按钮1",悬浮按钮1_被单击);
var CYS选择列表框1 = new CYS选择列表框("CYS选择列表框1",null);
var 按钮_加载 = new 按钮("按钮_加载",按钮_加载_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        删除玩家仓库指定资源_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        删除玩家仓库指定资源_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var oper_login= "";
var value= "";
function 删除玩家仓库指定资源_创建完毕(){
	根地址 = HPtools1.取URL();
	页面初始化();
}

function 页面初始化(){
	面板1.添加组件("编辑框_条件", "3");
	面板1.添加组件("按钮_查询", "1");
	面板2.添加组件("按钮_删除", "200px");
	面板2.添加组件("按钮_取消选择", "100px");

	悬浮按钮1.置可视(true);
	悬浮按钮1.置标题("TOP");
	悬浮按钮1.置按钮颜色("#007aff");
	悬浮按钮1.置按钮圆角("80%");
	悬浮按钮1.置按钮透明度("1");
	悬浮按钮1.置按钮宽高("60px","60px");

	悬浮按钮1.置按钮位置("10px","20px");
	document.getElementById("悬浮按钮1").style.color = "#FFFFFF";
}
function 按钮_查询_被单击(){
	刷新列表(1);
}
function 刷新列表(查询页号){
	if(查询页号 < 2 ){
		编辑框_玩家.置内容(文本操作.删首尾空(编辑框_玩家.取内容()));
		oper_login = 编辑框_玩家.取内容();
		CYS选择列表框1.清空项目();
		按钮_加载.置可视(false);
		查询页号 = 1;
		if(oper_login == "" ){
			仔仔弹出对话框1.错误("请输入玩家账号！");
			return;
		}
		编辑框_条件.置内容(文本操作.删首尾空(编辑框_条件.取内容()));
		value = 编辑框_条件.取内容();
	}
	var json = {"player": oper_login}
	m_post = 公用模块.生成提交数据(0, "warehouse_info", value, "select" , 查询页号, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在获取资源列表,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "warehouse_info" && json.model == "select" ){
				var old_num= 0;
				if(json.page < 2 ){
					CYS选择列表框1.清空项目();
				}
				page = json.page;
				按钮_加载.置可视(true);
				while(i < json.results.length){
					添加列表(json.results[i]);
					i++
				}
			}
		}
	}
}
function 添加列表(results){
	var str= "";
	if(results.oper_static < 1 ){
		str ="暂存仓库";
	}else if(results.oper_static == 1 ){
		str ="正在领取";
	}else{
		str ="已领取";
	}
	str = 公用模块.文本显示处理(results.value, "#000000", 2) + 公用模块.文本显示处理("状态："+str +" ，所属：" + results.oper_note, "#576B95", 2);
	CYS选择列表框1.添加项目(str, false, 转换操作.json转文本(results));

}
function 悬浮按钮1_被单击(){
	窗口操作.滚动到顶部();
}
function 按钮_删除_被单击(){
	if(CYS选择列表框1.取项目数() < 1 ){
		return;
	}
	var ids = [];
	var i=0;
	var str = "";
	while(i<CYS选择列表框1.取项目数()){
		if(CYS选择列表框1.取项目状态(i) == true ){
			str = CYS选择列表框1.取项目标记(i);
			str = 转换操作.文本转json(str);
			ids.push(str.ID);
		}
		i++
	}
	if(ids.length < 1 ){
		仔仔弹出对话框1.错误("请先选中要删除的资源！");
		return;
	}
	if(HPtools1.询问框("删除操作不可逆！是否继续？") == false ){
		return;
	}
	var json = {"ids": ids}
	m_post = 公用模块.生成提交数据(0, "warehouse_info", "", "delete" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 按钮_取消选择_被单击(){
	if(CYS选择列表框1.取项目数() < 1 ){
		return;
	}
	CYS选择列表框1.取消全选();
}
function 按钮_加载_被单击(){
	刷新列表(page+1);
}