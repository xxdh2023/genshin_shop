mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 文件选择器1 = new 文件选择器("文件选择器1",文件选择器1_选择完毕,文件选择器1_读入完毕,null);
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 按钮_设置图片_用户 = new 按钮("按钮_设置图片_用户",按钮_设置图片_用户_被单击,null,null);
var 按钮_设置图片_商城 = new 按钮("按钮_设置图片_商城",按钮_设置图片_商城_被单击,null,null);
var 面板1 = new 面板("面板1");
var div_warehouse_num_edit = new 编辑框("div_warehouse_num_edit",null,null,null,null,null);
var div_warehouse_num_btn = new 按钮("div_warehouse_num_btn",div_warehouse_num_btn_被单击,null,null);
var 标签1 = new 标签("标签1",null);
var 面板2 = new 面板("面板2");
var div_warehouse_max_edit = new 编辑框("div_warehouse_max_edit",null,null,null,null,null);
var div_warehouse_max_btn = new 按钮("div_warehouse_max_btn",div_warehouse_max_btn_被单击,null,null);
var 标签2 = new 标签("标签2",null);
var 面板3 = new 面板("面板3");
var div_warehouse_timeout_edit = new 编辑框("div_warehouse_timeout_edit",null,null,null,null,null);
var div_warehouse_timeout_btn = new 按钮("div_warehouse_timeout_btn",div_warehouse_timeout_btn_被单击,null,null);
var 标签3 = new 标签("标签3",null);
var div_only_usdt_edit = new 编辑框("div_only_usdt_edit",null,null,null,null,null);
var 按钮组1 = new 按钮组("按钮组1",按钮组1_被单击);
var 按钮组_换图 = new 按钮组("按钮组_换图",按钮组_换图_被单击);
var 标签4 = new 标签("标签4",null);
var 面板4 = new 面板("面板4");
var div_pay_proportion_edit = new 编辑框("div_pay_proportion_edit",null,null,null,null,null);
var div_pay_proportion_btn = new 按钮("div_pay_proportion_btn",div_pay_proportion_btn_被单击,null,null);
var 标签5 = new 标签("标签5",null);
var 标签6 = new 标签("标签6",null);
var 面板5 = new 面板("面板5");
var div_is_compress_dropbox = new 下拉框("div_is_compress_dropbox",div_is_compress_dropbox_表项被单击);
var div_is_compress_btn = new 按钮("div_is_compress_btn",div_is_compress_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        设置新特性_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        设置新特性_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var m_model= "user";
var is_compress= 1;



function 设置新特性_创建完毕(){
	弹出面板初始化();
	div_only_usdt_edit.置只读模式(true);
	按钮组1.置样式(0,"mui-btn mui-btn-royal");
	按钮组_换图.置样式(0,"mui-btn mui-btn-primary");
	根地址 = HPtools1.取URL();
	m_post = 公用模块.生成提交数据(0, "system_info", "", "", 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init435", m_password);
	美化等待框1.默认等待框("正在交互","正在更新,请稍等......");
	时钟1.开始执行(200,false);
}
function 弹出面板初始化(){
	面板1.添加组件("div_warehouse_num_edit","3");
	面板1.添加组件("div_warehouse_num_btn","1");
	面板2.添加组件("div_warehouse_max_edit","3");
	面板2.添加组件("div_warehouse_max_btn","1");
	面板3.添加组件("div_warehouse_timeout_edit","3");
	面板3.添加组件("div_warehouse_timeout_btn","1");
	面板4.添加组件("div_pay_proportion_edit","3");
	面板4.添加组件("div_pay_proportion_btn","1");
	面板5.添加组件("div_is_compress_dropbox","3");
	面板5.添加组件("div_is_compress_btn","1");
	div_is_compress_dropbox.清空项目();
	div_is_compress_dropbox.添加项目("0::关闭上传图片压缩功能");
	div_is_compress_dropbox.添加项目("1::开启上传图片压缩功能");
	div_is_compress_dropbox.置现行选中项(1);
}
function 按钮_设置图片_用户_被单击(){
	m_model = "user";
	文件选择器1.限制类型("image/jpeg,image/png,image/bmp");
	文件选择器1.开始选择();
}
function 按钮_设置图片_商城_被单击(){
	m_model = "shop";
	文件选择器1.限制类型("image/jpeg,image/png,image/bmp");
	文件选择器1.开始选择();
}
function 文件选择器1_选择完毕(文件路径,文件对象){
	文件选择器1.读入文件(文件对象,2);
}
function 文件选择器1_读入完毕(结果,内容){
	var data= "";
	var i= 文本操作.倒找文本(内容,",");
	if(i > -1 ){
		data = 文本操作.取文本右边(内容,文本操作.取文本长度(内容) - i - 1);
	}else{
		data = 内容;
	}
	if(m_model == "user" || m_model == "shop" ){
		var json= {}
		json.pic_head = data;
		m_post = 公用模块.生成提交数据(0, "pic_head", "", m_model, 0, 0, json);
	}else if(m_model == "mall_shop" || m_model == "mall_lottery" ){
		var json= {}
		json.pic_mall = data;
		m_post = 公用模块.生成提交数据(0, "pic_mall", "", m_model, 0, 0, json);
	}
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init435", m_password);
	美化等待框1.默认等待框("正在交互","正在更新图片,请稍等......");
	时钟1.开始执行(200,false);
}
function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}
function div_warehouse_num_btn_被单击(){
	update_warehouse("num");
}
function div_warehouse_max_btn_被单击(){
	update_warehouse("max");
}
function div_warehouse_timeout_btn_被单击(){
	update_warehouse("timeout");
}
function update_warehouse(model){
	if(model == "num" ){
		div_warehouse_num_edit.置内容(文本操作.删首尾空(div_warehouse_num_edit.取内容()));
		if(div_warehouse_num_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入对应数量！");
			return;
		}
		var num= 数学操作.取整数(转换操作.到数值(div_warehouse_num_edit.取内容()));
		if(num < 3 ){
			仔仔弹出对话框1.错误("数量不能小于3！");
			return;
		}
	}else if(model == "max" ){
		div_warehouse_max_edit.置内容(文本操作.删首尾空(div_warehouse_max_edit.取内容()));
		if(div_warehouse_max_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入对应数量！");
			return;
		}
		var num= 数学操作.取整数(转换操作.到数值(div_warehouse_max_edit.取内容()));
		if(num < 0 ){
			仔仔弹出对话框1.错误("数量不能小于0！");
			return;
		}
	}else if(model == "timeout" ){
		div_warehouse_timeout_edit.置内容(文本操作.删首尾空(div_warehouse_timeout_edit.取内容()));
		if(div_warehouse_timeout_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入超时时间！");
			return;
		}
		var num= 数学操作.取整数(转换操作.到数值(div_warehouse_timeout_edit.取内容()));
		if(num < 0 ){
			仔仔弹出对话框1.错误("超时时间不能小于0！");
			return;
		}
	}else{
		仔仔弹出对话框1.错误("调用越界！");
			return;
	}
	m_post = 公用模块.生成提交数据(0, "warehouse", "", model, num, 0);
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init435", m_password);
	美化等待框1.默认等待框("正在交互","正在更新,请稍等......");
	时钟1.开始执行(200,false);
}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
			if(json.table == "only_usdt" ){
				m_post = 公用模块.生成提交数据(0, "system_info", "", "", 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init435", m_password);
				美化等待框1.默认等待框("正在交互","正在更新,请稍等......");
				时钟1.开始执行(200,false);
			}
		}else if(json.static == 2 ){
			if(json.table == "system_info" ){
				if(json.msg.warehouse_num > 0 ){
					div_warehouse_num_edit.置内容(String(json.msg.warehouse_num));
				}
				div_warehouse_max_edit.置内容(String(json.msg.warehouse_max));
				div_warehouse_timeout_edit.置内容(String(json.msg.warehouse_timeout));
				if(json.msg.only_usdt < 1 ){
					div_only_usdt_edit.置内容("仅允许代理填写微信或支付宝的结算信息");
				}else{
					div_only_usdt_edit.置内容("仅允许代理填写USDT钱包地址的结算信息");
				}
				div_pay_proportion_edit.置内容(String(json.msg.pay_proportion));
				div_is_compress_dropbox.置现行选中项(json.msg.is_compress);
			}
		}
	}
}

function 按钮组1_被单击(按钮索引){
	m_post = 公用模块.生成提交数据(0, "only_usdt", "", "", 按钮索引, 0);
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init435", m_password);
	美化等待框1.默认等待框("正在交互","正在更新,请稍等......");
	时钟1.开始执行(200,false);
}
function 按钮组_换图_被单击(按钮索引){
	if(按钮索引 < 1 ){
		m_model = "mall_shop";
	}else{
		m_model = "mall_lottery";
	}
	文件选择器1.限制类型("image/jpeg,image/png,image/bmp");
	文件选择器1.开始选择();
}
function div_pay_proportion_btn_被单击(){
	div_pay_proportion_edit.置内容(文本操作.删首尾空(div_pay_proportion_edit.取内容()));
	if(div_pay_proportion_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请设置充赠比！");
		return;
	}
	var pay_proportion = 转换操作.到数值(div_pay_proportion_edit.取内容());
	if(pay_proportion < 1 ){
		仔仔弹出对话框1.错误("充赠比必须大于等于 1 ！");
		return;
	}
	var json= {}
	json.pay_proportion = pay_proportion;
	m_post = 公用模块.生成提交数据(0, "pay_proportion", "", "", 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init435", m_password);
	美化等待框1.默认等待框("正在交互","正在更新图片,请稍等......");
	时钟1.开始执行(200,false);
}
function div_is_compress_btn_被单击(){
	var json= {}
	json.is_compress = is_compress;
	m_post = 公用模块.生成提交数据(0, "is_compress", "", "", 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/init435", m_password);
	美化等待框1.默认等待框("正在交互","正在更新图片,请稍等......");
	时钟1.开始执行(200,false);
}
function div_is_compress_dropbox_表项被单击(项目索引,项目标题,项目标记){
	is_compress = 项目索引;
}