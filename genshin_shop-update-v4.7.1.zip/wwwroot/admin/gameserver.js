mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 标签1 = new 标签("标签1",null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var div_game_popover = new 弹出面板("div_game_popover",null,null);
var div_game_lable = new 标签("div_game_lable",null);
var div_game_name = new 编辑框("div_game_name",null,null,null,null,null);
var div_game_host = new 编辑框("div_game_host",null,null,null,null,null);
var div_game_port = new 编辑框("div_game_port",null,null,null,null,null);
var div_game_region = new 编辑框("div_game_region",null,null,null,null,null);
var div_game_btn = new 按钮("div_game_btn",div_game_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        游戏服务器设置_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        游戏服务器设置_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;





function 游戏服务器设置_创建完毕(){
	根地址 = HPtools1.取URL();
	高级表格初始化();
	弹出面板初始化();
	刷新列表();
}
function 高级表格初始化(){
	高级表格1.添加列("xh","",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",220,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("game_name","服务器名称",300,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("game_static","状态",80,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("game_gmapi_host","游戏端IP地址",150,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("game_gmapi_port","游戏端GM端口",150,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("game_gmapi_region","游戏端Regin参数",150,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1, false, "获取列表");
	高级表格1.添加工具栏按钮(2, false, "添加服务器");
	高级表格1.初始化("auto",true,true,false,true);


}
function 刷新列表(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	m_post = 公用模块.生成提交数据(0, "gameserver_info", "", "" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50,260, false);
	div_game_popover.初始化(rect[0], rect[1], rect[2], rect[3]);
	div_game_popover.添加组件("div_game_lable");
	div_game_popover.添加组件("div_game_name");
	div_game_popover.添加组件("div_game_host");
	div_game_popover.添加组件("div_game_port");
	div_game_popover.添加组件("div_game_region");
	div_game_popover.添加组件("div_game_btn");
}
function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "gameserver_info" ){
				if(json.model == "delete" ){
					高级表格1.删除行(转换操作.到数值(json.comm));
					高级表格1.初始化("auto",true,true,false,true);
					仔仔弹出对话框1.成功("删除成功！");
				}else if(json.model == "insert" ){
					ID = 转换操作.到数值(json.msg);
					div_game_popover.隐藏();
					刷新列表();
					仔仔弹出对话框1.成功("添加成功");
				}else{
					div_game_popover.隐藏();
					刷新列表();
					仔仔弹出对话框1.成功("更新成功");
				}
			}else if(json.table == "gameserver_info_static" ){
				刷新列表();
				仔仔弹出对话框1.成功("调整成功");

			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "gameserver_info" ){
				if(json.model != "read" ){
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "";
						arr[3] = json.results[i].game_name;
						arr[4] = "正常";
						if(json.results[i].game_static < 1 ){
							arr[4] = "失效";
						}
						arr[5] = json.results[i].game_gmapi_host;
						arr[6] = json.results[i].game_gmapi_port;
						arr[7] = json.results[i].game_gmapi_region;
						高级表格1.添加行(false,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(2,false,"编辑");
					高级表格1.添加操作栏按钮(3,false,"停用");
					高级表格1.添加操作栏按钮(2,false,"启用");
					高级表格1.添加操作栏按钮(4,false,"删除");
					高级表格1.初始化("auto",true,true,false,true);
				}else{
					ID = json.results.ID;
					div_game_name.置内容(json.results.game_name);
					div_game_host.置内容(json.results.game_gmapi_host);
					div_game_port.置内容(""+json.results.game_gmapi_port);
					div_game_region.置内容(json.results.game_gmapi_region);
					div_game_popover.显示();

				}



			}




		}
	}
}
function 高级表格1_工具栏按钮被单击(按钮索引){


	switch(按钮索引){
	case 0 :
		刷新列表();
	break;
	case 1 :
		ID = 0;
		div_game_name.置内容("");
		div_game_host.置内容("");
		div_game_port.置内容("");
		div_game_region.置内容("");
		div_game_popover.显示();
		break;
	}
}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){



	var _id= 行数据["id"];
	switch(按钮索引){
		case 0 :
			m_post = 公用模块.生成提交数据(_id, "gameserver_info", "", "read" , 1, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
			美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
			时钟1.开始执行(200,false);
		break;
		case 1 :

			if(HPtools1.询问框("是否停用？") == true ){
				var json= {}
				json.game_static = 0;
				m_post = 公用模块.生成提交数据(_id, "gameserver_info_static", "", "update" , 1, 0,json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
				时钟1.开始执行(200,false);
			}
		break;
		case 2 :

			if(HPtools1.询问框("是否启用？") == true ){
				var json= {}
				json.game_static = 1;
				m_post = 公用模块.生成提交数据(_id, "gameserver_info_static", "", "update" , 1, 0,json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
				时钟1.开始执行(200,false);
			}
		break;
		case 3 :

			if(HPtools1.询问框("是否删除？") == true ){
				m_post = 公用模块.生成提交数据(_id, "gameserver_info", ""+行索引, "delete" , 1, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
				美化等待框1.默认等待框("正在交互","正在删除,请稍等......");
				时钟1.开始执行(200,false);
			}

		break;
	}

}
function div_game_btn_被单击(){
	div_game_name.置内容(文本操作.删首尾空(div_game_name.取内容()));
	if(div_game_name.取内容() == "" ){
		仔仔弹出对话框1.错误("服务器名称不能为空");
		return;
	}
	div_game_host.置内容(文本操作.删首尾空(div_game_host.取内容()));
	if(div_game_host.取内容() == "" ){
		仔仔弹出对话框1.错误("游戏端IP地址无效");
		return;
	}
	div_game_port.置内容(文本操作.删首尾空(div_game_port.取内容()));
	if(div_game_port.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写GM端口");
		return;
	}
	var port= 转换操作.到数值(div_game_port.取内容());
	if(port < 1 ){
		仔仔弹出对话框1.错误("GM端口无效");
		return;
	}
	div_game_region.置内容(文本操作.删首尾空(div_game_region.取内容()));
	if(div_game_region.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写游戏端的Regin");
		return;
	}
	var json= {}
	json.game_name = div_game_name.取内容();
	json.game_gmapi_host = div_game_host.取内容();
	json.game_gmapi_port = port;
	json.game_gmapi_region = div_game_region.取内容();
	if(ID < 1 ){
		m_post = 公用模块.生成提交数据(0, "gameserver_info", "", "insert" , 0, 0,json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	}else{
		m_post = 公用模块.生成提交数据(ID, "gameserver_info", "", "update" , 0, 0,json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	}
	美化等待框1.默认等待框("正在交互","正在保存,请稍等......");
	时钟1.开始执行(200,false);
}