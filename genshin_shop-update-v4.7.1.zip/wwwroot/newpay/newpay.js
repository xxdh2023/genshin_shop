mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签_信息 = new 标签("标签_信息",null);
var 标签1 = new 标签("标签1",null);
var 列表框1 = new 列表框("列表框1",false,null,列表框1_按钮被单击);
var div_more_popover = new 弹出面板("div_more_popover",null,null);
var div_more_acc_name_title = new 标签("div_more_acc_name_title",null);
var div_more_acc_name_edit = new 编辑框("div_more_acc_name_edit",null,null,null,null,null);
var div_more_acc_num_title = new 标签("div_more_acc_num_title",null);
var div_more_acc_num_edit = new 编辑框("div_more_acc_num_edit",null,null,null,null,null);
var div_more_bank_num_title = new 标签("div_more_bank_num_title",null);
var div_more_bank_num_dropbox = new 下拉框("div_more_bank_num_dropbox",null);
var div_more_phone_title = new 标签("div_more_phone_title",null);
var div_more_phone_edit = new 编辑框("div_more_phone_edit",null,null,null,null,null);
var div_more_email_title = new 标签("div_more_email_title",null);
var div_more_email_edit = new 编辑框("div_more_email_edit",null,null,null,null,null);
var div_more_pay_btn = new 按钮("div_more_pay_btn",div_more_pay_btn_被单击,null,null);
var div_more_end_tips = new 标签("div_more_end_tips",null);
if(mui.os.plus){
    mui.plusReady(function() {
        newpay_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        newpay_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var coin= 0;
var order_no= "";
var popover= {}
var pay_type = "";
function newpay_创建完毕(){
	根地址 = HPtools1.取URL();
	var cur_id = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("cur_id")));
	coin = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("coin")));
	pay_type = 文本操作.删首尾空(窗口操作.取当前页面参数("pay_type"));
	if(pay_type == "" ){
		pay_type = "auto";
	}
	if(cur_id < 0 || coin <= 0 ){
		仔仔弹出对话框1.错误("非法调用！");
		return;
	}
	popover.phone = 0;
	popover.email = 0;
	popover.acc_name = 0;
	popover.acc_num = 0;
	popover.bank_num = 0;
	popover.url = "";
	页面初始化();
	弹出面板初始化();
	m_post = "";
	m_url = 公用模块.生成访问链接(根地址,"api/newpay/paypage?act=channel&cur_id="+String(cur_id)+"&coin="+String(coin)+"&pay_type="+pay_type,"");
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 页面初始化(){
	标签_信息.置标题("<br><br>...请稍等...");
	列表框1.清空项目();
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_more_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_more_popover.添加组件("div_more_acc_name_title");
	div_more_popover.添加组件("div_more_acc_name_edit");
	div_more_popover.添加组件("div_more_acc_num_title");
	div_more_popover.添加组件("div_more_acc_num_edit");
	div_more_popover.添加组件("div_more_bank_num_title");
	div_more_popover.添加组件("div_more_bank_num_dropbox");
	div_more_popover.添加组件("div_more_phone_title");
	div_more_popover.添加组件("div_more_phone_edit");
	div_more_popover.添加组件("div_more_email_title");
	div_more_popover.添加组件("div_more_email_edit");
	div_more_popover.添加组件("div_more_pay_btn");
	div_more_popover.添加组件("div_more_end_tips");



}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("/shop/index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){

			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			order_no = json.msg;
			var str= "<br><br>本次充值平台币数量：" + String(coin) + " 平台币";
			if(json.currency.proportion > 1 ){
				str = str + "<br><br>本次充值限时特惠：多送 "+String(数学操作.四舍五入(json.currency.proportion-1 * 100, 2))+"%, 总计获得："+String(数学操作.四舍五入(coin * json.currency.proportion, 2))+" 平台币";
			}
			var money_cny = 数学操作.四舍五入(coin / json.currency.invest, 2);
			str = str + "<br><br>本次充值付款金额：" + String(数学操作.四舍五入(money_cny * json.currency.cur_rate, 2)) + " " + json.currency.cur_symbol + ", " + json.currency.cur_name;
			if(json.currency.cur_id > 0 ){
				str = str + "<br><br>与人民币换算比例：" + String(json.currency.cur_rate) + " " + json.currency.cur_name + " : 1 人民币";
				str = str + "<br><br>对应的人民币金额：" + String(money_cny) + " 人民币 (CNY)";
			}

			标签_信息.置标题(str);
			标签1.置可视(true);
			列表框1.清空项目();
			while(i<json.channel.length){
				str = 公用模块.文本显示处理(json.channel[i].channel_name, "#FF00FF", 4);
				str = str + 公用模块.文本显示处理("[ "+json.channel[i].type_name+" ] [ "+json.channel[i].channel_plugin+" ]", "#000000", 2);
				列表框1.添加项目(str, 转换操作.json转文本(json.channel[i]), "mui-btn mui-btn-success", "付款");
				i++
			}

		}
	}
}
function 列表框1_按钮被单击(项目索引){
	var channel = 转换操作.文本转json(列表框1.取项目标记(项目索引));
	var channel_id= channel.channel_id;
	if(channel_id < 1 ){
		仔仔弹出对话框1.错误("列表数据异常,请重新发起充值！");
		return;
	}
	if(order_no == "" ){
		仔仔弹出对话框1.错误("页面交互异常,请重新发起充值！");
		return;
	}
	var url = 根地址 + "/api/newpay/paypage?act=start&channel_id="+String(channel_id)+"&order_no="+order_no+"&root_url="+加密操作1.url编码(根地址);

	if(channel.channel_plugin == "epay" ){
		发起同步跳转(url);
		return;
	}
	if(channel.channel_plugin == "llspayment" ){
		popover.phone = 1;
		popover.email = 1;
		var bank_num = [];
		if(pay_type == "va" ){
			popover.acc_name = 1;
			popover.acc_num = 1;
			popover.bank_num = 1;
			bank_num[0] = {"key": "36000002", "value": "BRI"}
			bank_num[1] = {"key": "36000003", "value": "BNI"}
			bank_num[2] = {"key": "36000006", "value": "CIMB"}
			bank_num[3] = {"key": "36000007", "value": "PERMATA"}
		}
		popover.url = url;
		弹出更多参数页面(bank_num);
		return;
	}





	仔仔弹出对话框1.错误("支付插件无效！");
}

function 发起同步跳转(url, more_param){
	if(typeof more_param != "string" ){
		more_param = "";
	}
	more_param = 文本操作.删首尾空(more_param);
	if(more_param != "" ){
		if(文本操作.取文本左边(more_param, 1) != "&" ){
			more_param = "&" + more_param;
		}
	}
	window.location.replace(url + more_param);

}


function 弹出更多参数页面(json_bank_num){
	div_more_acc_name_title.置可视(false);
	div_more_acc_name_edit.置可视(false);
	div_more_acc_name_edit.置内容("");
	div_more_acc_num_title.置可视(false);
	div_more_acc_num_edit.置可视(false);
	div_more_acc_num_edit.置内容("");
	div_more_bank_num_title.置可视(false);
	div_more_bank_num_dropbox.置可视(false);
	div_more_bank_num_dropbox.清空项目();
	div_more_phone_title.置可视(false);
	div_more_phone_edit.置可视(false);
	div_more_phone_edit.置内容("");
	div_more_email_title.置可视(false);
	div_more_email_edit.置可视(false);
	div_more_email_edit.置内容("");
	div_more_pay_btn.置可视(false);
	var show_pay_btn = false;
	if(popover.acc_name == 1 ){
		div_more_acc_name_title.置可视(true);
		div_more_acc_name_edit.置可视(true);
		show_pay_btn = true;
	}
	if(popover.acc_num == 1 ){
		div_more_acc_num_title.置可视(true);
		div_more_acc_num_edit.置可视(true);
		show_pay_btn = true;
	}
	if(popover.bank_num == 1 ){
		if(Array.isArray(json_bank_num) == false ){
			json_bank_num = [];
		}
		var num = json_bank_num.length;
		if(num < 1 ){
			div_more_bank_num_dropbox.添加项目("银行列表无效！", "");
		}else{
			var i=0;
			div_more_bank_num_dropbox.添加项目("请选择支付银行......", "");
			while(i<num){
				div_more_bank_num_dropbox.添加项目(json_bank_num[i].value, json_bank_num[i].key);

				i++
			}
		}
		div_more_bank_num_dropbox.置现行选中项(0);
		div_more_bank_num_title.置可视(true);
		div_more_bank_num_dropbox.置可视(true);
		show_pay_btn = true;
	}

	if(popover.phone == 1 ){
		div_more_phone_title.置可视(true);
		div_more_phone_edit.置可视(true);
		show_pay_btn = true;
	}
	if(popover.email == 1 ){
		div_more_email_title.置可视(true);
		div_more_email_edit.置可视(true);
		show_pay_btn = true;
	}

	if(show_pay_btn == true ){
		div_more_pay_btn.置可视(true);
	}
	div_more_popover.滚动条到顶部();
	div_more_popover.显示();
}
function div_more_pay_btn_被单击(){
	div_more_acc_name_edit.置内容(文本操作.删首尾空(div_more_acc_name_edit.取内容()));
	div_more_acc_num_edit.置内容(文本操作.删首尾空(div_more_acc_num_edit.取内容()));
	div_more_phone_edit.置内容(文本操作.删首尾空(div_more_phone_edit.取内容()));
	div_more_email_edit.置内容(文本操作.删首尾空(div_more_email_edit.取内容()));

	var more_param = "";
	if(popover.acc_name == 1 ){
		if(div_more_acc_name_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入付款人姓名！");
			return;
		}else{
			more_param = more_param + "&acc_name=" + div_more_acc_name_edit.取内容();
		}

	}
	if(popover.acc_num == 1 ){
		if(div_more_acc_num_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入付款卡号！");
			return;
		}else{
			more_param = more_param + "&acc_num=" + div_more_acc_num_edit.取内容();
		}

	}
	if(popover.bank_num == 1 ){
		var bank_num= div_more_bank_num_dropbox.取项目标记(div_more_bank_num_dropbox.取现行选中项());
		if(bank_num == "" ){
			仔仔弹出对话框1.错误("请选择支付银行！");
			return;
		}else{
			more_param = more_param + "&bank_num=" + bank_num;
		}

	}

	if(popover.phone == 1 ){
		if(div_more_phone_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入手机号！");
			return;
		}else{
			more_param = more_param + "&phone=" + div_more_phone_edit.取内容();
		}

	}
	if(popover.email == 1 ){
		if(div_more_email_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入电子邮箱！");
			return;
		}else{
			more_param = more_param + "&email=" + div_more_email_edit.取内容();
		}
	}




	div_more_popover.隐藏();
	发起同步跳转(popover.url, more_param);
}
