(function (){ 
window["公用模块"] = {}
function 延时发起访问请求(网络操作, post, url, 毫秒延时, 超时时长, 增强协议头){
	var mypost = post;
	var myurl = url;
	var timeout = 0;
	var type= typeof 超时时长;
	if(type != "number" ){
		timeout = 50000;
	}else{
		timeout = 超时时长;
		if(timeout < 50000 ){
			timeout = 50000;
		}
	}
	if(毫秒延时 < 5 ){
		毫秒延时 = 5;
	}
	var method="post";
	if(mypost == "" ){
		method="get";
	}
	if(增强协议头 == true ){
		网络操作.置附加请求头({"Content-Type":"application/json","Content-Length":  "10000000"});
		网络操作.置附加请求头();
	}else{
		网络操作.置附加请求头({"Content-Type":"application/json"});
	}
	setTimeout(function() {
		网络操作.发送网络请求(myurl,method,"text",mypost,timeout);
	}, 毫秒延时);
}
function 文本显示处理(待处理的文本, 显示颜色, 字体大小){
	var 类型= typeof 字体大小;
	if(类型 == "number" ){
		if(字体大小 < 1 ){
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+";\">"+待处理的文本+"</p>";
		}else if(字体大小 < 5 ){
			字体大小 = 数学操作.取整数(9 + 字体大小 * 2);
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+"; font-size:"+String(字体大小)+"px;\">"+待处理的文本+"</p>";
		}else{
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+"; font-size:"+String(字体大小)+"px;\">"+待处理的文本+"</p>";
		}
	}else{
		return "<p class=\"inline_block\" style=\"color:"+显示颜色+";\">"+待处理的文本+"</p>";
	}

}
function 生成访问链接(url,api_key, token){
	url = 文本操作.删首尾空(url);
	api_key = 文本操作.删首尾空(api_key);
	token = 文本操作.删首尾空(token);
	if(url == "" || api_key == "" ){
		return "";
	}
	if(文本操作.取文本右边(url,1) != "/" && 文本操作.取文本左边(api_key,1) != "/" ){
		url = url + "/";
	}
	if(token == "" ){
		str= url + api_key;
	}else{
		str= url + api_key + "?token="+token;
	}
	return str;
}

function 弹出面板初始化计算(左边, 顶边或高度, 真高度动态假顶边动态){




	var 窗口高度= 窗口操作.取窗口高度();
	var 窗口宽度= 窗口操作.取窗口宽度();
	if(左边 < 0 ){
		窗口宽度 = 数学操作.取绝对值(左边);
		if(窗口宽度 > 窗口操作.取窗口宽度() ){
			窗口宽度 = 窗口操作.取窗口宽度();
		}
		左边 = (窗口操作.取窗口宽度() - 窗口宽度)/2;
	}else{
		窗口宽度 = 窗口操作.取窗口宽度()-左边*2;
	}
	var 顶边= 0;
	if(真高度动态假顶边动态 == true ){
		顶边 = 顶边或高度;
		窗口高度 = 窗口高度-顶边或高度 * 2;

	}else{
		顶边 = 窗口高度/2 - 顶边或高度/2;
		窗口高度 = 顶边或高度;
	}


	var ret = new Array();
	ret[0] = ""+左边+"px";
	ret[1] = ""+顶边+"px";
	ret[2] = ""+窗口宽度+"px";
	ret[3] = ""+窗口高度+"px";
	return ret;
}
window["公用模块"]["延时发起访问请求"]=延时发起访问请求;
window["公用模块"]["文本显示处理"]=文本显示处理;
window["公用模块"]["生成访问链接"]=生成访问链接;
window["公用模块"]["弹出面板初始化计算"]=弹出面板初始化计算;
})();