mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var CCS类库1 = new CCS类库("CCS类库1");
var 标签9 = new 标签("标签9",null);
var div_oper_login = new 编辑框("div_oper_login",null,null,null,null,null);
var div_oper_name = new 编辑框("div_oper_name",null,null,null,null,null);
var div_oper_static = new 标签("div_oper_static",null);
var div_oper_model = new 标签("div_oper_model",null);
var div_oper_email = new 编辑框("div_oper_email",null,null,null,null,null);
var div_oper_question_dropbox = new 下拉框("div_oper_question_dropbox",div_oper_question_dropbox_表项被单击);
var div_oper_answer = new 编辑框("div_oper_answer",null,null,null,null,null);
var div_agent_oper = new 标签("div_agent_oper",null);
var div_agent_level = new 标签("div_agent_level",null);
var div_game_uid = new 标签("div_game_uid",null);
var div_vip_id = new 编辑框("div_vip_id",null,null,null,null,null);
var div_agent_re_scale = new 编辑框("div_agent_re_scale",null,null,null,null,null);
var 按钮组_操作 = new 按钮组("按钮组_操作",按钮组_操作_被单击);
if(mui.os.plus){
    mui.plusReady(function() {
        用户档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        用户档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;
var m_json= {}
var oper_question= "";







function 用户档案窗口_创建完毕(){
	div_vip_id.置只读模式(true);
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	ID = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("ID")));
	if(m_password == "" ){
		仔仔弹出对话框1.错误("password异常,请关闭后重试！");
		return;
	}
	根地址 = HPtools1.取URL();
	div_oper_question_dropbox.添加项目("请选择重置密码问题......","");
	div_oper_question_dropbox.添加项目("您所在的城市","您所在的城市");
	div_oper_question_dropbox.添加项目("您所在的国家","您所在的国家");
	div_oper_question_dropbox.添加项目("您最难忘的事是什么","您最难忘的事是什么");
	div_oper_question_dropbox.添加项目("您最难忘的是哪句话","您最难忘的是哪句话");
	档案查询();
}
function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info" ){
				if(json.model == "insert" ){
					ID = 转换操作.到数值(json.msg);
					div_oper_login.置只读模式(true);
					仔仔弹出对话框1.成功("添加成功,登陆密码：123456");
				}else if(json.model == "update" ){
					仔仔弹出对话框1.成功("更新成功！");
				}


			}else{
				仔仔弹出对话框1.成功("执行成功！");
			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "oper_login_info" ){
				档案新增();
				ID = json.results.ID;
				div_oper_login.置只读模式(true);
				div_oper_login.置内容(json.results.oper_login);
				div_oper_name.置内容(json.results.oper_name);
				div_oper_static.置标题("用户状态：正常");
				if(json.results.oper_static < 1 ){
					div_oper_static.置标题("用户状态：已封禁");
				}
				div_oper_model.置标题("用户类型：代理账号");
				div_agent_oper.置可视(false);
				div_agent_level.置可视(false);
				div_game_uid.置可视(false);
				div_vip_id.置可视(false);
				div_agent_re_scale.置可视(false);
				div_agent_oper.置标题("上级代理：");
				div_agent_level.置标题("代理等级：");
				div_game_uid.置标题("绑定UID：");
				if(json.results.oper_model < 1 ){
					div_oper_model.置标题("用户状态：玩家账号");
					if(json.results.vip_id != "" ){
						div_vip_id.置内容(json.results.vip_id+" :: " + json.results.vip_name);
					}
					div_vip_id.置可视(true);
					div_game_uid.置标题("绑定UID：" + 转换操作.到文本(json.results.game_uid));
					div_game_uid.置可视(true);
				}else{
					if(json.results.agent_oper != "" ){
						div_agent_oper.置标题("上级代理："+json.results.agent_oper+" :: " +json.results.agent_name);
					}
					div_agent_oper.置可视(true);
					div_agent_level.置标题("代理等级："+转换操作.到文本(json.results.agent_level)+"级代理");
					div_agent_re_scale.置内容(""+json.results.agent_re_scale);
					div_agent_re_scale.置可视(true);
					div_agent_re_scale.置只读模式(true);
					div_agent_level.置可视(true);
					div_oper_email.置内容(json.results.oper_email);
					div_oper_answer.置内容(json.results.oper_answer);
					oper_question = json.results.oper_question;
					var v= 0;
					while(i < div_oper_question_dropbox.取项目总数()){
						if(div_oper_question_dropbox.取项目标记(i) == json.results.oper_question ){
							div_oper_question_dropbox.置现行选中项(i);
							break;
						}
						i++
					}
				}
			}




		}
	}
}
function 档案查询(){
	if(ID > 0 ){
		m_post = 公用模块.生成提交数据(ID, "oper_login_info", "", "read" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		时钟1.开始执行(200,false);
	}
}
function 档案新增(){
	ID = 0;
	div_oper_login.置内容("");
	div_oper_login.置只读模式(false);
	div_oper_name.置内容("");
	div_oper_static.置标题("用户状态：正常");
	div_oper_model.置标题("用户类型：代理账号");
	div_oper_email.置内容("");
	div_oper_answer.置内容("");
	div_vip_id.置内容("");
	div_agent_oper.置标题("上级代理：");
	div_agent_level.置标题("代理等级：");
	div_game_uid.置标题("绑定UID：");
	div_agent_re_scale.置只读模式(false);
	div_agent_re_scale.置内容("");
}
function div_oper_question_dropbox_表项被单击(项目索引,项目标题,项目标记){
	oper_question = 项目标记;
}
function 按钮组_操作_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否新增？") == true ){
				档案新增();
			}
		break;
		case 1 :
			if(div_oper_model.取标题() == "用户状态：玩家账号" ){
				仔仔弹出对话框1.错误("玩家账号不能在此修改！");
				return;
			}
			div_oper_login.置内容(文本操作.删首尾空(div_oper_login.取内容()));
			if(div_oper_login.取内容() == "" ){
				仔仔弹出对话框1.错误("账号不能为空！");
				return;
			}





			div_oper_email.置内容(文本操作.删首尾空(div_oper_email.取内容()));
			if(div_oper_email.取内容() == "" ){
				仔仔弹出对话框1.错误("电子邮箱不能为空！");
				return;
			}
			if(oper_question == "" ){
				仔仔弹出对话框1.错误("请选择重置密码问题！");
				return;
			}
			div_oper_answer.置内容(文本操作.删首尾空(div_oper_answer.取内容()));
			if(div_oper_answer.取内容() == "" ){
				仔仔弹出对话框1.错误("请输入重置密码的答案！");
				return;
			}
			div_agent_re_scale.置内容(文本操作.删首尾空(div_agent_re_scale.取内容()));
			if(div_agent_re_scale.取内容() == "" ){
				仔仔弹出对话框1.错误("请输入返佣比例！");
				return;
			}
			var agent_re_scale= 转换操作.到数值(div_agent_re_scale.取内容());
			if(agent_re_scale < 1 || agent_re_scale > 99 ){
				仔仔弹出对话框1.错误("输入的返佣比例越界！");
				return;
			}
			var json= {}
			json.oper_login = div_oper_login.取内容();

			json.oper_email = div_oper_email.取内容();
			json.oper_question = oper_question;
			json.oper_answer = div_oper_answer.取内容();
			json.agent_re_scale = agent_re_scale;
			if(ID < 1 ){
				m_post = 公用模块.生成提交数据(ID, "oper_login_info", "", "insert" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
				美化等待框1.默认等待框("正在交互","正在添加档案,请稍等......");
			}else{
				m_post = 公用模块.生成提交数据(ID, "oper_login_info", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在更新档案,请稍等......");
			}
			时钟1.开始执行(200,false);
		break;
	}
}