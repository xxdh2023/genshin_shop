mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 文件选择器1 = new 文件选择器("文件选择器1",null,null,null);
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签1 = new 标签("标签1",null);
var div_clear_date = new 按钮("div_clear_date",div_clear_date_被单击,null,null);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
var 标签2 = new 标签("标签2",null);
var chk_inout_info_cash = new 复选框("chk_inout_info_cash",null);
var chk_inout_info_coin_add_lottery_add_other_add_pay = new 复选框("chk_inout_info_coin_add_lottery_add_other_add_pay",null);
var 标签4 = new 标签("标签4",null);
var chk_inout_info_coin_lottery = new 复选框("chk_inout_info_coin_lottery",null);
var 标签5 = new 标签("标签5",null);
var chk_log_info_mail_add_notify_add_shop_add_warehouse = new 复选框("chk_log_info_mail_add_notify_add_shop_add_warehouse",null);
var 标签3 = new 标签("标签3",null);
var 复选框_备份 = new 复选框("复选框_备份",null);
var 按钮_清理 = new 按钮("按钮_清理",按钮_清理_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        数据清理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        数据清理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var clear_date= "";


function 数据清理_创建完毕(){
	根地址 = HPtools1.取URL();
	CYS日期时间选择器1.初始化(1, 2023, 2099);
}
function div_clear_date_被单击(){
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	div_clear_date.置标题(res);
}
function 按钮_清理_被单击(){
	if(复选框_备份.取选中状态() == false ){
		仔仔弹出对话框1.错误("请先备份数据库,并勾选：我已备份数据，可以清理");
		return;
	}
	var str= "";
	var json={}
	json.chk_cash = 0;
	if(chk_inout_info_cash.取选中状态() == true ){
		str = "代理提现数据；";
		json.chk_cash = 1;
	}
	json.chk_inout = 0;
	if(chk_inout_info_coin_add_lottery_add_other_add_pay.取选中状态() == true ){
		if(str != "" ){
			str = str + "\n";
		}
		str = str + "商城消费数据（含充值、消费、营收）；";
		json.chk_inout = 1;
	}
	json.chk_lottery = 0;
	if(chk_inout_info_coin_lottery.取选中状态() == true ){
		if(str != "" ){
			str = str + "\n";
		}
		str = str + "抽奖类数据；";
		json.chk_lottery = 1;
	}
	json.chk_log = 0;
	if(chk_log_info_mail_add_notify_add_shop_add_warehouse.取选中状态() == true ){
		if(str != "" ){
			str = str + "\n";
		}
		str = str + "日志类数据；";
		json.chk_log = 1;
	}
	if(str == "" ){
		仔仔弹出对话框1.错误("请至少选择一项要清理的数据！");
		return;
	}
	json.clear_date = div_clear_date.取标题();
	var key= 文本操作.删首尾空(HPtools1.输入框("本次清理信息：\n\n小于此日期："+json.clear_date+"；\n\n清理项目：\n"+str+"\n\n请输入【确认清理】进行清理"));
	if(key != "确认清理" ){
		return;
	}
	m_post = 公用模块.生成提交数据(0, "system_clear_data", "", "delete", 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址, "api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在更新,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}
	}
}
