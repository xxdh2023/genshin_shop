mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签1 = new 标签("标签1",null);
var 按钮组_顶部 = new 按钮组("按钮组_顶部",按钮组_顶部_被单击);
var 标签4 = new 标签("标签4",null);
var 面板1 = new 面板("面板1");
var 标签2 = new 标签("标签2",null);
var 编辑框_账号 = new 编辑框("编辑框_账号",null,null,null,null,null);
var 面板2 = new 面板("面板2");
var 标签3 = new 标签("标签3",null);
var 编辑框_密码 = new 编辑框("编辑框_密码",null,null,null,null,null);
var 按钮_绑定 = new 按钮("按钮_绑定",按钮_绑定_被单击,null,null);
var CYS超级列表框1 = new CYS超级列表框("CYS超级列表框1",null,CYS超级列表框1_按钮被单击);
var 标签_提示 = new 标签("标签_提示",null);
var 标签_兑换 = new 标签("标签_兑换",null);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签5 = new 标签("标签5",null);
var div_vip_login = new 编辑框("div_vip_login",null,null,null,null,null);
var div_vip_passwd = new 编辑框("div_vip_passwd",null,null,null,null,null);
var div_vip_passwd_ = new 编辑框("div_vip_passwd_",null,null,null,null,null);
var div_vip_note = new 编辑框("div_vip_note",null,null,null,null,null);
var div_vip_btn = new 按钮("div_vip_btn",div_vip_btn_被单击,null,null);
var 弹出面板2 = new 弹出面板("弹出面板2",null,null);
var 标签6 = new 标签("标签6",null);
var div_upd_vip_login = new 编辑框("div_upd_vip_login",null,null,null,null,null);
var div_upd_vip_passwd = new 编辑框("div_upd_vip_passwd",null,null,null,null,null);
var div_new_vip_passwd = new 编辑框("div_new_vip_passwd",null,null,null,null,null);
var div_new_vip_passwd_ = new 编辑框("div_new_vip_passwd_",null,null,null,null,null);
var div_upd_vip_btn = new 按钮("div_upd_vip_btn",div_upd_vip_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        授权会员_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        授权会员_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_post="";
var 根地址= "";
var m_password= "";
var m_author= "";
function 授权会员_创建完毕(){
	根地址 = HPtools1.取URL();
	页面初始化();
	获取会员信息();
}

function 页面初始化(){
	按钮组_顶部.置样式(1, "mui-btn mui-btn-warning");
	面板1.添加组件("标签2", "1");
	面板1.添加组件("编辑框_账号", "3");
	面板1.置可视(false);
	面板2.添加组件("标签3", "1");
	面板2.添加组件("编辑框_密码", "3");
	面板2.置可视(false);
	CYS超级列表框1.置可视(false);

	var rect = 公用模块.弹出面板初始化计算(50,280, false);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板1.添加组件("标签5");
	弹出面板1.添加组件("div_vip_login");
	弹出面板1.添加组件("div_vip_passwd");
	弹出面板1.添加组件("div_vip_passwd_");
	弹出面板1.添加组件("div_vip_note");
	弹出面板1.添加组件("div_vip_btn");

	弹出面板2.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板2.添加组件("标签6");
	弹出面板2.添加组件("div_upd_vip_login");
	弹出面板2.添加组件("div_upd_vip_passwd");
	弹出面板2.添加组件("div_new_vip_passwd");
	弹出面板2.添加组件("div_new_vip_passwd_");
	弹出面板2.添加组件("div_upd_vip_btn");
}

function 获取会员信息(){
	m_post = "";
	m_url = 公用模块.生成访问链接_后端(根地址,"api/auth/auth",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			if(json.table == "auth" ){
				切换显示(true);
				标签_提示.置可视(false);
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "vip" ){
				if(json.model == "unbind" ){
					切换显示(true);
					仔仔弹出对话框1.成功(json.msg);
				}else if(json.model == "register" ){
					弹出面板1.隐藏();
					仔仔弹出对话框1.成功(json.msg);
				}else if(json.model == "passwd" ){
					弹出面板2.隐藏();
					仔仔弹出对话框1.成功(json.msg);
				}
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			if(json.table == "auth" ){
				切换显示(false);
				标签_提示.置可视(false);
				m_author = json.msg;
				显示会员信息(json.vip_info);
			}else if( json.table == "vip" ){
				切换显示(false);
				标签_提示.置可视(false);
				m_author = json.msg;
				显示会员信息(json.vip_info);
			}

		}
	}
}

function 切换显示(to_bind){
	标签_兑换.置可视(true);
	面板1.置可视(to_bind);
	面板2.置可视(to_bind);
	编辑框_账号.置内容("");
	编辑框_密码.置内容("");
	按钮_绑定.置可视(to_bind);
	if(to_bind == true ){
		to_bind = false;
	}else{
		to_bind = true;
	}
	CYS超级列表框1.置可视(to_bind);
}
function 按钮_绑定_被单击(){
	编辑框_账号.置内容(文本操作.删首尾空(编辑框_账号.取内容()));
	if(编辑框_账号.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入会员账号！");
		return;
	}
	编辑框_密码.置内容(文本操作.删首尾空(编辑框_密码.取内容()));
	if(编辑框_密码.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入会员密码！");
		return;
	}
	var json = {"login": 编辑框_账号.取内容(), "passwd": 编辑框_密码.取内容()}
	m_post = 公用模块.生成提交数据(0, "vip", "", "bind" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/vip",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 显示会员信息(vip_info){
	CYS超级列表框1.清空项目();
	CYS超级列表框1.添加项目(vip_info.vip_login,"会员账号",1,"","vip_login");
	CYS超级列表框1.添加项目(vip_info.create_time,"注册时间",1,"","create_time");
	if(vip_info.vip_note != "" ){
		CYS超级列表框1.添加项目(vip_info.vip_note,"",0,"","");
	}
	if(vip_info.vip_ratio <= 0 ){
		CYS超级列表框1.添加项目("永久授权","",0,"","");
	}else{
		CYS超级列表框1.添加项目("<span style=\"color: #FF00FF\">服务费比例："+转换操作.到文本(vip_info.vip_ratio)+"%</span>","",0,"","");
		CYS超级列表框1.添加项目("可用服务费："+转换操作.到文本(vip_info.vip_balance)+"元","",0,"","");
		CYS超级列表框1.添加项目("历史总额："+转换操作.到文本(vip_info.vip_money)+"元","",0,"","");
		CYS超级列表框1.添加项目("","服务费充值",4,"mui-btn-blue","pay_vip_balance");
	}
	CYS超级列表框1.添加项目("","解绑账号",4,"mui-btn-red","login-out");
}
function CYS超级列表框1_按钮被单击(项目索引){
	var str = CYS超级列表框1.取项目标记(项目索引);
	if(str == "pay_vip_balance" ){
		if(m_author == "" ){
			仔仔弹出对话框1.错误("author 异常,请刷新页面！");
			return;
		}
		str = 文本操作.删首尾空(HPtools1.输入框("请输入要充值的金额,不低于10元"));
		if(str == "" ){
			return;
		}
		str = 转换操作.到数值(str);
		if(str < 10 ){
			仔仔弹出对话框1.错误("充值金额不能低于10元！");
			return;
		}
		HPtools1.打开网页("epay.html?author="+m_author+"&money="+String(str));
		仔仔弹出对话框1.成功("充值成功后,请刷新本页面");
		return;
	}
	if(str == "login-out" ){
		if(HPtools1.询问框("是否解绑？解绑后需重新绑定！") == false ){
			return;
		}
		m_post = 公用模块.生成提交数据(0, "vip", "", "unbind" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/vip",m_password);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
	}
}
function 按钮组_顶部_被单击(按钮索引){
	if(按钮索引 < 1 ){
		div_vip_login.置内容("");
		div_vip_passwd.置内容("");
		div_vip_passwd_.置内容("");
		div_vip_note.置内容("");
		弹出面板1.滚动条到顶部();
		弹出面板1.显示();
	}else{
		div_upd_vip_login.置内容("");
		div_upd_vip_passwd.置内容("");
		div_new_vip_passwd.置内容("");
		div_new_vip_passwd_.置内容("");
		弹出面板2.滚动条到顶部();
		弹出面板2.显示();
	}
}
function div_vip_btn_被单击(){
	div_vip_login.置内容(文本操作.删首尾空(div_vip_login.取内容()));
	if(div_vip_login.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入会员账号！");
		return;
	}
	div_vip_passwd.置内容(文本操作.删首尾空(div_vip_passwd.取内容()));
	if(div_vip_passwd.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入会员密码！");
		return;
	}
	div_vip_passwd_.置内容(文本操作.删首尾空(div_vip_passwd_.取内容()));
	if(div_vip_passwd.取内容() != div_vip_passwd_.取内容() ){
		仔仔弹出对话框1.错误("两次密码输入不一致！");
		return;
	}
	div_vip_note.置内容(文本操作.删首尾空(div_vip_note.取内容()));
	var json = {}
	json.vip_login = div_vip_login.取内容();
	json.vip_passwd = div_vip_passwd.取内容();
	json.vip_note = div_vip_note.取内容();
	m_post = 公用模块.生成提交数据(0, "vip", "", "register" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/vip",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function div_upd_vip_btn_被单击(){
	div_upd_vip_login.置内容(文本操作.删首尾空(div_upd_vip_login.取内容()));
	if(div_upd_vip_login.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入会员账号！");
		return;
	}
	div_upd_vip_passwd.置内容(文本操作.删首尾空(div_upd_vip_passwd.取内容()));
	if(div_upd_vip_passwd.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入原会员密码！");
		return;
	}
	div_new_vip_passwd.置内容(文本操作.删首尾空(div_new_vip_passwd.取内容()));
	if(div_new_vip_passwd.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入新的会员密码！");
		return;
	}
	div_new_vip_passwd_.置内容(文本操作.删首尾空(div_new_vip_passwd_.取内容()));
	if(div_new_vip_passwd.取内容() != div_new_vip_passwd_.取内容() ){
		仔仔弹出对话框1.错误("两次新的密码输入不一致！");
		return;
	}
	var json = {}
	json.vip_login = div_upd_vip_login.取内容();
	json.old_passwd = div_upd_vip_passwd.取内容();
	json.vip_passwd = div_new_vip_passwd.取内容();
	m_post = 公用模块.生成提交数据(0, "vip", "", "passwd" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/vip",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}