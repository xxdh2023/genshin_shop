mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
if(mui.os.plus){
    mui.plusReady(function() {
        epay_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        epay_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_post="";
var 根地址= "";
var m_password= "";
function epay_创建完毕(){
	根地址 = HPtools1.取URL();
	页面初始化();
	var author= 文本操作.删首尾空(窗口操作.取当前页面参数("author"));
	var money= 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("money")));
	if(author == "" || money < 10 ){
		仔仔弹出对话框1.错误("非法调用！");
		return;
	}
	var json= {"author": author, "money": money}
	m_post = 公用模块.生成提交数据(0, "vip", "", "epay" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/vip",m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 页面初始化(){

}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			发起POST表单(json.api, json.submit);
		}
	}
}

function 发起POST表单(api, submit){
	var form = document.createElement("form");
	form.action = api;
	form.method = "POST";

	var money = document.createElement("input");
	money.type = "hidden";
	money.name = "money";
	money.value = submit.money;
    form.appendChild(money);

	var name = document.createElement("input");
	name.type = "hidden";
	name.name = "name";
	name.value = submit.name;
    form.appendChild(name);

	var notify_url = document.createElement("input");
	notify_url.type = "hidden";
	notify_url.name = "notify_url";
	notify_url.value = submit.notify_url;
    form.appendChild(notify_url);

	var out_trade_no = document.createElement("input");
	out_trade_no.type = "hidden";
	out_trade_no.name = "out_trade_no";
	out_trade_no.value = submit.out_trade_no;
    form.appendChild(out_trade_no);

	var pid = document.createElement("input");
	pid.type = "hidden";
	pid.name = "pid";
	pid.value = submit.pid;
    form.appendChild(pid);

	var return_url = document.createElement("input");
	return_url.type = "hidden";
	return_url.name = "return_url";
	return_url.value = submit.return_url;
    form.appendChild(return_url);

	var type1 = document.createElement("input");
	type1.type = "hidden";
	type1.name = "type";
	type1.value = submit.type;
    form.appendChild(type1);

	var sign = document.createElement("input");
	sign.type = "hidden";
	sign.name = "sign";
	sign.value = submit.sign;
    form.appendChild(sign);

	var sign_type = document.createElement("input");
	sign_type.type = "hidden";
	sign_type.name = "sign_type";
	sign_type.value = submit.sign_type;
    form.appendChild(sign_type);

	document.body.appendChild(form);
	form.submit();

}