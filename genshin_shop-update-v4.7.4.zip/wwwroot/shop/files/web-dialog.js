// web-dialog.js
(function() {
    'use strict';

    const style = document.createElement('style');
    style.textContent = `
        body.dialog-open {
            overflow: hidden;
            position: fixed;
            width: 100%;
        }

        .web-dialog-wrapper {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .web-dialog {
            background: #ffffff;
            border-radius: 4px;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            max-width: calc(100% - 40px);
            max-height: calc(100% - 40px);
            position: relative;
        }

        .dialog-header {
            padding: 20px;
            border-bottom: 1px solid #ebeef5;
            position: relative;
            flex-shrink: 0;
        }

        .close-btn {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 16px;
            color: #909399;
            transition: color 0.2s;
        }

        .close-btn:hover {
            color: #409EFF;
        }

        .dialog-body {
            flex: 1;
            min-height: 0;
            overflow: hidden;
            position: relative;
        }

        .loading-mask {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        .progress-container {
            width: 80%;
            margin-bottom: 20px;
        }

        .progress-bar {
            width: 100%;
            height: 12px;
            background: #ebeef5;
            border-radius: 6px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: #409EFF;
            transition: width 0.3s ease;
        }

        .confirm-dialog {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.1);
            z-index: 10001;
            min-width: 300px;
            outline: none;
        }

        .confirm-buttons {
            margin-top: 20px;
            text-align: right;
        }

        .confirm-button {
            padding: 8px 16px;
            margin-left: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .confirm-button.confirm {
            background: #409EFF;
            color: white;
        }

        .confirm-button.cancel {
            background: #ebeef5;
        }
    `;
    document.head.appendChild(style);

    let currentDialog = null;
    let scrollPosition = 0;

    class WebDialog {
        constructor(options) {
            this.options = {
                showClose: true,
                escapeClose: true,
                closeText: '',
                ...options
            };
            this.progress = 0;
            this.timeoutTimer = null;
            this.progressTimer = null;
            this.eventHandlers = new Map();
            this.isConfirming = false;
            this.confirmWrapper = null;
            this.init();
        }

        init() {
            this.lockBodyScroll();
            this.createWrapper();
            this.createDialog();
            this.bindEvents();
            this.startProgressSimulation();
            this.startTimeout();
            this.adjustSize();
            window.addEventListener('resize', this.handleResize);
        }

        lockBodyScroll() {
            scrollPosition = window.pageYOffset;
            document.body.style.top = `-${scrollPosition}px`;
            document.body.classList.add('dialog-open');
        }

        restoreBodyScroll() {
            document.body.classList.remove('dialog-open');
            window.scrollTo(0, scrollPosition);
            document.body.style.top = '';
        }

        createWrapper() {
            this.wrapper = document.createElement('div');
            this.wrapper.className = 'web-dialog-wrapper';
            document.body.appendChild(this.wrapper);
        }

        createDialog() {
            this.dialog = document.createElement('div');
            this.dialog.className = 'web-dialog';

            // Header
            const header = document.createElement('div');
            header.className = 'dialog-header';
            header.innerHTML = `
                <span>${this.options.title || ''}</span>
                ${this.options.showClose ? '<i class="close-btn">×</i>' : ''}
            `;
            this.dialog.appendChild(header);

            // Body
            const body = document.createElement('div');
            body.className = 'dialog-body';

            this.loadingMask = document.createElement('div');
            this.loadingMask.className = 'loading-mask';
            this.loadingMask.innerHTML = `
                <div class="progress-container">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 0%"></div>
                    </div>
                </div>
                <div class="loading-spinner">⌛</div>
                <div class="loading-text">加载中 0%</div>
            `;

            this.iframe = document.createElement('iframe');
            this.iframe.style.width = '100%';
            this.iframe.style.height = '100%';
            this.iframe.style.border = '0';
            this.iframe.src = this.options.url;

            body.appendChild(this.loadingMask);
            body.appendChild(this.iframe);
            this.dialog.appendChild(body);
            this.wrapper.appendChild(this.dialog);

            this.progressFill = this.loadingMask.querySelector('.progress-fill');
            this.loadingText = this.loadingMask.querySelector('.loading-text');
        }

        bindEvents() {
            if (this.options.showClose) {
                const closeBtn = this.dialog.querySelector('.close-btn');
                this.addEvent(closeBtn, 'click', () => this.beforeClose());
            }

            if (this.options.escapeClose) {
                this.addEvent(document, 'keydown', (e) => {
                    if (e.key === 'Escape' && !this.isConfirming) {
                        this.beforeClose();
                    }
                });
            }

            this.addEvent(this.iframe, 'load', () => this.handleLoad());
            this.addEvent(this.iframe, 'error', () => this.handleError());
        }

        handleConfirmKeydown = (e) => {
            if (e.key === 'Escape') {
                e.stopPropagation();
                this.cleanupConfirmDialog();
            }
        };

        beforeClose() {
            if (this.options.closeText) {
                this.showConfirmDialog();
            } else {
                this.close();
            }
        }

        showConfirmDialog() {
            if (this.isConfirming) return;

            this.confirmWrapper = document.createElement('div');
            this.confirmWrapper.className = 'web-dialog-wrapper';
            this.confirmWrapper.tabIndex = -1;

            const confirmDialog = document.createElement('div');
            confirmDialog.className = 'confirm-dialog';
            confirmDialog.innerHTML = `
                <div>${this.options.closeText}</div>
                <div class="confirm-buttons">
                    <button class="confirm-button cancel">取消</button>
                    <button class="confirm-button confirm">确定</button>
                </div>
            `;

            const confirmConfirm = confirmDialog.querySelector('.confirm');
            const confirmCancel = confirmDialog.querySelector('.cancel');

            this.addEvent(confirmConfirm, 'click', () => {
                this.cleanupConfirmDialog();
                this.close();
            });

            this.addEvent(confirmCancel, 'click', () => {
                this.cleanupConfirmDialog();
            });

            document.addEventListener('keydown', this.handleConfirmKeydown);

            this.confirmWrapper.appendChild(confirmDialog);
            document.body.appendChild(this.confirmWrapper);
            confirmDialog.focus();
            this.isConfirming = true;
        }

        cleanupConfirmDialog = () => {
            if (this.confirmWrapper) {
                document.removeEventListener('keydown', this.handleConfirmKeydown);
                this.confirmWrapper.remove();
                this.confirmWrapper = null;
                this.isConfirming = false;
            }
        };

        addEvent(target, event, handler) {
            const wrappedHandler = handler.bind(this);
            target.addEventListener(event, wrappedHandler);
            this.eventHandlers.set(handler, { target, event, wrappedHandler });
        }

        removeEvent(handler) {
            const eventData = this.eventHandlers.get(handler);
            if (eventData) {
                eventData.target.removeEventListener(eventData.event, eventData.wrappedHandler);
                this.eventHandlers.delete(handler);
            }
        }

        removeAllEvents() {
            this.eventHandlers.forEach(({ target, event, wrappedHandler }) => {
                target.removeEventListener(event, wrappedHandler);
            });
            this.eventHandlers.clear();
        }

        handleResize = () => {
            this.adjustSize();
        }

        adjustSize() {
            const maxWidth = window.innerWidth - 40;
            const maxHeight = window.innerHeight - 40;

            const width = this.parseSize(this.options.width, maxWidth);
            const height = this.parseSize(this.options.height, maxHeight);

            this.dialog.style.width = `${width}px`;
            this.dialog.style.height = `${height}px`;
        }

        parseSize(size, max) {
            if (typeof size === 'number') return Math.min(size, max);
            if (size.endsWith('%')) {
                const percent = parseFloat(size) / 100;
                return Math.min(percent * max, max);
            }
            return Math.min(parseInt(size, 10), max);
        }

        startTimeout() {
            this.timeoutTimer = setTimeout(() => {
                if (this.loadingMask.style.display !== 'none') {
                    this.showError('页面加载超时，请重试');
                }
            }, this.options.timeout || 10000);
        }

        startProgressSimulation() {
            const simulate = () => {
                if (this.progress < 90 && this.loadingMask.style.display !== 'none') {
                    this.progress += Math.random() * 15;
                    this.updateProgress();
                    this.progressTimer = setTimeout(simulate, 300);
                }
            };
            this.progressTimer = setTimeout(simulate, 500);
        }

        updateProgress() {
            const progress = Math.min(this.progress, 99);
            this.progressFill.style.width = `${progress}%`;
            this.loadingText.textContent =
                (this.options.loadingText || '加载中 {{progress}}%')
                    .replace('{{progress}}', progress.toFixed(0));
        }

        handleLoad() {
            clearTimeout(this.timeoutTimer);
            clearTimeout(this.progressTimer);
            this.progress = 100;
            this.updateProgress();
            setTimeout(() => {
                this.loadingMask.style.display = 'none';
            }, 300);
        }

        handleError() {
            clearTimeout(this.timeoutTimer);
            clearTimeout(this.progressTimer);
            this.showError('页面加载失败，请检查网络或地址');
        }

        showError(message) {
            this.loadingMask.innerHTML = `
                <div style="color: #f56c6c; margin-bottom: 10px;">❌</div>
                <div>${message}</div>
            `;
        }

        close() {
            this.wrapper.classList.add('closing');
            setTimeout(() => {
                this.destroy();
            }, 300);
        }

        destroy() {
            this.removeAllEvents();
            window.removeEventListener('resize', this.handleResize);
            clearTimeout(this.timeoutTimer);
            clearTimeout(this.progressTimer);
            this.cleanupConfirmDialog();
            this.restoreBodyScroll();
            if (this.wrapper.parentNode) {
                this.wrapper.parentNode.removeChild(this.wrapper);
            }
            if (currentDialog === this) {
                currentDialog = null;
            }
        }
    }

    function showWebDialog(options) {
        if (currentDialog) {
            currentDialog.close();
        }
        currentDialog = new WebDialog(options);
        return currentDialog;
    }

    function closeWebDialog() {
        if (currentDialog) {
            currentDialog.close();
        }
    }

    window.WebDialog = {
        show: showWebDialog,
        close: closeWebDialog
    };
})();
