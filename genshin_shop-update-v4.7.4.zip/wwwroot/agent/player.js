mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,导航栏1_项目被双击,null);
var HPtools1 = new HPtools("HPtools1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 顶部选项卡1 = new 顶部选项卡("顶部选项卡1",顶部选项卡1_子卡被单击,null);
var div_select_panel = new 面板("div_select_panel");
var 标签1 = new 标签("标签1",null);
var 编辑框_条件 = new 编辑框("编辑框_条件",null,null,null,null,null);
var 按钮_查询 = new 按钮("按钮_查询",按钮_查询_被单击,null,null);
var div_change_panel = new 面板("div_change_panel");
var 单选框_1_ = new 单选框("单选框_1_",null);
var 单选框_0 = new 单选框("单选框_0",null);
var 单选框_1 = new 单选框("单选框_1",null);
var div_list_grid = new 列表框("div_list_grid",false,null,null);
var 按钮_加载更多 = new 按钮("按钮_加载更多",按钮_加载更多_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        玩家账号_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        玩家账号_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 已初始化导航栏= false;
var page= 0;
var m_value= "";
var m_static= -1;
var m_menu= {}
var m_tabs= {}
var 导航索引= -1;
function 玩家账号_创建完毕(){
	根地址 = HPtools1.取URL();
	标题栏美化1.去标题栏阴影();
	弹出面板初始化();
	初始查询();
}
function 弹出面板初始化(){
	div_select_panel.添加组件("标签1","1");
	div_select_panel.添加组件("编辑框_条件","2");
	div_select_panel.添加组件("按钮_查询","1");
	div_change_panel.添加组件("单选框_1_","1");
	div_change_panel.添加组件("单选框_0","1");
	div_change_panel.添加组件("单选框_1","1");
	单选框_1_.置选中状态(true);


}

function 导航栏初始化(){
	if(已初始化导航栏 == false ){
		导航索引 = 公用模块.导航栏初始化(导航栏1,m_menu, "player");
		公用模块.顶部选项卡初始化(顶部选项卡1, 2, m_tabs);

		已初始化导航栏 = true;
	}
}
function 导航栏1_项目被单击(项目标题,目标名称){
	if(目标名称 == 公用模块.导航栏项目数组(m_menu)[导航索引] ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(目标名称+".html","");
	}
}
function 导航栏1_项目被双击(项目标题,目标名称){
	窗口操作.滚动到顶部();
}

function 顶部选项卡1_子卡被单击(子卡索引){
	公用模块.顶部选项卡子卡被单击(m_tabs, 子卡索引);
}
function 初始查询(){
	刷新列表(1);
}
function 刷新列表(查询的页号){
	if(查询的页号 < 2 ){
		div_list_grid.清空项目();
		查询的页号 = 1;
		按钮_加载更多.置可视(false);
		编辑框_条件.置内容(文本操作.删首尾空(编辑框_条件.取内容()));
		m_value = 编辑框_条件.取内容();
		m_static = -1;
		if(单选框_1.取选中状态() == true ){
			m_static = 1;
		}else if(单选框_0.取选中状态() == true ){
			m_static = 0;
		}
	}
	m_post = 公用模块.生成提交数据(m_static, "oper_login_info_player", m_value, "more" , 查询的页号, 0);
	m_url = 公用模块.生成访问链接(根地址, "api/agent/more", m_token);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 10);
}

function 按钮_查询_被单击(){
	初始查询();
}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "oper_login_info_player" ){
				m_menu = json.menu;
				m_tabs = json.tabs;
				导航栏初始化();
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info_player" ){
				m_menu = json.menu;
				m_tabs = json.tabs;
				导航栏初始化();
			}else{

				仔仔弹出对话框1.成功(json.msg);
			}


		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "oper_login_info_player" ){
				if(json.page == 1 ){
					div_list_grid.清空项目();
				}
				page = json.page;
				按钮_加载更多.置可视(true);
				while(i < json.results.length){
					添加列表(json.results[i]);
					i++
				}
				m_menu = json.menu;
				m_tabs = json.tabs;
				导航栏初始化();



			}
		}
	}
}
function 添加列表(results){
	var str= "[未知]";
	if(results.oper_static < 1 ){
		str = "封禁";
		str  = 公用模块.文本显示处理("["+str+"]","#FF0000",2);
	}else{
		str = "正常";
		str  = 公用模块.文本显示处理("["+str+"]","#0000FF",2);
	}
	var note= 公用模块.文本显示处理("玩家账号："+results.oper_login,"#000000",2)+str;

	note = note + "<br>" + 公用模块.文本显示处理("归属代理："+results.agent_oper,"#000000",2);
	note = note + 公用模块.文本显示处理("["+String(results.agent_level)+"级代理]","#FF00FF",2);
	note = note + "<br>" + 公用模块.文本显示处理("可用平台币："+String(results.coin_sum_ava)+"个","#FF00FF",2);
	note = note + "<br>" + 公用模块.文本显示处理("总计平台币："+String(results.coin_sum_in)+"个","#FF00FF",2);
	note = note + "<br>" + 公用模块.文本显示处理("注册时间："+results.create_time,"#000000",2);
	if(results.oper_static < 1 ){
		note = note + "<br>" + 公用模块.文本显示处理("封禁时间："+results.band_time,"#FF0000",2);
	}
	div_list_grid.添加项目2(note,results.ID,"","");
}
function 按钮_加载更多_被单击(){
	刷新列表(page+1);
}