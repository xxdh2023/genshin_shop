mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签_头部 = new 标签("标签_头部",null);
var 标签1 = new 标签("标签1",null);
var dropbox_coin_num = new 下拉框("dropbox_coin_num",dropbox_coin_num_表项被单击);
var 标签_优惠 = new 标签("标签_优惠",null);
var 标签2 = new 标签("标签2",null);
var dropbox_currency = new 下拉框("dropbox_currency",dropbox_currency_表项被单击);
var 标签3 = new 标签("标签3",null);
var dropbox_pay_type = new 下拉框("dropbox_pay_type",dropbox_pay_type_表项被单击);
var 标签4 = new 标签("标签4",null);
var 按钮_付款 = new 按钮("按钮_付款",按钮_付款_被单击,null,null);
var 按钮_切换 = new 按钮("按钮_切换",按钮_切换_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        主窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        主窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var is_test= false;
var invest_scale= 1;
var pay_proportion= 1;
var currency= [];
var cur_fail = {"cur_id": -1}
function 主窗口_创建完毕(){
	根地址 = HPtools1.取URL();
	var int= 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("test")));
	if(int == 1 ){
		is_test = true;
	}
	invest_scale = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("invest")));
	pay_proportion = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("proportion")));
	if(invest_scale <= 0 || pay_proportion <= 0 ){
		window.parent.显示提示消息("非法调用",false);
		关闭本窗口();
		return;
	}
	if(pay_proportion < 1 ){
		pay_proportion = 1;
	}
	if(pay_proportion > 1 ){
		标签_头部.置标题("[限时优惠：充赠比"+转换操作.到文本(pay_proportion)+"倍]");
	}
	页面初始化();
	m_post = "";
	m_url = 公用模块.生成访问链接(根地址,"api/newpay/paypage?act=select","");
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);

}
function 页面初始化(){
	dropbox_coin_num.清空项目();
	dropbox_coin_num.添加项目("请选择要充值的数量......", 0);
	dropbox_coin_num.置现行选中项(0);
	生成并插入平台币数量(6);
	生成并插入平台币数量(18);
	生成并插入平台币数量(58);
	生成并插入平台币数量(98);
	生成并插入平台币数量(198);
	生成并插入平台币数量(328);
	生成并插入平台币数量(648);
	生成并插入平台币数量(1000);

	dropbox_currency.清空项目();
	dropbox_currency.添加项目("请先选择平台币数量......", 转换操作.json转文本(cur_fail));
	dropbox_currency.置现行选中项(0);
	dropbox_pay_type.清空项目();
	dropbox_pay_type.添加项目("请先选择货币......", "");
	dropbox_pay_type.置现行选中项(0);
}

function 关闭本窗口(){
	window.parent.关闭充值弹窗();
}

function 生成并插入平台币数量(money){


	var coin = money*invest_scale;
	if(pay_proportion > 1 ){
		var str = String(coin)+" 平台币—>实际到账："+String(coin*pay_proportion)+" 平台币";
	}else{
		var str = String(coin)+" 平台币";
	}
	dropbox_coin_num.添加项目(str, coin);

}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("/shop/index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){

			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			currency = json.resutls;
		}
	}
}

function dropbox_coin_num_表项被单击(项目索引,项目标题,项目标记){
	var coin = 转换操作.到数值(项目标记);
	dropbox_currency.清空项目();
	if(coin <= 0 ){
		dropbox_currency.添加项目("请先选择平台币数量......", 转换操作.json转文本(cur_fail));
		dropbox_pay_type.清空项目();
		dropbox_pay_type.添加项目("请先选择货币......", "");
		dropbox_pay_type.置现行选中项(0);
	}else{
		if(currency.length < 1 ){
			dropbox_currency.添加项目("没有可选的币种......", 转换操作.json转文本(cur_fail));
			dropbox_currency.置现行选中项(0);
			dropbox_pay_type.清空项目();
			dropbox_pay_type.添加项目("请先选择货币......", "");
			dropbox_pay_type.置现行选中项(0);
			return;
		}
		var i=0;
		while(i<currency.length){
			dropbox_currency.添加项目(currency[i].cur_name+" ("+currency[i].cur_symbol+")", 转换操作.json转文本(currency[i]));
			if(i < 1 ){
				dropbox_pay_type.清空项目();
				dropbox_pay_type.添加项目("请选择支付方式......", "");
				var ii=0;
				while(ii<currency[i].pay_type.length){
					dropbox_pay_type.添加项目(currency[i].pay_type[ii].type_name + " ("+currency[i].pay_type[ii].type_id+")", currency[i].pay_type[ii].type_id);
					ii++
				}
				dropbox_pay_type.置现行选中项(0);
			}
			i++
		}
	}
	dropbox_currency.置现行选中项(0);
}
function dropbox_currency_表项被单击(项目索引,项目标题,项目标记){
	var json= 转换操作.文本转json(项目标记);
	var cur_id = json.cur_id;
	dropbox_pay_type.清空项目();
	if(cur_id < 0 ){
		dropbox_pay_type.添加项目("请先选择货币......", "");
	}else{
		dropbox_pay_type.添加项目("请选择支付方式......", "");
		var i=0;
		while(i<json.pay_type.length){
			dropbox_pay_type.添加项目(json.pay_type[i].type_name + " ("+json.pay_type[i].type_id+")", json.pay_type[i].type_id);
			i++
		}
	}
	dropbox_pay_type.置现行选中项(0);
}
function dropbox_pay_type_表项被单击(项目索引,项目标题,项目标记){

}
function 按钮_付款_被单击(){
	var coin = 转换操作.到数值(dropbox_coin_num.取项目标记(dropbox_coin_num.取现行选中项()));
	if(coin <= 0 ){
		仔仔弹出对话框1.错误("请选择平台币数量！");
		return;
	}
	var json= 转换操作.文本转json(dropbox_currency.取项目标记(dropbox_currency.取现行选中项()));
	if(json.cur_id < 0 ){
		仔仔弹出对话框1.错误("请选择币种！");
		return;
	}
	var pay_type = 文本操作.删首尾空(dropbox_pay_type.取项目标记(dropbox_pay_type.取现行选中项()));
	if(pay_type == "" ){
		仔仔弹出对话框1.错误("请选择支付方式！");
		return;
	}
	HPtools1.打开网页("/newpay/newpay.html?cur_id=" + String(json.cur_id) + "&coin=" + String(coin) + "&pay_type="+pay_type);
	底层_付款时调用();

}
function 按钮_切换_被单击(){
	window.parent.延时_打开兑换窗口(100);
	关闭本窗口();
}

function 底层_付款时调用(){

	if (window.parent.我的信息查询) {window.parent.显示提示消息("付款成功后,刷新本页面查看余额.",true)}
	else {window.parent.显示提示消息("付款成功后,请继续操作.",true)}

	关闭本窗口();
}