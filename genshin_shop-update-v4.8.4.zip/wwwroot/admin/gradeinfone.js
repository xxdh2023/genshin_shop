mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var div_vip_id_edit = new 编辑框("div_vip_id_edit",null,null,null,null,null);
var div_vip_name_edit = new 编辑框("div_vip_name_edit",null,null,null,null,null);
var div_vip_note_edit = new 编辑框("div_vip_note_edit",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var 自由面板1 = new 自由面板("自由面板1","150px");
var 按钮组_操作 = new 按钮组("按钮组_操作",按钮组_操作_被单击);
var 标签1 = new 标签("标签1",null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var div_add_popover = new 弹出面板("div_add_popover",null,null);
var div_add_edit = new 编辑框("div_add_edit",null,null,null,null,null);
var div_add_dropbox = new 下拉框("div_add_dropbox",div_add_dropbox_表项被单击);
var div_add_btn = new 按钮("div_add_btn",div_add_btn_被单击,null,null);
var div_add_grid = new 列表框("div_add_grid",false,null,div_add_grid_按钮被单击);
var div_add_btns = new 按钮组("div_add_btns",div_add_btns_被单击);
var CYS特效弹窗1 = new CYS特效弹窗("CYS特效弹窗1",CYS特效弹窗1_按钮被单击);
var div_add_next_popover = new 弹出面板("div_add_next_popover",null,null);
var div_add_next_benefits_edit = new 编辑框("div_add_next_benefits_edit",null,null,null,null,null);
var div_add_next_num_edit = new 编辑框("div_add_next_num_edit",null,null,null,null,null);
var div_add_next_level_edit = new 编辑框("div_add_next_level_edit",null,null,null,null,null);
var div_add_next_btn = new 按钮("div_add_next_btn",div_add_next_btn_被单击,null,null);
var div_vip_static_1 = new 单选框("div_vip_static_1",null);
var div_vip_static_0 = new 单选框("div_vip_static_0",null);
var div_sign_id_edit = new 编辑框("div_sign_id_edit",null,null,null,null,null);
var div_sign_id_btn = new 按钮("div_sign_id_btn",div_sign_id_btn_被单击,null,null);
var div_vip_monetary_edit = new 编辑框("div_vip_monetary_edit",null,null,null,null,null);
var 标签3 = new 标签("标签3",null);
var div_shop_model_id_popover = new 弹出面板("div_shop_model_id_popover",null,null);
var div_shop_model_id_dropbox = new 下拉框("div_shop_model_id_dropbox",div_shop_model_id_dropbox_表项被单击);
var div_shop_model_id_btn = new 按钮("div_shop_model_id_btn",div_shop_model_id_btn_被单击,null,null);
var div_vip_welfare_model_0 = new 单选框("div_vip_welfare_model_0",null);
var div_vip_welfare_model_1 = new 单选框("div_vip_welfare_model_1",null);
var 标签4 = new 标签("标签4",null);
var 高级表格2 = new 高级表格("高级表格2",高级表格2_工具栏按钮被单击,高级表格2_操作栏按钮被单击,null,null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var 高级表格3 = new 高级表格("高级表格3",高级表格3_工具栏按钮被单击,高级表格3_操作栏按钮被单击,null,null,null,null,null,null);
var div_benefits_popover = new 弹出面板("div_benefits_popover",null,null);
var div_benefits_name = new 编辑框("div_benefits_name",null,null,null,null,null);
var div_benefits_num = new 编辑框("div_benefits_num",null,null,null,null,null);
var div_benefits_btn = new 按钮("div_benefits_btn",div_benefits_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        VIP等级窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        VIP等级窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;
var class_name= "";
var value="";
var page= 0;
var m_json= {}
var class_name_model_id= "";
var add_table= "";
function VIP等级窗口_创建完毕(){
	ID = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("ID")));
	根地址 = HPtools1.取URL();
	按钮组_操作.置样式(0,"mui-btn");
	按钮组_操作.置样式(2,"mui-btn mui-btn-danger");
	div_vip_id_edit.置只读模式(true);
	div_add_btns.置样式(0,"mui-btn mui-btn-danger");
	div_vip_static_1.置选中状态(true);
	div_vip_static_1.置分组("A");
	div_vip_static_0.置分组("A");
	div_vip_welfare_model_0.置选中状态(true);
	div_vip_welfare_model_0.置分组("B");
	div_vip_welfare_model_1.置分组("B");
	div_vip_note_edit.置提示内容("VIP简介，也是累充福利的简介，<br>是换行，并且支持html语言，例如显示红色：<font color=\"red\">简介内容</font>；\n注意：引号、等号之类的字符一定要用半角英文");
	高级表格初始化();
	添加初始化();
	档案查询();
}
function 高级表格初始化(){
	高级表格1.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",80,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("vip_value","显示名称",400,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("vip_detail","内部脚本",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"添加单条脚本");
	高级表格1.添加工具栏按钮(2,false,"自定义批量导入");
	高级表格1.初始化("auto",true,true,false,true);
	高级表格2.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格2.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格2.添加列("oper","操作",80,false,false,true,true,false,false,"",false,false);
	高级表格2.添加列("ben_name","福利池里面的名称",400,false,false,false,false,false,false,"",false,false);
	高级表格2.添加列("ben_num","可领取的数量(几选几)",200,false,false,false,false,false,false,"",false,false);
	高级表格2.添加工具栏按钮(1,false,"添加单个福利名称");
	高级表格2.初始化("auto",true,true,false,true);
	高级表格3.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格3.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格3.添加列("oper","操作",80,false,false,true,true,false,false,"",false,false);
	高级表格3.添加列("ben_name","对应的福利名称",200,false,false,false,false,false,false,"",false,false);
	高级表格3.添加列("ben_value","显示名称",260,false,false,false,false,false,false,"",false,false);
	高级表格3.添加列("ben_detail","内部脚本",200,false,false,false,false,false,false,"",false,false);
	高级表格3.添加工具栏按钮(1,false,"添加单个福利名称");
	高级表格3.添加工具栏按钮(2,false,"自定义批量导入");
	高级表格3.初始化("auto",true,true,false,true);
}
function 添加初始化(){
	var rect = 公用模块.弹出面板初始化计算(50,80, true);
	div_add_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_popover.添加组件("div_add_edit" );
	div_add_popover.添加组件("div_add_dropbox");
	div_add_popover.添加组件("div_add_btn");
	div_add_popover.添加组件("div_add_grid");
	div_add_popover.添加组件("div_add_btns");
	CYS特效弹窗1.初始化("询问：","请确认任务处理方式：", ["完成该任务","接受该任务","取消"]);
	CYS特效弹窗1.置弹出动画(0);
	CYS特效弹窗1.置关闭特效(0);
	var rect = 公用模块.弹出面板初始化计算(50,160, false);
	div_add_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_next_popover.添加组件("div_add_next_benefits_edit" );
	div_add_next_popover.添加组件("div_add_next_num_edit" );
	div_add_next_popover.添加组件("div_add_next_level_edit" );
	div_add_next_popover.添加组件("div_add_next_btn" );
	var rect = 公用模块.弹出面板初始化计算(50,120, false);
	div_shop_model_id_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_shop_model_id_popover.添加组件("div_shop_model_id_dropbox" );
	div_shop_model_id_popover.添加组件("div_shop_model_id_btn" );
	var rect = 公用模块.弹出面板初始化计算(50,160, false);
	div_benefits_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_benefits_popover.添加组件("div_benefits_name" );
	div_benefits_popover.添加组件("div_benefits_num" );
	div_benefits_popover.添加组件("div_benefits_btn" );
}
function 档案查询(){
	if(ID > 0 ){
		m_post = 公用模块.生成提交数据(ID, "vip_grade_info", "", "read" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "vip_grade_info" ){
				if(json.model == "insert" ){
					ID = 转换操作.到数值(json.msg);
					div_vip_id_edit.置内容(json._id);
					仔仔弹出对话框1.成功("添加成功！");
				}else if(json.model == "update" ){
					仔仔弹出对话框1.成功("更新成功！");
				}else if(json.model == "delete" ){
					档案新增();
					仔仔弹出对话框1.成功("删除成功！");
				}
			}else if(json.table == "vip_grade_info_welfare" ){
				if(json.model == "insert" ){
					div_add_popover.隐藏();
					div_add_next_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else if(json.table == "vip_grade_info_benefits" ){
				if(json.model == "insert" ){
					div_benefits_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else if(json.table == "vip_grade_info_benefits_detail" ){
				if(json.model == "insert" ){
					div_add_popover.隐藏();
					div_add_next_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else{
				仔仔弹出对话框1.成功("执行成功！");
			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "vip_grade_info" ){
				档案新增();
				ID = json.results.ID;
				div_vip_id_edit.置内容(json.results.vip_id);
				div_vip_name_edit.置内容(json.results.vip_name);
				div_vip_note_edit.置内容(json.results.vip_note);
				div_vip_static_0.置选中状态(false);
				div_vip_static_1.置选中状态(false);
				div_vip_welfare_model_0.置选中状态(false);
				div_vip_welfare_model_1.置选中状态(false);
				if(json.results.vip_welfare_model < 1 ){
					div_vip_welfare_model_0.置选中状态(true);
				}else{
					div_vip_welfare_model_1.置选中状态(true);
				}
				if(json.results.vip_static < 1 ){
					div_vip_static_0.置选中状态(true);
				}else{
					div_vip_static_1.置选中状态(true);
				}
				if(json.results.sign_id != "" ){
					div_sign_id_edit.置内容(json.results.sign_id+" :: "+json.results.sign_name);
				}
				div_vip_monetary_edit.置内容(转换操作.到文本(json.results.vip_monetary));
				if(json.results.sign_id != "" ){
					div_sign_id_edit.置内容(json.results.sign_id+" :: "+ json.results.sign_name);
				}
				while(i < json.results.detail.length){
					高级表格1.添加行(false,["",json.results.detail[i].ID,"删除",json.results.detail[i].vip_value,json.results.detail[i].vip_detail]);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(4,false,"删除");
				高级表格1.初始化("auto",true,true,false,true);

				i=0;
				while(i < json.results.benefits.length){
					高级表格2.添加行(false,["",json.results.benefits[i].ID,"删除",json.results.benefits[i].ben_name,json.results.benefits[i].ben_num]);
					i++
				}
				高级表格2.清空操作栏按钮();
				高级表格2.添加操作栏按钮(4,false,"删除");
				高级表格2.初始化("auto",true,true,false,true);
				i=0;
				while(i < json.results.benefits_detail.length){
					高级表格3.添加行(false,["",json.results.benefits_detail[i].ID,"删除",json.results.benefits_detail[i].ben_name,json.results.benefits_detail[i].ben_value,json.results.benefits_detail[i].ben_detail]);
					i++
				}
				高级表格3.清空操作栏按钮();
				高级表格3.添加操作栏按钮(4,false,"删除");
				高级表格3.初始化("auto",true,true,false,true);
			}else if(json.table == "item_class_info" ){
				class_name = "";
				div_add_dropbox.清空项目();
				div_add_dropbox.添加项目("请选择类别......","");
				while(i < json.results.length){
					div_add_dropbox.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
				div_add_popover.显示();

			}else if(json.table == "item_item_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						div_add_grid.清空项目();
					}
					page = json.page;
					if(json.total > json.page ){
						div_add_btns.置可视(true);
					}
					while(i < json.results.length){
						div_add_grid.添加项目(json.results[i].item_id+" :: "+json.results[i].item_name, ""+json.results[i].item_model+","+json.results[i].item_maxnum,"mui-btn mui-btn-primary","添加");
						i++
					}
				}
			}else if(json.table == "item_sign_info_model_id" ){
				class_name_model_id = "";
				div_shop_model_id_dropbox.清空项目();
				div_shop_model_id_dropbox.添加项目("请选择签到奖励......","");
				var title;
				while(i < json.results.length){
					title = json.results[i].sign_id+" :: "+json.results[i].sign_name;
					switch(json.results[i].sign_type){
						case 0 :
							title = title + "(天卡)";
						break;
						case 1 :
							title = title + "(周卡)";
						break;
						case 2 :
							title = title + "(月卡)";
						break;
					}
					div_shop_model_id_dropbox.添加项目(title,json.results[i].sign_id);
					i++
				}
				div_shop_model_id_popover.显示();



			}



		}
	}
}

function 档案新增(){
	ID = 0;
	div_vip_id_edit.置内容("");
	div_vip_name_edit.置内容("");
	div_vip_note_edit.置内容("");
	div_sign_id_edit.置内容("");
	div_vip_monetary_edit.置内容("");
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	高级表格2.清空行();
	高级表格2.初始化("auto",true,true,false,true);
	高级表格3.清空行();
	高级表格3.初始化("auto",true,true,false,true);
}

function 按钮组_操作_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否新增？") == true ){
				档案新增();
			}
		break;
		case 1 :
			div_vip_name_edit.置内容(文本操作.删首尾空(div_vip_name_edit.取内容()));
			if(div_vip_name_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("VIP等级名称不能为空！");
				return;
			}
			div_vip_note_edit.置内容(文本操作.删首尾空(div_vip_note_edit.取内容()));
			var json= {}
			json.vip_id = div_vip_id_edit.取内容();
			json.vip_name = div_vip_name_edit.取内容();
			json.vip_note = div_vip_note_edit.取内容();
			json.vip_pic = "";
			if(div_vip_static_1.取选中状态() == true ){
				json.vip_static = 1;
			}else{
				json.vip_static = 0;
			}
			div_sign_id_edit.置内容(文本操作.删首尾空(div_sign_id_edit.取内容()));
			json.sign_id = 公用模块.取编码和名称(div_sign_id_edit.取内容(),"::")[0];
			div_vip_monetary_edit.置内容(文本操作.删首尾空(div_vip_monetary_edit.取内容()));
			if(div_vip_monetary_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("累充跳档值不能为空！");
				return;
			}
			var vip_monetary= 转换操作.到数值(div_vip_monetary_edit.取内容());
			if(vip_monetary < 0 ){
				仔仔弹出对话框1.错误("累充跳档值不能小于0！");
				return;
			}
			json.vip_monetary = vip_monetary;
			var vip_welfare_model= 0;
			if(div_vip_welfare_model_1.取选中状态() == true ){
				vip_welfare_model = 1;
			}
			json.vip_welfare_model = vip_welfare_model;
			if(ID < 1 ){
				m_post = 公用模块.生成提交数据(ID, "vip_grade_info", "", "insert" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
				美化等待框1.默认等待框("正在交互","正在添加档案,请稍等......");
			}else{
				m_post = 公用模块.生成提交数据(ID, "vip_grade_info", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在更新档案,请稍等......");
			}
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);

		break;
		case 2 :
			if(ID > 0 ){
				if(HPtools1.询问框("是否删除？") == true ){
					var json= {}
					json.vip_id = div_vip_id_edit.取内容();
					m_post = 公用模块.生成提交数据(ID, "vip_grade_info", "", "delete" , 1, 0, json);
					m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
					美化等待框1.默认等待框("正在交互","正在删除档案,请稍等......");
					公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
				}
			}
		break;
	}
}

function 高级表格1_工具栏按钮被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存VIP等级！");
				return;
			}
			if(div_vip_welfare_model_0.取选中状态() == false ){
				仔仔弹出对话框1.错误("请选简易版,再进行添加！");
				return;
			}
			add_table = "vip_grade_info_welfare";
			div_add_next_benefits_edit.置可视(false);
			if(div_add_dropbox.取项目总数() < 1 ){
				m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
				美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}else{
				div_add_popover.显示();
			}
		break;
		case 1 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存VIP等级！");
				return;
			}
			var url= "infoimport.html?table=vip_grade_info_welfare&item_id="+div_vip_id_edit.取内容();
			公用模块.居中打开小窗口(url, 900, 650);

		break;
	}
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	m_post = 公用模块.生成提交数据(_id, "vip_grade_info_welfare", "", "delete" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除脚本明细,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function div_add_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name = 项目标记;
}

function div_add_btn_被单击(){
	div_add_edit.置内容(文本操作.删首尾空(div_add_edit.取内容()));
	value = div_add_edit.取内容();
	if(class_name == "" ){
		仔仔弹出对话框1.错误("请选择要查询的类别！");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name , 1, 0);
	page = 1;
	div_add_btns.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function div_add_btns_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name , page+1, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
			美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
		break;
		case 1 :
			div_add_popover.滚动条到顶部();

		break;
	}
}

function div_add_grid_按钮被单击(项目索引){
	var res = 文本操作.分割文本(div_add_grid.取项目标记(项目索引),",");
	var item_model= 转换操作.到数值(res[0]);
	var item_maxnum= 转换操作.到数值(res[1]);
	res = 公用模块.取编码和名称(div_add_grid.取项目标题(项目索引),"::");
	var item_id= res[0];
	var item_name= res[1];
	m_json = {}
	m_json.item_model = item_model;
	m_json.item_id = item_id;
	m_json.item_name = item_name;
	m_json.item_maxnum = item_maxnum;
	if(item_model != 0 && item_model != 1 && item_model != 2 && item_model != 5 && item_model != 7 && item_model != 9 ){
		res = 公用模块.生成脚本内容及显示名称(item_model, item_id, item_name,0,0);
		var json= {}
		json.vip_id = div_vip_id_edit.取内容();
		json.vip_value = res[1];
		json.vip_detail = res[0];
		json.ben_name = "";
		if(add_table == "vip_grade_info_benefits_detail" ){
			json.ben_name = HPtools1.输入框("请输入对应的福利名称");
			if(json.ben_name == "" ){
				return;
			}
		}
		m_post = 公用模块.生成提交数据(ID, add_table, "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加脚本明细,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}else if(item_model == 5 ){
		CYS特效弹窗1.弹出();
	}else{
		if(item_model == 2 ){
			div_add_next_level_edit.置可视(true);
			var rect = 公用模块.弹出面板初始化计算(50,200, false);
			m_json.item_maxnum = 6;
			div_add_next_num_edit.置提示内容("请输入武器突破等级,最大不能超过：6");
			div_add_next_level_edit.置提示内容("请输入武器精炼等阶,最大不能超过：5");
		}else if(item_model == 7 ){
			div_add_next_level_edit.置可视(true);
			var rect = 公用模块.弹出面板初始化计算(50,200, false);
			div_add_next_num_edit.置提示内容("请输入数量,最大不能超过："+转换操作.到文本(item_maxnum));
			m_json.item_maxnum = 14;
			div_add_next_level_edit.置提示内容("请输入怪物数量,最大不能超过：14");
			div_add_next_level_edit.置提示内容("请输入怪物等级，最大200级");
		}else{
			div_add_next_level_edit.置可视(false);
			var rect = 公用模块.弹出面板初始化计算(50,160, false);
			if(item_maxnum > 0 ){
				if(item_model == 9 ){
					div_add_next_num_edit.置提示内容("请输入等级,最大不能超过："+转换操作.到文本(item_maxnum));
				}else{
					div_add_next_num_edit.置提示内容("请输入数量,最大不能超过："+转换操作.到文本(item_maxnum));
				}

			}else{
				if(item_model == 9 ){
					div_add_next_num_edit.置提示内容("请输入等级");
				}else{
					div_add_next_num_edit.置提示内容("请输入数量");
				}
			}
		}
		div_add_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
		div_add_next_num_edit.置内容("");
		div_add_next_level_edit.置内容("");
		div_add_next_popover.显示();
	}

}


function CYS特效弹窗1_按钮被单击(按钮索引){
	CYS特效弹窗1.关闭1();
	if(按钮索引 < 2 ){
		res = 公用模块.生成脚本内容及显示名称(m_json.item_model, m_json.item_id, m_json.item_name,按钮索引,0);
		var json= {}
		json.vip_id = div_vip_id_edit.取内容();
		json.vip_value = res[1];
		json.vip_detail = res[0];
		m_post = 公用模块.生成提交数据(ID, "vip_grade_info_welfare", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加脚本明细,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}

}
function div_add_next_btn_被单击(){
	div_add_next_num_edit.置内容(文本操作.删首尾空(div_add_next_num_edit.取内容()));
	div_add_next_level_edit.置内容(文本操作.删首尾空(div_add_next_level_edit.取内容()));
	var num= 转换操作.到数值(div_add_next_num_edit.取内容());
	if(num < 1 ){
		if(m_json.item_model != 2 ){
			仔仔弹出对话框1.错误("请输入大于0的数量！");
			return;
		}
	}
	if(num > m_json.item_maxnum && m_json.item_maxnum > 0 ){
		仔仔弹出对话框1.错误("输入的数量不能大于："+转换操作.到文本(m_json.item_maxnum));
		return;
	}
	var level= 转换操作.到数值(div_add_next_level_edit.取内容());
	if(m_json.item_model == 7  && level > 200 ){
		仔仔弹出对话框1.错误("怪物等级不能超过200！");
		return;
	}
	if(m_json.item_model == 2 && level > 5 ){
		仔仔弹出对话框1.错误("武器精炼等阶不能超过5！");
		return;
	}
	if(m_json.item_model == 2 && level > 1 && num < 1 ){
		仔仔弹出对话框1.错误("请输入大于0的武器突破等级！");
		return;
	}
	res = 公用模块.生成脚本内容及显示名称(m_json.item_model, m_json.item_id, m_json.item_name,num,level);
	var json= {}
	json.vip_id = div_vip_id_edit.取内容();
	json.vip_value = res[1];
	json.vip_detail = res[0];
	div_add_next_benefits_edit.置内容(文本操作.删首尾空(div_add_next_benefits_edit.取内容()));
	if(add_table == "vip_grade_info_benefits_detail" && div_add_next_benefits_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("福利名称无效！");
		return;
	}
	json.ben_name = div_add_next_benefits_edit.取内容();
	m_post = 公用模块.生成提交数据(ID, add_table, "", "insert" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	美化等待框1.默认等待框("正在交互","正在添加脚本明细,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function div_sign_id_btn_被单击(){
	m_post = 公用模块.生成提交数据(0, "item_sign_info_model_id", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_shop_model_id_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name_model_id = 项目标题;
}
function div_shop_model_id_btn_被单击(){
	if(class_name_model_id == "" ){
		仔仔弹出对话框1.错误("请先选择VIP等级/签到奖励");
		return;
	}
	div_sign_id_edit.置内容(class_name_model_id);
	div_shop_model_id_popover.隐藏();
}

function 高级表格2_工具栏按钮被单击(按钮索引){
	switch(按钮索引){
	case 0 :
		if(ID < 1 ){
			仔仔弹出对话框1.错误("请先保存VIP等级！");
			return;
		}
		if(div_vip_welfare_model_1.取选中状态() == false ){
			仔仔弹出对话框1.错误("请选自定义版,再进行添加！");
			return;
		}
		div_benefits_popover.显示();

		break;
	}
}
function 高级表格2_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	m_post = 公用模块.生成提交数据(_id, "vip_grade_info_benefits", "", "delete" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除福利名称,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_benefits_btn_被单击(){
	div_benefits_name.置内容(文本操作.删首尾空(div_benefits_name.取内容()));
	if(div_benefits_name.取内容() == "" ){
		仔仔弹出对话框1.错误("福利名称不能为空！");
		return;
	}
	div_benefits_num.置内容(文本操作.删首尾空(div_benefits_num.取内容()));
	if(div_benefits_num.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写数量！");
		return;
	}
	var ben_num= 转换操作.到数值(div_benefits_num.取内容());
	if(ben_num < 1 || ben_num > 99 ){
		仔仔弹出对话框1.错误("填写的数量越界！");
		return;
	}
	var json={}
	json.vip_id = div_vip_id_edit.取内容();
	json.ben_name = div_benefits_name.取内容();
	json.ben_num = ben_num;
	div_benefits_popover.隐藏();
	m_post = 公用模块.生成提交数据(0, "vip_grade_info_benefits", "", "insert" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	美化等待框1.默认等待框("正在交互","正在添加,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function 高级表格3_工具栏按钮被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存VIP等级！");
				return;
			}
			if(div_vip_welfare_model_1.取选中状态() == false ){
				仔仔弹出对话框1.错误("请选自定义版,再进行添加！");
				return;
			}
			add_table = "vip_grade_info_benefits_detail";
			div_add_next_benefits_edit.置可视(true);
			if(div_add_dropbox.取项目总数() < 1 ){
				m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
				美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}else{
				div_add_popover.显示();
			}
		break;
		case 1 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存VIP等级！");
				return;
			}
			var url= "infoimport.html?table=vip_grade_info_benefits_detail&item_id="+div_vip_id_edit.取内容();
			公用模块.居中打开小窗口(url, 900, 650);

		break;
	}
}
function 高级表格3_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];

	m_post = 公用模块.生成提交数据(_id, "vip_grade_info_benefits_detail", "", "delete" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除福利明细,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}