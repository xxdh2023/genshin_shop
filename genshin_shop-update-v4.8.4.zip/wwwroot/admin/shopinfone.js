mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 自由面板3 = new 自由面板("自由面板3","176px");
var 标签2 = new 标签("标签2",null);
var 自由面板1 = new 自由面板("自由面板1","232px");
var div_shop_static_1_ = new 单选框("div_shop_static_1_",div_shop_static_1__被单击);
var div_shop_static_0 = new 单选框("div_shop_static_0",div_shop_static_0_被单击);
var div_shop_static_1 = new 单选框("div_shop_static_1",div_shop_static_1_被单击);
var div_shop_static_2 = new 单选框("div_shop_static_2",div_shop_static_2_被单击);
var div_shop_note_edit = new 编辑框("div_shop_note_edit",null,null,null,null,null);
var div_shop_vip_edit = new 编辑框("div_shop_vip_edit",null,null,null,null,null);
var 标签4 = new 标签("标签4",null);
var div_shop_model_0 = new 单选框("div_shop_model_0",div_shop_model_0_被单击);
var div_shop_model_1 = new 单选框("div_shop_model_1",div_shop_model_1_被单击);
var div_shop_model_2 = new 单选框("div_shop_model_2",div_shop_model_2_被单击);
var div_shop_static_lable_1 = new 标签("div_shop_static_lable_1",null);
var div_shop_time_start = new 按钮("div_shop_time_start",div_shop_time_start_被单击,null,null);
var div_shop_static_lable_2 = new 标签("div_shop_static_lable_2",null);
var div_shop_time_end = new 按钮("div_shop_time_end",div_shop_time_end_被单击,null,null);
var div_shop_model_lable = new 标签("div_shop_model_lable",null);
var div_shop_model_id = new 编辑框("div_shop_model_id",null,null,null,null,null);
var 自由面板_按钮_选择 = new 按钮("自由面板_按钮_选择",自由面板_按钮_选择_被单击,null,null);
var div_shop_model_2_lable = new 标签("div_shop_model_2_lable",null);
var 自由面板2 = new 自由面板("自由面板2","94px");
var 标签1 = new 标签("标签1",null);
var div_shop_price_edit = new 编辑框("div_shop_price_edit",null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var div_shop_price_spec_edit = new 编辑框("div_shop_price_spec_edit",null,null,null,null,null);
var 标签6 = new 标签("标签6",null);
var div_buy_num_edit = new 编辑框("div_buy_num_edit",null,null,null,null,null);
var CCS类库1 = new CCS类库("CCS类库1");
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
var 标签9 = new 标签("标签9",null);
var div_shop_sort_edit = new 编辑框("div_shop_sort_edit",null,null,null,null,null);
var 标签10 = new 标签("标签10",null);
var 按钮组_操作 = new 按钮组("按钮组_操作",按钮组_操作_被单击);
var div_shop_mall_detail_lable = new 标签("div_shop_mall_detail_lable",null);
var 标签7 = new 标签("标签7",null);
var div_shop_num_edit = new 编辑框("div_shop_num_edit",null,null,null,null,null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 高级表格2 = new 高级表格("高级表格2",高级表格2_工具栏按钮被单击,高级表格2_操作栏按钮被单击,null,null,null,null,null,null);
var 图片框1 = new 图片框("图片框1",图片框1_被单击);
var div_shop_id_edit = new 编辑框("div_shop_id_edit",null,null,null,null,null);
var div_shop_name_edit = new 编辑框("div_shop_name_edit",null,null,null,null,null);
var 文件选择器1 = new 文件选择器("文件选择器1",文件选择器1_选择完毕,文件选择器1_读入完毕,null);
var 自由面板_下拉框 = new 下拉框("自由面板_下拉框",自由面板_下拉框_表项被单击);
var 自由面板_按钮_刷新 = new 按钮("自由面板_按钮_刷新",自由面板_按钮_刷新_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var 标签3 = new 标签("标签3",null);
var div_add_popover = new 弹出面板("div_add_popover",null,null);
var div_add_lable = new 标签("div_add_lable",null);
var div_add_edit = new 编辑框("div_add_edit",null,null,null,null,null);
var div_add_dropbox = new 下拉框("div_add_dropbox",div_add_dropbox_表项被单击);
var div_add_btn = new 按钮("div_add_btn",div_add_btn_被单击,null,null);
var div_add_grid = new 列表框("div_add_grid",false,null,div_add_grid_按钮被单击);
var div_add_btns = new 按钮组("div_add_btns",div_add_btns_被单击);
var CYS特效弹窗1 = new CYS特效弹窗("CYS特效弹窗1",CYS特效弹窗1_按钮被单击);
var div_add_next_popover = new 弹出面板("div_add_next_popover",null,null);
var div_add_next_num_edit = new 编辑框("div_add_next_num_edit",null,null,null,null,null);
var div_add_next_level_edit = new 编辑框("div_add_next_level_edit",null,null,null,null,null);
var div_add_next_btn = new 按钮("div_add_next_btn",div_add_next_btn_被单击,null,null);
var div_vip_price_popover = new 弹出面板("div_vip_price_popover",null,null);
var div_vip_price_dropbox = new 下拉框("div_vip_price_dropbox",div_vip_price_dropbox_表项被单击);
var div_vip_price_edit = new 编辑框("div_vip_price_edit",null,null,null,null,null);
var div_vip_price_btn = new 按钮("div_vip_price_btn",div_vip_price_btn_被单击,null,null);
var div_gm_script_popover = new 弹出面板("div_gm_script_popover",null,null);
var div_gm_script_dropbox = new 下拉框("div_gm_script_dropbox",div_gm_script_dropbox_表项被单击);
var div_gm_script_btn = new 按钮("div_gm_script_btn",div_gm_script_btn_被单击,null,null);
var div_shop_model_id_popover = new 弹出面板("div_shop_model_id_popover",null,null);
var div_shop_model_id_dropbox = new 下拉框("div_shop_model_id_dropbox",div_shop_model_id_dropbox_表项被单击);
var div_shop_model_id_btn = new 按钮("div_shop_model_id_btn",div_shop_model_id_btn_被单击,null,null);
var 标签8 = new 标签("标签8",null);
if(mui.os.plus){
    mui.plusReady(function() {
        商品档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        商品档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var class_name_shop= "";
var ID= 0;
var m_model= 0;
var m_shop_pic="";
var class_name_item= "";
var value= "";
var m_json= {}
var class_name_vip= "";
var class_name_script= "";
var class_name_model_id= "";






function 商品档案窗口_创建完毕(){
	ID = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("ID")));
	根地址 = HPtools1.取URL();
	调整组件尺寸();
	按钮组_操作.置样式(0,"mui-btn");
	按钮组_操作.置样式(2,"mui-btn mui-btn-danger");
	div_add_btns.置样式(0,"mui-btn mui-btn-danger");
	div_shop_time_start.置标题(CCS类库1.获取_当前日期时间());
	div_shop_time_end.置标题(CCS类库1.获取_当前日期时间());
	CYS日期时间选择器1.初始化(0, 2023, 2099);
	div_shop_id_edit.置只读模式(true);
	div_shop_note_edit.置提示内容("商品简介，<br>是换行，并且支持html语言，例如显示红色：<font color=\"red\">简介内容</font>；\n注意：引号、等号之类的字符一定要用半角英文");
	div_shop_vip_edit.置提示内容("限制显示范围，本参数空代表所有玩家都能看到本商品，否则输入VIP等级的编码;\n多个VIP等级编码,用半角逗号分隔,例如：VIP1,VIP2,VIP3,");
	高级表格初始化();
	刷新类别();
}
function 调整组件尺寸(){
	div_shop_static_1_.置分组("A");
	div_shop_static_0.置分组("A");
	div_shop_static_1.置分组("A");
	div_shop_static_2.置分组("A");
	div_shop_static_0.置选中状态(true);
	div_shop_model_0.置分组("B");
	div_shop_model_1.置分组("B");
	div_shop_model_2.置分组("B");
	div_shop_model_0.置选中状态(true);
	var width= 窗口操作.取窗口宽度();
	公用模块.自由面板_调整("div_shop_id_edit", 175, 620, 941,width);
	公用模块.自由面板_调整("div_shop_name_edit", 175, 620, 941,width);
	公用模块.自由面板_调整("自由面板_下拉框", 175, 402, 941,width);
	公用模块.自由面板_调整("自由面板_按钮_刷新", 588, 100, 941,width);
	公用模块.自由面板_调整("自由面板_按钮_添加", 694, 100, 941,width);
	var rect = 公用模块.弹出面板初始化计算(50,80, true);
	div_add_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_popover.添加组件("div_add_lable" );
	div_add_popover.添加组件("div_add_edit" );
	div_add_popover.添加组件("div_add_dropbox");
	div_add_popover.添加组件("div_add_btn");
	div_add_popover.添加组件("div_add_grid");
	div_add_popover.添加组件("div_add_btns");
	CYS特效弹窗1.初始化("询问：","请确认任务处理方式：", ["完成该任务","接受该任务","取消"]);
	CYS特效弹窗1.置弹出动画(0);
	CYS特效弹窗1.置关闭特效(0);
	var rect = 公用模块.弹出面板初始化计算(50,150, false);
	div_add_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_next_popover.添加组件("div_add_next_num_edit" );
	div_add_next_popover.添加组件("div_add_next_level_edit" );
	div_add_next_popover.添加组件("div_add_next_btn" );
	div_vip_price_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_vip_price_popover.添加组件("div_vip_price_dropbox" );
	div_vip_price_popover.添加组件("div_vip_price_edit" );
	div_vip_price_popover.添加组件("div_vip_price_btn" );
	var rect = 公用模块.弹出面板初始化计算(50,120, false);
	div_gm_script_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_gm_script_popover.添加组件("div_gm_script_dropbox" );
	div_gm_script_popover.添加组件("div_gm_script_btn" );
	div_shop_model_id_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_shop_model_id_popover.添加组件("div_shop_model_id_dropbox" );
	div_shop_model_id_popover.添加组件("div_shop_model_id_btn" );
}
function 高级表格初始化(){
	高级表格1.添加列("xz","",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",212,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("shop_value","编码",400,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_detail","名称",270,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_must","玩家必得",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"添加单条资源");
	高级表格1.添加工具栏按钮(3,false,"导入GM脚本");
	高级表格1.添加工具栏按钮(2,false,"自定义批量导入");

	高级表格1.初始化("auto",true,true,false,true);

	高级表格2.添加列("xz","",0,false,false,false,true,true,false,"",false,false);
	高级表格2.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格2.添加列("oper","操作",60,false,false,true,true,false,false,"",false,false);
	高级表格2.添加列("shop_value","VIP等级信息",400,false,false,false,false,false,false,"",false,false);
	高级表格2.添加列("shop_detail","对应价格",300,false,false,false,false,false,false,"",false,false);
	高级表格2.添加工具栏按钮(1,false,"添加VIP等级及价格");

	高级表格2.初始化("auto",true,true,false,true);
}
function shop_static_show(显示){
	div_shop_static_lable_1.置可视(显示);
	div_shop_static_lable_2.置可视(显示);
	div_shop_static_lable_1.置可视(显示);
	div_shop_time_start.置可视(显示);
	div_shop_time_end.置可视(显示);
}
function shop_model_show(shop_model){
	var 显示= false;
	var 提示= false;
	var 明细= false;
	switch(shop_model){
	case 0 :
		明细 = true;
	break;
	case 1 :
		显示 = true;
	break;
	case 2 :
		显示 = true;
		提示 = true;
		break;
	}
	div_shop_model_lable.置可视(显示);
	div_shop_model_id.置可视(显示);
	自由面板_按钮_选择.置可视(显示);
	div_shop_model_id.置内容("");
	div_shop_model_id.置只读模式(true);
	div_shop_model_2_lable.置可视(提示);
	if(明细 == true ){
		div_shop_mall_detail_lable.置标题("<br>添加资源明细列表");
		高级表格1.初始化("auto",true,true,false,true);
	}else{
		div_shop_mall_detail_lable.置标题("<br>无需添加资源列表");
		高级表格1.初始化("1px",true,true,false,true);
	}
}
function 刷新类别(){
	m_post = 公用模块.生成提交数据(0, "shop_class_info", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "shop_mall_info" ){
				if(json.model == "insert" ){
					ID = 转换操作.到数值(json.msg);
					div_shop_id_edit.置内容(json._id);
					仔仔弹出对话框1.成功("添加成功！");
				}else if(json.model == "update" ){
					仔仔弹出对话框1.成功("更新成功！");
				}else if(json.model == "delete" ){
					档案新增();
					仔仔弹出对话框1.成功("删除成功！");
				}
			}else if(json.table == "shop_mall_info_detail" ){
				if(json.model == "insert" ){
					div_add_popover.隐藏();
					div_add_next_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else if(json.table == "shop_mall_info_detail_script" ){
				if(json.model == "insert" ){
					div_gm_script_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else if(json.table == "shop_mall_info_vip" ){
				if(json.model == "insert" ){
					div_vip_price_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else if(json.table == "shop_mall_info_detail_must" ){
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();

			}else{
				仔仔弹出对话框1.成功("执行成功！");
			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "shop_class_info" ){
				class_name_shop = "";
				自由面板_下拉框.清空项目();
				自由面板_下拉框.添加项目("请选择类别......","");
				while(i < json.results.length){
					自由面板_下拉框.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
				档案查询();
			}else if(json.table == "item_class_info" ){
				class_name_item = "";
				div_add_dropbox.清空项目();
				div_add_dropbox.添加项目("请选择类别......","");
				while(i < json.results.length){
					div_add_dropbox.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
				div_add_popover.显示();
			}else if(json.table == "vip_grade_info_all" ){
				class_name_vip = "";
				div_vip_price_dropbox.清空项目();
				div_vip_price_dropbox.添加项目("请选择VIP等级......","");
				while(i < json.results.length){
					div_vip_price_dropbox.添加项目(json.results[i].vip_id+" :: "+json.results[i].vip_name,json.results[i].vip_id);
					i++
				}
				div_vip_price_popover.显示();
			}else if(json.table == "item_script_info_all" ){
				class_name_script = "";
				div_gm_script_dropbox.清空项目();
				div_gm_script_dropbox.添加项目("请选择GM脚本......","");
				while(i < json.results.length){
					div_gm_script_dropbox.添加项目(json.results[i].gm_id+" :: "+json.results[i].gm_name,json.results[i].gm_id);
					i++
				}
				div_gm_script_popover.显示();
			}else if(json.table == "item_item_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						div_add_grid.清空项目();
					}
					page = json.page;
					if(json.total > json.page ){
						div_add_btns.置可视(true);
					}
					while(i < json.results.length){
						div_add_grid.添加项目(json.results[i].item_id+" :: "+json.results[i].item_name, ""+json.results[i].item_model+","+json.results[i].item_maxnum,"mui-btn mui-btn-primary","添加");
						i++
					}
				}
			}else if(json.table == "vip_grade_info_model_id" ){
				class_name_model_id = "";
				div_shop_model_id_dropbox.清空项目();
				div_shop_model_id_dropbox.添加项目("请选择VIP等级......","");
				while(i < json.results.length){
					div_shop_model_id_dropbox.添加项目(json.results[i].vip_id+" :: "+json.results[i].vip_name,json.results[i].vip_id);
					i++
				}
				div_shop_model_id_popover.显示();
			}else if(json.table == "item_sign_info_model_id" ){
				class_name_model_id = "";
				div_shop_model_id_dropbox.清空项目();
				div_shop_model_id_dropbox.添加项目("请选择签到奖励......","");
				var title;
				while(i < json.results.length){
					title = json.results[i].sign_id+" :: "+json.results[i].sign_name;
					switch(json.results[i].sign_type){
						case 0 :
							title = title + "(天卡)";
						break;
						case 1 :
							title = title + "(周卡)";
						break;
						case 2 :
							title = title + "(月卡)";
						break;
					}
					div_shop_model_id_dropbox.添加项目(title,json.results[i].sign_id);
					i++
				}
				div_shop_model_id_popover.显示();
			}else if(json.table == "shop_mall_info" ){
				档案新增();
				ID = json.results.ID;
				div_shop_id_edit.置内容(json.results.shop_id);
				div_shop_name_edit.置内容(json.results.shop_name);
				while(i < 自由面板_下拉框.取项目总数()){
					if(自由面板_下拉框.取项目标记(i) == json.results.shop_class ){
						class_name_shop = json.results.shop_class;
						自由面板_下拉框.置现行选中项(i);
						break;
					}
					i++
				}
				switch(json.results.shop_static){
					case -1 :
						div_shop_static_1_.置选中状态(true);
						shop_static_show(false);
					break;
					case 0 :
						div_shop_static_0.置选中状态(true);
						shop_static_show(false);
					break;
					case 1 :
						div_shop_static_1.置选中状态(true);
						shop_static_show(false);
					break;
					case 2 :
						div_shop_static_2.置选中状态(true);
						shop_static_show(true);
					break;
				}
				switch(json.results.shop_model){
					case 0 :
						div_shop_model_0.置选中状态(true);
					break;
					case 1 :
						div_shop_model_1.置选中状态(true);
						div_shop_model_id.置内容(json.results.model_id+" :: "+json.results.model_name);
					break;
					case 2 :
						div_shop_model_2.置选中状态(true);
						div_shop_model_id.置内容(json.results.model_id+" :: "+json.results.model_name);
					break;
				}
				div_shop_time_start.置标题(json.results.shop_time_start);
				div_shop_time_end.置标题(json.results.shop_time_end);
				div_shop_note_edit.置内容(json.results.shop_note);
				div_shop_vip_edit.置内容(json.results.shop_vip);
				if(json.results.shop_model_id == "" ){
					div_shop_model_id.置内容("");
				}else{
					div_shop_model_id.置内容(json.results.shop_model_id + " :: " + json.results.shop_model_name);
				}
				div_shop_price_edit.置内容(转换操作.到文本(json.results.shop_price));
				div_shop_price_spec_edit.置内容(转换操作.到文本(json.results.shop_price_spec));
				div_shop_num_edit.置内容(转换操作.到文本(json.results.shop_num));
				div_buy_num_edit.置内容(转换操作.到文本(json.results.buy_num));
				if(typeof json.results.shop_sort == "number" ){
					div_shop_sort_edit.置内容(""+json.results.shop_sort);
				}
				json.results.shop_pic = 根地址+json.results.shop_pic+"?"+转换操作.到文本(时间操作.取时间戳(时间操作.取当前日期时间()));
				图片框1.置图片(json.results.shop_pic);
				i=0;
				var data = [];
				while(i < json.results.detail.length){
					data[0] = "";
					data[1] = json.results.detail[i].ID;
					data[2] = "删除";
					data[3] = json.results.detail[i].shop_value;
					data[4] = json.results.detail[i].shop_detail;
					if(json.results.detail[i].shop_must < 1 ){
						data[5] = "-";
					}else{
						data[5] = "必得资源";
					}
					高级表格1.添加行(false,data);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(4,false,"删除");
				高级表格1.添加操作栏按钮(2,false,"玩家必得");
				高级表格1.添加操作栏按钮(3,false,"取消必得");
				高级表格1.初始化("auto",true,true,false,true);

				shop_model_show(json.results.shop_model);
				if(json.results.shop_model > 0 ){
					div_shop_model_id.置内容(json.results.shop_model_id+" :: "+ json.results.shop_model_name);
				}
				i=0;
				while(i < json.results.price_vip.length){
					高级表格2.添加行(false,["",json.results.price_vip[i].ID,"删除",json.results.price_vip[i].shop_vip+" :: "+json.results.price_vip[i].vip_name,json.results.price_vip[i].shop_price_vip]);
					i++
				}
				高级表格2.清空操作栏按钮();
				高级表格2.添加操作栏按钮(4,false,"删除");
				高级表格2.初始化("auto",true,true,false,true);


			}




		}
	}
}
function 档案查询(){
	if(ID > 0 ){
		m_post = 公用模块.生成提交数据(ID, "shop_mall_info", "", "read" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}
}
function 档案新增(){
	ID = 0;
	div_shop_id_edit.置内容("");
	div_shop_name_edit.置内容("");
	div_shop_model_id.置内容("");
	div_shop_note_edit.置内容("");
	div_shop_price_edit.置内容("");
	div_shop_price_spec_edit.置内容("");
	div_shop_num_edit.置内容("");
	div_buy_num_edit.置内容("");
	div_shop_static_1_.置选中状态(false);
	div_shop_static_0.置选中状态(false);
	div_shop_static_1.置选中状态(false);
	div_shop_static_2.置选中状态(false);
	div_shop_model_0.置选中状态(false);
	div_shop_model_1.置选中状态(false);
	div_shop_model_2.置选中状态(false);
	图片框1.置图片("images/setpic.jpg");
	m_shop_pic = "";
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	高级表格2.清空行();
	高级表格2.初始化("auto",true,true,false,true);
	div_shop_sort_edit.置内容("");
}

function 自由面板_按钮_刷新_被单击(){
	刷新类别();
}

function 自由面板_按钮_添加_被单击(){
	var class_name_shop= 文本操作.删首尾空(HPtools1.输入框("新的类别名称",""));
	if(class_name_shop != "" ){
		var json= {}
		json.class_name = class_name_shop;
		m_post = 公用模块.生成提交数据(ID, "shop_class_info", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加类别,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);



	}
}

function 按钮组_操作_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否新增？") == true ){
				档案新增();
			}
		break;
		case 1 :
			div_shop_name_edit.置内容(文本操作.删首尾空(div_shop_name_edit.取内容()));
			if(div_shop_name_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("商品名称不能为空！");
				return;
			}
			var shop_static= -1;
			var shop_time_start = div_shop_time_start.取标题();
			var shop_time_end = div_shop_time_end.取标题();
			if(div_shop_static_0.取选中状态() == true ){
				shop_static = 0;
			}
			if(div_shop_static_1.取选中状态() == true ){
				shop_static = 1;
			}
			if(div_shop_static_2.取选中状态() == true ){
				shop_static = 2;
			}
			var shop_model= 0;
			var model_id= 公用模块.取编码和名称(div_shop_model_id.取内容(),"::")[0];
			if(div_shop_model_1.取选中状态() == true  ){
				shop_model = 1;
				if(model_id == "" ){
					仔仔弹出对话框1.错误("必须选择对应的VIP等级！");
					return;
				}
			}
			if(div_shop_model_2.取选中状态() == true  ){
				shop_model = 2;
				if(model_id == "" ){
					仔仔弹出对话框1.错误("必须选择对应的签到奖励！");
					return;
				}
			}
			div_shop_note_edit.置内容(文本操作.删首尾空(div_shop_note_edit.取内容()));
			div_shop_vip_edit.置内容(文本操作.删首尾空(div_shop_vip_edit.取内容()));
			var shop_price= 数学操作.四舍五入(转换操作.到数值(div_shop_price_edit.取内容()),2);
			if(shop_price < 0 ){
				仔仔弹出对话框1.错误("商品原价必须大于等于0！");
				return;
			}
			div_shop_price_spec_edit.置内容(文本操作.删首尾空(div_shop_price_spec_edit.取内容()));
			if(div_shop_price_spec_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("特价必须输入,支持0元特价！");
				return;
			}
			var shop_price_spec= 数学操作.四舍五入(转换操作.到数值(div_shop_price_spec_edit.取内容()),2);
			if(shop_price_spec < 0 ){
				仔仔弹出对话框1.错误("商品特价必须大于等于0！");
				return;
			}
			div_shop_num_edit.置内容(文本操作.删首尾空(div_shop_num_edit.取内容()));
			if(div_shop_price_spec_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("必须输入限购数量！");
				return;
			}
			var shop_num= 转换操作.到数值(div_shop_num_edit.取内容());
			if(class_name_shop == "" ){
				if(ID < 1 ){
					仔仔弹出对话框1.错误("必须选择一种商品类别！");
					return;
				}
			}
			div_buy_num_edit.置内容(文本操作.删首尾空(div_buy_num_edit.取内容()));
			if(div_shop_price_spec_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("必须设置资源几选几参数,允许填0");
				return;
			}
			div_shop_sort_edit.置内容(文本操作.删首尾空(div_shop_sort_edit.取内容()));
			var buy_num= 转换操作.到数值(div_buy_num_edit.取内容());
			var json= {}
			json.shop_id = div_shop_id_edit.取内容();
			json.shop_name = div_shop_name_edit.取内容();
			json.shop_note = div_shop_note_edit.取内容();
			json.shop_class = class_name_shop;
			json.shop_static = shop_static;
			json.shop_num = shop_num;
			json.shop_model = shop_model;
			json.shop_model_id = model_id;
			json.shop_price = shop_price;
			json.shop_price_spec = shop_price_spec;
			json.shop_time_start = shop_time_start;
			json.shop_time_end = shop_time_end;
			json.shop_vip = div_shop_vip_edit.取内容();
			json.buy_num = buy_num;
			json.shop_pic = "";
			json.shop_sort = div_shop_sort_edit.取内容();
			if(ID < 1 ){
				if(m_shop_pic == "" ){
					仔仔弹出对话框1.错误("必须给商品设置个图片！");
					return;
				}
				json.shop_pic = m_shop_pic;
				m_post = 公用模块.生成提交数据(ID, "shop_mall_info", "", "insert" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
				美化等待框1.默认等待框("正在交互","正在添加档案,请稍等......");
			}else{
				m_post = 公用模块.生成提交数据(ID, "shop_mall_info", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在更新档案,请稍等......");
			}
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);

		break;
		case 2 :
			if(ID > 0 ){
				if(HPtools1.询问框("是否删除？") == true ){
					var json= {}
					json.shop_id = div_shop_id_edit.取内容();
					m_post = 公用模块.生成提交数据(ID, "shop_mall_info", "", "delete" , 1, 0, json);
					m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
					美化等待框1.默认等待框("正在交互","正在删除档案,请稍等......");
					公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
				}
			}
		break;
	}
}

function 自由面板_下拉框_表项被单击(项目索引,项目标题,项目标记){
	class_name_shop = 项目标记;
}
function div_shop_static_1__被单击(){
	shop_static_show(false);
}
function div_shop_static_0_被单击(){
	shop_static_show(false);
}
function div_shop_static_1_被单击(){
	shop_static_show(false);
}
function div_shop_static_2_被单击(){
	shop_static_show(true);
}
function div_shop_model_0_被单击(){
	shop_model_show(0);
}
function div_shop_model_1_被单击(){
	shop_model_show(1);
}
function div_shop_model_2_被单击(){
	shop_model_show(2);
}
function div_shop_time_start_被单击(){
	m_model = 0;
	CYS日期时间选择器1.弹出();
}
function div_shop_time_end_被单击(){
	m_model = 1;
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(时);
	if(时 < 10 ){
		m = "0" + m;
	}
	res = res +" "+ m;
	m = 转换操作.到文本(分);
	if(分 < 10 ){
		m = "0" + m;
	}
	res = res +":"+ m+":00";
	if(m_model < 1 ){
		div_shop_time_start.置标题(res);
	}else{
		div_shop_time_end.置标题(res);
	}
}
function 自由面板_按钮_选择_被单击(){
	if(div_shop_model_0.取选中状态() == true ){
		仔仔弹出对话框1.错误("请选择非普通资源类的商品属性！");
		return;
	}else if(div_shop_model_1.取选中状态() == true ){
		m_post = 公用模块.生成提交数据(0, "vip_grade_info_model_id", "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}else if(div_shop_model_2.取选中状态() == true ){
		m_post = 公用模块.生成提交数据(1, "item_sign_info_model_id", "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}

}
function 图片框1_被单击(){
	if(ID > 0 ){
		if(HPtools1.询问框("是否更换图片？") == false ){
			return;
		}
	}
	文件选择器1.限制类型("image/jpeg,image/png,image/bmp");
	文件选择器1.开始选择();
}
function 文件选择器1_选择完毕(文件路径,文件对象){
	文件选择器1.读入文件(文件对象,2);
}
function 文件选择器1_读入完毕(结果,内容){
	图片框1.置图片(内容);
	var data= "";
	var i= 文本操作.倒找文本(内容,",");
	if(i > -1 ){
		data = 文本操作.取文本右边(内容,文本操作.取文本长度(内容) - i - 1);
	}else{
		data = 内容;
	}
	m_shop_pic = data;
	if(ID > 0 ){
		var json= {}
		json.shop_pic = data;
		m_post = 公用模块.生成提交数据(ID, "shop_mall_info", "shop_pic", "update" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
		美化等待框1.默认等待框("正在交互","正在更新图片,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}
}
function 高级表格1_工具栏按钮被单击(按钮索引){


	if(div_shop_model_0.取选中状态() == false ){
		仔仔弹出对话框1.错误("商品属性不是普通资源类！");
		return;
	}
	if(ID < 1 ){
		仔仔弹出对话框1.错误("请先保存商品档案！");
		return;
	}
	if(div_shop_static_1.取选中状态() == true || div_shop_static_2.取选中状态() == true ){
		仔仔弹出对话框1.错误("请先下架再进行此操作！");
		return;
	}
	switch(按钮索引){
		case 0 :
			if(div_add_dropbox.取项目总数() < 1 ){
				m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
				美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}else{
				div_add_popover.显示();
			}
		break;
		case 1 :
			if(div_gm_script_dropbox.取项目总数() < 1 ){
				m_post = 公用模块.生成提交数据(0, "item_script_info_all", "", "" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
				美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}else{
				div_gm_script_popover.显示();
			}
		break;
		case 2 :
			var url= "infoimport.html?table=shop_mall_info_detail&item_id="+div_shop_id_edit.取内容();
			公用模块.居中打开小窗口(url, 900, 650);


		break;
	}
}
function div_add_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name_item = 项目标记;
}
function div_add_btn_被单击(){
	div_add_edit.置内容(文本操作.删首尾空(div_add_edit.取内容()));
	value = div_add_edit.取内容();
	if(class_name_item == "" ){
		仔仔弹出对话框1.错误("请选择要查询的类别！");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name_item , 1, 0);
	page = 1;
	div_add_btns.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_add_btns_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name_item , page+1, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
			美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
		break;
		case 1 :
			div_add_popover.滚动条到顶部();

		break;
	}
}
function div_add_grid_按钮被单击(项目索引){
	var res = 文本操作.分割文本(div_add_grid.取项目标记(项目索引),",");
	var item_model= 转换操作.到数值(res[0]);
	var item_maxnum= 转换操作.到数值(res[1]);
	res = 公用模块.取编码和名称(div_add_grid.取项目标题(项目索引),"::");
	var item_id= res[0];
	var item_name= res[1];
	m_json = {}
	m_json.item_model = item_model;
	m_json.item_id = item_id;
	m_json.item_name = item_name;
	m_json.item_maxnum = item_maxnum;
	if(item_model != 0 && item_model != 1 && item_model != 2 && item_model != 5 && item_model != 7 && item_model != 9 ){
		res = 公用模块.生成脚本内容及显示名称(item_model, item_id, item_name,0,0);
		var json= {}
		json.shop_id = div_shop_id_edit.取内容();
		json.shop_value = res[1];
		json.shop_detail = res[0];
		m_post = 公用模块.生成提交数据(ID, "shop_mall_info_detail", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加资源明细,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}else if(item_model == 5 ){
		CYS特效弹窗1.弹出();
	}else{
		if(item_model == 2 ){
			div_add_next_level_edit.置可视(true);
			var rect = 公用模块.弹出面板初始化计算(50,160, false);
			m_json.item_maxnum = 6;
			div_add_next_num_edit.置提示内容("请输入武器突破等级,最大不能超过：6");
			div_add_next_level_edit.置提示内容("请输入武器精炼等阶,最大不能超过：5");
		}else if(item_model == 7 ){
			div_add_next_level_edit.置可视(true);
			var rect = 公用模块.弹出面板初始化计算(50,160, false);
			div_add_next_num_edit.置提示内容("请输入数量,最大不能超过："+转换操作.到文本(item_maxnum));
			m_json.item_maxnum = 14;
			div_add_next_level_edit.置提示内容("请输入怪物数量,最大不能超过：14");
			div_add_next_level_edit.置提示内容("请输入怪物等级，最大200级");
		}else{
			div_add_next_level_edit.置可视(false);
			var rect = 公用模块.弹出面板初始化计算(50,120, false);
			if(item_maxnum > 0 ){
				if(item_model != 9 ){
					div_add_next_num_edit.置提示内容("请输入数量,最大不能超过："+转换操作.到文本(item_maxnum));
				}else{
					div_add_next_num_edit.置提示内容("请输入等级,最大不能超过："+转换操作.到文本(item_maxnum));
				}

			}else{
				if(item_model != 9 ){
					div_add_next_num_edit.置提示内容("请输入数量");
				}else{
					div_add_next_num_edit.置提示内容("请输入等级");
				}
			}
		}
		div_add_next_num_edit.置内容("");
		div_add_next_level_edit.置内容("");
		div_add_next_popover.显示();
	}
}
function div_add_next_btn_被单击(){
	div_add_next_num_edit.置内容(文本操作.删首尾空(div_add_next_num_edit.取内容()));
	div_add_next_level_edit.置内容(文本操作.删首尾空(div_add_next_level_edit.取内容()));
	var num= 转换操作.到数值(div_add_next_num_edit.取内容());
	if(num < 1 ){
		if(m_json.item_model != 2 ){
			仔仔弹出对话框1.错误("请输入大于0的数量！");
			return;
		}
	}
	if(num > m_json.item_maxnum && m_json.item_maxnum > 0 ){
		仔仔弹出对话框1.错误("输入的数量不能大于："+转换操作.到文本(m_json.item_maxnum));
		return;
	}
	var level= 转换操作.到数值(div_add_next_level_edit.取内容());
	if(m_json.item_model == 7  && level > 200 ){
		仔仔弹出对话框1.错误("怪物等级不能超过200！");
		return;
	}
	if(m_json.item_model == 2 && level > 5 ){
		仔仔弹出对话框1.错误("武器精炼等阶不能超过5！");
		return;
	}
	if(m_json.item_model == 2 && level > 1 && num < 1 ){
		仔仔弹出对话框1.错误("请输入大于0的武器突破等级！");
		return;
	}
	res = 公用模块.生成脚本内容及显示名称(m_json.item_model, m_json.item_id, m_json.item_name,num,level);
	var json= {}
	json.shop_id = div_shop_id_edit.取内容();
	json.shop_value = res[1];
	json.shop_detail = res[0];
	m_post = 公用模块.生成提交数据(ID, "shop_mall_info_detail", "", "insert" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	美化等待框1.默认等待框("正在交互","正在添加资源明细,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function CYS特效弹窗1_按钮被单击(按钮索引){
	CYS特效弹窗1.关闭1();
	if(按钮索引 < 2 ){
		res = 公用模块.生成脚本内容及显示名称(m_json.item_model, m_json.item_id, m_json.item_name,按钮索引,0);
		var json= {}
		json.shop_id = div_shop_id_edit.取内容();
		json.shop_value = res[1];
		json.shop_detail = res[0];
		m_post = 公用模块.生成提交数据(ID, "shop_mall_info_detail", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加资源明细,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}
}
function div_vip_price_btn_被单击(){
	div_vip_price_edit.置内容(文本操作.删首尾空(div_vip_price_edit.取内容()));
	if(class_name_vip == "" ){
		仔仔弹出对话框1.错误("请选择VIP等级！");
		return;
	}
	if(div_vip_price_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入VIP对应的价格！");
		return;
	}
	var price= 转换操作.到数值(div_vip_price_edit.取内容());
	if(price < 0 ){
		仔仔弹出对话框1.错误("金额输入有误！");
		return;
	}
	if(price == 0 ){
		if(HPtools1.询问框("是否设置价格为：0 ？") == false ){
			return;
		}
	}
	var json= {}
		json.shop_id = div_shop_id_edit.取内容();
		json.shop_vip = class_name_vip;
		json.shop_price_vip = price;
		m_post = 公用模块.生成提交数据(ID, "shop_mall_info_vip", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加资源明细,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_vip_price_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name_vip = 项目标记;
}
function 高级表格2_工具栏按钮被单击(按钮索引){
	if(ID < 1 ){
		仔仔弹出对话框1.错误("请先保存商品档案！");
		return;
	}
	if(div_vip_price_dropbox.取项目总数() < 1 ){
		m_post = 公用模块.生成提交数据(0, "vip_grade_info_all", "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}else{
		div_vip_price_edit.置内容("");
		div_vip_price_dropbox.置现行选中项(0);
		class_name_vip = "";
		div_vip_price_popover.显示();
	}
}
function div_gm_script_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name_script = 项目标记;
}
function div_gm_script_btn_被单击(){
	if(class_name_script == "" ){
		仔仔弹出对话框1.错误("请先选择要导入的脚本");
		return;
	}
	var json= {}
		json.shop_id = div_shop_id_edit.取内容();
		json.gm_id = class_name_script;
		m_post = 公用模块.生成提交数据(ID, "shop_mall_info_detail_script", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在导入GM脚本,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	if(按钮索引 < 1 ){
		m_post = 公用模块.生成提交数据(_id, "shop_mall_info_detail", "", "delete" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	}else{
		if(按钮索引 == 1 ){
			var msg = "功能说明：\n\n1、只有在“资源几选几”大于0时有效\n\n2、设置为必得后，玩家购买时无需选择\n\n是否设置为玩家必得？";
			if(HPtools1.询问框(msg) == false ){
				return;
			}
		}
		var num = 1;
		if(按钮索引 == 2 ){
			num = 0;
		}
		m_post = 公用模块.生成提交数据(_id, "shop_mall_info_detail_must", "", "update" , num, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	}
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function 高级表格2_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	m_post = 公用模块.生成提交数据(_id, "shop_mall_info_vip", "", "delete" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除脚本明细,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_shop_model_id_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name_model_id = 项目标题;
}
function div_shop_model_id_btn_被单击(){
	if(class_name_model_id == "" ){
		仔仔弹出对话框1.错误("请先选择VIP等级/签到奖励");
		return;
	}
	div_shop_model_id.置内容(class_name_model_id);
	div_shop_model_id_popover.隐藏();
}