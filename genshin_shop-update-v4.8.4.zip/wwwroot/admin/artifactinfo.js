mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 面板1 = new 面板("面板1");
var 下拉框_状态 = new 下拉框("下拉框_状态",null);
var 下拉框_限购 = new 下拉框("下拉框_限购",null);
var 下拉框_加价 = new 下拉框("下拉框_加价",null);
var 面板8 = new 面板("面板8");
var 标签12 = new 标签("标签12",null);
var 下拉框_查询_套装 = new 下拉框("下拉框_查询_套装",null);
var 按钮_查询_刷新 = new 按钮("按钮_查询_刷新",按钮_查询_刷新_被单击,null,null);
var 标签1 = new 标签("标签1",null);
var 面板2 = new 面板("面板2");
var 编辑框_通用条件 = new 编辑框("编辑框_通用条件",null,null,null,null,null);
var 按钮_查询 = new 按钮("按钮_查询",按钮_查询_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var 弹出面板2 = new 弹出面板("弹出面板2",null,null);
var 面板3 = new 面板("面板3");
var 下拉框_批量_状态 = new 下拉框("下拉框_批量_状态",null);
var 按钮_批量_状态 = new 按钮("按钮_批量_状态",按钮_批量_状态_被单击,null,null);
var 标签2 = new 标签("标签2",null);
var 弹出面板3 = new 弹出面板("弹出面板3",null,null);
var 面板4 = new 面板("面板4");
var 编辑框_批量_限购 = new 编辑框("编辑框_批量_限购",null,null,null,null,null);
var 按钮_批量_限购 = new 按钮("按钮_批量_限购",按钮_批量_限购_被单击,null,null);
var 标签3 = new 标签("标签3",null);
var 弹出面板4 = new 弹出面板("弹出面板4",null,null);
var 面板5 = new 面板("面板5");
var 编辑框_批量_加价 = new 编辑框("编辑框_批量_加价",null,null,null,null,null);
var 按钮_批量_加价 = new 按钮("按钮_批量_加价",按钮_批量_加价_被单击,null,null);
var 标签4 = new 标签("标签4",null);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签13 = new 标签("标签13",null);
var 编辑框_添加_编号 = new 编辑框("编辑框_添加_编号",null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var 编辑框_添加_名称 = new 编辑框("编辑框_添加_名称",null,null,null,null,null);
var 标签14 = new 标签("标签14",null);
var 面板9 = new 面板("面板9");
var 下拉框_添加_套装 = new 下拉框("下拉框_添加_套装",null);
var 按钮_添加_刷新 = new 按钮("按钮_添加_刷新",按钮_添加_刷新_被单击,null,null);
var 标签15 = new 标签("标签15",null);
var 下拉框_添加_位置 = new 下拉框("下拉框_添加_位置",null);
var 面板6 = new 面板("面板6");
var 标签6 = new 标签("标签6",null);
var 标签7 = new 标签("标签7",null);
var 标签8 = new 标签("标签8",null);
var 面板7 = new 面板("面板7");
var 下拉框_添加_状态 = new 下拉框("下拉框_添加_状态",null);
var 编辑框_添加_限购 = new 编辑框("编辑框_添加_限购",null,null,null,null,null);
var 编辑框_添加_加价 = new 编辑框("编辑框_添加_加价",null,null,null,null,null);
var 按钮_添加_保存 = new 按钮("按钮_添加_保存",按钮_添加_保存_被单击,null,null);
var 标签9 = new 标签("标签9",null);
var 标签10 = new 标签("标签10",null);
var 标签11 = new 标签("标签11",null);
var 特定修复1 = new 特定修复("特定修复1");
if(mui.os.plus){
    mui.plusReady(function() {
        圣遗物管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        圣遗物管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var m_json= {}
var m_ids = [];
var m_table = "artifact_info";
var m_ID = 0;
var is_upd = false;




function 圣遗物管理_创建完毕(){
	根地址 = HPtools1.取URL();
	界面初始化();
	弹出面板初始化();
	高级表格初始化();

	刷新套装();
}

function 刷新套装(){
	下拉框_查询_套装.清空项目();
	下拉框_查询_套装.添加项目("查询全部", "all");
	下拉框_查询_套装.置现行选中项(0);
	下拉框_添加_套装.清空项目();
	下拉框_添加_套装.添加项目("请选择...", "");
	下拉框_添加_套装.置现行选中项(0);
	m_post = 公用模块.生成提交数据(0, "simple_artifact_info_cat", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function 界面初始化(){
	面板1.添加组件(特定修复1.下拉框("下拉框_状态"), "120px");
	面板1.添加组件(特定修复1.下拉框("下拉框_限购"), "120px");
	面板1.添加组件(特定修复1.下拉框("下拉框_加价"), "120px");
	面板2.添加组件("编辑框_通用条件", "270px");
	面板2.添加组件("按钮_查询", "90px");
	面板8.添加组件("标签12","120px");
	面板8.添加组件(特定修复1.下拉框("下拉框_查询_套装"),"140px");
	面板8.添加组件("按钮_查询_刷新","100px");
	下拉框_查询_套装.添加项目("查询全部", "all");
	下拉框_查询_套装.置现行选中项(0);

	下拉框_状态.清空项目();
	下拉框_状态.添加项目("全部状态", "all");
	下拉框_状态.添加项目("仅上线记录", "1");
	下拉框_状态.添加项目("仅下线记录", "0");
	下拉框_状态.置现行选中项(0);

	下拉框_限购.清空项目();
	下拉框_限购.添加项目("忽略限购", "all");
	下拉框_限购.添加项目("仅不限购记录", "0");
	下拉框_限购.添加项目("仅限购记录", "1");
	下拉框_限购.置现行选中项(0);

	下拉框_加价.清空项目();
	下拉框_加价.添加项目("忽略加价", "all");
	下拉框_加价.添加项目("仅不加价记录", "0");
	下拉框_加价.添加项目("仅加价记录", "1");
	下拉框_加价.置现行选中项(0);

}

function 高级表格初始化(){
	高级表格1.添加列("xz","",40,true,false,false,true,false,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",120,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("artifact_name","圣遗物名称",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("cat_name","套装名称",160,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_static","上线状态",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_limit","限购数量",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_amount","额外加价",240,false,true,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"添加");
	高级表格1.添加工具栏按钮(3,false,"批量修改上线状态");
	高级表格1.添加工具栏按钮(2,false,"批量修改限购数量");
	高级表格1.添加工具栏按钮(1,false,"批量修改额外加价");

	高级表格1.初始化("auto",true,true,false,true);
}

function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 120, false);
	弹出面板2.初始化(rect[0],rect[1],rect[2],rect[3]);
	面板3.添加组件(特定修复1.下拉框("下拉框_批量_状态"),"3");
	面板3.添加组件("按钮_批量_状态","1");
	弹出面板2.添加组件("面板3");
	弹出面板2.添加组件("标签2");

	下拉框_批量_状态.清空项目();
	下拉框_批量_状态.添加项目("下线", "0");
	下拉框_批量_状态.添加项目("上线", "1");
	下拉框_批量_状态.置现行选中项(1);

	弹出面板3.初始化(rect[0],rect[1],rect[2],rect[3]);
	面板4.添加组件("编辑框_批量_限购","3");
	面板4.添加组件("按钮_批量_限购","1");
	弹出面板3.添加组件("面板4");
	弹出面板3.添加组件("标签3");
	编辑框_批量_限购.置内容("0");

	弹出面板4.初始化(rect[0],rect[1],rect[2],rect[3]);
	面板5.添加组件("编辑框_批量_加价","3");
	面板5.添加组件("按钮_批量_加价","1");
	弹出面板4.添加组件("面板5");
	弹出面板4.添加组件("标签4");
	编辑框_批量_加价.置内容("0");

	var rect = 公用模块.弹出面板初始化计算(20, 80, true);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板1.添加组件("标签13");
	弹出面板1.添加组件("编辑框_添加_编号");
	弹出面板1.添加组件("标签5");
	弹出面板1.添加组件("编辑框_添加_名称");
	弹出面板1.添加组件("标签14");
	弹出面板1.添加组件("面板9");
	面板9.添加组件(特定修复1.下拉框("下拉框_添加_套装"), "3");
	面板9.添加组件("按钮_添加_刷新", "1");
	弹出面板1.添加组件("标签15");
	弹出面板1.添加组件("下拉框_添加_位置");
	下拉框_添加_位置.添加项目("[空之杯]", "1");
	下拉框_添加_位置.添加项目("[死之羽]", "2");
	下拉框_添加_位置.添加项目("[理之冠]", "3");
	下拉框_添加_位置.添加项目("[生之花]", "4");
	下拉框_添加_位置.添加项目("[时之沙]", "5");
	下拉框_添加_位置.置现行选中项(0);
	弹出面板1.添加组件("面板6");
	面板6.添加组件("标签6", "1");
	面板6.添加组件("标签7", "1");
	面板6.添加组件("标签8", "1");
	弹出面板1.添加组件("面板7");
	面板7.添加组件(特定修复1.下拉框("下拉框_添加_状态"), "1");
	下拉框_添加_状态.清空项目();
	下拉框_添加_状态.添加项目("下线", "0");
	下拉框_添加_状态.添加项目("上线", "1");
	下拉框_添加_状态.置现行选中项(1);
	面板7.添加组件("编辑框_添加_限购", "1");
	面板7.添加组件("编辑框_添加_加价", "1");
	弹出面板1.添加组件("按钮_添加_保存");
	弹出面板1.添加组件("标签9");
	弹出面板1.添加组件("标签10");
	弹出面板1.添加组件("标签11");




}
function 刷新档案(){
	if(page < 2 ){
		page = 1;
		m_json.cat_id = 下拉框_查询_套装.取项目标记(下拉框_查询_套装.取现行选中项());
		m_json.status = 下拉框_状态.取项目标记(下拉框_状态.取现行选中项());
		m_json.limit = 下拉框_限购.取项目标记(下拉框_限购.取现行选中项());
		m_json.amount = 下拉框_加价.取项目标记(下拉框_加价.取现行选中项());
		m_json.value = 文本操作.删首尾空(编辑框_通用条件.取内容());

	}

	m_post = 公用模块.生成提交数据(0, m_table, "", "" , page, 0, m_json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);

}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table != m_table + "_one" ){
				if(json.table == m_table ){
					弹出面板1.隐藏();
				}
				仔仔弹出对话框1.成功("操作成功,请重新查询！");
			}else{
				档案数据填充(json.result);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "simple_artifact_info_cat" ){
				if(json.results.length > 0 ){
					while(i<json.results.length){
						下拉框_查询_套装.添加项目(json.results[i].cat_name, String(json.results[i].ID));
						下拉框_添加_套装.添加项目(json.results[i].cat_name, String(json.results[i].ID));
						i++
					}
				}
				if(is_upd == false ){
					is_upd = true;
					page = 1;
					刷新档案();
				}
			}else if(json.table == m_table ){
				if(json.page == 1 ){
					高级表格1.清空行();
				}
				page = json.page;
				if(json.total > json.page ){
					按钮_底部.置可视(true);
				}
				var 行数据 = [];
				while(i < json.results.length){
					行数据[0] = "";
					行数据[1] = json.results[i].ID;
					行数据[2] = "编辑";
					行数据[3] = json.results[i].artifact_name;
					if(json.results[i].artifact_type == 1 ){
						行数据[3] = 行数据[3] + "[空之杯]";
					}else if(json.results[i].artifact_type == 2 ){
						行数据[3] = 行数据[3] + "[死之羽]";
					}else if(json.results[i].artifact_type == 3 ){
						行数据[3] = 行数据[3] + "[理之冠]";
					}else if(json.results[i].artifact_type == 4 ){
						行数据[3] = 行数据[3] + "[生之花]";
					}else if(json.results[i].artifact_type == 5 ){
						行数据[3] = 行数据[3] + "[时之沙]";

					}

					行数据[4] = json.results[i].cat_name;

					行数据[5] = "已上线";
					if(json.results[i].artifact_static < 1 ){
						行数据[5] = "已下线";
					}
					行数据[6] = "不限购";
					if(json.results[i].artifact_limit > 0 ){
						行数据[6] = String(json.results[i].artifact_limit)+"件";
					}
					行数据[7] = "不加价";
					if(json.results[i].artifact_amount > 0 ){
						行数据[7] = "加价："+String(json.results[i].artifact_amount)+"平台币";
					}
					高级表格1.添加行(true, 行数据);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(2,false,"编辑");
				高级表格1.添加操作栏按钮(4,false,"删除");
				高级表格1.初始化("auto",true,true,false,true);



			}



		}
	}
}



function 按钮_底部_被单击(){
	按钮_底部.置可视(false);
	page = page + 1;
	刷新档案();
}
function 按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	按钮_底部.置可视(false);
	page = 1;
	刷新档案();
}
function 高级表格1_工具栏按钮被单击(按钮索引){
	if(按钮索引 < 1 ){
		m_ID = 0;
		新增操作();
		弹出面板1.显示();
		return;
	}
	var 选中数据 = 高级表格1.取选中数据();
	m_ids = [];
	var num = 选中数据.length;
	if(num < 1 ){
		仔仔弹出对话框1.错误("请先选中要修改的记录！");
		return;
	}
	var i=0;
	while(i<num){
		m_ids[i] = 选中数据[i]["id"];
		i++
	}
	if(按钮索引 == 1 ){
		下拉框_批量_状态.置现行选中项(1);
		弹出面板2.显示();
	}else if(按钮索引 == 2 ){
		编辑框_批量_限购.置内容("0");
		弹出面板3.显示();
	}else if(按钮索引 == 3 ){
		编辑框_批量_加价.置内容("0");
		弹出面板4.显示();
	}
}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	if(按钮索引 < 1 ){
		m_ID = 数学操作.取整数(转换操作.到数值(行数据["id"]));
		if(m_ID < 0 ){
			m_ID = 0;
		}
		新增操作();
		m_post = 公用模块.生成提交数据(m_ID, m_table + "_one", "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
		美化等待框1.默认等待框("正在交互","请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}else{
		var msg = "是否删除：" + 行数据["artifact_name"] + "？";
		if(HPtools1.询问框(msg) == false ){
			return;
		}
		m_post = 公用模块.生成提交数据(行数据["id"], m_table, "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/delete", m_password);
		美化等待框1.默认等待框("正在交互","请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);


	}
}
function 按钮_批量_状态_被单击(){
	if(m_ids.length < 1 ){
		仔仔弹出对话框1.错误("请先选中要修改的记录！");
		return;
	}
	var msg = "是否将选中记录的状态修改为：";
	if(下拉框_批量_状态.取现行选中项() < 1 ){
		msg = msg + "下线";
	}else{
		msg = msg + "上线";
	}
	if(HPtools1.询问框(msg) == false ){
		return;
	}
	var json = {"ids": m_ids, "status": 下拉框_批量_状态.取现行选中项()}
	弹出面板2.隐藏();
	m_post = 公用模块.生成提交数据(0, m_table + "_status", "", "" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/update", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);

}
function 按钮_批量_限购_被单击(){
	if(m_ids.length < 1 ){
		仔仔弹出对话框1.错误("请先选中要修改的记录！");
		return;
	}
	编辑框_批量_限购.置内容(文本操作.删首尾空(编辑框_批量_限购.取内容()));
	if(编辑框_批量_限购.取内容() == "" ){
		编辑框_批量_限购.置内容("0");
	}
	var limit = 数学操作.取整数(转换操作.到数值(编辑框_批量_限购.取内容()));
	if(limit < 0 ){
		编辑框_批量_限购.置内容("0");
		limit = 0;
	}
	var msg = "是否将选中记录的限购修改为：";
	if(limit == 0 ){
		msg = msg + "不限购";
	}else{
		msg = msg + "永久限购"+String(limit)+"个";
	}
	if(HPtools1.询问框(msg) == false ){
		return;
	}
	var json = {"ids": m_ids, "limit": limit}
	弹出面板3.隐藏();
	m_post = 公用模块.生成提交数据(0, m_table + "_limit", "", "" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/update", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);


}
function 按钮_批量_加价_被单击(){
	if(m_ids.length < 1 ){
		仔仔弹出对话框1.错误("请先选中要修改的记录！");
		return;
	}
	编辑框_批量_加价.置内容(文本操作.删首尾空(编辑框_批量_加价.取内容()));
	if(编辑框_批量_加价.取内容() == "" ){
		编辑框_批量_加价.置内容("0");
	}
	var amount = 转换操作.到数值(编辑框_批量_加价.取内容());
	if(amount < 0 ){
		编辑框_批量_加价.置内容("0");
		amount = 0;
	}
	var msg = "是否将选中记录的加价修改为：";
	if(amount == 0 ){
		msg = msg + "不加价";
	}else{
		msg = msg + "加价"+String(amount)+"平台币";
	}
	if(HPtools1.询问框(msg) == false ){
		return;
	}
	var json = {"ids": m_ids, "amount": amount}
	弹出面板4.隐藏();
	m_post = 公用模块.生成提交数据(0, m_table + "_amount", "", "" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/update", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 新增操作(){
	编辑框_添加_编号.置内容("");
	编辑框_添加_编号.置只读模式(false);
	编辑框_添加_编号.置背景颜色(255,255,255,1);
	编辑框_添加_名称.置内容("");
	下拉框_添加_套装.置现行选中项(0);
	下拉框_添加_状态.置现行选中项(1);
	编辑框_添加_限购.置内容("0");
	编辑框_添加_加价.置内容("0");
	弹出面板1.滚动条到顶部();
}
function 档案数据填充(result){
	编辑框_添加_编号.置内容(result.artifact_id);
	编辑框_添加_编号.置只读模式(true);
	编辑框_添加_编号.置背景颜色(240,240,240,1);
	编辑框_添加_名称.置内容(result.artifact_name);
	if(下拉框_添加_套装.取项目总数() > 1 ){
		var i=0;
		while(i<下拉框_添加_套装.取项目总数()){
			if(下拉框_添加_套装.取项目标记(i) == String(result.cat_id) ){
				下拉框_添加_套装.置现行选中项(i);
				break;
			}
			i++
		}


	}
	下拉框_添加_位置.置现行选中项(result.artifact_type - 1);
	下拉框_添加_状态.置现行选中项(result.artifact_static);
	编辑框_添加_限购.置内容(""+result.artifact_limit);
	编辑框_添加_加价.置内容(""+result.artifact_amount);
	弹出面板1.显示();
}
function 按钮_添加_保存_被单击(){
	编辑框_添加_编号.置内容(文本操作.删首尾空(编辑框_添加_编号.取内容()));
	if(编辑框_添加_编号.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入圣遗物编号！");
		return;
	}
	编辑框_添加_名称.置内容(文本操作.删首尾空(编辑框_添加_名称.取内容()));
	if(编辑框_添加_名称.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入圣遗物名称！");
		return;
	}
	var cat_id = 下拉框_添加_套装.取项目标记(下拉框_添加_套装.取现行选中项());
	if(cat_id == "" ){
		仔仔弹出对话框1.错误("请选择归属套装！");
		return;
	}
	编辑框_添加_限购.置内容(文本操作.删首尾空(编辑框_添加_限购.取内容()));
	if(编辑框_添加_限购.取内容() == "" ){
		编辑框_添加_限购.置内容("0");
	}
	var limit = 数学操作.取整数(转换操作.到数值(编辑框_添加_限购.取内容()));
	if(limit < 0 ){
		limit = 0;
		编辑框_添加_限购.置内容("0");
	}

	编辑框_添加_加价.置内容(文本操作.删首尾空(编辑框_添加_加价.取内容()));
	if(编辑框_添加_加价.取内容() == "" ){
		编辑框_添加_加价.置内容("0");
	}
	var amount = 转换操作.到数值(编辑框_添加_加价.取内容());
	if(amount < 0 ){
		amount = 0;
		编辑框_添加_加价.置内容("0");
	}
	var json = {"name": 编辑框_添加_名称.取内容(), "status": 下拉框_添加_状态.取现行选中项(), "limit": limit, "amount": amount}
	json.id = 编辑框_添加_编号.取内容();
	json.cat_id = cat_id;
	json.type = 下拉框_添加_位置.取项目标记(下拉框_添加_位置.取现行选中项());
	m_post = 公用模块.生成提交数据(m_ID, m_table, "", "" , 0, 0, json);
	if(m_ID < 1 ){
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/insert", m_password);
	}else{
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/update", m_password);
	}

	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);


}

function 按钮_查询_刷新_被单击(){
	刷新套装();
}
function 按钮_添加_刷新_被单击(){
	刷新套装();
}