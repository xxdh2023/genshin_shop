mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,导航栏1_项目被双击,null);
var HPtools1 = new HPtools("HPtools1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 顶部选项卡1 = new 顶部选项卡("顶部选项卡1",顶部选项卡1_子卡被单击,null);
var 标签2 = new 标签("标签2",null);
var 面板1 = new 面板("面板1");
var 按钮_刷新 = new 按钮("按钮_刷新",按钮_刷新_被单击,null,null);
var 自由DIV组1 = new 自由DIV组("自由DIV组1",null);
var 自由DIV组2 = new 自由DIV组("自由DIV组2",null);
if(mui.os.plus){
    mui.plusReady(function() {
        数据总览_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        数据总览_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var m_menu= {}
var m_tabs= [];
var 导航索引= -1;
var 已初始化导航栏= false;

function 数据总览_创建完毕(){
	根地址 = HPtools1.取URL();
	标题栏美化1.去标题栏阴影();
	面板1.添加组件("按钮_刷新", "200px");
	刷新页面();
}
function 导航栏初始化(){
	if(已初始化导航栏 == false ){
		导航索引 = 公用模块.导航栏初始化(导航栏1,m_menu, "summary");
		公用模块.顶部选项卡初始化(顶部选项卡1, 2, m_tabs);

		已初始化导航栏 = true;
	}
}
function 导航栏1_项目被单击(项目标题,目标名称){
	if(目标名称 == 公用模块.导航栏项目数组(m_menu)[导航索引] ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(目标名称+".html","");
	}
}
function 导航栏1_项目被双击(项目标题,目标名称){
	窗口操作.滚动到顶部();
}
function 顶部选项卡1_子卡被单击(子卡索引){
	公用模块.顶部选项卡子卡被单击(m_tabs, 子卡索引);
}


function 刷新页面(){
	m_post = 公用模块.生成提交数据(0, "select_summary_data", "", "more" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址, "api/agent/more", m_token);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "select_summary_data" ){
				m_menu = json.menu;
				m_tabs = json.tabs;
				导航栏初始化();
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}


		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "select_summary_data" ){
				m_menu = json.menu;
				m_tabs = json.tabs;
				导航栏初始化();
				自由DIV组1.清空顶部DIV项目();
				单个数据展示(自由DIV组1, "代理总数", json.results.agent, true);
				单个数据展示(自由DIV组1, "今日玩家注册数", json.results.player_today, true);
				单个数据展示(自由DIV组1, "玩家注册总数", json.results.player_all, true);
				自由DIV组2.清空顶部DIV项目();
				单个数据展示(自由DIV组2, "今日流水", json.results.money_today);
				单个数据展示(自由DIV组2, "昨日流水", json.results.money_yesterday);
				单个数据展示(自由DIV组2, "总流水", json.results.money_all);
			}
		}
	}
}
function 按钮_刷新_被单击(){
	刷新页面();
}


function 单个数据展示(自由DIV组, title, data, 是数量){
	if(是数量 == true ){
		var str= String(data)+"条";
	}else{
		var str= "￥"+String(data)+"元";
	}
	自由DIV组.创建顶部DIV("#","150px","150px","2px","#FF00FF","20px","100%","16px","Microsoft YaHei","40px","#FF00FF",title,"20px","SimHei","20px","#FF00FF",str);
}

