    function 登录界面(name,event1,event2,event3){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 登录界面(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;
        
        //组件命令：
        this.置账号内容 = function (newText){
            document.getElementById(this.名称).getElementsByClassName("mui-input-clear mui-input")[0].value=newText;
        } 
		
		//组件命令：
        this.取账号内容 = function (){
           return document.getElementById(this.名称).getElementsByClassName("mui-input-clear mui-input")[0].value;
        }  

        //组件命令：
        this.置密码内容 = function (newText){
            document.getElementById(this.名称).getElementsByClassName("mui-input-clear mui-input")[1].value=newText;
        } 
		
		//组件命令：
        this.取密码内容 = function (){
           return document.getElementById(this.名称).getElementsByClassName("mui-input-clear mui-input")[1].value;
        }  

        //组件命令：
        this.置开关状态 = function (state){
            var cell = document.getElementById(this.名称).getElementsByClassName("mui-table-view-cell");
            if(cell==null){
                return;
            }
            if(cell.length<1){
                return;
            }
            var sw = cell[0].getElementsByClassName("mui-switch");
            if(state==true){
				if(!sw[0].classList.contains("mui-active")){
					//sw[0].classList.add("mui-active");
					mui("#switch_autoLogin").switch().toggle();				
				}
			}else{
				if(sw[0].classList.contains("mui-active")){
					//sw[0].classList.remove("mui-active");	
					mui("#switch_autoLogin").switch().toggle();
				}				
			}
        } 
		
		//组件命令：
        this.取开关状态 = function (){
            var cell = document.getElementById(this.名称).getElementsByClassName("mui-table-view-cell");
            if(cell==null){
                return false;
            }
            if(cell.length<1){
                return false;
            }
            var sw = cell[0].getElementsByClassName("mui-switch");
			return sw[0].classList.contains("mui-active");  
        } 
		        
        //组件命令：
        this.置可视 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称);
                div.style.display="";//显示，也可以设置为block	                
            }else{
                var div = document.getElementById(this.名称);
                div.style.display="none"; //不占位隐藏               
            }
        } 
        
        //组件命令：
        this.置可视2 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称);
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称);
                div.style.visibility="hidden"; //占位隐藏               
            }
        } 
        
        //组件事件
        if(event1!=null){
 			document.getElementById(this.名称).getElementsByClassName("mui-btn mui-btn-block mui-btn-primary")[0].addEventListener("tap", function () {
                event1();//登录按钮被单击事件
            });       	
        }
		
        //组件事件
        if(event2!=null){
 			document.getElementById(this.名称).getElementsByTagName("a")[0].addEventListener("tap", function () {
                event2();//注册账号被单击事件
            });       	
        }		
		
        //组件事件
        if(event3!=null){
 			document.getElementById(this.名称).getElementsByTagName("a")[1].addEventListener("tap", function () {
                event3();//忘记密码被单击事件
            });       	
        }		
		
		
    }