mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var CYS悬浮文字导航1 = new CYS悬浮文字导航("CYS悬浮文字导航1",CYS悬浮文字导航1_项目被单击,null);
var 抽奖转盘1 = new 抽奖转盘("抽奖转盘1",抽奖转盘1_开始抽奖回调,抽奖转盘1_结束抽奖回调);
var div_detail_popover = new 弹出面板("div_detail_popover",null,null);
var 标签1 = new 标签("标签1",null);
var CYS索引列表框1 = new CYS索引列表框("CYS索引列表框1",null);
var div_lottery_popover = new 弹出面板("div_lottery_popover",null,null);
var div_lottery_lable = new 标签("div_lottery_lable",null);
var div_lottery_grid = new 高级列表框("div_lottery_grid",false,true,false,null);
var div_lottery_grid_group = new CYS索引列表框("div_lottery_grid_group",null);
var div_lottery_lable_random = new 标签("div_lottery_lable_random",null);
var div_lottery_grid_random = new 高级列表框("div_lottery_grid_random",false,true,false,null);
var div_lottery_btn = new 按钮("div_lottery_btn",div_lottery_btn_被单击,null,null);
var div_ten_popover = new 弹出面板("div_ten_popover",null,null);
var div_ten_btn_1 = new 按钮("div_ten_btn_1",div_ten_btn_1_被单击,null,null);
var div_ten_btn_10 = new 按钮("div_ten_btn_10",div_ten_btn_10_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        开始抽奖_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        开始抽奖_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var m_lot_id= "";
var m_json= {}
var 转盘大小= 800;
var 抽奖进度= 0;
var 中奖结果= {}
var pay_model="alipay";
var submit_model= 1;
function 开始抽奖_创建完毕(){
	公用模块.动态加载脚本("files/popup.js", 隐藏框架);
	m_lot_id = 文本操作.删首尾空(窗口操作.取当前页面参数("lot_id"));
	if(m_lot_id == "" ){
		仔仔弹出对话框1.错误("数据无效,请关闭页面");
		return;
	}
	根地址 = HPtools1.取URL();

	标题栏美化1.去标题栏阴影();
	弹出面板初始化();

	CYS悬浮文字导航1.添加项目("查看奖池", "");
	CYS悬浮文字导航1.置悬浮("45px");
	var json= {}
	json.lot_id = m_lot_id;
	m_post = 公用模块.生成提交数据(0, "lottery_draw_info", "", "get-one" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/lottery", m_token);
	显示等待框();
	时钟1.开始执行(200,false);
}

function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_lottery_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_lottery_popover.添加组件("div_lottery_lable");
	div_lottery_popover.添加组件("div_lottery_grid");
	div_lottery_popover.添加组件("div_lottery_grid_group");
	div_lottery_popover.添加组件("div_lottery_lable_random");
	div_lottery_popover.添加组件("div_lottery_grid_random");
	div_lottery_popover.添加组件("div_lottery_btn");
	div_detail_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_detail_popover.添加组件("标签1");
	div_detail_popover.添加组件("CYS索引列表框1");
	var rect = 公用模块.弹出面板初始化计算(50, 100, false);
	div_ten_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_ten_popover.添加组件("div_ten_btn_1");
	div_ten_popover.添加组件("div_ten_btn_10");
}

function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){
	关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			仔仔弹出对话框1.错误("数据无效,请关闭页面");
		}else if(json.static == 0 ){
			if(json.model != "get-one" ){
				抽奖进度 = 0;
				抽奖转盘1.结束抽奖(0);
			}
			if(json.comm == "coin" ){
				发起直充前();
			}else if(json.table == "user_pay" && json.model == "select" ){
				打开兑换窗口();
				仔仔弹出对话框1.错误(json.msg);
			}else{
				仔仔弹出对话框1.错误(json.msg);
			}
		}else if(json.static == 1 ){
			if(json.table == "lottery_draw_info" && json.model == "state" ){
				抽奖转盘1.开始抽奖();
				var start= {}
				start.lot_id = m_lot_id;
				m_post = 公用模块.生成提交数据(0, "lottery_draw_info", "", "start_new" , json._id, 0, start);
				m_url = 公用模块.生成访问链接(根地址,"api/shop/lottery", m_token);
				时钟1.开始执行(2000,false);
			}else if(json.table == "lottery_draw_info" && json.model == "start_new" ){
				抽奖进度 = 2;
				中奖结果 = json.results;
				抽奖转盘1.结束抽奖(json.results.lottery[0].inout_cell);
			}else if(json.table == "user_pay" && json.model == "select" ){
				打开充值窗口(json);

			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "lottery_draw_info" && json.model == "get-one" ){
				抽奖进度 = 0;
				m_json = json;
				if(json.results.lot_cell_num < 4 ){
					仔仔弹出对话框1.错误("抽奖设置有误,请联系客服");
					return;
				}
				if(json.results.detail.length < 1 ){
					仔仔弹出对话框1.错误("抽奖设置有误,请联系客服");
					return;
				}
				标题栏1.置标题(json.results.lot_name);
				if(窗口操作.取窗口宽度() < 转盘大小 ){
					转盘大小 = 窗口操作.取窗口宽度();
				}
				if(窗口操作.取窗口高度() < 转盘大小 ){
					转盘大小 = 窗口操作.取窗口高度();
				}
				抽奖转盘1.置抽奖转盘大小("" + 转盘大小 + "px");
				抽奖转盘1.置转盘背景样式("12px","#FFF851","images/lottery_bg.png","","" + 转盘大小 + "px","" + 转盘大小 + "px",true);
				抽奖转盘1.置奖品文字样式("10%","#FFFFFF","20px","sans-serif",400,"20px",false,"90%",true);
				抽奖转盘1.置奖品图片样式("30%","30%","");
				抽奖转盘1.置抽奖按钮样式("20%",false,"");
				抽奖转盘1.置按钮文字样式("","","","","",0,"");
				抽奖转盘1.置按钮图片样式("images/lottery_start.png","-168%","120%","");
				CYS索引列表框1.清空();
				var arr = new Array();
				while(i < json.results.lot_cell_num){
					arr[i] = 0;
					CYS索引列表框1.添加分组("奖品："+json.results["lot_cell_"+转换操作.到文本(i+1)+"_name"]+" 包含以下明细");
					var color= "#B890F3";
					if(i % 2 ){
						color = "#7021E8";
					}
					抽奖转盘1.添加奖品(color, 100, json.results["lot_cell_"+转换操作.到文本(i+1)+"_name"], "images/lottery_default.png");
					i++
				}
				抽奖转盘1.渲染转盘();
				i=0;
				while(i < json.results.detail.length){
					arr[json.results.detail[i].lot_type - 1] = 1;
					CYS索引列表框1.添加项目(json.results.detail[i].lot_type - 1,公用模块.取空格文本(8)+json.results.detail[i].lot_value);
					i++
				}
				i=0;
				while(i < arr.length){
					if(arr[i] == 0 ){
						CYS索引列表框1.添加项目(i,公用模块.取空格文本(8)+"空");
					}
					i++
				}
				标签1.置可视(true);
				div_ten_btn_1.置标题("花费："+转换操作.到文本(json.results.lot_coin)+"平台币抽一次");
				if(json.results.lot_coin2 <= 0 ){
					json.results.lot_coin2 = json.results.lot_coin * 10;
					m_json.results.lot_coin2 = json.results.lot_coin2;
				}
				div_ten_btn_10.置标题("花费："+转换操作.到文本(json.results.lot_coin2)+"平台币抽十次");



			}


		}
	}
}
function 抽奖转盘1_开始抽奖回调(){
	switch(抽奖进度){
		case 0 :
			开始抽奖();
		break;
		case 1 :
			HPtools1.弹出提示("正在操作中......");
		break;
		case 2 :
			if(m_json.results.lot_model != 4 ){
				仔仔弹出对话框1.错误("已完成抽奖！");
				return;
			}
			抽奖进度 = 0;
			开始抽奖();
		break;
	}
}

function 开始抽奖(){
	if(抽奖进度 != 0 ){
		HPtools1.弹出提示("请勿重复点击");
		return;
	}
	if(m_json.results.lot_model == 4 ){
		div_ten_popover.显示();
	}else{
		抽奖进度 = 1;
		var json= {}
		json.lot_id = m_lot_id;
		m_post = 公用模块.生成提交数据(0, "lottery_draw_info", "", "state" , 0, 0, json);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/lottery", m_token);
		显示等待框();
		时钟1.开始执行(200,false);
	}


}

function 抽奖转盘1_结束抽奖回调(){
	if(抽奖进度 == 2 ){
		div_lottery_grid.清空项目();
		div_lottery_grid_group.清空();
		div_lottery_lable_random.置可视(false);
		div_lottery_grid_random.置可视(false);
		div_lottery_grid_random.清空项目();
		div_lottery_popover.滚动条到顶部();
		var i= 0;
		if(中奖结果.lottery.length < 2 ){
			var str= "中奖结果：<br>";
			str = str +  "恭喜您抽中了"+转换操作.到文本(中奖结果.lottery[0].inout_cell + 1)+"号奖品："+中奖结果.lottery[0].inout_name+"<br>以下奖品内的资源已暂存到【仓库】中,您可随时领取.";
			div_lottery_lable.置标题(str);
			while(i < 中奖结果.lottery[0].list.length){
				div_lottery_grid.添加项目2("",中奖结果.lottery[0].list[i],"","");
				i++
			}
		}else{
			div_lottery_lable.置标题("十连抽中奖结果：<br>您抽中的所有奖品资源已全部暂存到了【仓库】中,您可随时领取.");
			var v= 0;
			while(i < 中奖结果.lottery.length){
				div_lottery_grid_group.添加分组("恭喜您抽中了"+转换操作.到文本(中奖结果.lottery[i].inout_cell + 1)+"号奖品："+中奖结果.lottery[i].inout_name+",以下是奖品内的资源.");
				v=0;
				while(v < 中奖结果.lottery[i].list.length){
					div_lottery_grid_group.添加项目(i, 中奖结果.lottery[i].list[v]);
					v++
				}
				i++
			}
		}
		i=0;
		while(i < 中奖结果.random.length){
			div_lottery_grid_random.添加项目2("",中奖结果.random[i],"","");
			i++
		}
		if(中奖结果.random.length > 0 ){
			div_lottery_lable_random.置可视(true);
			div_lottery_grid_random.置可视(true);
		}
		div_lottery_popover.显示();
	}
}
function div_lottery_btn_被单击(){
	div_lottery_popover.隐藏();
}


function CYS悬浮文字导航1_项目被单击(项目索引){
	switch(项目索引){
	case 0 :
		div_detail_popover.显示();

		break;
	}
}
function 发起直充前(){
	m_post = "";
	m_url = 公用模块.生成访问链接(根地址,"api/pay/select", m_token);
	显示等待框();
	时钟1.开始执行(200,false);
}
function div_ten_btn_1_被单击(){
	if(抽奖进度 != 0 ){
		HPtools1.弹出提示("请勿重复点击");
		return;
	}
	抽奖进度 = 1;
	var json= {}
	json.lot_id = m_lot_id;
	m_post = 公用模块.生成提交数据(0, "lottery_draw_info", "", "state" , 1, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/lottery", m_token);
	div_ten_popover.隐藏();
	显示等待框();
	时钟1.开始执行(200,false);
}
function div_ten_btn_10_被单击(){
	if(抽奖进度 != 0 ){
		HPtools1.弹出提示("请勿重复点击");
		return;
	}
	抽奖进度 = 1;
	var json= {}
	json.lot_id = m_lot_id;
	m_post = 公用模块.生成提交数据(0, "lottery_draw_info", "", "state" , 10, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/lottery", m_token);
	div_ten_popover.隐藏();
	显示等待框();
	时钟1.开始执行(200,false);
}

function 隐藏框架(){
	popup.hideIframeB("coinpay");
	console.log("已加载");
}
function 显示提示消息(msg, model){
	if(model == true ){
		仔仔弹出对话框1.成功(msg);
	}else{
		仔仔弹出对话框1.错误(msg);
	}

}
function 显示等待框(){
	公用模块.showMask("页面遮罩");
	HPtools1.显示等待框("请稍等......");

}
function 关闭等待框(){

	公用模块.hideMask("页面遮罩");
	HPtools1.关闭等待框();
}
function 显示充值遮罩及等待框(){
	setTimeout(function() {
		公用模块.在指定元素上创建遮罩及等待框("coinpay","正在加载");
	}, 10);
}

function 关闭充值遮罩及等待框(){
	setTimeout(function() {
		公用模块.在指定元素上移除遮罩及等待框("coinpay");
	}, 10);
}
function 延时_打开兑换窗口(毫秒延时){
	setTimeout(function() {
		打开兑换窗口();
	}, 毫秒延时);
}
function 打开兑换窗口(){
	if(popup.Ishow("coinpay") == true ){
		console.log("弹窗已被占用");
		return;
	}
	var rect = 公用模块.弹出面板初始化计算(30,60,true);
	popup.showIframeB("coinpay","coincdk.html?agent",rect[0],rect[1],rect[2],rect[3]);
	显示充值遮罩及等待框();
}
function 打开充值窗口(json ){
	if(popup.Ishow("coinpay") == true ){
		console.log("弹窗已被占用");
		return;
	}
	var rect = 公用模块.弹出面板初始化计算(20,400,false);
	var str= "proportion="+String(json.comm)+"&invest="+String(json._id.invest_scale);
	popup.showIframeB("coinpay","coinpay.html?"+str,rect[0],rect[1],rect[2],rect[3]);
	显示充值遮罩及等待框();
}