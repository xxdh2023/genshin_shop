mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 自由面板1 = new 自由面板("自由面板1","145px");
var 自由面板_标签 = new 标签("自由面板_标签",null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_下拉框 = new 下拉框("自由面板_下拉框",自由面板_下拉框_表项被单击);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 自由面板_按钮_刷新 = new 按钮("自由面板_按钮_刷新",自由面板_按钮_刷新_被单击,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var 标签1 = new 标签("标签1",null);
var div_shop_static_2_ = new 单选框("div_shop_static_2_",div_shop_static_2__被单击);
var div_shop_static_1_ = new 单选框("div_shop_static_1_",div_shop_static_1__被单击);
var div_shop_static_0 = new 单选框("div_shop_static_0",div_shop_static_0_被单击);
var div_shop_static_2 = new 单选框("div_shop_static_2",div_shop_static_2_被单击);
var div_shop_static_1 = new 单选框("div_shop_static_1",div_shop_static_1_被单击);
var 标签2 = new 标签("标签2",null);
var div_shop_model_1_ = new 单选框("div_shop_model_1_",div_shop_model_1__被单击);
var div_shop_model_0 = new 单选框("div_shop_model_0",div_shop_model_0_被单击);
var div_shop_model_1 = new 单选框("div_shop_model_1",div_shop_model_1_被单击);
var div_shop_model_2 = new 单选框("div_shop_model_2",div_shop_model_2_被单击);
var div_on_popover = new 弹出面板("div_on_popover",null,null);
var div_on_shop_static_btns = new 按钮组("div_on_shop_static_btns",div_on_shop_static_btns_被单击);
var div_on_lable_1 = new 标签("div_on_lable_1",null);
var div_on_shop_time_start = new 按钮("div_on_shop_time_start",div_on_shop_time_start_被单击,null,null);
var div_on_lable_2 = new 标签("div_on_lable_2",null);
var div_on_shop_time_end = new 按钮("div_on_shop_time_end",div_on_shop_time_end_被单击,null,null);
var div_on_btn = new 按钮("div_on_btn",div_on_btn_被单击,null,null);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
var CCS类库1 = new CCS类库("CCS类库1");
if(mui.os.plus){
    mui.plusReady(function() {
        商城管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        商城管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var class_name= "";
var value= "";
var shop_static= -2;
var shop_model= -1;
var 表格数据 = new Array();
var m_model= 0;
var on_shop_static= 0;

function 商城管理_创建完毕(){
	根地址 = HPtools1.取URL();
	CYS日期时间选择器1.初始化(0, 2023, 2099);
	div_on_shop_time_start.置标题(CCS类库1.获取_当前日期时间());
	div_on_shop_time_end.置标题(CCS类库1.获取_当前日期时间());
	调整组件尺寸();
	高级表格初始化();
	HPtools1.信息框("在添加或修改商品时,请避免使用【角色】类资源,最好就是不用！");
	刷新类别();
	仔仔弹出对话框1.提示("请选择类别后,进行查询.");
}

function 调整组件尺寸(){
	var width= 窗口操作.取窗口宽度();
	公用模块.自由面板_调整("自由面板_标签", 416, 100, 941,width);
	公用模块.自由面板_调整("自由面板_编辑框_条件", 514, 220, 941,width);
	公用模块.自由面板_调整("自由面板_下拉框", 214, 200, 941,width);
	公用模块.自由面板_调整("自由面板_按钮_刷新", 110, 100, 941,width);
	公用模块.自由面板_调整("自由面板_按钮_查询", 740, 100, 941,width);
	公用模块.自由面板_调整("自由面板_按钮_添加", 6, 100, 941,width);
	div_shop_static_2_.置选中状态(true);
	div_shop_static_2_.置分组("A");
	div_shop_static_1_.置分组("A");
	div_shop_static_0.置分组("A");
	div_shop_static_1.置分组("A");
	div_shop_static_2.置分组("A");
	div_shop_model_1_.置选中状态(true);
	div_shop_model_1_.置分组("B");
	div_shop_model_0.置分组("B");
	div_shop_model_1.置分组("B");
	div_shop_model_2.置分组("B");
	var rect = 公用模块.弹出面板初始化计算(50,120, false);
	div_on_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_on_popover.添加组件("div_on_shop_static_btns");
	div_on_popover.添加组件("div_on_lable_1");
	div_on_popover.添加组件("div_on_shop_time_start");
	div_on_popover.添加组件("div_on_lable_2");
	div_on_popover.添加组件("div_on_shop_time_end");
	div_on_popover.添加组件("div_on_btn");
}

function 高级表格初始化(){
	高级表格1.添加列("xz","",40,true,false,false,true,false,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",210,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("shop_id","SKU",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_name","名称",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_pic","图片",0,false,false,false,false,true,false,"",false,false);
	高级表格1.添加列("shop_class","类型",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_static","状态",100,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_num","限购",80,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("buy_num","资源几选几",90,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_price","原价(平台币)",90,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_price_spec","特价(平台币)",90,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_vip","显示范围",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_time_start","开始时间",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_time_end","结束时间",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("shop_note","简介",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"批量上架");
	高级表格1.添加工具栏按钮(3,false,"批量下架");

	高级表格1.初始化("auto",true,true,false,true);
}


function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "shop_mall_info" && json.model == "delete" ){
				仔仔弹出对话框1.成功("删除成功,请重新查询！");
			}else if(json.table == "shop_mall_info_on" ){
				仔仔弹出对话框1.成功(json.msg);
			}else if(json.table == "shop_mall_info_off" ){
				仔仔弹出对话框1.成功("下架成功,请重新查询！");
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}


		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "shop_class_info" ){
				class_name = "";
				自由面板_下拉框.清空项目();
				自由面板_下拉框.添加项目("所有类别","");
				while(i < json.results.length){
					自由面板_下拉框.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
			}else if(json.table == "shop_mall_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "";
						arr[3] = json.results[i].shop_id;
						arr[4] = json.results[i].shop_name;
						arr[5] = json.results[i].shop_pic;
						arr[6] = json.results[i].shop_class;
						arr[7] = "停用";
						switch(json.results[i].shop_static){
							case 0 :
								arr[7] = "待上架";
							break;
							case 1 :
								arr[7] = "长期销售";
							break;
							case 2 :
								arr[7] = "限时销售";
							break;
						}
						arr[8] = "无";
						if(json.results[i].shop_num > 0 ){
							arr[8] = json.results[i].shop_num;
						}

						arr[9] = "-";
						if(json.results[i].buy_num > 0 ){
							arr[9] = "资源x选"+转换操作.到文本(json.results[i].buy_num);
						}
						arr[10] = json.results[i].shop_price;
						arr[11] = json.results[i].shop_price_spec;
						arr[12] = json.results[i].shop_vip;
						if(arr[12] == "" ){
							arr[12] = "所有玩家";
						}
						arr[13] = json.results[i].shop_time_start;
						arr[14] = json.results[i].shop_time_end;
						arr[15] = json.results[i].shop_note;
						高级表格1.添加行(true,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(2,false,"编辑");
					高级表格1.添加操作栏按钮(1,false,"上架");
					高级表格1.添加操作栏按钮(3,false,"下架");
					高级表格1.添加操作栏按钮(4,false,"删除");
					高级表格1.初始化("auto",true,true,false,true);
				}



			}




		}
	}
}

function 刷新类别(){
	m_post = 公用模块.生成提交数据(0, "shop_class_info", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
	时钟1.开始执行(200,false);
}


function 自由面板_按钮_刷新_被单击(){
	刷新类别();
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	var json= {}
	json.shop_model = shop_model;
	json.shop_static = shop_static;
	m_post = 公用模块.生成提交数据(0, "shop_mall_info", value, class_name , 1, 0, json);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}

function 自由面板_下拉框_表项被单击(项目索引,项目标题,项目标记){
	class_name = 项目标记;
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
}

function 按钮_底部_被单击(){
	var json= {}
	json.shop_model = shop_model;
	json.shop_static = shop_static;
	m_post = 公用模块.生成提交数据(0, "shop_mall_info", value, class_name , page+1, 0, json);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	时钟1.开始执行(200,false);
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
	case 0 :
		公用模块.居中打开小窗口("shopinfone.html?ID="+转换操作.到文本(_id), 1000, 700);
	break;
	case 1 :

		数组操作.清空数组(表格数据);
		表格数据[0] = 行数据;
		div_on_popover.显示();
	break;
	case 2 :

		if(HPtools1.询问框("是否下架？") == true ){
			var json= {}
			json.shop_static = 0;
			json.ids = [];
			json.ids[0] = _id;
			m_post = 公用模块.生成提交数据(0, "shop_mall_info_off", "", "update" , 1, 0, json);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
			美化等待框1.默认等待框("正在交互","正在下架,请稍等......");
			时钟1.开始执行(200,false);
		}
	break;
	case 3 :

		if(HPtools1.询问框("是否删除？") == true ){
			var json= {}
			json.shop_id = 行数据["shop_id"];
			m_post = 公用模块.生成提交数据(_id, "shop_mall_info", "", "delete" , 1, 0, json);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
			美化等待框1.默认等待框("正在交互","正在删除档案,请稍等......");
			时钟1.开始执行(200,false);
		}
		break;
	}

}

function 自由面板_按钮_添加_被单击(){
	公用模块.居中打开小窗口("shopinfone.html?ID=0", 1000, 700);
}
function div_shop_static_2__被单击(){
	shop_static = -2;
}
function div_shop_static_1__被单击(){
	shop_static = -1;
}
function div_shop_static_0_被单击(){
	shop_static = 0;
}
function div_shop_static_2_被单击(){
	shop_static = 2;
}
function div_shop_static_1_被单击(){
	shop_static = 1;
}
function div_shop_model_1__被单击(){
	shop_model = -1;
}
function div_shop_model_0_被单击(){
	shop_model = 0;
}
function div_shop_model_1_被单击(){
	shop_model = 1;
}
function div_shop_model_2_被单击(){
	shop_model = 2;
}
function 高级表格1_工具栏按钮被单击(按钮索引){
	if(按钮索引 == 0 || 按钮索引 == 1 ){
		var 选中数据 = 高级表格1.取选中数据();
		var num = 数组操作.取成员数(选中数据);
		if(num < 1 ){
			仔仔弹出对话框1.错误("请先勾选项目！");
			return;
		}
		表格数据 = 选中数据;
	}
	switch(按钮索引){
		case 0 :
			div_on_popover.显示();
		break;
		case 1 :
			if(HPtools1.询问框("是否批量下架？") == true ){
				var json= {}
				json.shop_static = 0;
				json.ids = [];
				var i= 0;
				while(i < num){
					var one= 选中数据[i];
					json.ids[i] = one["id"];
					i++
				}
				m_post = 公用模块.生成提交数据(0, "shop_mall_info_off", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在下架,请稍等......");
				时钟1.开始执行(200,false);
			}
		break;
	}



}

function div_on_shop_time_start_被单击(){
	m_model = 0;
	CYS日期时间选择器1.弹出();
}
function div_on_shop_time_end_被单击(){
	m_model = 1;
	CYS日期时间选择器1.弹出();
}
function div_on_btn_被单击(){
	var json= {}
	json.ids = [];
	var shop_static= 0;
	if(on_shop_static == 0 ){
		仔仔弹出对话框1.错误("请选择上架类型！");
		return;
	}
	json.shop_static = on_shop_static;
	json.shop_time_start = div_on_shop_time_start.取标题();
	json.shop_time_end = div_on_shop_time_end.取标题();
	var i= 0;
	while(i < 数组操作.取成员数(表格数据)){
		var one= 表格数据[i];
		json.ids[i] = one["id"];
		i++
	}
	m_post = 公用模块.生成提交数据(0, "shop_mall_info_on", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在上架,请稍等......");
	div_on_popover.隐藏();
	时钟1.开始执行(200,false);
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(时);
	if(时 < 10 ){
		m = "0" + m;
	}
	res = res +" "+ m;
	m = 转换操作.到文本(分);
	if(分 < 10 ){
		m = "0" + m;
	}
	res = res +":"+ m+":00";
	if(m_model < 1 ){
		div_on_shop_time_start.置标题(res);
	}else{
		div_on_shop_time_end.置标题(res);
	}
}
function div_on_shop_static_btns_被单击(按钮索引){
	div_on_shop_static_btns.置样式(0,"mui-btn");
	div_on_shop_static_btns.置样式(1,"mui-btn");
	div_on_shop_static_btns.置样式(按钮索引,"mui-btn mui-btn-primary");
	if(按钮索引 == 0 ){
		on_shop_static = 1;
		var rect = 公用模块.弹出面板初始化计算(50,110, false);
		div_on_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
		div_on_lable_1.置可视(false);
		div_on_shop_time_start.置可视(false);
		div_on_lable_2.置可视(false);
		div_on_shop_time_end.置可视(false);
	}else{
		on_shop_static = 2;
		var rect = 公用模块.弹出面板初始化计算(50,250, false);
		div_on_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
		div_on_lable_1.置可视(true);
		div_on_shop_time_start.置可视(true);
		div_on_lable_2.置可视(true);
		div_on_shop_time_end.置可视(true);
	}



}