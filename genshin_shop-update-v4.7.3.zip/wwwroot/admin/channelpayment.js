mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var div_type_title = new 标签("div_type_title",null);
var div_type_dropbox = new 下拉框("div_type_dropbox",null);
var div_acc_name_title = new 标签("div_acc_name_title",null);
var div_acc_name_edit = new 编辑框("div_acc_name_edit",null,null,null,null,null);
var div_acc_num_title = new 标签("div_acc_num_title",null);
var div_acc_num_edit = new 编辑框("div_acc_num_edit",null,null,null,null,null);
var div_bank_num_title = new 标签("div_bank_num_title",null);
var div_bank_num_dropbox = new 下拉框("div_bank_num_dropbox",null);
var div_bank_name_title = new 标签("div_bank_name_title",null);
var div_bank_name_edit = new 编辑框("div_bank_name_edit",null,null,null,null,null);
var div_phone_title = new 标签("div_phone_title",null);
var div_phone_edit = new 编辑框("div_phone_edit",null,null,null,null,null);
var div_email_title = new 标签("div_email_title",null);
var div_email_edit = new 编辑框("div_email_edit",null,null,null,null,null);
var div_amount_title = new 标签("div_amount_title",null);
var div_amount_edit = new 编辑框("div_amount_edit",null,null,null,null,null);
var div_payment_btn = new 按钮("div_payment_btn",div_payment_btn_被单击,null,null);
var div_payment_end = new 标签("div_payment_end",null);
if(mui.os.plus){
    mui.plusReady(function() {
        支付通道代付_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        支付通道代付_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var payment_config = {}
var ID= 0;
var plugin= "";
var currency_id= -1;

function 支付通道代付_创建完毕(){
	var params = UrlParams.get();
	根地址 = HPtools1.取URL();
	var id = URL参数取值(params, "id", 0);
	if(id == "" ){
		ID = 0;
	}else{
		id = 数学操作.取整数(转换操作.到数值(id));
		if(id < 0 ){
			id = 0;
		}
		ID = id;
	}
	plugin  = URL参数取值(params, "plugin", "");
	currency_id = URL参数取值(params, "currency", -1);
	if(currency_id  == "" ){
		currency_id = -1;
	}else{
		currency_id = 转换操作.到数值(currency_id);
	}
	if(ID < 1 || plugin == "" || currency_id < 0 ){
		仔仔弹出对话框1.错误("非法调用！");
		return;
	}
	var type_list = URL参数取值(params, "type_list", "[]");
	if(type_list == "" ){
		type_list = "[]";
	}
	type_list = 转换操作.文本转json(type_list);
	var acc_name = URL参数取值(params, "acc_name", 0);
	var acc_num = URL参数取值(params, "acc_num", 0);
	var bank_num_list = URL参数取值(params, "bank_num", "[]");
	if(bank_num_list == "" ){
		bank_num_list = "[]";
	}
	bank_num_list = 转换操作.文本转json(bank_num_list);
	var bank_name = URL参数取值(params, "bank_name", 0);
	var phone = URL参数取值(params, "phone", 0);
	var email = URL参数取值(params, "email", 0);
	var amount = URL参数取值(params, "amount", "");
	弹出代付操作页面(type_list, acc_name, acc_num, bank_num_list, bank_name, phone, email, amount);
}

function URL参数取值(params, key, default_data){
	const data = params[key];
	if(data == null || typeof data == "undefined" ){
		return default_data;
	}
	return data;
}
function 弹出面板初始化(){

	var rect = 公用模块.弹出面板初始化计算(20, 80, true);
	div_payment_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_payment_popover.添加组件("div_type_title");
	div_payment_popover.添加组件("div_type_dropbox");
	div_payment_popover.添加组件("div_acc_name_title");
	div_payment_popover.添加组件("div_acc_name_edit");
	div_payment_popover.添加组件("div_acc_num_title");
	div_payment_popover.添加组件("div_acc_num_edit");
	div_payment_popover.添加组件("div_bank_num_title");
	div_payment_popover.添加组件("div_bank_num_dropbox");
	div_payment_popover.添加组件("div_bank_name_title");
	div_payment_popover.添加组件("div_bank_name_edit");
	div_payment_popover.添加组件("div_phone_title");
	div_payment_popover.添加组件("div_phone_edit");
	div_payment_popover.添加组件("div_email_title");
	div_payment_popover.添加组件("div_email_edit");
	div_payment_popover.添加组件("div_amount_title");
	div_payment_popover.添加组件("div_amount_edit");
	div_payment_popover.添加组件("div_payment_btn");
	div_payment_popover.添加组件("div_payment_end");
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功("保存成功！");
		}else if(json.static == 2 ){
			var i= 0;

		}
	}
}

function 弹出代付操作页面(type_list, acc_name, acc_num, bank_num_list, bank_name, phone, email, amount){
	// type_list: 代付出款类型, list 格式, 如果是 [],代表隐藏此参数的选择, 单个元素：{"key": "10", "value": "银行出款"}
	// acc_name: 收款人姓名编辑框提示内容,非字符串代表隐藏此参数的输入;
	// acc_num: 银行卡号编辑框提示内容,非字符串代表隐藏此参数的输入;
	// bank_num_list: 银联号,list 格式, 如果是 [],代表隐藏此参数的选择, 单个元素：{"key": "36000002", "value": "BRI"}
	// bank_name: 银行名称编辑框提示内容,非字符串代表隐藏此参数的输入;
	// phone: 手机号编辑框提示内容,非字符串代表隐藏此参数的输入;
	// email: 电子邮箱编辑框提示内容,非字符串代表隐藏此参数的输入;
	// amount: 代付金额编辑框提示内容,非字符串不会隐藏此参数的输入;
	var res = 逻辑型 = false;
	payment_config = {}
	res = 子_弹出代付操作页面_下拉框处理(type_list, div_type_title, div_type_dropbox);
	payment_config.type = res;
	res = 子_弹出代付操作页面_编辑框处理(acc_name, div_acc_name_title, div_acc_name_edit);
	payment_config.acc_name = res;
	res = 子_弹出代付操作页面_编辑框处理(acc_num, div_acc_num_title, div_acc_num_edit);
	payment_config.acc_num = res;
	res = 子_弹出代付操作页面_下拉框处理(bank_num_list, div_bank_num_title, div_bank_num_dropbox);
	payment_config.bank_num = res;
	res = 子_弹出代付操作页面_编辑框处理(bank_name, div_bank_name_title, div_bank_name_edit);
	payment_config.bank_name = res;
	res = 子_弹出代付操作页面_编辑框处理(phone, div_phone_title, div_phone_edit);
	payment_config.phone = res;
	res = 子_弹出代付操作页面_编辑框处理(email, div_email_title, div_email_edit);
	payment_config.email = res;
	if(typeof amount != "string" ){
		amount = "";
	}
	amount = 文本操作.删首尾空(amount);
	div_amount_edit.置提示内容(amount);
	div_amount_edit.置内容("");
	div_payment_btn.置可视(true);
}
function 子_弹出代付操作页面_下拉框处理(list_data, div_title, div_dropbox){
	if(typeof list_data != "object" ){
		list_data = [];
	}
	var _ret = false;
	if(list_data.length < 1 ){
		div_title.置可视(false);
		div_dropbox.清空项目();
		div_dropbox.添加项目("","");
		div_dropbox.置可视(false);
	}else{
		div_title.置可视(true);
		div_dropbox.清空项目();
		var i=0;
		while(i<list_data.length){
			div_dropbox.添加项目(list_data[i].value+" ("+list_data[i].key+")",list_data[i].key);
			i++
		}
		div_dropbox.置可视(true);
		_ret = true;
	}
	div_dropbox.置现行选中项(0);
	return _ret;
}
function 子_弹出代付操作页面_编辑框处理(tips, div_title, div_edit){
	var _ret = false;
	if(typeof tips != "string" ){
		div_title.置可视(false);
		div_edit.置可视(false);
	}else{
		div_title.置可视(true);
		div_edit.置可视(true);
		div_edit.置提示内容(tips);
		_ret = true;
	}
	div_edit.置内容("");
	return _ret;
}
function div_payment_btn_被单击(){

	var json= {}
	json.type = div_type_dropbox.取项目标记(div_type_dropbox.取现行选中项());
	div_acc_name_edit.置内容(文本操作.删首尾空(div_acc_name_edit.取内容()));
	json.acc_name = div_acc_name_edit.取内容();
	if(div_acc_name_edit.取内容() == "" && payment_config.acc_name == true ){
		仔仔弹出对话框1.错误("请输入收款人姓名");
		return;
	}

	div_acc_num_edit.置内容(文本操作.删首尾空(div_acc_num_edit.取内容()));
	json.acc_num = div_acc_num_edit.取内容();
	if(div_acc_num_edit.取内容() == "" && payment_config.acc_num == true ){
		仔仔弹出对话框1.错误("请输入收款银行卡号");
		return;
	}
	json.bank_num = div_bank_num_dropbox.取项目标记(div_bank_num_dropbox.取现行选中项());

	div_bank_name_edit.置内容(文本操作.删首尾空(div_bank_name_edit.取内容()));
	json.bank_name = div_bank_name_edit.取内容();
	if(div_bank_name_edit.取内容() == "" && payment_config.bank_name == true ){
		仔仔弹出对话框1.错误("请输入银行名称");
		return;
	}

	div_phone_edit.置内容(文本操作.删首尾空(div_phone_edit.取内容()));
	json.phone = div_phone_edit.取内容();
	if(div_phone_edit.取内容() == "" && payment_config.phone == true ){
		仔仔弹出对话框1.错误("请输入手机号");
		return;
	}

	div_email_edit.置内容(文本操作.删首尾空(div_email_edit.取内容()));
	json.email = div_email_edit.取内容();
	if(div_email_edit.取内容() == "" && payment_config.email == true ){
		仔仔弹出对话框1.错误("请输入电子邮箱");
		return;
	}

	div_amount_edit.置内容(文本操作.删首尾空(div_amount_edit.取内容()));
	if(div_amount_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入代付金额");
		return;
	}
	var amount= 转换操作.到数值(div_amount_edit.取内容());
	if(amount <= 0 ){
		仔仔弹出对话框1.错误("代付金额必须大于0");
		return;
	}
	json.amount = amount;
	if(HPtools1.询问框("以上参数是否无误？") == false ){
		return;
	}
	json.plugin = plugin;
	json.currency_id = currency_id;
	json.root_url = 根地址;
	m_post = 公用模块.生成提交数据(ID, "newpay_channel_info_payment", "", "insert" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin2/insert",m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	发起POST表单(m_url, 转换操作.文本转json(m_post));

}

function 发起POST表单(submit, payload){
	var form = document.createElement("form");
	form.action = submit;
	form.method = "POST";
	Object.entries(payload).forEach(([key, value]) => {
		const element = document.createElement("input");
		element.type = "hidden";
		element.name = key;
		element.value = value;
		form.appendChild(element);
	});
	document.body.appendChild(form);
	form.submit();

}