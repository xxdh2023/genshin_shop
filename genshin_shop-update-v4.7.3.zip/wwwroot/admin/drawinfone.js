mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 自由面板2 = new 自由面板("自由面板2","260px");
var 标签1 = new 标签("标签1",null);
var 自由面板1 = new 自由面板("自由面板1","107px");
var div_lot_model_0 = new 单选框("div_lot_model_0",div_lot_model_0_被单击);
var div_lot_model_1 = new 单选框("div_lot_model_1",div_lot_model_1_被单击);
var div_lot_model_2 = new 单选框("div_lot_model_2",div_lot_model_2_被单击);
var div_lot_model_3 = new 单选框("div_lot_model_3",div_lot_model_3_被单击);
var div_lot_model_4 = new 单选框("div_lot_model_4",div_lot_model_4_被单击);
var 标签2 = new 标签("标签2",null);
var div_lot_static_0 = new 单选框("div_lot_static_0",null);
var div_lot_static_1 = new 单选框("div_lot_static_1",null);
var 图片框_图标 = new 图片框("图片框_图标",图片框_图标_被单击);
var div_lot_id_edit = new 编辑框("div_lot_id_edit",null,null,null,null,null);
var div_lot_name_edit = new 编辑框("div_lot_name_edit",null,null,null,null,null);
var div_lot_note_edit = new 编辑框("div_lot_note_edit",null,null,null,null,null);
var 标签4 = new 标签("标签4",null);
var div_lot_cell_num_dropbox = new 下拉框("div_lot_cell_num_dropbox",div_lot_cell_num_dropbox_表项被单击);
var 高级表格_奖品 = new 高级表格("高级表格_奖品",null,null,null,高级表格_奖品_单元格被编辑,null,null,null,null);
var div_lot_vip_edit = new 编辑框("div_lot_vip_edit",null,null,null,null,null);
var 按钮组_操作 = new 按钮组("按钮组_操作",按钮组_操作_被单击);
var 标签3 = new 标签("标签3",null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var div_add_popover = new 弹出面板("div_add_popover",null,null);
var div_add_edit = new 编辑框("div_add_edit",null,null,null,null,null);
var div_add_dropbox = new 下拉框("div_add_dropbox",div_add_dropbox_表项被单击);
var div_add_btn = new 按钮("div_add_btn",div_add_btn_被单击,null,null);
var div_add_grid = new 列表框("div_add_grid",true,null,div_add_grid_按钮被单击);
var div_add_btns = new 按钮组("div_add_btns",div_add_btns_被单击);
var div_add_next_popover = new 弹出面板("div_add_next_popover",null,null);
var div_add_next_dropbox = new 下拉框("div_add_next_dropbox",div_add_next_dropbox_表项被单击);
var div_add_next_num_edit = new 编辑框("div_add_next_num_edit",null,null,null,null,null);
var div_add_next_level_edit = new 编辑框("div_add_next_level_edit",null,null,null,null,null);
var div_add_next_accept = new 单选框("div_add_next_accept",null);
var div_add_next_finish = new 单选框("div_add_next_finish",null);
var div_add_next_btn = new 按钮("div_add_next_btn",div_add_next_btn_被单击,null,null);
var 文件选择器1 = new 文件选择器("文件选择器1",文件选择器1_选择完毕,文件选择器1_读入完毕,null);
var 仔仔1 = new 仔仔("仔仔1",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null);
var div_lot_model_4_lable = new 标签("div_lot_model_4_lable",null);
var div_lot_coin = new 编辑框("div_lot_coin",null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var 高级表格_随机 = new 高级表格("高级表格_随机",高级表格_随机_工具栏按钮被单击,高级表格_随机_操作栏按钮被单击,null,null,null,null,null,null);
var div_lot_model_5_lable = new 标签("div_lot_model_5_lable",null);
var div_lot_coin2 = new 编辑框("div_lot_coin2",null,null,null,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        抽奖档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        抽奖档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;
var class_name= "";
var value="";
var page= 0;
var m_json= {}
var lot_type= 0;
var lot_pic ="";
var 集_表格数据 = new Array();
var lot_cell_num= 8;
var add_table= "";


function 抽奖档案窗口_创建完毕(){
	ID = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("ID")));
	根地址 = HPtools1.取URL();
	按钮组_操作.置样式(0,"mui-btn");
	按钮组_操作.置样式(2,"mui-btn mui-btn-danger");
	div_lot_id_edit.置只读模式(true);
	div_add_btns.置样式(0,"mui-btn mui-btn-danger");
	div_lot_model_0.置分组("A");
	div_lot_model_2.置分组("A");
	div_lot_model_1.置分组("A");
	div_lot_model_3.置分组("A");
	div_lot_model_4.置分组("A");
	div_lot_static_0.置分组("C");
	div_lot_static_1.置分组("C");
	div_add_next_accept.置分组("B");
	div_add_next_finish.置分组("B");
	div_lot_note_edit.置提示内容("抽奖简介，<br>是换行，并且支持html语言，例如显示红色：<font color=\"red\">简介内容</font>；\n注意：引号、等号之类的字符一定要用半角英文");
	div_lot_vip_edit.置提示内容("限制显示范围，本参数空代表所有玩家都能看到本抽奖，否则输入VIP等级的编码;\n多个VIP等级编码,用半角逗号分隔,例如：VIP1,VIP2,VIP3,");
	高级表格初始化();
	添加初始化();
	var i= 0;
	while(i < 16){
		集_表格数据[i] = ["",0,0];
		i++
	}
	奖品列表重置(8);
	div_lot_cell_num_dropbox.添加项目("4个奖品","4");
	div_lot_cell_num_dropbox.添加项目("6个奖品","6");
	div_lot_cell_num_dropbox.添加项目("8个奖品","8");
	div_lot_cell_num_dropbox.添加项目("10个奖品","10")
div_lot_cell_num_dropbox.添加项目("12个奖品","12");
	div_lot_cell_num_dropbox.添加项目("14个奖品","14");
	div_lot_cell_num_dropbox.添加项目("16个奖品","16");
	div_lot_cell_num_dropbox.置现行选中项(2);
	档案查询();
}

function 高级表格初始化(){
	高级表格1.添加列("xh","",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",80,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("lot_cell","奖品序号",150,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_value","显示名称",300,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_detail","内部脚本",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"添加奖品明细");
	高级表格1.添加工具栏按钮(2,false,"自定义批量导入");
	高级表格1.初始化("auto",true,true,false,true);
	高级表格_随机.添加列("xh","",0,false,false,false,true,true,false,"",false,false);
	高级表格_随机.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格_随机.添加列("oper","操作",80,false,false,true,true,false,false,"",false,false);
	高级表格_随机.添加列("rand_value","随机福利名称",300,false,false,false,false,false,false,"",false,false);
	高级表格_随机.添加列("rand_detail","内部脚本",200,false,false,false,false,false,false,"",false,false);
	高级表格_随机.添加工具栏按钮(1,false,"添加随机福利");
	高级表格_随机.添加工具栏按钮(2,false,"自定义批量导入");
	高级表格_随机.初始化("auto",true,true,false,true);
	高级表格_奖品.添加列("xh","",0,false,false,false,true,true,false,"",false,false);
	高级表格_奖品.添加列("lot_type","奖品序号",150,false,false,false,false,false,false,"",false,false);
	高级表格_奖品.添加列("lot_cell_name","奖品名称(直接在下方单元格填写)",300,false,false,false,false,false,false,"",true,false);
	高级表格_奖品.添加列("lot_cell_rate","中奖率(直接在下方单元格填写)",200,false,false,false,false,false,false,"",true,false);
	高级表格_奖品.添加列("lot_cell_random","随机发放福利数",150,false,false,false,false,false,false,"",true,false);
	高级表格_奖品.初始化("auto",true,true,false,true);
}
function 添加初始化(){
	var rect = 公用模块.弹出面板初始化计算(50,80, true);
	div_add_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_popover.添加组件("div_add_edit" );
	div_add_popover.添加组件("div_add_dropbox");
	div_add_popover.添加组件("div_add_btn");
	div_add_popover.添加组件("div_add_grid");
	div_add_popover.添加组件("div_add_btns");
	var rect = 公用模块.弹出面板初始化计算(50,140, false);
	div_add_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_next_popover.添加组件("div_add_next_dropbox" );
	div_add_next_popover.添加组件("div_add_next_num_edit" );
	div_add_next_popover.添加组件("div_add_next_level_edit" );
	div_add_next_popover.添加组件("div_add_next_accept" );
	div_add_next_popover.添加组件("div_add_next_finish" );
	div_add_next_popover.添加组件("div_add_next_btn" );
}
function 档案查询(){
	if(ID > 0 ){
		m_post = 公用模块.生成提交数据(ID, "lottery_draw_info", "", "read" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		时钟1.开始执行(200,false);
	}
}
function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}
function 奖品列表重置(奖品数量){
	if(奖品数量 < 0 ){
		奖品数量 = 0;
	}
	if(奖品数量 > 16 ){
		奖品数量 = 16;
	}
	lot_cell_num = 奖品数量;
	div_add_next_dropbox.清空项目();
	div_add_next_dropbox.添加项目("请选择奖品序号......","0");
	lot_type = 0;
	if(奖品数量 == 0 ){
		高级表格_奖品.清空行();
		高级表格_奖品.初始化("auto",true,true,false,true);
		return;
	}
	高级表格_奖品.取指定行数据();
	var i= 0;
	高级表格_奖品.清空行();
	while(i < 奖品数量){
		div_add_next_dropbox.添加项目("第"+转换操作.到文本(i+1)+"号奖品",""+(i+1));
		if(i < 数组操作.取成员数(集_表格数据) ){
			高级表格_奖品.添加行(false,["","第"+转换操作.到文本(i+1)+"号奖品",集_表格数据[i][0],集_表格数据[i][1],集_表格数据[i][2]]);
		}else{
			高级表格_奖品.添加行(false,["","第"+转换操作.到文本(i+1)+"号奖品","","",0]);
		}
		i++
	}
	高级表格_奖品.初始化("auto",true,true,false,true);
}
function 高级表格_奖品_单元格被编辑(行索引,列索引,新数据,行数据){
	if(列索引 == "lot_cell_name" ){
		集_表格数据[行索引][0] = 新数据;
		var 行数= 高级表格_奖品.取行数();
		var i= 0;
		while(i < 行数){
			if(i != 行索引 ){

				if(新数据 == 集_表格数据[0] ){
					仔仔弹出对话框1.错误("第"+转换操作.到文本(行索引+1)+"号奖品名称与其他奖品重复！");
				}
			}
			i++
		}
	}else if(列索引 == "lot_cell_rate" ){
		集_表格数据[行索引][1] = 新数据;
		var bool= 公用模块.是否为整数文本(新数据, false, true);
		if(bool == false ){
			仔仔弹出对话框1.错误("第"+转换操作.到文本(行索引+1)+"号奖品中奖率设置错误！");
		}else{
			if(转换操作.到数值(新数据) > 99 ){
				仔仔弹出对话框1.错误("第"+转换操作.到文本(行索引+1)+"号奖品中奖率设置错误！");
			}
		}
	}else if(列索引 == "lot_cell_random" ){
		集_表格数据[行索引][2] = 新数据;
		var bool= 公用模块.是否为整数文本(新数据, false, true);
		if(bool == false ){
			仔仔弹出对话框1.错误("第"+转换操作.到文本(行索引+1)+"号奖品随机发放福利数设置错误！");
		}else{
			if(转换操作.到数值(新数据) < 0 ){
				仔仔弹出对话框1.错误("第"+转换操作.到文本(行索引+1)+"号奖品随机发放福利数设置错误！");
			}
		}

	}
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "lottery_draw_info" ){
				if(json.model == "insert" ){
					ID = 转换操作.到数值(json.msg);
					div_lot_id_edit.置内容(json._id);
					仔仔弹出对话框1.成功("添加成功！");
				}else if(json.model == "update" ){
					仔仔弹出对话框1.成功("更新成功！");
				}else if(json.model == "delete" ){
					档案新增();
					仔仔弹出对话框1.成功("删除成功！");
				}
			}else if(json.table == "lottery_draw_info_detail" ){
				if(json.model == "insert" ){
					div_add_popover.隐藏();
					div_add_next_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else if(json.table == "lottery_draw_info_random" ){
				if(json.model == "insert" ){
					div_add_popover.隐藏();
					div_add_next_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else{
				仔仔弹出对话框1.成功("执行成功！");
			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "lottery_draw_info" ){
				档案新增();
				ID = json.results.ID;
				div_lot_id_edit.置内容(json.results.lot_id);
				div_lot_name_edit.置内容(json.results.lot_name);
				div_lot_note_edit.置内容(json.results.lot_note);
				div_lot_vip_edit.置内容(json.results.lot_vip);
				价格组件显隐(false);
				switch(json.results.lot_model){
					case 0 :
						div_lot_model_0.置选中状态(true);
					break;
					case 1 :
						div_lot_model_1.置选中状态(true);
					break;
					case 2 :
						div_lot_model_2.置选中状态(true);
					break;
					case 3 :
						div_lot_model_3.置选中状态(true);
					break;
					case 4 :
						div_lot_model_4.置选中状态(true);
						价格组件显隐(true);
						div_lot_coin.置内容(转换操作.到文本(json.results.lot_coin));
						div_lot_coin2.置内容(转换操作.到文本(json.results.lot_coin2));
					break;
				}
				switch(json.results.lot_static){
					case 0 :
						div_lot_static_0.置选中状态(true);
					break;
					case 1 :
						div_lot_static_1.置选中状态(true);
					break;
				}
				奖品列表重置(0);
				lot_cell_num = json.results.lot_cell_num;
				if(lot_cell_num < 4 ){
					lot_cell_num = 4;
				}
				if(lot_cell_num > 16 ){
					lot_cell_num = 16;
				}
				switch(lot_cell_num){
					case 4 :
						div_lot_cell_num_dropbox.置现行选中项(0);
					break;
					case 6 :
						div_lot_cell_num_dropbox.置现行选中项(1);
					break;
					case 8 :
						div_lot_cell_num_dropbox.置现行选中项(2);
					break;
					case 10 :
						div_lot_cell_num_dropbox.置现行选中项(3);
					break;
					case 12 :
						div_lot_cell_num_dropbox.置现行选中项(4);
					break;
					case 14 :
						div_lot_cell_num_dropbox.置现行选中项(5);
					break;
					case 16 :
						div_lot_cell_num_dropbox.置现行选中项(6);
					break;
				}
				集_表格数据[0] = [json.results.lot_cell_1_name, json.results.lot_cell_1_rate, json.results.lot_cell_1_random];
				集_表格数据[1] = [json.results.lot_cell_2_name, json.results.lot_cell_2_rate, json.results.lot_cell_2_random];
				集_表格数据[2] = [json.results.lot_cell_3_name, json.results.lot_cell_3_rate, json.results.lot_cell_2_random];
				集_表格数据[3] = [json.results.lot_cell_4_name, json.results.lot_cell_4_rate, json.results.lot_cell_4_random];
				集_表格数据[4] = [json.results.lot_cell_5_name, json.results.lot_cell_5_rate, json.results.lot_cell_5_random];
				集_表格数据[5] = [json.results.lot_cell_6_name, json.results.lot_cell_6_rate, json.results.lot_cell_6_random];
				集_表格数据[6] = [json.results.lot_cell_7_name, json.results.lot_cell_7_rate, json.results.lot_cell_7_random];
				集_表格数据[7] = [json.results.lot_cell_8_name, json.results.lot_cell_8_rate, json.results.lot_cell_8_random];
				集_表格数据[8] = [json.results.lot_cell_9_name, json.results.lot_cell_9_rate, json.results.lot_cell_9_random];
				集_表格数据[9] = [json.results.lot_cell_10_name, json.results.lot_cell_10_rate, json.results.lot_cell_10_random];
				集_表格数据[10] = [json.results.lot_cell_11_name, json.results.lot_cell_11_rate, json.results.lot_cell_11_random];
				集_表格数据[11] = [json.results.lot_cell_12_name, json.results.lot_cell_12_rate, json.results.lot_cell_12_random];
				集_表格数据[12] = [json.results.lot_cell_13_name, json.results.lot_cell_13_rate, json.results.lot_cell_13_random];
				集_表格数据[13] = [json.results.lot_cell_14_name, json.results.lot_cell_14_rate, json.results.lot_cell_14_random];
				集_表格数据[14] = [json.results.lot_cell_15_name, json.results.lot_cell_15_rate, json.results.lot_cell_15_random];
				集_表格数据[15] = [json.results.lot_cell_16_name, json.results.lot_cell_16_rate, json.results.lot_cell_16_random];
				奖品列表重置(lot_cell_num);
				图片框_图标.置图片(根地址+json.results.lot_pic+"?"+转换操作.到文本(时间操作.取时间戳(时间操作.取当前日期时间())));
				var arr = new Array();
				while(i < json.results.detail.length){
					arr[0] = "";
					arr[1] = json.results.detail[i].ID;
					arr[2] = "删除";
					arr[3] = "第"+转换操作.到文本(json.results.detail[i].lot_type)+"号奖品";
					arr[4] = json.results.detail[i].lot_value;
					arr[5] = json.results.detail[i].lot_detail;
					高级表格1.添加行(false,arr);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(4,false,"删除");
				高级表格1.初始化("auto",true,true,false,true);
				i=0;
				while(i < json.results.random.length){
					arr[0] = "";
					arr[1] = json.results.random[i].ID;
					arr[2] = "删除";
					arr[3] = json.results.random[i].rand_value;
					arr[4] = json.results.random[i].rand_detail;
					高级表格_随机.添加行(false,arr);
					i++
				}
				高级表格_随机.清空操作栏按钮();
				高级表格_随机.添加操作栏按钮(4,false,"删除");
				高级表格_随机.初始化("auto",true,true,false,true);
			}else if(json.table == "item_class_info" ){
				class_name = "";
				div_add_dropbox.清空项目();
				div_add_dropbox.添加项目("请选择类别......","");
				while(i < json.results.length){
					div_add_dropbox.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
				div_add_popover.显示();

			}else if(json.table == "item_item_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						div_add_grid.清空项目();
					}
					page = json.page;
					if(json.total > json.page ){
						div_add_btns.置可视(true);
					}
					while(i < json.results.length){
						div_add_grid.添加项目(json.results[i].item_id+" :: "+json.results[i].item_name, ""+json.results[i].item_model+","+json.results[i].item_maxnum,"mui-btn mui-btn-primary","添加");
						i++
					}
				}
			}
		}
	}
}

function 档案新增(){
	ID = 0;
	图片框_图标.置图片("images/setpic.jpg");
	lot_pic="";
	div_lot_id_edit.置内容("");
	div_lot_name_edit.置内容("");
	div_lot_note_edit.置内容("");
	div_lot_model_0.置选中状态(false);
	div_lot_model_1.置选中状态(false);
	div_lot_model_2.置选中状态(false);
	div_lot_model_3.置选中状态(false);
	div_lot_model_4.置选中状态(false);
	价格组件显隐(false);
	div_lot_static_0.置选中状态(false);
	div_lot_static_1.置选中状态(false);
	var i= 0;
	while(i < 16){
		集_表格数据[i] = ["",0,0];
		i++
	}
	奖品列表重置(lot_cell_num);
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	高级表格_随机.清空行();
	高级表格_随机.初始化("auto",true,true,false,true);
}

function 按钮组_操作_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否新增？") == true ){
				档案新增();
			}
		break;
		case 1 :
			div_lot_name_edit.置内容(文本操作.删首尾空(div_lot_name_edit.取内容()));
			if(div_lot_name_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("抽奖名称不能为空！");
				return;
			}
			var lot_model= -1;
			var lot_coin= 0;
			if(div_lot_model_0.取选中状态()  == true ){
				lot_model = 0;
			}
			if(div_lot_model_1.取选中状态()  == true ){
				lot_model = 1;
			}
			if(div_lot_model_2.取选中状态()  == true ){
				lot_model = 2;
			}
			if(div_lot_model_3.取选中状态()  == true ){
				lot_model = 3;
			}
			var lot_coin2= 0;
			if(div_lot_model_4.取选中状态()  == true ){
				lot_model = 4;
				div_lot_coin.置内容(文本操作.删首尾空(div_lot_coin.取内容()));
				if(div_lot_coin.取内容() == "" ){
					仔仔弹出对话框1.错误("请输入需要花费的平台币数量！");
					return;
				}
				lot_coin = 转换操作.到数值(div_lot_coin.取内容());
				if(lot_coin <= 0 ){
					仔仔弹出对话框1.错误("单抽平台币价格必须大于0！");
					return;
				}
				lot_coin2 = 转换操作.到数值(div_lot_coin2.取内容());
				if(lot_coin2 < 0 ){
					仔仔弹出对话框1.错误("十连抽平台币价格不能小于0！");
					return;
				}
			}
			if(lot_model < 0 ){
				仔仔弹出对话框1.错误("请选择抽奖类型！");
				return;
			}
			div_lot_note_edit.置内容(文本操作.删首尾空(div_lot_note_edit.取内容()));
			div_lot_vip_edit.置内容(文本操作.删首尾空(div_lot_vip_edit.取内容()));
			var lot_static= 1;
			if(div_lot_static_0.取选中状态() == true ){
				lot_static = 0;
			}
			var i= 0;
			var cell_name = new Array();
			var cell_rate= 0;
			while(i < lot_cell_num){
				cell_name[i] = 集_表格数据[i][0];
				if(公用模块.是否为整数文本(集_表格数据[i][1],false,true) == false ){
					仔仔弹出对话框1.错误("第"+转换操作.到文本(i+1)+"号奖品的中奖率设置有误！");
					return;
				}
				cell_rate = cell_rate + 转换操作.到数值(集_表格数据[i][1]);
				i++
			}
			i = 16;
			while(i > lot_cell_num){
				集_表格数据[i-1][0] = "";
				集_表格数据[i-1][1] = 0;
				集_表格数据[i-1][2] = 0;
				i--
			}
			cell_name = 仔仔1.数组_数组去重(cell_name);
			if(数组操作.取成员数(cell_name) < lot_cell_num ){
				仔仔弹出对话框1.错误("设置的奖品名称不能重复！");
				return;
			}




			var json= {}
			json.lot_id = div_lot_id_edit.取内容();
			json.lot_name = div_lot_name_edit.取内容();
			json.lot_note = div_lot_note_edit.取内容();
			json.lot_vip = div_lot_vip_edit.取内容();
			json.lot_static = lot_static;
			json.lot_model = lot_model;
			json.lot_cell_num = lot_cell_num;
			json.lot_coin = lot_coin;
			json.lot_coin2 = lot_coin2;
			i=0;
			json.lot_cell_1_name = 集_表格数据[i][0];
			json.lot_cell_1_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_1_random = 转换操作.到数值(集_表格数据[i][2]);
			i=1;
			json.lot_cell_2_name = 集_表格数据[i][0];
			json.lot_cell_2_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_2_random = 转换操作.到数值(集_表格数据[i][2]);
			i=2;
			json.lot_cell_3_name = 集_表格数据[i][0];
			json.lot_cell_3_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_3_random = 转换操作.到数值(集_表格数据[i][2]);
			i=3;
			json.lot_cell_4_name = 集_表格数据[i][0];
			json.lot_cell_4_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_4_random = 转换操作.到数值(集_表格数据[i][2]);
			i=4;
			json.lot_cell_5_name = 集_表格数据[i][0];
			json.lot_cell_5_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_5_random = 转换操作.到数值(集_表格数据[i][2]);
			i=5;
			json.lot_cell_6_name = 集_表格数据[i][0];
			json.lot_cell_6_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_6_random = 转换操作.到数值(集_表格数据[i][2]);
			i=6;
			json.lot_cell_7_name = 集_表格数据[i][0];
			json.lot_cell_7_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_7_random = 转换操作.到数值(集_表格数据[i][2]);
			i=7;
			json.lot_cell_8_name = 集_表格数据[i][0];
			json.lot_cell_8_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_8_random = 转换操作.到数值(集_表格数据[i][2]);
			i=8;
			json.lot_cell_9_name = 集_表格数据[i][0];
			json.lot_cell_9_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_9_random = 转换操作.到数值(集_表格数据[i][2]);
			i=9;
			json.lot_cell_10_name = 集_表格数据[i][0];
			json.lot_cell_10_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_10_random = 转换操作.到数值(集_表格数据[i][2]);
			i=10;
			json.lot_cell_11_name = 集_表格数据[i][0];
			json.lot_cell_11_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_11_random = 转换操作.到数值(集_表格数据[i][2]);
			i=11;
			json.lot_cell_12_name = 集_表格数据[i][0];
			json.lot_cell_12_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_12_random = 转换操作.到数值(集_表格数据[i][2]);
			i=12;
			json.lot_cell_13_name = 集_表格数据[i][0];
			json.lot_cell_13_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_13_random = 转换操作.到数值(集_表格数据[i][2]);
			i=13;
			json.lot_cell_14_name = 集_表格数据[i][0];
			json.lot_cell_14_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_14_random = 转换操作.到数值(集_表格数据[i][2]);
			i=14;
			json.lot_cell_15_name = 集_表格数据[i][0];
			json.lot_cell_15_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_15_random = 转换操作.到数值(集_表格数据[i][2]);
			i=15;
			json.lot_cell_16_name = 集_表格数据[i][0];
			json.lot_cell_16_rate = 转换操作.到数值(集_表格数据[i][1]);
			json.lot_cell_16_random = 转换操作.到数值(集_表格数据[i][2]);
			json.lot_pic = "";
			if(ID < 1 ){
				if(lot_pic == "" ){
					仔仔弹出对话框1.错误("请设置抽奖档案的图标！");
					return;
				}
				json.lot_pic = lot_pic;
				m_post = 公用模块.生成提交数据(ID, "lottery_draw_info", "", "insert" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
				美化等待框1.默认等待框("正在交互","正在添加档案,请稍等......");
			}else{
				m_post = 公用模块.生成提交数据(ID, "lottery_draw_info", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在更新档案,请稍等......");
			}
			时钟1.开始执行(200,false);

		break;
		case 2 :
			if(ID > 0 ){
				if(HPtools1.询问框("是否删除？") == true ){
					var json= {}
					json.lot_id = div_lot_id_edit.取内容();
					m_post = 公用模块.生成提交数据(ID, "lottery_draw_info", "", "delete" , 1, 0, json);
					m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
					美化等待框1.默认等待框("正在交互","正在删除档案,请稍等......");
					时钟1.开始执行(200,false);
				}
			}
		break;
	}
}

function 高级表格1_工具栏按钮被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存抽奖档案！");
				return;
			}
			add_table = "lottery_draw_info_detail";
			div_add_next_dropbox.置可视(true);
			if(div_add_dropbox.取项目总数() < 1 ){
				m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
				美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
				时钟1.开始执行(200,false);
			}else{
				div_add_popover.显示();
			}
		break;
		case 1 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存抽奖档案！");
				return;
			}
			var url= "infoimport.html?table=lottery_draw_info_detail&item_id="+div_lot_id_edit.取内容();
			公用模块.居中打开小窗口(url, 900, 650);

		break;
	}
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	m_post = 公用模块.生成提交数据(_id, "lottery_draw_info_detail", "", "delete" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除奖品对应的明细,请稍等......");
	时钟1.开始执行(200,false);
}

function div_add_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name = 项目标记;
}

function div_add_btn_被单击(){
	div_add_edit.置内容(文本操作.删首尾空(div_add_edit.取内容()));
	value = div_add_edit.取内容();
	if(class_name == "" ){
		仔仔弹出对话框1.错误("请选择要查询的类别！");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name , 1, 0);
	page = 1;
	div_add_btns.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}

function div_add_btns_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name , page+1, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
			美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
			时钟1.开始执行(200,false);
		break;
		case 1 :
			div_add_popover.滚动条到顶部();

		break;
	}
}

function div_add_grid_按钮被单击(项目索引){
	var res = 文本操作.分割文本(div_add_grid.取项目标记(项目索引),",");
	var item_model= 转换操作.到数值(res[0]);
	var item_maxnum= 转换操作.到数值(res[1]);
	res = 公用模块.取编码和名称(div_add_grid.取项目标题(项目索引),"::");
	var item_id= res[0];
	var item_name= res[1];
	m_json = {}
	m_json.item_model = item_model;
	m_json.item_id = item_id;
	m_json.item_name = item_name;
	m_json.item_maxnum = item_maxnum;
	div_add_next_num_edit.置可视(false);
	div_add_next_level_edit.置可视(false);
	div_add_next_accept.置可视(false);
	div_add_next_finish.置可视(false);
	var h= 0;
	var 提示内容= "";
	if(item_model == 0 || item_model == 1 || item_model == 9 ){
		div_add_next_num_edit.置可视(true);
		if(item_model == 9 ){
			提示内容 = "请输入等级";
		}else{
			提示内容 = "请输入数量";
		}
		if(m_json.item_maxnum > 0 ){
			提示内容 = 提示内容 + ",最大不能超过：" + 转换操作.到文本(m_json.item_maxnum);
		}
		div_add_next_num_edit.置提示内容(提示内容);
		h++
	}else if(item_model == 7 ){
		m_json.item_maxnum = 14;
		div_add_next_num_edit.置可视(true);
		div_add_next_num_edit.置提示内容("请输入怪物数量,最大不能超过：14");
		div_add_next_level_edit.置可视(true);
		div_add_next_level_edit.置提示内容("请输入怪物等级，最大200级");
		h=h+2;
	}else if(item_model == 5 ){
		div_add_next_accept.置可视(true);
		div_add_next_finish.置可视(true);
		h=h+2;
	}else if(item_model == 2 ){
		m_json.item_maxnum = 6;
		div_add_next_num_edit.置可视(true);
		div_add_next_num_edit.置提示内容("请输入武器突破等级,最大不能超过：6");
		div_add_next_level_edit.置可视(true);
		div_add_next_level_edit.置提示内容("请输入武器精炼等阶,最大不能超过：5");
		h=h+2;

	}
	var rect = 公用模块.弹出面板初始化计算(50,120+h*40, false);
	div_add_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_next_num_edit.置内容("");
	div_add_next_level_edit.置内容("");
	div_add_next_popover.显示();

}


function div_add_next_btn_被单击(){
	if(lot_type < 1 && add_table == "lottery_draw_info_detail" ){
		仔仔弹出对话框1.错误("请选择奖品序号！");
		return;
	}
	div_add_next_num_edit.置内容(文本操作.删首尾空(div_add_next_num_edit.取内容()));
	div_add_next_level_edit.置内容(文本操作.删首尾空(div_add_next_level_edit.取内容()));
	var num= 转换操作.到数值(div_add_next_num_edit.取内容());
	if(m_json.item_model == 0 || m_json.item_model == 1 || m_json.item_model == 9 || m_json.item_model == 7 ){
		if(num < 1 ){
			仔仔弹出对话框1.错误("请输入大于0的数量！");
			return;
		}
		if(num > m_json.item_maxnum && m_json.item_maxnum > 0 ){
			仔仔弹出对话框1.错误("输入的数量不能大于："+转换操作.到文本(m_json.item_maxnum));
			return;
		}
	}else if(m_json.item_model == 5 ){
		num = -1;
		if(div_add_next_accept.取选中状态() == true ){
			num = 1;
		}
		if(div_add_next_finish.取选中状态() == true ){
			num = 0;
		}
		if(num < 0 ){
			仔仔弹出对话框1.错误("请确认任务类型：接受/完成");
			return;
		}
	}
	var level= 转换操作.到数值(div_add_next_level_edit.取内容());
	if(m_json.item_model == 7  && level > 200 ){
		仔仔弹出对话框1.错误("怪物等级不能超过200！");
		return;
	}
	if(m_json.item_model == 2 && level > 5 ){
		仔仔弹出对话框1.错误("武器精炼等阶不能超过5！");
		return;
	}
	if(m_json.item_model == 2 && level > 1 && num < 1 ){
		仔仔弹出对话框1.错误("请输入大于0的武器突破等级！");
		return;
	}
	res = 公用模块.生成脚本内容及显示名称(m_json.item_model, m_json.item_id, m_json.item_name,num,level);
	var json= {}
	json.lot_id = div_lot_id_edit.取内容();
	json.lot_value = res[1];
	json.lot_detail = res[0];
	json.lot_type = lot_type;
	m_post = 公用模块.生成提交数据(ID, add_table, "", "insert" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	美化等待框1.默认等待框("正在交互","正在添加奖品明细,请稍等......");
	时钟1.开始执行(200,false);
}
function div_add_next_dropbox_表项被单击(项目索引,项目标题,项目标记){
	lot_type = 转换操作.到数值(项目标记);
}
function 图片框_图标_被单击(){
	if(ID > 0 ){
		if(HPtools1.询问框("是否更换图片？") == false ){
			return;
		}
	}
	文件选择器1.限制类型("image/jpeg,image/png,image/bmp");
	文件选择器1.开始选择();
}
function 文件选择器1_选择完毕(文件路径,文件对象){
	文件选择器1.读入文件(文件对象,2);
}
function 文件选择器1_读入完毕(结果,内容){
	var data= "";
	var i= 文本操作.倒找文本(内容,",");
	if(i > -1 ){
		data = 文本操作.取文本右边(内容,文本操作.取文本长度(内容) - i - 1);
	}else{
		data = 内容;
	}
	图片框_图标.置图片(内容);
	if(ID < 1 ){
		lot_pic = data;
	}
	if(ID > 0 ){
		var json= {}
		json.lot_pic = data;
		m_post = 公用模块.生成提交数据(ID, "lottery_draw_info", "lot_pic", "update" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
		美化等待框1.默认等待框("正在交互","正在更新图片,请稍等......");
		时钟1.开始执行(200,false);
	}
}

function div_lot_model_0_被单击(){
	价格组件显隐(false);
}
function div_lot_model_1_被单击(){
	价格组件显隐(false);
}
function div_lot_model_2_被单击(){
	价格组件显隐(false);
}
function div_lot_model_3_被单击(){
	价格组件显隐(false);
}
function div_lot_model_4_被单击(){
	价格组件显隐(true);
}
function 价格组件显隐(显示){
	div_lot_model_4_lable.置可视(显示);
	div_lot_coin.置可视(显示);
	div_lot_model_5_lable.置可视(显示);
	div_lot_coin2.置可视(显示);
	if(显示 == false ){
		div_lot_coin.置内容("");
		div_lot_coin2.置内容("");
	}
}
function div_lot_cell_num_dropbox_表项被单击(项目索引,项目标题,项目标记){
	lot_cell_num = 转换操作.到数值(项目标记);
	奖品列表重置(lot_cell_num);
}
function 高级表格_随机_工具栏按钮被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存抽奖档案！");
				return;
			}
			add_table = "lottery_draw_info_random";
			div_add_next_dropbox.置可视(false);
			if(div_add_dropbox.取项目总数() < 1 ){
				m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
				美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
				时钟1.开始执行(200,false);
			}else{
				div_add_popover.显示();
			}
		break;
		case 1 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存抽奖档案！");
				return;
			}
			var url= "infoimport.html?table=lottery_draw_info_random&item_id="+div_lot_id_edit.取内容();
			公用模块.居中打开小窗口(url, 900, 650);
		break;
	}
}
function 高级表格_随机_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	m_post = 公用模块.生成提交数据(_id, "lottery_draw_info_random", "", "delete" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除随机奖品池明细,请稍等......");
	时钟1.开始执行(200,false);
}