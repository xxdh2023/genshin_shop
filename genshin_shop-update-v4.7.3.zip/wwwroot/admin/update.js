mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 标签_错误提示 = new 标签("标签_错误提示",null);
var 标签_基础提示 = new 标签("标签_基础提示",null);
var 标签_升级包名称 = new 标签("标签_升级包名称",null);
var 复选框_确认_1 = new 复选框("复选框_确认_1",null);
var 复选框_确认_2 = new 复选框("复选框_确认_2",null);
var 复选框_确认_3 = new 复选框("复选框_确认_3",null);
var 复选框_确认_4 = new 复选框("复选框_确认_4",null);
var 复选框_确认_5 = new 复选框("复选框_确认_5",null);
var 复选框_确认_6 = new 复选框("复选框_确认_6",null);
var 标签_下载进度 = new 标签("标签_下载进度",null);
var 按钮_确认 = new 按钮("按钮_确认",按钮_确认_被单击,null,null);
var 标签_日志 = new 标签("标签_日志",null);
var CYS索引列表框1 = new CYS索引列表框("CYS索引列表框1",null);
var 客户端1 = new 客户端("客户端1",客户端1_连接成功,客户端1_出现错误,客户端1_收到数据,客户端1_连接断开);
var 时钟_倒计时 = new 时钟("时钟_倒计时",时钟_倒计时_周期事件);
if(mui.os.plus){
    mui.plusReady(function() {
        平台升级_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        平台升级_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var 正在升级= false;
var 禁止重置= false;
var 倒计时= 60;



function 平台升级_创建完毕(){
	根地址 = HPtools1.取URL();
	m_post = "";
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在获取,请稍等......");
	时钟1.开始执行(200,false);
}

function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			标签_错误提示.置标题(json.msg);
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			标签_错误提示.置标题(json.msg);
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			标签_错误提示.置可视(false);
			标签_基础提示.置标题("最新版本号："+json.comm+"<br>完整下载链接："+json.model);
			标签_基础提示.置可视(true);
			标签_升级包名称.置标题("<br>本次升级包名称："+json.msg.name+"<br>升级确认：");
			标签_升级包名称.置可视(true);
			复选框_确认_1.置可视(true);
			复选框_确认_2.置可视(true);


			复选框_确认_5.置可视(true);
			复选框_确认_6.置可视(true);
			按钮_确认.置可视(true);
			标签_日志.置可视(true);
			CYS索引列表框1.清空();
			var i= 0;
			while(i<json._id.logs.length){
				v=0;
				CYS索引列表框1.添加分组(json._id.logs[i].title);
				while(v < json._id.logs[i].values.length){
					if(json._id.logs[i].values[v] != "" ){
						CYS索引列表框1.添加项目(i, json._id.logs[i].values[v]);
					}
					v++
				}
				i++
			}


		}else if(json.static == 2 ){
			var i= 0;




		}
	}
}

function 按钮_确认_被单击(){
	if(正在升级 == true ){
		仔仔弹出对话框1.提示("正在升级中......");
		return;
	}
	if(复选框_确认_1.取选中状态() == false ){
		仔仔弹出对话框1.错误("请确认并勾选【升级确认】的条目");
		return;
	}
	if(复选框_确认_2.取选中状态() == false ){
		仔仔弹出对话框1.错误("请确认并勾选【升级确认】的条目");
		return;
	}








	if(复选框_确认_5.取选中状态() == false ){
		仔仔弹出对话框1.错误("请确认并勾选【升级确认】的条目");
		return;
	}
	if(复选框_确认_6.取选中状态() == false ){
		仔仔弹出对话框1.错误("请确认并勾选【升级确认】的条目");
		return;
	}
	if(HPtools1.询问框("警告！升级过程不可逆,是否确认升级？") == false ){
		return;
	}
	按钮_确认.置标题("正在连接......");
	var ws= 公用模块.生成访问链接_后端(根地址,"websocket","");
	ws = "ws" + 文本操作.取文本右边(ws, 文本操作.取文本长度(ws) - 4);
	客户端1.打开连接(ws);
}
function 客户端1_连接成功(){
	正在升级 = true;
	按钮_确认.置标题("连接成功！");
	按钮_确认.置样式("mui-btn");
	var server_port= 公用模块.取端口(根地址);
	var str= 公用模块.生成提交数据(0, "update", m_password, "", server_port);
	客户端1.发送数据(str);
}
function 客户端1_出现错误(错误信息){
	按钮_确认.置标题("开始升级");
	仔仔弹出对话框1.错误("交互异常："+错误信息);
}
function 客户端1_收到数据(数据){
	var json=转换操作.文本转json(数据);
	if(json.static == 0 ){
		仔仔弹出对话框1.错误(json.msg);
	}else if(json.static == 1 ){
		标签_下载进度.置可视(true);
		标签_下载进度.置标题("正在下载中,当前进度："+转换操作.到文本(json.msg)+"%");
	}else if(json.static == 2 ){
		禁止重置 = true;
		标签_下载进度.置可视(true);
		标签_下载进度.置标题("正在下载中,当前进度："+转换操作.到文本(json.msg)+"%");
		按钮_确认.置标题("下载完成,正在升级文件......("+转换操作.到文本(倒计时)+")");
		时钟_倒计时.开始执行(1000, true);
	}
}
function 客户端1_连接断开(){
	if(禁止重置 == true ){
		return;
	}
	正在升级 = false;
	按钮_确认.置样式("mui-btn mui-btn-primary");
}
function 时钟_倒计时_周期事件(){
	if(倒计时 > 1 ){
		倒计时 = 倒计时 - 1;
		按钮_确认.置标题("下载完成,正在升级文件......("+转换操作.到文本(倒计时)+")");
		if(倒计时 < 46 ){
			测试服务器是否上线();
		}
	}else{
		按钮_确认.置标题("请关闭本页面, 并继续使用本平台");
		时钟_倒计时.停止执行();
	}
}

function 测试服务器是否上线(){
	var xhr = new XMLHttpRequest();
	xhr.open("GET", 根地址, true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				倒计时 = 0;
				仔仔弹出对话框1.成功("已升级成功！");
			} else {console.log(根地址 + " is not valid.");}
		}
	};
	xhr.send();
}