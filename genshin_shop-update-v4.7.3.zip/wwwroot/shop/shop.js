mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",标题栏1_被双击,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,null,null);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var div_show_lable = new 标签("div_show_lable",null);
var 列表哥AUI搜索框1 = new 列表哥AUI搜索框("列表哥AUI搜索框1",列表哥AUI搜索框1_搜索按钮被单击);
var CYS悬浮文字导航1 = new CYS悬浮文字导航("CYS悬浮文字导航1",CYS悬浮文字导航1_项目被单击,null);
var div_head_pic = new 图片框("div_head_pic",null);
var CYS订单列表框1 = new CYS订单列表框("CYS订单列表框1",CYS订单列表框1_项目被单击,CYS订单列表框1_按钮被单击);
var 按钮_加载更多 = new 按钮("按钮_加载更多",按钮_加载更多_被单击,null,null);
var div_detail_popover = new 弹出面板("div_detail_popover",null,null);
var div_detail_lable = new 标签("div_detail_lable",null);
var div_detail_grid = new CYS选择列表框("div_detail_grid",null);
var div_detail_label = new 标签("div_detail_label",null);
var div_detail_btn = new 按钮("div_detail_btn",div_detail_btn_被单击,null,null);
var div_buy_num = new 标签("div_buy_num",null);
var div_row = new 标签("div_row",null);
if(mui.os.plus){
    mui.plusReady(function() {
        商城_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        商城_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 导航索引= 0;
var class_name="";
var select_value= "";
var page= 0;
function 商城_创建完毕(){
	公用模块.动态加载脚本("files/popup.js", 隐藏框架);
	根地址 = HPtools1.取URL();
	导航栏初始化(0);

	标题栏美化1.去标题栏阴影();
	弹出面板初始化();
	div_head_pic.置可视2(false);
	列表哥AUI搜索框1.置可视(false);
	m_post = 公用模块.生成提交数据(0, "shop_class_info", "", "select" , 1, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/shop", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 导航栏初始化(激活项目){
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-cart","商城","0",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-grech","抽奖","1",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-gift","福利","2",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-express","仓库","3",0);
	导航栏1.添加项目("mui-icon", "mui-icon-contact","我的","4",0);
	导航栏1.添加完毕();
	导航栏1.置激活项目背景色("#F2F2F2");
	导航栏1.置项目激活状态(0,false);
	导航栏1.置项目激活状态(1,false);
	导航栏1.置项目激活状态(2,false);
	导航栏1.置项目激活状态(3,false);
	导航栏1.置项目激活状态(4,false);
	导航栏1.置项目激活状态(激活项目,true);
	导航索引 = 激活项目;
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_detail_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_detail_popover.添加组件("div_detail_lable");
	div_detail_popover.添加组件("div_detail_grid");
	div_detail_popover.添加组件("div_detail_label");
	div_detail_popover.添加组件("div_detail_btn");
}
function 导航栏1_项目被单击(项目标题,目标名称){
	var arr = ["shop","lottery","welfare","warehouse","user"];
	var 子卡索引=转换操作.到数值(目标名称);
	if(子卡索引 == 导航索引 ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(arr[子卡索引]+".html","");
	}
}

function 刷新列表(查询的页号){
	if(查询的页号 < 2 ){
		CYS订单列表框1.清空项目();
		按钮_加载更多.置可视(false);
	}
	var json= {}
	json.value = select_value;
	m_post = 公用模块.生成提交数据(0, "shop_mall_info", class_name, "select" , 查询的页号, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/shop", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 网络操作1_发送完毕(发送结果,返回信息){
	关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			if(json.table == "shop_mall_info" && json.model == "buy" ){
				div_detail_popover.隐藏();
				CYS订单列表框1.删除项目(json.results.row);
				仔仔弹出对话框1.错误(json.msg);
			}else if(json.table == "shop_mall_info" && json.model == "select" ){
				仔仔弹出对话框1.错误(json.msg);
			}else{
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
			}
		}else if(json.static == 0 ){
			if(json.table == "shop_mall_info" && json.model == "buy" ){
				div_detail_popover.隐藏();
				CYS订单列表框1.置按钮标题(json.results.row,"立即购买");
				if(json.comm != "coin" ){
					仔仔弹出对话框1.错误(json.msg);
				}else{
					发起直充前();
				}
			}else if(json.table == "user_pay" && json.model == "select" ){
				打开兑换窗口();
				仔仔弹出对话框1.错误(json.msg);
			}else if(json.table == "shop_mall_info" && json.model == "ask" ){
				CYS订单列表框1.置按钮标题(json.results.row,"立即购买");
				仔仔弹出对话框1.错误(json.msg);
			}else if(json.table == "shop_mall_info" && json.model == "select" ){
				仔仔弹出对话框1.错误(json.msg);
			}else{
				if(json.table == "shop_class_info" && json.model == "select" ){
					if(json._id == "" ){
						div_head_pic.置图片("images/shop_head.png");
					}else{
						div_head_pic.置图片(json._id);
					}
					公用模块.头部图片自适应("div_head_pic", 200);
				}
				仔仔弹出对话框1.错误(json.msg);
			}
		}else if(json.static == 1 ){
			if(json.table == "shop_mall_info" && json.model == "buy" ){
				CYS订单列表框1.置按钮标题(json.results.row,"立即购买");
				str = CYS订单列表框1.取交易状态(json.results.row);
				str = 公用模块.交易状态_设置(str, json.results.shop_num, json.results.sold_num);
				CYS订单列表框1.置交易状态(json.results.row,str);
				仔仔弹出对话框1.成功(json.msg);
			}else if(json.table == "user_pay" && json.model == "select" ){
				公用模块.打开充值窗口(json, 0, 显示充值遮罩及等待框);
			}else if(json.table == "shop_mall_info" && json.model == "ask" ){
				if(json.msg < 1 ){
					var buys= {}
					buys.row = json.results.row;
					buys.shop_id = CYS订单列表框1.取标记(json.results.row);
					buys.token = "";
					buys.IDs = [];
					m_post = 公用模块.生成提交数据(0, "shop_mall_info", "", "buy" , 0, 0, buys);
					m_url = 公用模块.生成访问链接(根地址,"api/shop/shop", m_token);
					显示等待框();
					公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
				}else{
					CYS订单列表框1.置按钮标题(json.results.row,"立即购买");
					div_row.置标题(""+json.results.row);
					div_buy_num.置标题(""+json.msg);
					div_detail_lable.置标题("请在以下列表中任意选择"+div_buy_num.取标题()+"个资源");
					div_detail_grid.清空项目();
					var i= 0;
					while(i < json.results.detail.length){
						div_detail_grid.添加项目(json.results.detail[i].shop_value,false,""+json.results.detail[i].ID);
						i++
					}
					div_detail_label.置标题("");
					if(json.results.must.length > 0 ){
						var msg = "必得：<br>";
						i=0;
						while(i < json.results.must.length){
							if(i>0 ){
								msg = msg + "，";
							}
							msg = msg + json.results.must[i].shop_value;
							i++
						}
					}
					div_detail_label.置标题(msg);
					div_detail_popover.显示();
				}
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}


		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "shop_class_info" && json.model == "select" ){
				CYS悬浮文字导航1.清空项目();
				CYS悬浮文字导航1.添加项目("全部", "");
				while(i < json.results.length){
					CYS悬浮文字导航1.添加项目(json.results[i].class_name, json.results[i].class_name);
					i++
				}
				div_head_pic.置可视2(true);
				列表哥AUI搜索框1.置可视(true);
				div_show_lable.置可视(false);
				if(json._id == "" ){
					div_head_pic.置图片("images/shop_head.png");
				}else{
					div_head_pic.置图片(json._id);
				}
				公用模块.头部图片自适应("div_head_pic", 200);
				刷新列表(1);
			}else if(json.table == "shop_mall_info" && json.model == "select" ){
				if(json.page == 1 ){
					CYS订单列表框1.清空项目();
				}
				page = json.page;
				if(page < json.total ){
					按钮_加载更多.置可视(true);
				}else{
					按钮_加载更多.置可视(false);
				}
				var 交易状态= "";
				var 限时销售= "";
				var 价格显示= "";
				while(i < json.results.length){
					限时销售 = "";
					if(json.results[i].shop_static == 2 ){
						限时销售 = "限时销售："+json.results[i].shop_time_start + " - " + json.results[i].shop_time_end;
					}
					if(json.results[i].shop_price == json.results[i].shop_price_spec ){
						价格显示 = "售价："+转换操作.到文本(json.results[i].shop_price);
					}else{

						价格显示 = "<span style=\"text-decoration: line-through;\">原价："+转换操作.到文本(json.results[i].shop_price)+"</span> ，<span style=\"color:red;\">特价："+转换操作.到文本(json.results[i].shop_price_spec)+"</span>";
					}
					if(json.results[i].shop_num < 1 ){
						交易状态 = "库存充足";
					}else{
						交易状态 = "限购 "+转换操作.到文本(json.results[i].shop_num)+" 已购 "+转换操作.到文本(json.results[i].sold_num);
					}
					CYS订单列表框1.添加项目(json.results[i].shop_pic, json.results[i].shop_name, 交易状态, json.results[i].shop_pic, json.results[i].shop_note, 限时销售, 价格显示, "立即购买", json.results[i].shop_id);
					i++
				}



			}



		}
	}
}
function CYS悬浮文字导航1_项目被单击(项目索引){
	class_name = CYS悬浮文字导航1.取项目标记(项目索引);
	select_value = "";
	刷新列表(1);
}
function CYS订单列表框1_项目被单击(项目索引){

}
function CYS订单列表框1_按钮被单击(项目索引){
	if(CYS订单列表框1.取按钮标题(项目索引) == "购买中..." ){
		return;
	}
	var bool= 公用模块.交易状态_可否购买(CYS订单列表框1.取交易状态(项目索引));
	if(bool == false ){
		仔仔弹出对话框1.错误("无法购买,已达限购量");
		return;
	}
	bool = 公用模块.限时状态_可否购买(CYS订单列表框1.取商品描述(项目索引));
	if(bool < 0 ){
		仔仔弹出对话框1.错误("还未到购买时间");
		return;
	}
	if(bool > 0 ){
		仔仔弹出对话框1.错误("已结束购买");
		return;
	}
	var json= {}
	json.row = 项目索引;

	if(HPtools1.询问框("是否购买？") == false ){
		return;
	}
	CYS订单列表框1.置按钮标题(项目索引,"购买中...");
	json.row = 项目索引;
	json.shop_id = CYS订单列表框1.取标记(项目索引);
	json.token = "";
	m_post = 公用模块.生成提交数据(0, "shop_mall_info", "", "ask" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/shop", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);


}

function 发起直充前(){
	m_post = "";
	m_url = 公用模块.生成访问链接(根地址,"api/pay/select", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function div_detail_btn_被单击(){
	var 项目索引= 转换操作.到数值(div_row.取标题());
	CYS订单列表框1.置按钮标题(项目索引,"购买中...");
	var buy_num= div_buy_num.取标题();
	var i= 0;
	var buys= {}
	buys.IDs = [];
	var v= 0;
	while(i < div_detail_grid.取项目数()){
		if(div_detail_grid.取项目状态(i) == true ){
			buys.IDs[v] = 转换操作.到数值(div_detail_grid.取项目标记(i));
			v++
		}
		i++
	}
	if(buy_num != buys.IDs.length ){
		仔仔弹出对话框1.错误("您只能选择其中的"+转换操作.到文本(buy_num)+"条资源");
		return;
	}
	buys.row = 项目索引;
	buys.shop_id = CYS订单列表框1.取标记(项目索引);
	buys.token = "";
	div_detail_popover.隐藏();
	m_post = 公用模块.生成提交数据(0, "shop_mall_info", "", "buy" , 0, 0, buys);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/shop", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 列表哥AUI搜索框1_搜索按钮被单击(搜索内容){
	select_value = 搜索内容;
	刷新列表(1);
}
function 隐藏框架(){
	popup.hideIframeB("coinpay");
	console.log("已加载");
}
function 显示提示消息(msg, model){
	if(model == true ){
		仔仔弹出对话框1.成功(msg);
	}else{
		仔仔弹出对话框1.错误(msg);
	}

}
function 显示等待框(){
	公用模块.showMask("页面遮罩");
	HPtools1.显示等待框("请稍等......");

}
function 关闭等待框(){

	公用模块.hideMask("页面遮罩");
	HPtools1.关闭等待框();
}
function 显示充值遮罩及等待框(){
	setTimeout(function() {
		公用模块.在指定元素上创建遮罩及等待框("coinpay","正在加载");
	}, 10);
}

function 关闭充值遮罩及等待框(){
	setTimeout(function() {
		公用模块.在指定元素上移除遮罩及等待框("coinpay");
	}, 10);
}
function 延时_打开兑换窗口(毫秒延时){
	setTimeout(function() {
		打开兑换窗口();
	}, 毫秒延时);
}
function 打开兑换窗口(){
	if(popup.Ishow("coinpay") == true ){
		console.log("弹窗已被占用");
		return;
	}
	var rect = 公用模块.弹出面板初始化计算(30,60,true);
	popup.showIframeB("coinpay","coincdk.html?agent",rect[0],rect[1],rect[2],rect[3]);
	显示充值遮罩及等待框();
}










function 关闭充值弹窗(){
	WebDialog.close();
}
function 按钮_加载更多_被单击(){
	刷新列表(page+1);
}
function 标题栏1_被双击(){
	窗口操作.滚动到顶部();
}