    function 渐渐图文列表框(name,event1){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 渐渐图文列表框(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;
        this.项目总数 = 0;
		this.is = 0;
        //组件命令：
        this.置标题 = function (newTitle){
            document.getElementById(this.名称).innerHTML=newTitle;
        } 
        
        //组件命令：
        this.取标题 = function (){
           return document.getElementById(this.名称).innerHTML;
        }  
        
        //组件命令：
        this.置可视 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="block";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="none"; //不占位隐藏               
            }
        } 
        
        //组件命令：
        this.置可视2 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="hidden"; //占位隐藏               
            }
        }
		
		//组件命令：
		this.添加项目 = function (项目图片,项目标题,项目消息,图片方向){
			var classes = "";
			var classes1 = "";
			var div = document.createElement("div");//创建一个卡片节点
			div.id = "divCell"+this.项目总数;
			div.className = "mui-content";//设置类名
			div.setAttribute("index",""+this.项目总数);//设置项目索引
			this.项目总数 = this.项目总数+1;
			this.is = this.项目总数 - 1;
			div.setAttribute("tag",项目图片);//设置项目标记
			div.setAttribute("tag1",项目标题);//设置项目标记
			div.setAttribute("tag2",项目消息);//设置项目标记
			if(图片方向 == 0){
				classes = "mui-media-object mui-pull-left"
			}else{
				classes = "mui-media-object mui-pull-right"
			}
			div.innerHTML ="<li class=\"mui-table-view-cell mui-media\" index=\""+this.is+"\">\n"+
			"       <a href=\"javascript:;\">\n"+
			"           <img class=\""+classes+"\" src=\""+项目图片+"\">\n"+
			"			<div class=\"mui-media-body\">"+项目标题+"<p class='mui-ellipsis'>"+项目消息+"</p></div>\n"+
			"		</a>\n"+
			"	</li>\n"+
			"<a href=\"javascript:;\">"
            var root = document.getElementById(this.名称);
			root.appendChild(div);//将卡片节点添加到卡片列表根节点
			return this.is;
		}
		
		//组件命令：
		this.清空项目 = function (){
		   this.项目总数 = 0;
           document.getElementById(this.名称).innerHTML="";
        }
		//组件命令：
		this.取项目图片 = function (表项索引){
			var card = document.getElementById(this.名称).getElementsByClassName("mui-content");
			if(card.length>表项索引){
				return card[表项索引].getAttribute("tag");
			}else{
				return "";
			}
        }
		//组件命令：
		this.取项目标题 = function (表项索引){
			var card = document.getElementById(this.名称).getElementsByClassName("mui-content");
			if(card.length>表项索引){
				return card[表项索引].getAttribute("tag1");
			}else{
				return "";
			}
		}
		//组件命令：
		this.取项目消息 = function (表项索引){
			var card = document.getElementById(this.名称).getElementsByClassName("mui-content");
			if(card.length>表项索引){
				return card[表项索引].getAttribute("tag2");
			}else{
				return "";
			}
		}
		
		this.删除项目 = function(index){
			var my = document.getElementById("divCell"+index);
    		if (my != null)
        	my.parentNode.removeChild(my);		
		}
		
        //组件事件
        if(event1!=null){
			//mui("#"+组件ID).on(事件名称, 标签名称或类名称, function() {
 			mui("#"+this.名称).on("tap", "li", function() {
				var index2 = this.getAttribute("index");
                event1(Number(index2));//触发组件的相关事件，这里的是"表项内容被单击"事件
            });
        }
    }