mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,导航栏1_项目被双击,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 美化等待框1 = new 美化等待框("美化等待框1");
var CYS超级列表框1 = new CYS超级列表框("CYS超级列表框1",null,CYS超级列表框1_按钮被单击);
var 标签2 = new 标签("标签2",null);
var 编辑框2 = new 编辑框("编辑框2",null,null,null,null,null);
var 按钮2 = new 按钮("按钮2",按钮2_被单击,null,null);
var 标签3 = new 标签("标签3",null);
var 编辑框3 = new 编辑框("编辑框3",null,null,null,null,null);
var 按钮3 = new 按钮("按钮3",按钮3_被单击,null,null);
var div_reset_popover = new 弹出面板("div_reset_popover",null,null);
var div_reset_password_old = new 编辑框("div_reset_password_old",null,null,null,null,null);
var div_reset_password = new 编辑框("div_reset_password",null,null,null,null,null);
var div_reset_password_ = new 编辑框("div_reset_password_",null,null,null,null,null);
var div_reset_btn = new 按钮("div_reset_btn",div_reset_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        我的_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        我的_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 已初始化导航栏= false;
var m_menu= {}
var m_tabs= [];
var 导航索引= -1;
function 我的_创建完毕(){





	根地址 = HPtools1.取URL();
	标题栏美化1.去标题栏阴影();

	编辑框2.置只读模式(true);
	编辑框3.置内容(根地址+"/shop/index.html");
	编辑框3.置只读模式(true);
	弹出面板初始化();
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/agent/login", m_token);
	美化等待框1.默认等待框("正在交互","正在获取用户信息,请稍等......");
	时钟1.开始执行(200,false);
}
function 导航栏初始化(){
	if(已初始化导航栏 == false ){
		导航索引 = 公用模块.导航栏初始化(导航栏1,m_menu, "user");


		已初始化导航栏 = true;
	}
}
function 导航栏1_项目被单击(项目标题,目标名称){
	if(目标名称 == 公用模块.导航栏项目数组(m_menu)[导航索引] ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(目标名称+".html","");
	}
}
function 导航栏1_项目被双击(项目标题,目标名称){
	窗口操作.滚动到顶部();
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_reset_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_reset_popover.添加组件("div_reset_password_old");
	div_reset_popover.添加组件("div_reset_password");
	div_reset_popover.添加组件("div_reset_password_");
	div_reset_popover.添加组件("div_reset_btn");
}

function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			m_menu = json.menu;
			导航栏初始化();
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info" && json.model == "reset-pwd" ){
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("密码已修改,请重新登陆"),"");
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "oper_login_info" && json.model == "select" ){

				CYS超级列表框1.清空项目();
				CYS超级列表框1.添加项目(json.results.oper_login,"代理账号",1,"","oper_login");














				编辑框3.置内容(根地址+"/shop/index.html?agid="+String(json.results.ID)+"&reg=popover");
				CYS超级列表框1.添加项目(json.results.oper_name,"代理昵称",1,"","oper_name");
				CYS超级列表框1.添加项目(""+json.results.agent_level+"级代理","代理等级",1,"","agent_level");
				CYS超级列表框1.添加项目(""+json.results.agent_re_scale+"%","返佣收益比例",1,"","agent_re_scale");
				CYS超级列表框1.添加项目(json.results.create_time,"注册时间",1,"","create_time");
				CYS超级列表框1.添加项目(json.results.login_time,"最后登录",1,"","login_time");
				CYS超级列表框1.添加项目("玩家数量："+转换操作.到文本(json.results.gameplayers),"不包含下级代理的玩家",1,"","gameplayers");
				CYS超级列表框1.添加项目("剩余的平台币数量："+转换操作.到文本(json.results.coin_sum_all),"",0,"","");
				CYS超级列表框1.添加项目("可提现平台币数量："+转换操作.到文本(json.results.coin_sum_ava),"",0,"","");
				CYS超级列表框1.添加项目("冻结中平台币数量："+转换操作.到文本(json.results.coin_sum_freeze),"",0,"","");
				CYS超级列表框1.添加项目("已提现平台币数量："+转换操作.到文本(json.results.coin_all - json.results.coin_sum_all),"",0,"","");
				CYS超级列表框1.添加项目("今日返佣收益："+转换操作.到文本(json.results.coin_today),"",0,"","");
				CYS超级列表框1.添加项目("昨日返佣收益："+转换操作.到文本(json.results.coin_yesterday),"",0,"","");
				CYS超级列表框1.添加项目("近七日返佣收益："+转换操作.到文本(json.results.coin_week),"",0,"","");
				CYS超级列表框1.添加项目("近30日返佣收益："+转换操作.到文本(json.results.coin_month),"",0,"","");
				CYS超级列表框1.添加项目("历史总返佣收益："+转换操作.到文本(json.results.coin_all),"",0,"","");
				CYS超级列表框1.添加项目("修改当前账号密码","修改密码",4,"mui-btn-red","reset-pwd");
				CYS超级列表框1.添加项目("跳回到登陆页面","切换账号",4,"mui-btn-red","login-out");
				m_menu = json.menu;
				导航栏初始化();
			}

		}
	}
}
function CYS超级列表框1_按钮被单击(项目索引){
	var 标记= CYS超级列表框1.取项目标记(项目索引);
	if(标记 == "reset-pwd" ){
		div_reset_popover.显示();
		return;
	}
	if(标记 == "login-out" ){
		if(HPtools1.询问框("是否登陆别的账号？") == true ){
			窗口操作.切换窗口("index.html");
			return;
		}
	}
}

function div_reset_btn_被单击(){
	div_reset_password_old.置内容(文本操作.删首尾空(div_reset_password_old.取内容()));
	if(div_reset_password_old.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入原密码");
		return;
	}
	div_reset_password.置内容(文本操作.删首尾空(div_reset_password.取内容()));
	if(div_reset_password.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入新密码");
		return;
	}
	div_reset_password_.置内容(文本操作.删首尾空(div_reset_password_.取内容()));
	if(div_reset_password.取内容() != div_reset_password_.取内容() ){
		仔仔弹出对话框1.错误("两次输入的密码不一致");
		return;
	}
	var oper_password_old= 加密操作1.取md5值(div_reset_password_old.取内容());
	oper_password_old = "" + oper_password_old;
	var oper_password= 加密操作1.取md5值(div_reset_password.取内容());
	oper_password = "" + oper_password;
	var json= {}
	json.old_password = oper_password_old;
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "reset-pwd" , 0, 0, json, CYS超级列表框1.取项目标题(0), oper_password);
	m_url = 公用模块.生成访问链接(根地址,"api/agent/login", "");
	美化等待框1.默认等待框("正在交互","正在重置,请稍等......");
	时钟1.开始执行(200,false);
}
function 按钮2_被单击(){
	HPtools1.置剪贴板内容(编辑框2.取内容());
	仔仔弹出对话框1.提示("已复制下级代理注册地址");
}
function 按钮3_被单击(){
	HPtools1.置剪贴板内容(编辑框3.取内容());
	仔仔弹出对话框1.提示("已复制下级玩家注册地址");
}