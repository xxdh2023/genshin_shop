mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 自由面板1 = new 自由面板("自由面板1","54px");
var 自由面板_标签 = new 标签("自由面板_标签",null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",null,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        平台福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        平台福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
function 平台福利_创建完毕(){
	根地址 = HPtools1.取URL();
	调整组件尺寸();
	高级表格初始化();
	查询数据();
}
function 调整组件尺寸(){
	var width= 窗口操作.取窗口宽度();
	公用模块.自由面板_调整("自由面板_标签", 110, 100, 800,width);
	公用模块.自由面板_调整("自由面板_编辑框_条件", 214, 400, 800,width);
	公用模块.自由面板_调整("自由面板_按钮_查询", 622, 100, 800,width);
	公用模块.自由面板_调整("自由面板_按钮_添加", 6, 100, 800,width);
}

function 高级表格初始化(){
	高级表格1.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",100,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("wel_id","编码",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("wel_value","显示名称",300,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("wel_static","状态",60,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("wel_num","可用数量",80,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("wel_cycle","数量复用脚本",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("wel_vip","显示范围",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"批量启用");
	高级表格1.添加工具栏按钮(2,false,"批量停用");
	高级表格1.添加工具栏按钮(3,false,"批量调整属性");
	高级表格1.添加工具栏按钮(4,false,"批量删除");
	高级表格1.初始化("auto",true,true,false,true);
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "item_welfare_info" ){
				高级表格1.删除行(转换操作.到数值(json.comm));
				高级表格1.初始化("auto",true,true,false,true);
				仔仔弹出对话框1.成功("删除成功！");


			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "item_welfare_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					while(i < json.results.length){
						高级表格1.添加行(false,["",json.results[i].ID,"编辑",json.results[i].gm_id,json.results[i].gm_name,json.results[i].gm_note]);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(2,false,"编辑");
					高级表格1.添加操作栏按钮(4,false,"删除");
					高级表格1.初始化("auto",true,true,false,true);
				}



			}




		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	m_post = 公用模块.生成提交数据(0, "item_welfare_info", value, "" , 1, 0);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}

function 按钮_底部_被单击(){
	m_post = 公用模块.生成提交数据(0, "item_welfare_info", value, "" , page+1, 0);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
		case 0 :
			公用模块.居中打开小窗口("welfareinfone.html?ID="+转换操作.到文本(_id), 800, 600);
		break;
		case 1 :

			if(HPtools1.询问框("是否删除？") == true ){
				var json= {}
				json.wel_id = 行数据["wel_id"];
				m_post = 公用模块.生成提交数据(_id, "item_welfare_info", ""+行索引, "delete" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
				美化等待框1.默认等待框("正在交互","正在删除,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}
		break;
	}

}

function 自由面板_按钮_添加_被单击(){
	公用模块.居中打开小窗口("welfareinfone.html?ID=0", 800, 600);
}