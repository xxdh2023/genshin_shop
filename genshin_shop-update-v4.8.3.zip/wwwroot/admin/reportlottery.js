mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 面板1 = new 面板("面板1");
var 标签3 = new 标签("标签3",null);
var 标签4 = new 标签("标签4",null);
var 面板2 = new 面板("面板2");
var div_start_time = new 按钮("div_start_time",div_start_time_被单击,null,null);
var div_end_time = new 按钮("div_end_time",div_end_time_被单击,null,null);
var 标签5 = new 标签("标签5",null);
var 面板3 = new 面板("面板3");
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",null,null,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
if(mui.os.plus){
    mui.plusReady(function() {
        抽奖营收_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        抽奖营收_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var start_time= "";
var end_time= "";
var m_model= 0;

function 抽奖营收_创建完毕(){
	根地址 = HPtools1.取URL();
	调整尺寸();
	CYS日期时间选择器1.初始化(1, 2023, 2099);
	div_start_time.置标题(公用模块.取当前日期年月日(时间操作.取当前日期时间()));
	div_end_time.置标题(公用模块.取当前日期年月日(时间操作.取当前日期时间()));
	高级表格初始化();
	查询数据();
}
function 调整尺寸(){
	面板1.添加组件("标签3","180px");
	面板1.添加组件("标签4","180px");
	面板2.添加组件("div_start_time","180px");
	面板2.添加组件("div_end_time","180px");
	面板3.添加组件("自由面板_编辑框_条件", "240px");
	面板3.添加组件("自由面板_按钮_查询", "120px");
}
function 高级表格初始化(){
	高级表格1.添加列("inout_create","发生时间",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_login","玩家账号",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_name","玩家昵称",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_name","抽奖",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_coin","花费(RMB)",120,false,true,false,false,false,true,"花费(RMB)",false,false);
	高级表格1.添加列("inout_cell","中奖序号",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_name","中奖奖品",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_id","SKU",180,false,true,false,false,false,false,"",false,false);
	高级表格1.初始化("auto",true,true,true,true);
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.page == 1 ){
				高级表格1.清空行();
			}
			page = json.page;
			if(json.total > json.page ){
				按钮_底部.置可视(true);
			}
			var arr = new Array();
			while(i < json.results.length){
				arr[0] = json.results[i].inout_create;
				arr[1] = json.results[i].oper_login;
				arr[2] = json.results[i].oper_name;
				arr[3] = json.results[i].lot_name;
				if(json.msg < 1 ){
					arr[4] = "充值比例错误";
				}else{
					arr[4] = json.results[i].inout_coin / json.msg;
				}
				arr[5] = json.results[i].inout_cell;
				arr[6] = json.results[i].inout_name;
				arr[7] = json.results[i].inout_id;
				高级表格1.添加行(true,arr);
				i++
			}
			高级表格1.初始化("auto",true,true,true,true);
		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,true,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	var json= {}
	start_time = div_start_time.取标题();
	end_time = div_end_time.取标题();
	json.start_time = start_time;
	json.end_time = end_time;
	m_post = 公用模块.生成提交数据(0, "inout_info_lottery", value, "" , 1, 0, json);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/report", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,true,true);
		查询数据();
	}
}


function 按钮_底部_被单击(){
	var json= {}
	json.start_time = start_time;
	json.end_time = end_time;
	m_post = 公用模块.生成提交数据(0, "inout_info_lottery", value, "" , page+1, 0, json);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/report", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function div_start_time_被单击(){
	m_model = 0;
	CYS日期时间选择器1.弹出();
}
function div_end_time_被单击(){
	m_model = 1;
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	if(m_model < 1 ){
		div_start_time.置标题(res);
	}else{
		div_end_time.置标题(res);
	}
}