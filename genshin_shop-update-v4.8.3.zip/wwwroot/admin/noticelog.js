mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标签6 = new 标签("标签6",null);
var CYS索引列表框1 = new CYS索引列表框("CYS索引列表框1",null);
if(mui.os.plus){
    mui.plusReady(function() {
        更新日志_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        更新日志_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

function 更新日志_创建完毕(){
	var logs = window.parent.取公告页面升级日志();
	读取日志(logs);
}

function 读取日志(logs){
	var i= 0;
	var v= 0;
	CYS索引列表框1.清空();
	while(i<logs.length){
		v=0;
		CYS索引列表框1.添加分组(logs[i].title);
		if(logs[i].values != null ){
			while(v < logs[i].values.length){
				if(logs[i].values[v] != "" ){
					CYS索引列表框1.添加项目(i, logs[i].values[v]);
				}
				v++
			}
		}
		i++
	}
}