mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 面板1 = new 面板("面板1");
var 标签1 = new 标签("标签1",null);
var 标签2 = new 标签("标签2",null);
var 面板2 = new 面板("面板2");
var div_start_time = new 按钮("div_start_time",div_start_time_被单击,null,null);
var div_end_time = new 按钮("div_end_time",div_end_time_被单击,null,null);
var 面板3 = new 面板("面板3");
var 下拉框_状态 = new 下拉框("下拉框_状态",null);
var 编辑框_条件 = new 编辑框("编辑框_条件",null,null,null,null,null);
var 按钮_查询 = new 按钮("按钮_查询",按钮_查询_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",null,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签3 = new 标签("标签3",null);
var 下拉框_服务器 = new 下拉框("下拉框_服务器",null);
var 按钮_补发 = new 按钮("按钮_补发",按钮_补发_被单击,null,null);
var 标签4 = new 标签("标签4",null);
var 标签_补发_单号 = new 标签("标签_补发_单号",null);
var 特定修复1 = new 特定修复("特定修复1");
if(mui.os.plus){
    mui.plusReady(function() {
        圣遗物定制记录_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        圣遗物定制记录_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var m_ID = 0;
var m_json= {}
var m_model = 0;




function 圣遗物定制记录_创建完毕(){
	根地址 = HPtools1.取URL();
	CYS日期时间选择器1.初始化(1, 2023, 2099);
	界面初始化();
	弹出面板初始化();
	高级表格初始化();
	刷新档案();
}

function 界面初始化(){
	面板1.添加组件("标签1", "240px");
	面板1.添加组件("标签2", "240px");
	面板2.添加组件("div_start_time", "240px");
	div_start_time.置标题(公用模块.取当前日期年月日(时间操作.取当前日期时间()));
	面板2.添加组件("div_end_time", "240px");
	div_end_time.置标题(公用模块.取当前日期年月日(时间操作.取当前日期时间()));

	面板3.添加组件(特定修复1.下拉框("下拉框_状态"), "120px");
	下拉框_状态.清空项目();
	下拉框_状态.添加项目("全部记录", "all");
	下拉框_状态.添加项目("接口调用失败", "-1");
	下拉框_状态.添加项目("即将定制", "0");
	下拉框_状态.添加项目("正在调用接口", "1");
	下拉框_状态.添加项目("定制成功", "2");
	下拉框_状态.置现行选中项(0);

	面板3.添加组件("编辑框_条件", "240px");
	面板3.添加组件("按钮_查询", "120px");

}

function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(-300, 180, false);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板1.添加组件("标签3");
	弹出面板1.添加组件("下拉框_服务器");
	弹出面板1.添加组件("标签4");
	弹出面板1.添加组件("按钮_补发");
}

function 高级表格初始化(){
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",80,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("artifact_create","定制时间",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_amount","花费平台币",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_login","玩家账号",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_static","定制状态",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_end","完成时间",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("send_msg","接口调用结果",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_note","定制明细",300,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("artifact_no","唯一单号",200,false,false,false,false,false,false,"",false,false);

	高级表格1.初始化("auto",true,true,false,true);
}

function 刷新档案(){
	if(page < 2 ){
		page = 1;
		m_json.status = 下拉框_状态.取项目标记(下拉框_状态.取现行选中项());
		m_json.start_time = div_start_time.取标题();
		m_json.end_time = div_end_time.取标题();
		m_json.value = 文本操作.删首尾空(编辑框_条件.取内容());

	}

	m_post = 公用模块.生成提交数据(0, "artifact_mall", "", "" , page, 0, m_json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function div_start_time_被单击(){
	m_model = 0;
	CYS日期时间选择器1.弹出();
}
function div_end_time_被单击(){
	m_model = 1;
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	if(m_model < 1 ){
		div_start_time.置标题(res);
	}else{
		div_end_time.置标题(res);
	}
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "artifact_mall" ){
				if(json.page == 1 ){
					高级表格1.清空行();
				}
				page = json.page;
				if(json.total > json.page ){
					按钮_底部.置可视(true);
				}
				var 行数据 = [];
				while(i < json.results.length){
					行数据[0] = json.results[i].ID;
					行数据[1] = "编辑";
					行数据[2] = json.results[i].artifact_create;
					行数据[3] = json.results[i].artifact_amount;
					行数据[4] = json.results[i].oper_login +" - " + json.results[i].oper_name;
					行数据[5] = "未知";
					if(json.results[i].artifact_static < 0 ){
						行数据[5] = "接口调用失败";
					}else if(json.results[i].artifact_static == 0 ){
						行数据[5] = "即将定制";
					}else if(json.results[i].artifact_static == 1 ){
						行数据[5] = "正在调用接口";
					}else if(json.results[i].artifact_static == 2 ){
						行数据[5] = "定制成功";
					}
					行数据[6] = json.results[i].artifact_end;
					行数据[7] = json.results[i].send_msg;
					行数据[8] = json.results[i].artifact_note;
					行数据[9] = json.results[i].artifact_no;

					高级表格1.添加行(true, 行数据);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(2,false,"补发");
				高级表格1.初始化("auto",true,true,false,true);
			}else if(json.table == "artifact_mall_reissue" ){
				标签_补发_单号.置标题(json.comm);
				下拉框_服务器.清空项目();
				while(i<json.results.length){
					下拉框_服务器.添加项目(json.results[i].game_name, json.results[i].ID);
					i++
				}
				下拉框_服务器.置现行选中项(0);
				弹出面板1.显示();
			}


		}
	}
}



function 按钮_底部_被单击(){
	按钮_底部.置可视(false);
	page = page + 1;
	刷新档案();
}
function 按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	按钮_底部.置可视(false);
	page = 1;
	刷新档案();
}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var artifact_no = 文本操作.删首尾空(行数据["artifact_no"]);
	if(artifact_no == "" ){
		仔仔弹出对话框1.错误("列表异常,请刷新页面！");
		return;
	}
	标签_补发_单号.置标题("");
	m_post = 公用模块.生成提交数据(0, "artifact_mall_reissue", artifact_no, "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);


}
function 按钮_补发_被单击(){
	if(标签_补发_单号.取标题() == "" ){
		仔仔弹出对话框1.错误("交互数据异常,请刷新页面后重试！");
		return;
	}
	if(HPtools1.询问框("是否向[ "+下拉框_服务器.取项目标题(下拉框_服务器.取现行选中项())+" ]中补发？") == false ){
		return;
	}
	var server_id = 下拉框_服务器.取项目标记(下拉框_服务器.取现行选中项());
	弹出面板1.隐藏();
	m_post = 公用模块.生成提交数据(server_id, "artifact_mall_reissue", 标签_补发_单号.取标题(), "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/update", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);


}