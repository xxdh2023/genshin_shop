mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 面板1 = new 面板("面板1");
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 标签2 = new 标签("标签2",null);
var 面板2 = new 面板("面板2");
var div_lot_model_1_ = new 单选框("div_lot_model_1_",div_lot_model_1__被单击);
var div_lot_model_0 = new 单选框("div_lot_model_0",div_lot_model_0_被单击);
var div_lot_model_4 = new 单选框("div_lot_model_4",div_lot_model_4_被单击);
var div_lot_model_1 = new 单选框("div_lot_model_1",div_lot_model_1_被单击);
var div_lot_model_2 = new 单选框("div_lot_model_2",div_lot_model_2_被单击);
var div_lot_model_3 = new 单选框("div_lot_model_3",div_lot_model_3_被单击);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var div_lot_model_popover = new 弹出面板("div_lot_model_popover",null,null);
var div_lot_model_btns_1 = new 按钮组("div_lot_model_btns_1",div_lot_model_btns_1_被单击);
var div_lot_model_btns_2 = new 按钮组("div_lot_model_btns_2",div_lot_model_btns_2_被单击);
var div_lot_model_btn = new 按钮("div_lot_model_btn",div_lot_model_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        抽奖管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        抽奖管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var lot_model= -1;
var 表格数据 = new Array();
function 抽奖管理_创建完毕(){
	根地址 = HPtools1.取URL();
	div_lot_model_1_.置选中状态(true);
	调整组件尺寸();
	高级表格初始化();
	查询数据();
}
function 调整组件尺寸(){
	面板1.添加组件("自由面板_按钮_添加", "120px");
	面板1.添加组件("自由面板_编辑框_条件", "240px");
	面板1.添加组件("自由面板_按钮_查询", "120px");

	面板2.添加组件("div_lot_model_1_", "110px");
	面板2.添加组件("div_lot_model_0", "110px");
	面板2.添加组件("div_lot_model_4", "110px");
	面板2.添加组件("div_lot_model_1", "110px");
	面板2.添加组件("div_lot_model_2", "110px");
	面板2.添加组件("div_lot_model_3", "110px");


	var rect = 公用模块.弹出面板初始化计算(50,160, false);
	div_lot_model_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_lot_model_popover.添加组件("div_lot_model_btns_1");
	div_lot_model_popover.添加组件("div_lot_model_btns_2");
	div_lot_model_popover.添加组件("div_lot_model_btn");
}
function 高级表格初始化(){
	高级表格1.添加列("xz","",40,true,false,false,true,false,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",220,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("lot_id","编码",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_name","名称",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_static","状态",60,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_pic","图片",0,false,false,false,false,true,false,"",false,false);
	高级表格1.添加列("lot_model","类型",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_coin","单抽平台币价格",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_coin2","十连抽平台币价格",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_num","奖品数量",80,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_1_rate","奖品1中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_1_name","奖品1名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_2_rate","奖品2中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_2_name","奖品2名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_3_rate","奖品3中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_3_name","奖品3名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_4_rate","奖品4中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_4_name","奖品4名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_5_rate","奖品5中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_5_name","奖品5名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_6_rate","奖品6中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_6_name","奖品6名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_7_rate","奖品7中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_7_name","奖品7名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_8_rate","奖品8中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_8_name","奖品8名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_9_rate","奖品9中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_9_name","奖品9名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_10_rate","奖品10中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_10_name","奖品10名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_11_rate","奖品11中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_11_name","奖品11名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_12_rate","奖品12中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_12_name","奖品12名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_13_rate","奖品13中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_13_name","奖品13名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_14_rate","奖品14中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_14_name","奖品14名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_15_rate","奖品15中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_15_name","奖品15名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_16_rate","奖品16中奖率",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_cell_16_name","奖品16名称",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_vip","显示范围",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("lot_note","简介",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"批量启用");
	高级表格1.添加工具栏按钮(4,false,"批量停用");
	高级表格1.添加工具栏按钮(5,false,"批量修改类型");
	高级表格1.初始化("auto",true,true,false,true);
}
function 自由面板_按钮_添加_被单击(){
	公用模块.居中打开小窗口("drawinfone.html?ID=0", 1000, 700);
}
function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}
function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}
function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	var json= {}
	json.lot_model = lot_model;
	m_post = 公用模块.生成提交数据(0, "lottery_draw_info", value, "" , 1, 0, json);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_lot_model_1__被单击(){
	lot_model = -1;
}
function div_lot_model_0_被单击(){
	lot_model = 0;
}
function div_lot_model_1_被单击(){
	lot_model = 1;
}
function div_lot_model_2_被单击(){
	lot_model = 2;
}
function div_lot_model_3_被单击(){
	lot_model = 3;
}
function div_lot_model_4_被单击(){
	lot_model = 4;
}
function 按钮_底部_被单击(){
	var json= {}
	json.lot_model = lot_model;
	m_post = 公用模块.生成提交数据(0, "lottery_draw_info", value, "" , page+1, 0, json);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "lottery_draw_info" && json.model == "delete" ){
				高级表格1.删除行(转换操作.到数值(json.comm));
				高级表格1.初始化("auto",true,true,false,true);
				仔仔弹出对话框1.成功("删除成功！");
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}


		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "lottery_draw_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "";
						arr[3] = json.results[i].lot_id;
						arr[4] = json.results[i].lot_name;
						arr[5] = "停用";
						if(json.results[i].lot_static == 1 ){
							arr[5] = "启用";
						}
						arr[6] = json.results[i].lot_pic;
						arr[7] = "一次性抽奖";
						arr[8] = "";
						arr[9] = "";
						switch(json.results[i].lot_model){
							case 1 :
								arr[7] = "整点一抽";
							break;
							case 2 :
								arr[7] = "每天一抽";
							break;
							case 3 :
								arr[7] = "每周一抽";
							break;
							case 4 :
								arr[7] = "付费抽奖";
								arr[8] = json.results[i].lot_coin;
								arr[9] = json.results[i].lot_coin * 10;
								if(json.results[i].lot_coin2 > 0 ){
									arr[9] = json.results[i].lot_coin2;
								}
							break;
						}
						arr[10] = json.results[i].lot_cell_num;

						arr[11] = json.results[i].lot_cell_1_rate;
						arr[12] = json.results[i].lot_cell_1_name;
						arr[13] = json.results[i].lot_cell_2_rate;
						arr[14] = json.results[i].lot_cell_2_name;
						arr[15] = json.results[i].lot_cell_3_rate;
						arr[16] = json.results[i].lot_cell_3_name;
						arr[17] = json.results[i].lot_cell_4_rate;
						arr[18] = json.results[i].lot_cell_4_name;
						arr[19] = json.results[i].lot_cell_5_rate;
						arr[20] = json.results[i].lot_cell_5_name;
						arr[21] = json.results[i].lot_cell_6_rate;
						arr[22] = json.results[i].lot_cell_6_name;
						arr[23] = json.results[i].lot_cell_7_rate;
						arr[24] = json.results[i].lot_cell_7_name;
						arr[25] = json.results[i].lot_cell_8_rate;
						arr[26] = json.results[i].lot_cell_8_name;
						arr[27] = json.results[i].lot_cell_9_rate;
						arr[28] = json.results[i].lot_cell_9_name;
						arr[29] = json.results[i].lot_cell_10_rate;
						arr[30] = json.results[i].lot_cell_10_name;
						arr[31] = json.results[i].lot_cell_11_rate;
						arr[32] = json.results[i].lot_cell_11_name;
						arr[33] = json.results[i].lot_cell_12_rate;
						arr[34] = json.results[i].lot_cell_12_name;
						arr[35] = json.results[i].lot_cell_13_rate;
						arr[36] = json.results[i].lot_cell_13_name;
						arr[37] = json.results[i].lot_cell_14_rate;
						arr[38] = json.results[i].lot_cell_14_name;
						arr[39] = json.results[i].lot_cell_15_rate;
						arr[40] = json.results[i].lot_cell_15_name;
						arr[41] = json.results[i].lot_cell_16_rate;
						arr[42] = json.results[i].lot_cell_16_name;
						arr[43] = json.results[i].lot_vip;
						if(arr[43] == "" ){
							arr[43] = "所有玩家";
						}
						arr[44] = json.results[i].lot_note;
						高级表格1.添加行(true,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(2,false,"编辑");
					高级表格1.添加操作栏按钮(3,false,"查看奖品明细");
					高级表格1.添加操作栏按钮(4,false,"删除");
					高级表格1.初始化("auto",true,true,false,true);
				}



			}




		}
	}
}
function 高级表格1_工具栏按钮被单击(按钮索引){
	if(按钮索引 == 0 || 按钮索引 == 1 || 按钮索引 == 2 ){
		var 选中数据 = 高级表格1.取选中数据();
		var num = 数组操作.取成员数(选中数据);
		if(num < 1 ){
			仔仔弹出对话框1.错误("请先勾选项目！");
			return;
		}
		表格数据 = 选中数据;
	}
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否批量启用？") == true ){
				var json= {}
				json.lot_static = 1;
				json.ids = [];
				var i= 0;
				while(i < num){
					var one= 选中数据[i];
					json.ids[i] = one["id"];
					i++
				}
				m_post = 公用模块.生成提交数据(0, "lottery_draw_info_static", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在启用,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}
		break;
		case 1 :
			if(HPtools1.询问框("是否批量停用？") == true ){
				var json= {}
				json.lot_static = 0;
				json.ids = [];
				var i= 0;
				while(i < num){
					var one= 选中数据[i];
					json.ids[i] = one["id"];
					i++
				}
				m_post = 公用模块.生成提交数据(0, "lottery_draw_info_static", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在停用,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}
		break;
		case 2 :
			div_lot_model_popover.显示();
		break;
	}

}

function div_lot_model_btns_1_被单击(按钮索引){
	div_lot_model_btns_1.置样式(0,"mui-btn");
	div_lot_model_btns_1.置样式(1,"mui-btn");
	div_lot_model_btns_1.置样式(2,"mui-btn");
	div_lot_model_btns_2.置样式(0,"mui-btn");
	div_lot_model_btns_2.置样式(1,"mui-btn");
	div_lot_model_btns_1.置样式(按钮索引,"mui-btn mui-btn-primary");
	lot_model = 按钮索引;
}
function div_lot_model_btns_2_被单击(按钮索引){
	div_lot_model_btns_1.置样式(0,"mui-btn");
	div_lot_model_btns_1.置样式(1,"mui-btn");
	div_lot_model_btns_1.置样式(2,"mui-btn");
	div_lot_model_btns_2.置样式(0,"mui-btn");
	div_lot_model_btns_2.置样式(1,"mui-btn");
	div_lot_model_btns_2.置样式(按钮索引,"mui-btn mui-btn-primary");
	lot_model = 按钮索引 + 3;
}
function div_lot_model_btn_被单击(){
	var json= {}
	json.lot_model = lot_model;
	json.ids = [];
	var i= 0;
	var num = 数组操作.取成员数(表格数据);
	while(i < num){
		var one= 表格数据[i];
		json.ids[i] = one["id"];
		i++
	}
	m_post = 公用模块.生成提交数据(0, "lottery_draw_info_model", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在修改类型,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
	case 0 :
		公用模块.居中打开小窗口("drawinfone.html?ID="+转换操作.到文本(_id), 1000, 700);
	break;
	case 1 :

		var url= "";
			url = 公用模块.生成明细查看摘要(m_password, 0, "lot_id", 行数据["lot_id"], "lottery_draw_info_detail", "lot_type,lot_value,lot_detail", "奖品序号,显示名称,内部脚本","");

			公用模块.居中打开小窗口(url, 800, 600);
	break;
	case 2 :

		if(HPtools1.询问框("是否删除？") == true ){
			var json= {}
			json.lot_id = 行数据["lot_id"];
			m_post = 公用模块.生成提交数据(_id, "lottery_draw_info", "" + 行索引, "delete" , 1, 0, json);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
			美化等待框1.默认等待框("正在交互","正在删除抽奖,请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
		}
		break;
	}
}