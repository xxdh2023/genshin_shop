mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,null,null);
var div_head_pic = new 图片框("div_head_pic",null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 美化等待框1 = new 美化等待框("美化等待框1");
var CYS超级列表框1 = new CYS超级列表框("CYS超级列表框1",null,CYS超级列表框1_按钮被单击);
var 标签1 = new 标签("标签1",null);
var 按钮组_日志 = new 按钮组("按钮组_日志",按钮组_日志_被单击);
var CYS时钟轴1 = new CYS时钟轴("CYS时钟轴1",null);
var div_cdk_popover = new 弹出面板("div_cdk_popover",null,null);
var div_cdk_lable = new 标签("div_cdk_lable",null);
var div_cdk_edit = new 编辑框("div_cdk_edit",null,null,null,null,null);
var div_cdk_btn = new 按钮("div_cdk_btn",div_cdk_btn_被单击,null,null);
var div_cdk_next_popover = new 弹出面板("div_cdk_next_popover",null,null);
var div_cdk_next_lable = new 标签("div_cdk_next_lable",null);
var div_cdk_next_grid = new 高级列表框("div_cdk_next_grid",false,true,false,null);
var div_sign_popover = new 弹出面板("div_sign_popover",null,null);
var div_sign_lable = new 标签("div_sign_lable",null);
var div_sign_grid = new 高级列表框("div_sign_grid",false,true,false,null);
var div_reset_popover = new 弹出面板("div_reset_popover",null,null);
var div_reset_password_old = new 编辑框("div_reset_password_old",null,null,null,null,null);
var div_reset_password = new 编辑框("div_reset_password",null,null,null,null,null);
var div_reset_password_ = new 编辑框("div_reset_password_",null,null,null,null,null);
var div_reset_btn = new 按钮("div_reset_btn",div_reset_btn_被单击,null,null);
var div_card_popover = new 弹出面板("div_card_popover",null,null);
var div_card_lable = new 标签("div_card_lable",null);
var div_card_grid = new 高级列表框("div_card_grid",false,true,false,null);
var div_draw_popover = new 弹出面板("div_draw_popover",null,null);
var div_draw_lable = new 标签("div_draw_lable",null);
var div_draw_grid = new 自由列表框("div_draw_grid",null,div_draw_grid_按钮被单击);
var 自由面板1 = new 自由面板("自由面板1","90px");
var div_draw_grid_title = new 标签("div_draw_grid_title",null);
var div_draw_grid_note = new 标签("div_draw_grid_note",null);
var div_draw_grid_btn = new 按钮("div_draw_grid_btn",null,null,null);
var div_pay_popover = new 弹出面板("div_pay_popover",null,null);
var div_pay_lable_1 = new 标签("div_pay_lable_1",null);
var div_pay_model = new 按钮组("div_pay_model",div_pay_model_被单击);
var div_pay_lable_2 = new 标签("div_pay_lable_2",null);
var div_pay_btns_1 = new 按钮组("div_pay_btns_1",div_pay_btns_1_被单击);
var div_pay_btns_2 = new 按钮组("div_pay_btns_2",div_pay_btns_2_被单击);
var div_pay_btns_3 = new 按钮组("div_pay_btns_3",div_pay_btns_3_被单击);
var div_pay_btns_4 = new 按钮组("div_pay_btns_4",div_pay_btns_4_被单击);
var div_pay_btn_cdk = new 按钮("div_pay_btn_cdk",div_pay_btn_cdk_被单击,null,null);
var div_pay_test_btn = new 按钮("div_pay_test_btn",div_pay_test_btn_被单击,null,null);
var div_pay_test_btn2 = new 按钮("div_pay_test_btn2",div_pay_test_btn2_被单击,null,null);
var div_pay_id = new 标签("div_pay_id",null);
if(mui.os.plus){
    mui.plusReady(function() {
        测试模式_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        测试模式_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 导航索引= 0;
var pay_model="alipay";
var submit_model= 1;
function 测试模式_创建完毕(){





	根地址 = HPtools1.取URL();
	导航栏初始化(4);

	标题栏美化1.去标题栏阴影();
	弹出面板初始化();
	调整组件尺寸();
	直充弹出初始化();
	div_head_pic.置图片("images/user_head.png");
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
	美化等待框1.默认等待框("正在交互","正在获取用户信息,请稍等......");
	时钟1.开始执行(200,false);
}
function 导航栏初始化(激活项目){
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-cart","商城","0",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-grech","抽奖","1",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-gift","福利","2",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-express","仓库","3",0);
	导航栏1.添加项目("mui-icon", "mui-icon-contact","我的","4",0);
	导航栏1.添加完毕();
	导航栏1.置激活项目背景色("#F2F2F2");
	导航栏1.置项目激活状态(0,false);
	导航栏1.置项目激活状态(1,false);
	导航栏1.置项目激活状态(2,false);
	导航栏1.置项目激活状态(3,false);
	导航栏1.置项目激活状态(4,false);
	导航栏1.置项目激活状态(激活项目,true);
	导航索引 = 激活项目;
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_cdk_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_cdk_popover.添加组件("div_cdk_lable");
	div_cdk_popover.添加组件("div_cdk_edit");
	div_cdk_popover.添加组件("div_cdk_btn");
	div_cdk_edit.置提示内容("请输入平台币CDK\n支持输入多行CDK\n一行里面只能有一个CDK");
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_cdk_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_cdk_next_popover.添加组件("div_cdk_next_lable");
	div_cdk_next_popover.添加组件("div_cdk_next_grid");
	div_sign_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_sign_popover.添加组件("div_sign_lable");
	div_sign_popover.添加组件("div_sign_grid");
	div_card_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_card_popover.添加组件("div_card_lable");
	div_card_popover.添加组件("div_card_grid");
	div_draw_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_draw_popover.添加组件("div_draw_lable");
	div_draw_popover.添加组件("div_draw_grid");
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_reset_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_reset_popover.添加组件("div_reset_password_old");
	div_reset_popover.添加组件("div_reset_password");
	div_reset_popover.添加组件("div_reset_password_");
	div_reset_popover.添加组件("div_reset_btn");
}
function 直充弹出初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 220, false);
	div_pay_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_pay_popover.添加组件("div_pay_lable_1");
	div_pay_popover.添加组件("div_pay_model");
	div_pay_popover.添加组件("div_pay_lable_2");
	div_pay_popover.添加组件("div_pay_btns_1");
	div_pay_popover.添加组件("div_pay_btns_2");
	div_pay_popover.添加组件("div_pay_btns_3")
div_pay_popover.添加组件("div_pay_btns_4");
	div_pay_popover.添加组件("div_pay_btn_cdk");
	div_pay_popover.添加组件("div_pay_test_btn");
	div_pay_popover.添加组件("div_pay_test_btn2");
	div_pay_model.置样式(0,"mui-btn mui-btn-success");
}
function 调整组件尺寸(){

	var width= 窗口操作.取窗口宽度();


	窗口操作.置组件宽度("div_draw_grid_title","" + 转换操作.到文本(width -100- 64 - 24) + "px");
	窗口操作.置组件宽度("div_draw_grid_note","" + 转换操作.到文本(width -100- 64 - 24)+ "px");
	窗口操作.置组件左边("div_draw_grid_btn","" + 转换操作.到文本(width -100- 64-20) + "px");

}
function 导航栏1_项目被单击(项目标题,目标名称){
	var arr = ["shop","lottery","welfare","warehouse","user"];
	var 子卡索引=转换操作.到数值(目标名称);
	if(子卡索引 == 导航索引 ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(arr[子卡索引]+".html","");
	}
}
function 时钟1_周期事件(){
	HPtools1.调试输出(m_post);
	HPtools1.调试输出(m_url);
	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{
		HPtools1.调试输出(返回信息);
		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "user_pay" && json.model == "select" ){
				div_cdk_popover.显示();
				仔仔弹出对话框1.错误(json.msg);
			}else{
				仔仔弹出对话框1.错误(json.msg);
			}
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info" && json.model == "reset-pwd" ){
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("密码已修改,请重新登陆"),"");
			}else if(json.table == "oper_login_info" && json.model == "sign" ){
				var i= 0;
				div_sign_grid.清空项目();
				while(i < json._id.length){
					div_sign_grid.添加项目2("", json._id[i], "", "");
					i++
				}
				div_sign_popover.显示();
			}else if(json.table == "oper_login_info" && json.model == "card" ){
				var i= 0;
				div_card_grid.清空项目();

				var str;
				while(i < json._id.length){
					if(json._id[i][1] == 7 ){
						str = "周卡：";
					}else{
						str = "月卡：";
					}
					str=str+json._id[i][0];
					if(json._id[i][2] == 0 ){
						str=str+" 已领取";
					}else if(json._id[i][2] == 1 ){
						str=str+" 领取成功";
					}else{
						str=str+" 领取失败";
					}
					div_card_grid.添加项目2("", str, json._id[i][3], "");
					i++
				}
				div_card_popover.显示();
			}else if(json.table == "oper_login_info_vip_draw" ){
				仔仔弹出对话框1.成功("已领取,请在仓库中提取资源");
			}else if(json.table == "user_pay" && json.model == "select" ){
				div_pay_id.置标题(json.msg);
				发起后渲染充值按钮(json._id,json.comm);
				div_pay_popover.显示();
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "oper_login_info" && json.model == "select" ){

				CYS超级列表框1.清空项目();
				CYS超级列表框1.添加项目(json.results.oper_login,"玩家账号",1,"","oper_login");
				CYS超级列表框1.添加项目(json.results.oper_name,"玩家昵称",1,"","oper_name");
				CYS超级列表框1.添加项目(json.results.game_account_username,"绑定的游戏账号",1,"","game_account_username");
				CYS超级列表框1.添加项目(json.results.game_uid,"绑定UID",1,"","game_uid");
				CYS超级列表框1.添加项目(json.results.server_name,"当前登陆服务器",1,"","server_name");
				CYS超级列表框1.添加项目(json.results.create_time,"注册时间",1,"","create_time");
				CYS超级列表框1.添加项目(json.results.login_time,"最后登录",1,"","login_time");
				var vip= "无";
				if(json.results.vip_id != "" ){
					vip = json.results.vip_name;
				}
				CYS超级列表框1.添加项目(vip,"VIP等级",1,"","vip_id");
				if(json.results.sign_name != null ){

					CYS超级列表框1.添加项目("VIP签到","领取今日份福利",4,"mui-btn-green","vip_sign");
				}
				CYS超级列表框1.添加项目("累充福利","领取累充福利",4,"mui-btn-green","vip_draw");
				if(json.results.week_card + json.results.month_card > 0 ){
					vip = "您有";
					if(json.results.week_card > 0 ){
						vip=vip+转换操作.到文本(json.results.week_card)+"张周卡";
					}
					if(json.results.month_card > 0 ){
						if(json.results.week_card > 0 ){
							vip=vip+","+转换操作.到文本(json.results.month_card)+"张月卡";
						}else{
							vip=vip+转换操作.到文本(json.results.month_card)+"张月卡";
						}
					}
					CYS超级列表框1.添加项目(vip,"领取资源",4,"mui-btn-green","shop_card");
				}


				CYS超级列表框1.添加项目("平台币余额："+转换操作.到文本(json.results.coin_sum_ava),"测试：充值0.1元",4,"mui-btn-blue","coin_sum_ava");
				CYS超级列表框1.添加项目("总充值平台币数量："+转换操作.到文本(json.results.coin_sum_in),"",0,"","");
				CYS超级列表框1.添加项目("修改当前账号密码","修改密码",4,"mui-btn-red","reset-pwd");
				CYS超级列表框1.添加项目("跳回到登陆页面","切换账号",4,"mui-btn-red","login-out");
				标签1.置可视(true);
				按钮组_日志.置可视(true);
			}else if(json.table == "oper_login_info" && json.model == "excdk" ){
				div_cdk_popover.隐藏();
				div_cdk_next_grid.清空项目();
				while(i < json.results.length){
					if(json.results[i][1] < 0 ){
						div_cdk_next_grid.添加项目2("","兑换："+json.results[i][0],"失败："+json.results[i][2],"");
					}else{
						div_cdk_next_grid.添加项目2("","兑换："+json.results[i][0],"成功！"+json.results[i][2],"");
					}
					i++
				}
				div_cdk_next_popover.显示();
				m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "select" , 0, 0);
				m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
				美化等待框1.默认等待框("正在交互","正在获取服务器列表,请稍等......");
				时钟1.开始执行(200,false);
			}else if(json.table == "oper_login_info" && json.model == "inout-log" ){
				var num= 转换操作.到数值(json.msg);
				while(i < json.results.length){
					if(num < 1 ){
						CYS时钟轴1.添加项目("充值日志",json.results[i].inout_note,json.results[i].inout_create,"");
					}else if(num == 1 ){
						CYS时钟轴1.添加项目("消费日志",json.results[i].inout_note,json.results[i].inout_create,"");
					}else{
						CYS时钟轴1.添加项目("抽奖日志",json.results[i].inout_note,json.results[i].inout_create,"");
					}

					i++
				}
			}else if(json.table == "oper_login_info" && json.model == "vip_draw" ){
				while(i < json.results.length){
					var title= "【 "+json.results[i].vip_name+" 】";
					title = title + "累充"+转换操作.到文本(json.results[i].vip_monetary)+"平台币可领取";
					var btn= "领取";
					var 按钮样式= "mui-btn mui-btn-success";
					if(json.results[i].is_receive > 0 ){
						btn = "已领<br>取过";
						按钮样式 = "mui-btn mui-btn-danger";
					}else if(json.results[i].vip_monetary > json.msg ){
						btn = "累充<br>不足";
						按钮样式 = "mui-btn mui-btn-royal";
					}
					var note= json.results[i].vip_note;
					if(note == "" ){
						note = title;
					}
					div_draw_grid_添加项目(title, note, btn, 按钮样式, json.results[i].vip_id);
					i++
				}
				div_draw_popover.显示();



			}

		}
	}
}
function CYS超级列表框1_按钮被单击(项目索引){
	var 标记= CYS超级列表框1.取项目标记(项目索引);
	if(标记 == "coin_sum_ava" ){


		发起直充前();
		return;
	}
	if(标记 == "vip_sign" ){
		m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "sign" , 0, 0);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
		美化等待框1.默认等待框("正在交互","正在签到,请稍等......");
		时钟1.开始执行(200,false);
		return;
	}
	if(标记 == "reset-pwd" ){
		div_reset_popover.显示();
		return;
	}
	if(标记 == "login-out" ){
		if(HPtools1.询问框("是否登陆别的账号？") == true ){
			窗口操作.切换窗口("index.html");
			return;
		}
	}
	if(标记 == "shop_card" ){
		m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "card" , 0, 0);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
		美化等待框1.默认等待框("正在交互","正在领取,请稍等......");
		时钟1.开始执行(200,false);
	}
	if(标记 == "sign_name" ){




		return;
	}
	if(标记 == "vip_draw" ){
		div_draw_grid.清空项目();
		m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "vip_draw" , 0, 0);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		时钟1.开始执行(200,false);

	}
}
function div_cdk_btn_被单击(){
	div_cdk_edit.置内容(文本操作.删首尾空(div_cdk_edit.取内容()));
	if(div_cdk_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入CDK");
		return;
	}
	var str_arr = 文本操作.分割文本(div_cdk_edit.取内容(), "\n");
	if(HPtools1.询问框("是否兑换？") == false ){
		return;
	}
	var json ={}
	json.cdk = str_arr;
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "excdk" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
	美化等待框1.默认等待框("正在交互","正在兑换CDK,请稍等......");
	时钟1.开始执行(200,false);
}
function 按钮组_日志_被单击(按钮索引){
	CYS时钟轴1.清空项目();
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "inout-log" , 按钮索引, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
	美化等待框1.默认等待框("正在交互","正在查询日志,请稍等......");
	时钟1.开始执行(200,false);
}
function div_reset_btn_被单击(){
	div_reset_password_old.置内容(文本操作.删首尾空(div_reset_password_old.取内容()));
	if(div_reset_password_old.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入原密码");
		return;
	}
	div_reset_password.置内容(文本操作.删首尾空(div_reset_password.取内容()));
	if(div_reset_password.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入新密码");
		return;
	}
	div_reset_password_.置内容(文本操作.删首尾空(div_reset_password_.取内容()));
	if(div_reset_password.取内容() != div_reset_password_.取内容() ){
		仔仔弹出对话框1.错误("两次输入的密码不一致");
		return;
	}
	var oper_password_old= 加密操作1.取md5值(div_reset_password_old.取内容());
	oper_password_old = "" + oper_password_old;
	var oper_password= 加密操作1.取md5值(div_reset_password.取内容());
	oper_password = "" + oper_password;
	var json= {}
	json.old_password = oper_password_old;
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "reset-pwd" , 0, 0, json, CYS超级列表框1.取项目标题(0), oper_password);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", "");
	美化等待框1.默认等待框("正在交互","正在重置,请稍等......");
	时钟1.开始执行(200,false);
}
function div_draw_grid_添加项目(项目标题, 项目内容, 按钮标题, 按钮样式, 项目标记){
	div_draw_grid_title.置标题(项目标题);
	div_draw_grid_note.置标题(项目内容);
	div_draw_grid_btn.置标题(按钮标题);
	div_draw_grid_btn.置样式(按钮样式);
	div_draw_grid.添加项目("自由面板1",true,项目标记);
}

function div_draw_grid_按钮被单击(项目索引,按钮名称){
	var vip_id= div_draw_grid.取项目标记(项目索引);
	按钮标题 = div_draw_grid.取按钮标题(项目索引, 按钮名称);

	if(按钮标题 == "领取" ){
		var json= {}
		json.vip_id = vip_id;
		m_post = 公用模块.生成提交数据(0, "oper_login_info_vip_draw", "", "" , 0, 0,json);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
		美化等待框1.默认等待框("正在交互","正在领取,请稍等......");
		时钟1.开始执行(200,false);
	}else if(按钮标题 == "已领<br>取过" ){
		仔仔弹出对话框1.提示("您已领取过");
	}else{
		仔仔弹出对话框1.提示("您的累充不足");
	}
}


function 发起直充前(){
	div_pay_id.置标题("");
	m_post = "";
	m_url = 公用模块.生成访问链接(根地址,"api/pay/select", m_token);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}
function 发起后渲染充值按钮(_id, 充赠比){
	if(充赠比 < 1 ){
		充赠比 = 1;
	}
	var str= "";
	if(充赠比 > 1 ){
		str = "[限时优惠：充赠比"+转换操作.到文本(充赠比)+"倍]";
	}
	submit_model = _id.pay_model;
	if(submit_model < 10 ){
		div_pay_lable_1.置可视(true);
		div_pay_model.置可视(true);
	}else{
		div_pay_lable_1.置可视(false);
		div_pay_model.置可视(false);
	}
	div_pay_lable_2.置标题("确认要充值的金额：" + str);
	div_pay_btns_1.置标题(0, "充值6元 → "+转换操作.到文本(6*充赠比*_id.invest_scale)+"平台币");
	div_pay_btns_1.置标题(1, "充值18元 → "+转换操作.到文本(18*充赠比*_id.invest_scale)+"平台币");
	div_pay_btns_2.置标题(0, "充值58元 → "+转换操作.到文本(58*充赠比*_id.invest_scale)+"平台币");
	div_pay_btns_2.置标题(1, "充值98元 → "+转换操作.到文本(98*充赠比*_id.invest_scale)+"平台币");
	div_pay_btns_3.置标题(0, "充值198元 → "+转换操作.到文本(198*充赠比*_id.invest_scale)+"平台币");
	div_pay_btns_3.置标题(1, "充值328元 → "+转换操作.到文本(328*充赠比*_id.invest_scale)+"平台币");
	div_pay_btns_4.置标题(0, "充值648元 → "+转换操作.到文本(648*充赠比*_id.invest_scale)+"平台币");
	div_pay_btns_4.置标题(1, "充值1000元 → "+转换操作.到文本(1000*充赠比*_id.invest_scale)+"平台币");
}

function div_pay_model_被单击(按钮索引){
	div_pay_model.置样式(0,"mui-btn");
	div_pay_model.置样式(1,"mui-btn");
	div_pay_model.置样式(按钮索引,"mui-btn mui-btn-success");
	pay_model = "alipay";
	if(按钮索引 == 1 ){
		pay_model = "wxpay";
	}
}

function div_pay_btns_1_被单击(按钮索引){
	var amount= 6;
	if(按钮索引 > 0 ){
		amount = 18;
	}
	公用模块.发起真实充值操作(amount, m_token, submit_model, pay_model, 仔仔弹出对话框1);
}
function div_pay_btns_2_被单击(按钮索引){
	var amount= 58;
	if(按钮索引 > 0 ){
		amount = 98;
	}
	公用模块.发起真实充值操作(amount, m_token, submit_model, pay_model, 仔仔弹出对话框1);
}
function div_pay_btns_3_被单击(按钮索引){
	var amount= 198;
	if(按钮索引 > 0 ){
		amount = 328;
	}
	公用模块.发起真实充值操作(amount, m_token, submit_model, pay_model, 仔仔弹出对话框1);
}
function div_pay_btns_4_被单击(按钮索引){
	var amount= 648;
	if(按钮索引 > 0 ){
		amount = 1000;
	}
	公用模块.发起真实充值操作(amount, m_token, submit_model, pay_model, 仔仔弹出对话框1);
}
function div_pay_btn_cdk_被单击(){
	div_pay_popover.隐藏();
	div_cdk_popover.显示();
}

function div_pay_test_btn_被单击(){
	公用模块.发起真实充值操作(0.1, m_token, submit_model, pay_model, 仔仔弹出对话框1);
}
function div_pay_test_btn2_被单击(){
	var str= HPtools1.输入框("请输入要充值的金额");
	str = 文本操作.删首尾空(str);
	if(str == "" ){
		return;
	}
	var num= 转换操作.到数值(str);
	if(num <= 0 ){
		仔仔弹出对话框1.错误("充值金额不能为0！");
		return;
	}
	公用模块.发起真实充值操作(num, m_token, submit_model, pay_model, 仔仔弹出对话框1);

}