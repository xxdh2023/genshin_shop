mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 时钟1 = new 时钟("时钟1",null);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 标签_提示 = new 标签("标签_提示",null);
var 标签1 = new 标签("标签1",null);
var 下拉框_套装 = new 下拉框("下拉框_套装",下拉框_套装_表项被单击);
var 标签_套装_提示 = new 标签("标签_套装_提示",null);
var 标签2 = new 标签("标签2",null);
var 下拉框_圣遗物 = new 下拉框("下拉框_圣遗物",下拉框_圣遗物_表项被单击);
var 标签_圣遗物_提示 = new 标签("标签_圣遗物_提示",null);
var 标签10 = new 标签("标签10",null);
var 下拉框_等级 = new 下拉框("下拉框_等级",下拉框_等级_表项被单击);
var 标签_等级_提示 = new 标签("标签_等级_提示",null);
var 标签3 = new 标签("标签3",null);
var 下拉框_主词条 = new 下拉框("下拉框_主词条",下拉框_主词条_表项被单击);
var 标签_主词条_提示 = new 标签("标签_主词条_提示",null);
var 标签4 = new 标签("标签4",null);
var 下拉框_关键词 = new 下拉框("下拉框_关键词",下拉框_关键词_表项被单击);
var 标签5 = new 标签("标签5",null);
var 面板1 = new 面板("面板1");
var 下拉框_副词条 = new 下拉框("下拉框_副词条",下拉框_副词条_表项被单击);
var 按钮_添加 = new 按钮("按钮_添加",按钮_添加_被单击,null,null);
var 标签_副词条_提示 = new 标签("标签_副词条_提示",null);
var 标签6 = new 标签("标签6",null);
var 列表框1 = new 列表框("列表框1",false,null,列表框1_按钮被单击);
var 面板2 = new 面板("面板2");
var 标签7 = new 标签("标签7",null);
var 标签_总金额 = new 标签("标签_总金额",null);
var 按钮_开始定制 = new 按钮("按钮_开始定制",按钮_开始定制_被单击,null,null);
var 标签8 = new 标签("标签8",null);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签9 = new 标签("标签9",null);
var 复选框_确认 = new 复选框("复选框_确认",null);
var 按钮_发起定制 = new 按钮("按钮_发起定制",按钮_发起定制_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        定制圣遗物_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        定制圣遗物_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var show_element = [];
var artifact_amount = 0;
var artifact_limit = 0;
var cat_amount = 0;
var info_amount = 0;
var main_amount = 0;
var m_json = {}
var max_sub = 1;
var max_level = 1;
var level_amount = 0;


function 定制圣遗物_创建完毕(){
	根地址 = HPtools1.取URL();
	标题栏美化1.去标题栏阴影();
	界面初始化();
	弹出面板初始化();
	m_post = 公用模块.生成提交数据(0, "artifact_init", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/artifact/select", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 界面初始化(){
	show_element.push(标签1);
	下拉框_套装.清空项目();
	下拉框_套装.添加项目("请选择...", "");
	下拉框_套装.置现行选中项(0);
	show_element.push(下拉框_套装);
	show_element.push(标签2);
	下拉框_圣遗物.清空项目();
	下拉框_圣遗物.添加项目("请先选择上面的套装", "");
	下拉框_圣遗物.置现行选中项(0);
	show_element.push(下拉框_圣遗物);
	show_element.push(标签3);
	show_element.push(标签10);
	下拉框_等级.清空项目();
	下拉框_等级.添加项目("请选择...", "");
	下拉框_等级.置现行选中项(0);
	show_element.push(下拉框_等级);
	下拉框_主词条.清空项目();
	下拉框_主词条.添加项目("请选择...", "");
	下拉框_主词条.置现行选中项(0);
	show_element.push(下拉框_主词条);
	show_element.push(标签4);
	下拉框_关键词.清空项目();
	下拉框_关键词.添加项目("请选择...", "");
	下拉框_关键词.置现行选中项(0);
	show_element.push(下拉框_关键词);
	show_element.push(标签5);
	下拉框_副词条.清空项目();
	下拉框_副词条.添加项目("请先选择上面的种类", "");
	下拉框_副词条.置现行选中项(0);
	下拉框_副词条.置可视(true);
	面板1.添加组件("下拉框_副词条", "3");
	按钮_添加.置可视(true);
	面板1.添加组件("按钮_添加", "1");
	面板1.置可视(false);
	show_element.push(面板1);
	show_element.push(标签6);
	show_element.push(列表框1);
	面板2.置高度("80px");
	标签7.置可视(true);
	面板2.添加组件("标签7", "140px");
	标签_总金额.置可视(true);
	面板2.添加组件("标签_总金额", "200px");
	面板2.置可视(false);
	show_element.push(面板2);
	show_element.push(按钮_开始定制);
	show_element.push(标签8);
	标签_套装_提示.置标题("<br>&nbsp;");
	标签_圣遗物_提示.置标题("<br>&nbsp;");
	标签_等级_提示.置标题("<br>&nbsp;");
	标签_主词条_提示.置标题("<br>&nbsp;");
	标签_副词条_提示.置标题("");


}

function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(-240, 180, false);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	标签9.置可视(true);
	弹出面板1.添加组件("标签9");
	复选框_确认.置可视(true);
	弹出面板1.添加组件("复选框_确认");
	按钮_发起定制.置可视(true);
	弹出面板1.添加组件("按钮_发起定制");
}
function 显示等待框(){
	公用模块.showMask("页面遮罩");
	HPtools1.显示等待框("请稍等......");

}
function 关闭等待框(){

	公用模块.hideMask("页面遮罩");
	HPtools1.关闭等待框();
}

function 网络操作1_发送完毕(发送结果,返回信息){
	关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "artifact_start_sub" ){
				仔仔弹出对话框1.错误("副词条[ "+json.sub_name+" ]"+json.msg);
				return;
			}

			仔仔弹出对话框1.错误(json.msg);
			if(json.table == "artifact_init" ){
				标签_提示.置标题("<br><br><br>" + json.msg);
			}
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "artifact_init" ){
				if(json.artifact == false ){
					标签_提示.置标题("<br><br><br>定制功能未开启");
				}else{
					标签_提示.置可视(false);
					i=0;
					while(i<json.artifact_cat.length){
						下拉框_套装.添加项目(json.artifact_cat[i].cat_name, 转换操作.json转文本(json.artifact_cat[i]));
						i++
					}
					i=0;
					while(i<json.attr_main.length){
						下拉框_主词条.添加项目(json.attr_main[i].attr_main_name, 转换操作.json转文本(json.attr_main[i]));
						i++
					}
					i=0;
					while(i<json.attr_sub.length){
						下拉框_关键词.添加项目(json.attr_sub[i].attr_sub_name, json.attr_sub[i].attr_sub_name);
						i++
					}
					i=0;
					while(i<json.level_list.length){
						下拉框_等级.添加项目(""+json.level_list[i].level, 转换操作.json转文本(json.level_list[i]));
						i++
					}
					i=0;
					while(i<show_element.length){
						show_element[i].置可视(true);
						i++
					}
					artifact_amount = json.msg.amount;
					artifact_limit = json.msg.limit;
					max_level = json.msg.max_level;
					max_sub = json.msg.max_sub;
					标签6.置标题("<br>已添加副词条：（最少1条，最多"+String(max_sub)+"条）");
					计算定价总金额();
				}
			}else if(json.table == "artifact_info" ){
				下拉框_圣遗物.清空项目();
				下拉框_圣遗物.添加项目("请选择圣遗物...", "");
				下拉框_圣遗物.置现行选中项(0);
				var title = "";
				while(i<json.results.length){
					title = json.results[i].artifact_name;
					if(json.results[i].artifact_type == 1 ){
						title = title + "[空之杯]";
					}else if(json.results[i].artifact_type == 2 ){
						title = title + "[死之羽]";
					}else if(json.results[i].artifact_type == 3 ){
						title = title + "[理之冠]";
					}else if(json.results[i].artifact_type == 4 ){
						title = title + "[生之花]";
					}else if(json.results[i].artifact_type == 5 ){
						title = title + "[时之沙]";
					}
					下拉框_圣遗物.添加项目(title, 转换操作.json转文本(json.results[i]));
					i++
				}
			}else if(json.table == "artifact_sub" ){
				下拉框_副词条.清空项目();
				下拉框_副词条.添加项目("请选择副词条...", "");
				下拉框_副词条.置现行选中项(0);
				while(i<json.results.length){
					下拉框_副词条.添加项目(json.results[i].attr_sub_name, 转换操作.json转文本(json.results[i]));
					i++
				}
			}else{

			}
		}
	}
}

function 计算定价总金额(){
	var 总金额 = artifact_amount + cat_amount + info_amount + main_amount + level_amount;
	var i=0;
	if(列表框1.取项目总数() > 0 ){
		var 项目标记 = "";
		var json = {}
		while(i<列表框1.取项目总数()){
			项目标记 = 文本操作.删首尾空(列表框1.取项目标记(i));
			if(项目标记 == "" ){
				continue;
			}
			json = 转换操作.文本转json(项目标记);

			if(转换操作.到数值(json.attr_sub_amount) > 0 ){
				总金额 = 总金额 + 转换操作.到数值(json.attr_sub_amount);
			}
			i++
		}
	}

	标签_总金额.置标题(""+总金额);
}
function 下拉框_套装_表项被单击(项目索引,项目标题,项目标记){

	下拉框_圣遗物.清空项目();
	下拉框_圣遗物.添加项目("请先选择上面的套装", "");
	下拉框_圣遗物.置现行选中项(0);
	标签_圣遗物_提示.置标题("<br>&nbsp;");
	info_amount = 0;
	标签_套装_提示.置标题("<br>&nbsp;");
	cat_amount = 0;
	if(项目标记 == "" ){
		计算定价总金额();
		return;
	}
	var json = 转换操作.文本转json(项目标记);

	if(json.cat_amount > 0 ){
		标签_套装_提示.置标题("总价：+ "+String(json.cat_amount));
		cat_amount = json.cat_amount;
	}
	计算定价总金额();
	m_post = 公用模块.生成提交数据(json.ID, "artifact_info", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/artifact/select", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);



}
function 下拉框_圣遗物_表项被单击(项目索引,项目标题,项目标记){

	标签_圣遗物_提示.置标题("<br>&nbsp;");
	info_amount = 0;
	if(项目标记 == "" ){
		计算定价总金额();
		return;
	}
	var json = 转换操作.文本转json(项目标记);

	var msg = "";
	if(json.artifact_amount > 0 ){
		msg = "总价：+ "+String(json.artifact_amount);
		info_amount = json.artifact_amount;
	}
	if(json.artifact_limit > 0 ){
		if(msg != "" ){
			msg = msg + "，";
		}
		msg = msg + "限购："+String(json.artifact_limit)+"件";
	}
	标签_圣遗物_提示.置标题(msg);
	计算定价总金额();



}
function 下拉框_主词条_表项被单击(项目索引,项目标题,项目标记){

	标签_主词条_提示.置标题("<br>&nbsp;");
	main_amount = 0;
	if(项目标记 == "" ){
		计算定价总金额();
		return;
	}
	var json = 转换操作.文本转json(项目标记);

	var msg = "";
	if(json.attr_main_amount > 0 ){
		msg = "总价：+ "+String(json.attr_main_amount);
		main_amount = json.attr_main_amount;
	}
	if(json.attr_main_limit > 0 ){
		if(msg != "" ){
			msg = msg + "，";
		}
		msg = msg + "限购："+String(json.attr_main_limit)+"件";
	}
	标签_主词条_提示.置标题(msg);
	计算定价总金额();
}
function 下拉框_关键词_表项被单击(项目索引,项目标题,项目标记){

	下拉框_副词条.清空项目();
	下拉框_副词条.添加项目("请先选择上面的种类", "");
	下拉框_副词条.置现行选中项(0);
	标签_副词条_提示.置标题("");
	if(项目标记 == "" ){
		return;
	}

	m_post = 公用模块.生成提交数据(0, "artifact_sub", 项目标记, "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/artifact/select", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);



}
function 下拉框_副词条_表项被单击(项目索引,项目标题,项目标记){

	标签_副词条_提示.置标题("");
	if(项目标记 == "" ){
		return;
	}
	var json = 转换操作.文本转json(项目标记);

	var msg = "";
	if(json.attr_sub_amount > 0 ){
		msg = "总价：+ "+String(json.attr_sub_amount);
	}
	if(json.attr_sub_limit > 0 ){
		if(msg != "" ){
			msg = msg + "，";
		}
		msg = msg + "限购："+String(json.attr_sub_limit)+"条";
	}
	标签_副词条_提示.置标题(msg);
}
function 按钮_添加_被单击(){
	if(列表框1.取项目总数() >= max_sub ){
		仔仔弹出对话框1.错误("已有"+String(max_sub)+"条副词条,不能添加！");
		return;
	}
	var 项目标记 = 下拉框_副词条.取项目标记(下拉框_副词条.取现行选中项());
	if(项目标记 == "" ){
		仔仔弹出对话框1.错误("请先选择副词条！");
		return;
	}
	var json = 转换操作.文本转json(项目标记);

	if(json.attr_sub_limit > 0 && 列表框1.取项目总数() > 0 ){
		var i=0;
		var count = 0;
		var _j = {}
		while(i<列表框1.取项目总数()){
			项目标记 = 文本操作.删首尾空(列表框1.取项目标记(i));
			if(项目标记 == "" ){
				continue;
			}
			_j = 转换操作.文本转json(项目标记);
			if(_j.ID == json.ID ){
				count ++
			}
			i++
		}
		if(count >= json.attr_sub_limit && json.attr_sub_limit > 0 ){
			仔仔弹出对话框1.错误("限购"+String(json.attr_sub_limit)+"条,不能添加！");
			return;
		}

	}

	列表框1.添加项目2(json.attr_sub_name,转换操作.json转文本(json), "mui-btn mui-btn-danger", "删除");
	计算定价总金额();
}
function 列表框1_按钮被单击(项目索引){
	列表框1.删除项目(项目索引);
	计算定价总金额();
}

function 按钮_开始定制_被单击(){

	m_json = {}
	var 项目标记 = "";
	var json = {}
	项目标记 = 文本操作.删首尾空(下拉框_圣遗物.取项目标记(下拉框_圣遗物.取现行选中项()));
	if(项目标记 == "" ){
		仔仔弹出对话框1.错误("请选择要定制的圣遗物！");
		return;
	}
	json = 转换操作.文本转json(项目标记);
	m_json.artifact_id = json.ID;
	var artifact_level = 下拉框_等级.取现行选中项() - 1;
	if(artifact_level < 0 ){
		仔仔弹出对话框1.错误("请选择圣遗物等级！");
		return;
	}
	if(artifact_level > max_level ){
		仔仔弹出对话框1.错误("圣遗物等级越界！");
		return;
	}

	m_json.artifact_level = artifact_level;

	项目标记 = 文本操作.删首尾空(下拉框_主词条.取项目标记(下拉框_主词条.取现行选中项()));
	if(项目标记 == "" ){
		仔仔弹出对话框1.错误("请选择主词条！");
		return;
	}
	json = 转换操作.文本转json(项目标记);
	m_json.main_id = json.ID;
	if(列表框1.取项目总数() < 1 ){
		仔仔弹出对话框1.错误("至少添加1条副词条");
		return;
	}
	if(列表框1.取项目总数() > max_sub ){
		仔仔弹出对话框1.错误("最多只能添加"+String(max_sub)+"条副词条");
		return;
	}
	m_json.sub_id = [];
	var i=0;
	var ii=0;
	var iii = false;
	var attr_sub = [];
	while(i<列表框1.取项目总数()){
		项目标记 = 文本操作.删首尾空(列表框1.取项目标记(i));
		if(项目标记 == "" ){
			continue;
		}
		json = 转换操作.文本转json(项目标记);
		m_json.sub_id.push(json.ID);
		ii=0;
		var title = 文本操作.分割文本(列表框1.取项目标题(i), "+")[0];

		if(attr_sub.length < 1 ){
			attr_sub.push(title);
		}else{
			iii = false;
			while(ii<attr_sub.length){
				if(attr_sub[ii] == title ){
					iii = true;
					break;
				}
				ii++
			}
			if(iii == false ){
				attr_sub.push(title);
			}
		}
		i++
	}
	if(attr_sub.length > 4 ){
		仔仔弹出对话框1.错误("副词条的种类不能多于4种！");
		return;
	}
	if(attr_sub.length < 4 ){
		if(HPtools1.询问框("您选了"+String(attr_sub.length)+"种副词条,一共可以选择4种副词条,是否继续？") == false ){
			return;
		}
	}

	复选框_确认.置选中状态(false);
	弹出面板1.显示();
}
function 按钮_发起定制_被单击(){
	if(复选框_确认.取选中状态() == false ){
		仔仔弹出对话框1.错误("请确保游戏在线并勾选确认项！");
		return;
	}
	弹出面板1.隐藏();
	m_post = 公用模块.生成提交数据(0, "artifact_start", "", "update" , 0, 0, m_json);
	m_url = 公用模块.生成访问链接(根地址,"api/artifact/update", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 下拉框_等级_表项被单击(项目索引,项目标题,项目标记){

	标签_等级_提示.置标题("<br>&nbsp;");
	level_amount = 0;
	if(项目标记 == "" ){
		计算定价总金额();
		return;
	}
	var json = 转换操作.文本转json(项目标记);
	var msg = "";
	if(json.amount > 0 ){
		msg = "总价：+ "+String(json.amount);
		level_amount = json.amount;
	}
	标签_等级_提示.置标题(msg);
	计算定价总金额();


}