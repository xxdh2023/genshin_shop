mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 登录界面1 = new 登录界面("登录界面1",登录界面1_登录按钮被单击,登录界面1_注册账号被单击,登录界面1_忘记密码被单击);
var CYS滚动选择器1 = new CYS滚动选择器("CYS滚动选择器1",CYS滚动选择器1_项目被选择);
var div_reset_popover = new 弹出面板("div_reset_popover",null,null);
var div_reset_lable = new 标签("div_reset_lable",null);
var div_reset_login = new 编辑框("div_reset_login",null,null,null,null,null);
var div_reset_dropbox = new 下拉框("div_reset_dropbox",div_reset_dropbox_表项被单击);
var div_reset_answer = new 编辑框("div_reset_answer",null,null,null,null,null);
var div_reset_password = new 编辑框("div_reset_password",null,null,null,null,null);
var div_reset_password_ = new 编辑框("div_reset_password_",null,null,null,null,null);
var div_reset_btn = new 按钮("div_reset_btn",div_reset_btn_被单击,null,null);
var div_reset_mail = new 按钮("div_reset_mail",div_reset_mail_被单击,null,null);
var div_mail_popover = new 弹出面板("div_mail_popover",null,null);
var div_mail_lable = new 标签("div_mail_lable",null);
var div_mail_edit = new 编辑框("div_mail_edit",null,null,null,null,null);
var div_mail_btn = new 按钮("div_mail_btn",div_mail_btn_被单击,null,null);
var div_mail_show = new 标签("div_mail_show",null);
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        主窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        主窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var agent= "";
var agid= 0;
var reg= "";
var question_reset= "";
var m_static= 0;
var 可以注册= false;
function 主窗口_创建完毕(){
	窗口操作.置窗口标题("元神商城登陆");
	var msg= 文本操作.删首尾空(窗口操作.取当前页面参数("msg"));
	if(msg != "" ){
		msg = 加密操作1.url解码(msg);
	}
	if(msg != "" ){
		仔仔弹出对话框1.提示(msg,1500000);
	}
	agent = 文本操作.删首尾空(窗口操作.取当前页面参数("agid"));
	if(agent == "" ){
		agid = 0;
	}else{
		agid = 数学操作.取整数(转换操作.到数值(agent));
	}
	agent = 文本操作.删首尾空(窗口操作.取当前页面参数("agent"));
	根地址 = HPtools1.取URL();
	公用模块.动态加载脚本("files/popup.js", 隐藏框架);
	CYS滚动选择器1.置样式(1);
	标题栏美化1.置标题栏透明();
	标题栏美化1.去标题栏阴影();
	登陆界面初始化();
	MyCookie.setCookie("genshin-shop-token", "", 1);
	reg = 文本操作.删首尾空(窗口操作.取当前页面参数("reg"));
	m_post = 公用模块.生成提交数据(0, "gameserver", "", "" , 0, 0, {"t": HPtools1.取毫秒数()});
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", "");
	显示等待框();
	时钟1.开始执行(200,false);
}
function 隐藏框架(){
	popup.hideIframeB("register");
	console.log("已加载");
}
function 账号注册(){
	if(可以注册 == false ){
		仔仔弹出对话框1.错误("内测模式，已暂停注册！");
		return;
	}
	if(popup.Ishow("register") == true ){
		console.log("弹窗已被占用");
		return;
	}
	var rect = 公用模块.弹出面板初始化计算(40,40,true);
	popup.showIframeB("register","playereg.html?agent="+agent+"&agid="+String(agid),rect[0],rect[1],rect[2],rect[3]);
	显示注册遮罩及等待框();
}
function 登陆界面初始化(){
	rect = 公用模块.弹出面板初始化计算(50, 360, false);
	div_reset_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_reset_popover.添加组件("div_reset_lable");
	div_reset_popover.添加组件("div_reset_login");
	div_reset_popover.添加组件("div_reset_dropbox");
	div_reset_popover.添加组件("div_reset_answer");
	div_reset_popover.添加组件("div_reset_password")
div_reset_popover.添加组件("div_reset_password_")
div_reset_popover.添加组件("div_reset_btn");
	div_reset_popover.添加组件("div_reset_mail");
	div_reset_dropbox.添加项目("请选择重置密码问题......","");
	div_reset_dropbox.添加项目("您所在的城市","您所在的城市");
	div_reset_dropbox.添加项目("您所在的国家","您所在的国家");
	div_reset_dropbox.添加项目("您最难忘的事是什么","您最难忘的事是什么");
	div_reset_dropbox.添加项目("您最难忘的是哪句话","您最难忘的是哪句话");
	rect = 公用模块.弹出面板初始化计算(50, 220, false);
	div_mail_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_mail_popover.添加组件("div_mail_lable");
	div_mail_popover.添加组件("div_mail_edit");
	div_mail_popover.添加组件("div_mail_btn");
	div_mail_popover.添加组件("div_mail_show");
}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){
	关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info" ){
				if(json.model == "login" ){

					if(json._id == 0 ){
						MyCookie.setCookie("genshin-shop-token", json.msg, 7*24*60*60);
						窗口操作.切换窗口("shop.html","");
					}else{
						MyCookie.setCookie("genshin-agent-token", json.msg, 7*24*60*60);
						窗口操作.切换窗口(根地址+"/agent/user.html","");
					}
				}else if(json.model == "reset" ){
					div_reset_popover.隐藏();
					仔仔弹出对话框1.成功("重置成功");
				}
			}else{
				div_mail_popover.隐藏();
				仔仔弹出对话框1.成功(json.msg);
			}


		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "gameserver" ){
				m_static = 0;
				CYS滚动选择器1.清空项目();
				CYS滚动选择器1.添加项目("..请选择游戏服务器..", 0);
				while(i < json.results.length){
					CYS滚动选择器1.添加项目(json.results[i].game_name, json.results[i].ID);
					i++
				}
				if(json.results.length  == 1 ){
					m_static = json.results[0].ID;
				}
				可以注册 = json.comm;
				if(reg == "popover" ){
					账号注册();
				}
			}
		}
	}
}
function 登录界面1_登录按钮被单击(){
	var oper_login= 文本操作.删首尾空(登录界面1.取账号内容());
	var oper_password= 文本操作.删首尾空(登录界面1.取密码内容());
	if(oper_login == "" ){
		仔仔弹出对话框1.错误("账号不能为空！");
		return;
	}
	if(oper_password == "" ){
		仔仔弹出对话框1.错误("密码不能为空！");
		return;
	}
	if(m_static == 0 ){
		CYS滚动选择器1.弹出();
	}else{
		登陆系统(m_static);
	}
}
function 登录界面1_注册账号被单击(){
	账号注册();
}
function 登录界面1_忘记密码被单击(){
	div_reset_login.置内容("");
	div_reset_answer.置内容("");
	div_reset_password.置内容("");
	div_reset_password_.置内容("");
	div_reset_popover.显示();
}
function CYS滚动选择器1_项目被选择(标题,值){
	登陆系统(值);
}
function div_reset_dropbox_表项被单击(项目索引,项目标题,项目标记){
	question_reset = 项目标记;
}

function div_reset_btn_被单击(){
	div_reset_login.置内容(文本操作.删首尾空(div_reset_login.取内容()));
	if(div_reset_login.取内容() == "" ){
		仔仔弹出对话框1.错误("账号不能为空");
		return;
	}
	if(question_reset == "" ){
		仔仔弹出对话框1.错误("请选择问题");
		return;
	}
	div_reset_answer.置内容(文本操作.删首尾空(div_reset_answer.取内容()));
	if(div_reset_answer.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入答案");
		return;
	}
	div_reset_password.置内容(文本操作.删首尾空(div_reset_password.取内容()));
	div_reset_password_.置内容(文本操作.删首尾空(div_reset_password_.取内容()));
	if(div_reset_password.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入密码");
		return;
	}
	if(div_reset_password.取内容() != div_reset_password_.取内容() ){
		仔仔弹出对话框1.错误("两次密码输入不一致");
		return;
	}
	var oper_password= 加密操作1.取md5值(div_reset_password.取内容());
	oper_password = "" + oper_password;
	var json= {}
	json.oper_question = question_reset;
	json.oper_answer = div_reset_answer.取内容();
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "reset" , 0, 0, json, div_reset_login.取内容(), oper_password);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", "");
	显示等待框();
	时钟1.开始执行(200,false);


}
function div_reset_mail_被单击(){
	div_reset_popover.隐藏();
	div_mail_popover.显示();
}
function div_mail_btn_被单击(){
	div_mail_edit.置内容(文本操作.删首尾空(div_mail_edit.取内容()));
	if(div_mail_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写邮箱地址");
		 return;
	}
	var json= {}
	json.mail_addr = div_mail_edit.取内容();
	json.root_url = 根地址;
	m_post = 公用模块.生成提交数据(0, "oper_login_info_mail", "", "mail_reset" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/mail_reset", "");
	显示等待框();
	时钟1.开始执行(200,false);
}

function 登陆系统(static){
	if(static < 1 ){
		仔仔弹出对话框1.错误("请选择要登陆的服务器");
		return;
	}
	var oper_login= 文本操作.删首尾空(登录界面1.取账号内容());
	var oper_password= 文本操作.删首尾空(登录界面1.取密码内容());
	oper_password = 加密操作1.取md5值(oper_password);
	oper_password = "" + oper_password;
	m_post = 公用模块.生成提交数据(static, "oper_login_info", "", "login" , 0, 0, 0, oper_login, oper_password);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", "");
	显示等待框();
	时钟1.开始执行(200,false);
}
function 显示提示消息(msg, model){
	if(model == true ){
		仔仔弹出对话框1.成功(msg);
	}else{
		仔仔弹出对话框1.错误(msg);
	}

}
function 显示等待框(){
	公用模块.showMask("页面遮罩");
	HPtools1.显示等待框("请稍等......");

}

function 关闭等待框(){

	公用模块.hideMask("页面遮罩");
	HPtools1.关闭等待框();
}

function 显示注册遮罩及等待框(){
	公用模块.在指定元素上创建遮罩及等待框("register","正在加载");
}

function 关闭注册遮罩及等待框(){
	公用模块.在指定元素上移除遮罩及等待框("register");
}