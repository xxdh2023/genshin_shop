mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,导航栏1_项目被双击,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var CYS超级列表框1 = new CYS超级列表框("CYS超级列表框1",null,CYS超级列表框1_按钮被单击);
var 标签1 = new 标签("标签1",null);
var 高级列表框_申请 = new 高级列表框("高级列表框_申请",true,true,false,高级列表框_申请_表项被单击);
var 标签2 = new 标签("标签2",null);
var 按钮组_日志 = new 按钮组("按钮组_日志",按钮组_日志_被单击);
var CYS时钟轴1 = new CYS时钟轴("CYS时钟轴1",null);
var div_rebate_popover = new 弹出面板("div_rebate_popover",null,null);
var div_rebate_lable_1 = new 标签("div_rebate_lable_1",null);
var div_rebate_realname = new 编辑框("div_rebate_realname",null,null,null,null,null);
var div_rebate_dropbox = new 下拉框("div_rebate_dropbox",div_rebate_dropbox_表项被单击);
var div_rebate_lable_2 = new 标签("div_rebate_lable_2",null);
var div_rebate_account = new 编辑框("div_rebate_account",null,null,null,null,null);
var div_rebate_btn = new 按钮("div_rebate_btn",div_rebate_btn_被单击,null,null);
var div_rebate_lable_3 = new 标签("div_rebate_lable_3",null);
var div_rebate_lable_4 = new 标签("div_rebate_lable_4",null);
var div_rebate_pic = new 图片框("div_rebate_pic",div_rebate_pic_被单击);
var div_rebate_pic_base64 = new 标签("div_rebate_pic_base64",null);
var div_cash_popover = new 弹出面板("div_cash_popover",null,null);
var div_cash_lable = new 标签("div_cash_lable",null);
var div_cash_edit = new 编辑框("div_cash_edit",null,null,div_cash_edit_内容被改变,null,null);
var div_cash_show = new 标签("div_cash_show",null);
var div_cash_btn = new 按钮("div_cash_btn",div_cash_btn_被单击,null,null);
var 文件选择器1 = new 文件选择器("文件选择器1",文件选择器1_选择完毕,文件选择器1_读入完毕,null);
if(mui.os.plus){
    mui.plusReady(function() {
        提现_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        提现_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 已初始化导航栏= false;
var m_menu= {}
var m_tabs= [];
var 导航索引= -1;
var 集_参数={}
var rebate_model= 0;
var iskb= false;

function 提现_创建完毕(){
	根地址 = HPtools1.取URL();
	标题栏美化1.去标题栏阴影();
	div_rebate_dropbox.清空项目();
	div_rebate_dropbox.添加项目("支付宝","0");
	div_rebate_dropbox.添加项目("微信","1");
	div_rebate_dropbox.置现行选中项(0);
	弹出面板初始化();
	func_iskb();
	m_post = 公用模块.生成提交数据(0, "cash", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/agent/cash", m_token);
	美化等待框1.默认等待框("正在交互","正在获取参数,请稍等......");
	时钟1.开始执行(200,false);
}
function 导航栏初始化(){
	if(已初始化导航栏 == false ){
		导航索引 = 公用模块.导航栏初始化(导航栏1,m_menu, "cash");


		已初始化导航栏 = true;
	}
}
function 导航栏1_项目被单击(项目标题,目标名称){
	if(目标名称 == 公用模块.导航栏项目数组(m_menu)[导航索引] ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(目标名称+".html","");
	}
}
function 导航栏1_项目被双击(项目标题,目标名称){
	窗口操作.滚动到顶部();
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_rebate_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_rebate_popover.添加组件("div_rebate_lable_1");
	div_rebate_popover.添加组件("div_rebate_realname");
	div_rebate_popover.添加组件("div_rebate_dropbox");
	div_rebate_popover.添加组件("div_rebate_lable_2");
	div_rebate_popover.添加组件("div_rebate_account");
	div_rebate_popover.添加组件("div_rebate_btn");
	div_rebate_popover.添加组件("div_rebate_lable_3");
	div_rebate_popover.添加组件("div_rebate_lable_4");
	div_rebate_popover.添加组件("div_rebate_pic");
	var rect = 公用模块.弹出面板初始化计算(50, 240, false);
	div_cash_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_cash_popover.添加组件("div_cash_lable");
	div_cash_popover.添加组件("div_cash_edit");
	div_cash_popover.添加组件("div_cash_show");
	div_cash_popover.添加组件("div_cash_btn");
}
function func_iskb(){
	if(iskb == false ){
		return;
	}
	div_rebate_lable_1.置标题("提现设置：<br>充币网络：");
	div_rebate_lable_2.置标题("充币地址：");
	div_rebate_dropbox.置可视(false);
	div_rebate_account.置提示内容("请输入数字钱包地址");
	div_rebate_dropbox.清空项目();
	div_rebate_dropbox.添加项目("USDT","0");
	div_rebate_dropbox.添加项目("USDT","1");
	div_rebate_dropbox.置现行选中项(0);
	div_rebate_realname.置内容("USDT-TRC20");
	div_rebate_realname.置只读模式(true);
	div_rebate_lable_3.置可视(false);
	div_rebate_lable_4.置可视(false);
	div_rebate_pic.置可视(false);
}

function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			if(json.table == "cash" && json.model == "cash" ){
				div_rebate_realname.置内容(集_参数.results.rebate_realname);
				div_rebate_account.置内容(集_参数.results.rebate_account);
				if(集_参数.results.rebate_pic == "" ){
					div_rebate_pic.置图片("images/setpic.jpg");
				}else{
					div_rebate_pic.置图片(集_参数.results.rebate_pic);
				}



				if(iskb == true ){
					div_rebate_realname.置内容("USDT-TRC20");
				}
				div_rebate_popover.显示();
				仔仔弹出对话框1.错误(json.msg);
			}else{
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
			}
		}else if(json.static == 0 ){
			if(json.table == "cash" && json.model == "select" ){
				m_menu = json.menu;
				导航栏初始化();
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "cash" && json.model == "update" ){
				div_rebate_popover.隐藏();
				m_post = 公用模块.生成提交数据(0, "cash", "", "select" , 0, 0);
				m_url = 公用模块.生成访问链接(根地址,"api/agent/cash", m_token);
				美化等待框1.默认等待框("正在交互","正在获取参数,请稍等......");
				时钟1.开始执行(200,false);
				仔仔弹出对话框1.成功("设置成功");
			}else if(json.table == "cash" && json.model == "cash" ){
				div_cash_popover.隐藏();
				m_post = 公用模块.生成提交数据(0, "cash", "", "select" , 0, 0);
				m_url = 公用模块.生成访问链接(根地址,"api/agent/cash", m_token);
				美化等待框1.默认等待框("正在交互","正在获取参数,请稍等......");
				时钟1.开始执行(200,false);
				仔仔弹出对话框1.成功("已成功发起提现申请");
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "cash" && json.model == "select" ){
				集_参数 = json;
				rebate_model = json.results.rebate_model;
				if(转换操作.到数值(json.results.only_usdt) < 1 ){
					iskb = false;
				}else{
					iskb = true;
				}
				func_iskb();
				div_rebate_dropbox.置现行选中项(rebate_model);
				CYS超级列表框1.清空项目();
				CYS超级列表框1.添加项目("剩余的平台币数量："+转换操作.到文本(json.results.coin_sum_all),"",0,"","");
				CYS超级列表框1.添加项目("可提现平台币数量："+转换操作.到文本(json.results.coin_sum_ava),"",0,"","");
				CYS超级列表框1.添加项目("冻结中平台币数量："+转换操作.到文本(json.results.coin_sum_freeze),"",0,"","");
				CYS超级列表框1.添加项目("已提现平台币数量："+转换操作.到文本(json.results.coin_all - json.results.coin_sum_all),"",0,"","");
				if(json.results.rebate < 1 ){
					CYS超级列表框1.添加项目("当前暂停提现","",0,"","");
				}else{
					CYS超级列表框1.添加项目("正常可提现","申请提现",4,"mui-btn-green","cash");
					CYS超级列表框1.添加项目("","提现结算设置",4,"mui-btn-green","rebate");
					if(json.results.rebate_min <= 0 ){
						CYS超级列表框1.添加项目("无最低提现金额限制","",0,"","");
					}else{
						CYS超级列表框1.添加项目("最低提现金额："+转换操作.到文本(json.results.rebate_min)+" RMB,对应平台币："+转换操作.到文本(json.results.rebate_min * 转换操作.到数值(json.results.invest_scale)),"",0,"","");
					}
					if(json.results.commission <= 0 ){
						CYS超级列表框1.添加项目("无需提现手续费","",0,"","");
					}else{
						CYS超级列表框1.添加项目("提现手续费："+转换操作.到文本(json.results.commission*100)+"%","",0,"","");
					}
					if(json.results.commission_min <= 0 ){
						CYS超级列表框1.添加项目("无最低手续费要求","",0,"","");
					}else{
						CYS超级列表框1.添加项目("最低要收取的手续费："+转换操作.到文本(json.results.commission_min)+" RMB,对应平台币："+转换操作.到文本(json.results.commission_min * 转换操作.到数值(json.results.invest_scale)),"",0,"","");
					}
				}

				高级列表框_申请.清空项目();
				CYS时钟轴1.清空项目();
				if(json.results.inout.length < 1 ){
					标签1.置可视(false);
				}else{
					标签1.置可视(true);
					while(i < json.results.inout.length){
						高级列表框_申请.添加项目2("","申请时间："+json.results.inout[i].inout_create,json.results.inout[i].inout_note,"");
						i++
					}
				}
				m_menu = json.menu;
				导航栏初始化();
			}else if(json.table == "cash" && json.model == "inout-log" ){
			var num= 转换操作.到数值(json.msg);
			var str= "";
			while(i < json.results.length){
				if(num < 1 ){
					CYS时钟轴1.添加项目("返佣收益日志",json.results[i].inout_note,json.results[i].inout_create,"");
				}else{
					if(json.results[i].inout_flow < 0 ){
						str = "申请被驳回,驳回原因：";
						if(json.results[i].fail_note == "" ){
							str = str + "无.";
						}else{
							str = str + json.results[i].fail_note;
						}
					}else if(json.results[i].inout_flow == 0 ){
						str = "审核中";
					}else{
						str = "审核通过";
					}
					CYS时钟轴1.添加项目("返佣提现日志",json.results[i].inout_note,json.results[i].inout_create+" , "+str,"");
				}
				i++
			}





			}

		}
	}
}

function 按钮组_日志_被单击(按钮索引){
	CYS时钟轴1.清空项目();
	m_post = 公用模块.生成提交数据(0, "cash", "", "inout-log" , 按钮索引, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/agent/cash", m_token);
	美化等待框1.默认等待框("正在交互","正在查询日志,请稍等......");
	时钟1.开始执行(200,false);
}
function CYS超级列表框1_按钮被单击(项目索引){
	var 标记= CYS超级列表框1.取项目标记(项目索引);
	if(标记 == "cash" ){
		div_cash_popover.显示();
		div_cash_edit.置内容("");
		div_cash_show.置标题("<br>本次提现的金额：<br><br>本次扣除手续费：<br><br>实际提现的金额：");
	}
	if(标记 == "rebate" ){
		div_rebate_realname.置内容(集_参数.results.rebate_realname);
		div_rebate_account.置内容(集_参数.results.rebate_account);
		div_rebate_dropbox.置现行选中项(集_参数.results.rebate_model);
		rebate_model = 集_参数.results.rebate_model;
		if(iskb == false ){
			if(集_参数.results.rebate_pic == "" ){
				div_rebate_pic.置图片("images/setpic.jpg");
			}else{
				div_rebate_pic.置图片(集_参数.results.rebate_pic);
			}
		}else{
			div_rebate_pic.置图片("images/setpic.jpg");
			div_rebate_pic_base64.置标题(默认图片());
			div_rebate_realname.置内容("USDT-TRC20");
		}



		div_rebate_popover.显示();
	}
}
function div_rebate_dropbox_表项被单击(项目索引,项目标题,项目标记){
	rebate_model = 转换操作.到数值(项目标记);
}
function div_rebate_pic_被单击(){



	文件选择器1.限制类型("image/jpeg,image/png,image/bmp");
	文件选择器1.开始选择();
}
function 文件选择器1_选择完毕(文件路径,文件对象){
	文件选择器1.读入文件(文件对象,2);
}
function 文件选择器1_读入完毕(结果,内容){
	div_rebate_pic.置图片(内容);
	var data= "";
	var i= 文本操作.倒找文本(内容,",");
	if(i > -1 ){
		data = 文本操作.取文本右边(内容,文本操作.取文本长度(内容) - i - 1);
	}else{
		data = 内容;
	}
	div_rebate_pic_base64.置标题(data);
}
function div_rebate_btn_被单击(){
	div_rebate_realname.置内容(文本操作.删首尾空(div_rebate_realname.取内容()));
	if(div_rebate_realname.取内容() == "" ){
		if(iskb == false ){
			仔仔弹出对话框1.错误("请填写真实姓名");
		}
		return;
	}
	div_rebate_account.置内容(文本操作.删首尾空(div_rebate_account.取内容()));
	if(div_rebate_account.取内容() == "" ){
		if(iskb == false ){
			仔仔弹出对话框1.错误("请填写支付宝/微信账号");
		}else{
			仔仔弹出对话框1.错误("请填写数字钱包地址");
		}
		return;
	}
	if(div_rebate_pic_base64.取标题() == "" && iskb == false ){
		仔仔弹出对话框1.错误("请选择新的收款二维码");
		return;
	}
	var json= {}
	if(iskb == false ){
		json.rebate_realname = div_rebate_realname.取内容();
	}else{
		json.rebate_realname = "USDT-TRC20";
	}
	json.rebate_model = rebate_model;
	json.rebate_account = div_rebate_account.取内容();
	json.rebate_pic = div_rebate_pic_base64.取标题();
	m_post = 公用模块.生成提交数据(0, "cash", "", "update" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/agent/cash", m_token);
	美化等待框1.默认等待框("正在交互","正在设置,请稍等......");
	时钟1.开始执行(200,false);
}
function div_cash_edit_内容被改变(内容){
	var coin= 数学操作.四舍五入(转换操作.到数值(内容), 2);
	var 提现金额= 数学操作.四舍五入(coin / 转换操作.到数值(集_参数.results.invest_scale), 2);
	var 手续费= 数学操作.四舍五入(提现金额 * 集_参数.results.commission, 2);
	if(手续费 < 集_参数.results.commission_min ){
		手续费 = 数学操作.四舍五入(集_参数.results.commission_min, 2);
	}
	div_cash_show.置标题("<br>本次提现的金额："+转换操作.到文本(提现金额)+"元<br><br>本次扣除手续费："+转换操作.到文本(手续费)+"元<br><br>实际提现的金额："+转换操作.到文本(提现金额-手续费)+"元");
}
function div_cash_btn_被单击(){
	div_cash_edit.置内容(文本操作.删首尾空(div_cash_edit.取内容()));
	if(div_cash_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入要提现的平台币数量");
		return;
	}
	var cash= 数学操作.四舍五入(转换操作.到数值(div_cash_edit.取内容()), 2);
	if(cash > 集_参数.results.coin_sum_ava ){
		仔仔弹出对话框1.错误("您没有足够的平台币");
		return;
	}
	if(cash < 集_参数.results.commission_min * 转换操作.到数值(集_参数.results.invest_scale) ){
		仔仔弹出对话框1.错误("不能低于最低提现要求");
		return;
	}
	var json= {}
	json.cash = cash;
	m_post = 公用模块.生成提交数据(0, "cash", "", "cash" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/agent/cash", m_token);
	美化等待框1.默认等待框("正在交互","正在申请提现,请稍等......");
	时钟1.开始执行(200,false);
}
function 高级列表框_申请_表项被单击(项目索引,项目图片,项目标题,项目信息,项目标记){
	HPtools1.信息框(项目信息);
}
function 默认图片(){

	return "usdt";
}