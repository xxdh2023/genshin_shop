mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签1 = new 标签("标签1",null);
var 标签2 = new 标签("标签2",null);
var 标签12 = new 标签("标签12",null);
var 标签29 = new 标签("标签29",null);
var 标签3 = new 标签("标签3",null);
var 标签4 = new 标签("标签4",null);
var 标签5 = new 标签("标签5",null);
var 标签6 = new 标签("标签6",null);
var 标签7 = new 标签("标签7",null);
var 标签8 = new 标签("标签8",null);
var 标签28 = new 标签("标签28",null);
var 标签9 = new 标签("标签9",null);
var 面板1 = new 面板("面板1");
var 标签10 = new 标签("标签10",null);
var 标签11 = new 标签("标签11",null);
var 面板2 = new 面板("面板2");
var 编辑框_定制价格 = new 编辑框("编辑框_定制价格",null,null,null,null,null);
var 编辑框_限购数量 = new 编辑框("编辑框_限购数量",null,null,null,null,null);
var 面板4 = new 面板("面板4");
var 标签14 = new 标签("标签14",null);
var 标签15 = new 标签("标签15",null);
var 面板5 = new 面板("面板5");
var 下拉框_等级 = new 下拉框("下拉框_等级",null);
var 编辑框_副词条数量 = new 编辑框("编辑框_副词条数量",null,null,null,null,null);
var 面板3 = new 面板("面板3");
var 下拉框_开关 = new 下拉框("下拉框_开关",null);
var 按钮_保存 = new 按钮("按钮_保存",按钮_保存_被单击,null,null);
var 标签13 = new 标签("标签13",null);
var 标签30 = new 标签("标签30",null);
var 标签16 = new 标签("标签16",null);
var 标签17 = new 标签("标签17",null);
var 标签19 = new 标签("标签19",null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 标签20 = new 标签("标签20",null);
var 下拉框_加价_等级 = new 下拉框("下拉框_加价_等级",null);
var 面板6 = new 面板("面板6");
var 标签21 = new 标签("标签21",null);
var 标签22 = new 标签("标签22",null);
var 面板7 = new 面板("面板7");
var 下拉框_加价_上线 = new 下拉框("下拉框_加价_上线",null);
var 编辑框_加价_金额 = new 编辑框("编辑框_加价_金额",null,null,null,null,null);
var 按钮_加价 = new 按钮("按钮_加价",按钮_加价_被单击,null,null);
var 标签24 = new 标签("标签24",null);
var 标签25 = new 标签("标签25",null);
var 标签26 = new 标签("标签26",null);
var 标签27 = new 标签("标签27",null);
var 标签23 = new 标签("标签23",null);
var 标签18 = new 标签("标签18",null);
var 特定修复1 = new 特定修复("特定修复1");
if(mui.os.plus){
    mui.plusReady(function() {
        定制设置_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        定制设置_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var m_ID = 0;






function 定制设置_创建完毕(){
	根地址 = HPtools1.取URL();
	界面初始化();
	弹出面板初始化();
	高级表格初始化();
	刷新档案();
}

function 界面初始化(){
	面板1.添加组件("标签10", "200px");
	面板1.添加组件("标签11", "200px");
	面板2.添加组件("编辑框_定制价格", "200px");
	面板2.添加组件("编辑框_限购数量", "200px");
	面板3.添加组件(特定修复1.下拉框("下拉框_开关"), "200px");
	面板3.添加组件("按钮_保存", "200px");
	面板4.添加组件("标签14", "200px");
	面板4.添加组件("标签15", "200px");
	面板5.添加组件(特定修复1.下拉框("下拉框_等级"), "200px");
	面板5.添加组件("编辑框_副词条数量", "200px");
	var i=0;
	下拉框_等级.清空项目();
	下拉框_加价_等级.清空项目();
	下拉框_加价_等级.添加项目("请选择等级...");
	下拉框_加价_等级.置现行选中项(0);
	while(i<20){
		下拉框_等级.添加项目("最高"+String(i+1)+"级");
		下拉框_加价_等级.添加项目("从"+String(i+1)+"级开始");
		i++
	}
	下拉框_等级.置现行选中项(19);
	编辑框_副词条数量.置内容("4");
	下拉框_开关.添加项目("关闭定制圣遗物");
	下拉框_开关.添加项目("开启定制圣遗物");
	下拉框_开关.置现行选中项(0);
}

function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	弹出面板1.添加组件("标签20");
	弹出面板1.添加组件("下拉框_加价_等级");
	弹出面板1.添加组件("面板6");
	面板6.添加组件("标签21", "1");
	面板6.添加组件("标签22", "1");
	弹出面板1.添加组件("面板7");
	面板7.添加组件(特定修复1.下拉框("下拉框_加价_上线"),"1");
	面板7.添加组件("编辑框_加价_金额", "1");
	下拉框_加价_上线.清空项目();
	下拉框_加价_上线.添加项目("下线");
	下拉框_加价_上线.添加项目("上线");
	下拉框_加价_上线.置现行选中项(0);
	弹出面板1.添加组件("编辑框_加价_金额");
	弹出面板1.添加组件("按钮_加价");
	弹出面板1.添加组件("标签24");
	弹出面板1.添加组件("标签25");
	弹出面板1.添加组件("标签26");
	弹出面板1.添加组件("标签27");
	弹出面板1.添加组件("标签23");

}

function 高级表格初始化(){
	高级表格1.添加列("xz","",40,true,false,false,true,false,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",120,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("level_id","开始加价等级",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("level_static","上线状态",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("level_amount","额外加价",240,false,true,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"添加");
	高级表格1.添加工具栏按钮(2,false,"刷新列表");

	高级表格1.初始化("auto",true,true,false,true);
}

function 刷新档案(){
	m_post = 公用模块.生成提交数据(0, "system_info_artifact", "", "" ,0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 刷新列表(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	m_post = 公用模块.生成提交数据(0, "artifact_info_level", "", "" ,0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);

}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "artifact_info_level" ){
				仔仔弹出对话框1.错误("等级加价管理：" + json.msg);
				return;
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "artifact_info_level" ){
				弹出面板1.隐藏();
				仔仔弹出对话框1.成功("等级加价管理：" + json.msg);
				刷新列表();
				return;
			}

			if(json.table == "artifact_info_level_one" ){
				下拉框_加价_等级.置现行选中项(json.result.level_id);
				下拉框_加价_上线.置现行选中项(json.result.level_static);
				编辑框_加价_金额.置内容(""+json.result.level_amount);
				弹出面板1.滚动条到顶部();
				弹出面板1.显示();
				return;
			}

			仔仔弹出对话框1.成功("保存成功！");
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "system_info_artifact" ){
				编辑框_定制价格.置内容(""+json.result.artifact_amount);
				编辑框_限购数量.置内容(""+json.result.artifact_limit);
				下拉框_开关.置现行选中项(json.result.artifact_static);
				下拉框_等级.置现行选中项(json.result.artifact_max_level - 1);
				编辑框_副词条数量.置内容(""+json.result.artifact_sub_num);
				刷新列表();
			}else if(json.table == "artifact_info_level" ){
				高级表格1.清空行();
				var 行数据 = [];
				while(i < json.results.length){
					行数据[0] = "";
					行数据[1] = json.results[i].ID;
					行数据[2] = "编辑";
					行数据[3] = ""+json.results[i].level_id;
					行数据[4] = "已上线";
					if(json.results[i].level_static < 1 ){
						行数据[4] = "已下线";
					}
					行数据[5] = "不加价";
					if(json.results[i].level_amount > 0 ){
						行数据[5] = "加价："+String(json.results[i].level_amount)+"平台币";
					}
					高级表格1.添加行(true, 行数据);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(2,false,"编辑");
				高级表格1.添加操作栏按钮(4,false,"删除");
				高级表格1.初始化("auto",true,true,false,true);


			}

		}
	}
}
function 按钮_保存_被单击(){
	编辑框_定制价格.置内容(文本操作.删首尾空(编辑框_定制价格.取内容()));
	if(编辑框_定制价格.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入：基础定制价格！");
		return;
	}
	var artifact_amount = 转换操作.到数值(编辑框_定制价格.取内容());
	if(artifact_amount <= 0 ){
		仔仔弹出对话框1.错误("基础定制价格必须大于0！");
		return;
	}
	编辑框_限购数量.置内容(文本操作.删首尾空(编辑框_限购数量.取内容()));
	if(编辑框_限购数量.取内容() == "" ){
		编辑框_限购数量.置内容("0");
	}
	artifact_limit = 数学操作.取整数(转换操作.到数值(编辑框_限购数量.取内容()));
	if(artifact_limit < 0 ){
		artifact_limit = 0;
		编辑框_限购数量.置内容("0");
	}

	var artifact_max_level = 下拉框_等级.取现行选中项() + 1;
	编辑框_副词条数量.置内容(文本操作.删首尾空(编辑框_副词条数量.取内容()));
	if(编辑框_副词条数量.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入：副词条数量！");
		return;
	}
	var artifact_sub_num = 数学操作.取整数(转换操作.到数值(编辑框_副词条数量.取内容()));
	if(artifact_sub_num < 1 ){
		仔仔弹出对话框1.错误("副词条数量必须大于0！");
		return;
	}

	var msg = "请确认：\n";
	if(下拉框_开关.取现行选中项() < 1 ){
		msg = msg + "关闭定制圣遗物";
	}else{
		msg = msg + "开启定制圣遗物";
	}
	if(artifact_limit < 1 ){
		msg = msg + "\n\n总限购数量：不限购";
	}else{
		msg = msg + "\n\n总限购数量："+String(artifact_limit)+"件";
	}
	msg = msg + "\n\n基础定制价格：" + String(artifact_amount)+"平台币";
	msg = msg + "\n\n最高等级：" + String(artifact_max_level);
	msg = msg + "\n\n副词条数量：" + String(artifact_sub_num);


	if(HPtools1.询问框(msg) == false ){
		return;
	}
	var json = {"artifact_static": 下拉框_开关.取现行选中项(), "artifact_limit": artifact_limit, "artifact_amount": artifact_amount}
	json.artifact_max_level = artifact_max_level;
	json.artifact_sub_num = artifact_sub_num;
	m_post = 公用模块.生成提交数据(0, "system_info_artifact", "", "" ,0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/update", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);

}

function 新增操作(){
	下拉框_加价_等级.置现行选中项(0);
	编辑框_加价_金额.置内容("");
	弹出面板1.滚动条到顶部();
	下拉框_加价_上线.置现行选中项(1);
}
function 高级表格1_工具栏按钮被单击(按钮索引){
	if(按钮索引 < 1 ){
		m_ID = 0;
		新增操作();
		弹出面板1.显示();
		return;
	}
	if(按钮索引 == 1 ){
		刷新列表();
	}
}
function 按钮_加价_被单击(){
	if(下拉框_加价_等级.取现行选中项() < 1 ){
		仔仔弹出对话框1.错误("请选择：开始加价的等级");
		return;
	}

	编辑框_加价_金额.置内容(文本操作.删首尾空(编辑框_加价_金额.取内容()));
	if(编辑框_加价_金额.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写：额外加价");
		return;
	}

	var amount = 转换操作.到数值(编辑框_加价_金额.取内容());
	if(amount <= 0 ){
		仔仔弹出对话框1.错误("额外加价必须大于0！");
		return;
	}

	var json = {"level_id": 下拉框_加价_等级.取现行选中项(), "status": 下拉框_加价_上线.取现行选中项(), "amount": amount}
	m_post = 公用模块.生成提交数据(m_ID, "artifact_info_level", "", "" , 0, 0, json);
	if(m_ID < 1 ){
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/insert", m_password);
	}else{
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/update", m_password);
	}

	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);


}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	if(按钮索引 < 1 ){
		m_ID = 数学操作.取整数(转换操作.到数值(行数据["id"]));
		if(m_ID < 0 ){
			m_ID = 0;
		}
		新增操作();
		m_post = 公用模块.生成提交数据(m_ID, "artifact_info_level_one", "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/select", m_password);
		美化等待框1.默认等待框("正在交互","请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}else{
		var msg = "是否删除？";
		if(HPtools1.询问框(msg) == false ){
			return;
		}
		m_post = 公用模块.生成提交数据(行数据["id"], "artifact_info_level", "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin48/delete", m_password);
		美化等待框1.默认等待框("正在交互","请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);


	}
}