    function 特定修复(name,event){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 特定修复(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;
        
        //组件命令：
        this.下拉框 = function (select_name){	
            const child = document.getElementById(select_name);//获取组件元素
            const parent = child.parentNode;//获取组件的父元素
            const title = select_name + "_div";
            parent.id = title;
            return title;
        } 
}