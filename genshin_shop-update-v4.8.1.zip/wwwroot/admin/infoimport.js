mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签1 = new 标签("标签1",null);
var 标签2 = new 标签("标签2",null);
var 编辑框1 = new 编辑框("编辑框1",null,null,null,null,null);
var 标签3 = new 标签("标签3",null);
var 编辑框2 = new 编辑框("编辑框2",null,null,null,null,null);
var 标签4 = new 标签("标签4",null);
var 按钮组1 = new 按钮组("按钮组1",按钮组1_被单击);
var 图片框1 = new 图片框("图片框1",null);
if(mui.os.plus){
    mui.plusReady(function() {
        批量导入_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        批量导入_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var m_model= 0;
var m_item_id= "";
var m_table= "";



function 批量导入_创建完毕(){
	m_item_id = 文本操作.删首尾空(窗口操作.取当前页面参数("item_id"));
	m_table = 文本操作.删首尾空(窗口操作.取当前页面参数("table"));
	if(m_item_id == "" || m_table == "" ){
		仔仔弹出对话框1.错误("调用异常,请关闭本页面！");
		return;
	}
	根地址 = HPtools1.取URL();
	按钮组1.置样式(0,"mui-btn mui-btn-danger");
	导入信息判断();
}
function 导入信息判断(){
	var str= "您当前要导入的是：";
	var pic= "";
	if(m_table == "item_script_info_detail" ){
		str = str + "GM脚本的明细列表,GM脚本的编码为：";
		pic = "images/test_detail.png";
	}else if(m_table == "item_sign_info_detail" ){
		str = str + "签到奖励的明细列表,签到奖励的编码为：";
		pic = "images/test_detail_sign.png";
	}else if(m_table == "shop_mall_info_detail" ){
		str = str + "商品的明细列表,商品的SKU为：";
		pic = "images/test_detail.png";
	}else if(m_table == "lottery_draw_info_detail" ){
		str = str + "抽奖的奖品明细列表,抽奖的SKU为：";
		pic = "images/test_detail_lottery.png";
	}else if(m_table == "lottery_draw_info_random" ){
		str = str + "抽奖的随机福利池列表,抽奖的SKU为：";
		pic = "images/test_detail.png";
	}else if(m_table == "vip_grade_info_welfare" ){
		str = str + "VIP等级简易模式下的明细列表,VIP等级编码为：";
		pic = "images/test_detail.png";
	}else if(m_table == "vip_grade_info_benefits_detail" ){
		str = str + "VIP等级自定义模式下的福利明细列表,VIP等级编码为：";
		pic = "images/test_detail_vip.png";


	}
	str = str + m_item_id;
	图片框1.置图片(pic);
	标签1.置标题(str);
	按钮组1.置可视(true);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功("已导入成功！备注：导入时会自动跳过格式不对的文本行");
		}else if(json.static == 2 ){
			var i= 0;





		}
	}
}


function 按钮组1_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否清空内容？") == true ){
				m_model = 0;
				编辑框1.置内容("");
			}
		break;
		case 1 :
			编辑框1.置内容(文本操作.删首尾空(编辑框1.取内容()));
			if(编辑框1.取内容() == "" ){
				仔仔弹出对话框1.错误("请粘贴要导入的文本");
				return;
			}
			if(编辑框2.取内容() == "" ){
				仔仔弹出对话框1.错误("请输入分隔符");
				return;
			}
			if(HPtools1.询问框("是否导入？注意！不校验是否重复,不校验是否正确！") == false ){
				return;
			}
			var json= {}
			var txt= 加密操作1.base64加密(编辑框1.取内容());
			txt = ""+txt;
			json.txt = txt;
			json.sep = 编辑框2.取内容();
			json.item_id = m_item_id;
			m_post = 公用模块.生成提交数据(0, m_table, "", "" , 1, 0,json);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/import", m_password);
			美化等待框1.默认等待框("正在交互","正在导入,请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
		break;
	}
}