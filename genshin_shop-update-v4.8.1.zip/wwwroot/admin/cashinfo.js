mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签2 = new 标签("标签2",null);
var 面板1 = new 面板("面板1");
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 标签3 = new 标签("标签3",null);
var 面板2 = new 面板("面板2");
var div_inout_flow_2_ = new 单选框("div_inout_flow_2_",div_inout_flow_2__被单击);
var div_div_inout_flow_1_ = new 单选框("div_div_inout_flow_1_",div_div_inout_flow_1__被单击);
var div_inout_flow_0 = new 单选框("div_inout_flow_0",div_inout_flow_0_被单击);
var div_inout_flow_1 = new 单选框("div_inout_flow_1",div_inout_flow_1_被单击);
var 高级表格1 = new 高级表格("高级表格1",null,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var div_fail_popover = new 弹出面板("div_fail_popover",null,null);
var div_fail_lable = new 标签("div_fail_lable",null);
var div_fail_note = new 编辑框("div_fail_note",null,null,null,null,null);
var div_fail_btn = new 按钮("div_fail_btn",div_fail_btn_被单击,null,null);
var div_rebate_popover = new 弹出面板("div_rebate_popover",null,null);
var div_rebate_lable_1 = new 标签("div_rebate_lable_1",null);
var div_rebate_realname = new 编辑框("div_rebate_realname",null,null,null,null,null);
var div_rebate_model = new 标签("div_rebate_model",null);
var div_rebate_lable_2 = new 标签("div_rebate_lable_2",null);
var div_rebate_account = new 编辑框("div_rebate_account",null,null,null,null,null);
var div_rebate_lable_3 = new 标签("div_rebate_lable_3",null);
var div_rebate_pic = new 图片框("div_rebate_pic",null);
if(mui.os.plus){
    mui.plusReady(function() {
        提现管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        提现管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var inout_flow= -2;
var cash_id= 0;


function 提现管理_创建完毕(){
	根地址 = HPtools1.取URL();
	调整组件尺寸();
	高级表格初始化();
	div_inout_flow_2_.置选中状态(true);
	查询数据();
}
function 调整组件尺寸(){
	面板1.添加组件("自由面板_编辑框_条件", "240px");
	面板1.添加组件("自由面板_按钮_查询", "120px");

	面板2.添加组件("div_inout_flow_2_", "110px");
	面板2.添加组件("div_div_inout_flow_1_", "130px");
	面板2.添加组件("div_inout_flow_0", "130px");
	面板2.添加组件("div_inout_flow_1", "130px");
	var rect = 公用模块.弹出面板初始化计算(50, 140, false);
	div_fail_popover.初始化(rect[0], rect[1], rect[2], rect[3]);
	div_fail_popover.添加组件("div_fail_lable");
	div_fail_popover.添加组件("div_fail_note");
	div_fail_popover.添加组件("div_fail_btn");
	var rect = 公用模块.弹出面板初始化计算(50, 80,true);
	div_rebate_popover.初始化(rect[0], rect[1], rect[2], rect[3]);
	div_rebate_popover.添加组件("div_rebate_lable_1");
	div_rebate_popover.添加组件("div_rebate_realname");
	div_rebate_popover.添加组件("div_rebate_model");
	div_rebate_popover.添加组件("div_rebate_lable_2");
	div_rebate_popover.添加组件("div_rebate_account");
	div_rebate_popover.添加组件("div_rebate_lable_3");
	div_rebate_popover.添加组件("div_rebate_pic");
	div_rebate_realname.置只读模式(true);
	div_rebate_account.置只读模式(true);
}

function 高级表格初始化(){
	高级表格1.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",220,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("inout_flow","状态",100,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper","申请账号",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_create","申请时间",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_amount_real","实际发放RMB",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_commission","手续费",80,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_amount","申请提现金额",120,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_end","审核时间",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_note","备注",300,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("inout_no","账单号",100,false,false,false,false,false,false,"",false,false);




	高级表格1.初始化("auto",true,true,false,true);
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "inout_info_cash" && json.model == "reject" ){
				div_fail_popover.隐藏();
				仔仔弹出对话框1.错误(json.msg);
			}else{
				仔仔弹出对话框1.错误(json.msg);
			}
		}else if(json.static == 1 ){
			if(json.table == "inout_info_cash" ){
				if(json.model == "reject" ){
					div_fail_popover.隐藏();
					仔仔弹出对话框1.成功("驳回成功,请重新查询");
				}else if(json.model == "pass" ){
					仔仔弹出对话框1.成功("审核通过,请重新查询");
				}else if(json.model == "rebate" ){
					div_rebate_realname.置内容(json.results.rebate_realname);
					if(json.results.rebate_model < 1 ){
						div_rebate_model.置标题("支付宝");
					}else{
						div_rebate_model.置标题("微信");
					}
					div_rebate_account.置内容(json.results.rebate_account);
					div_rebate_pic.置图片(json.results.rebate_pic);
					div_rebate_popover.显示();
				}
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "inout_info_cash" ){
				if(json.model != "insert" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "";
						arr[3] = "审核驳回";
						if(json.results[i].inout_flow == 0 ){
							arr[3] = "审核中";
						}else if(json.results[i].inout_flow == 1 ){
							arr[3] = "审核通过";
						}
						arr[4] = json.results[i].oper_login + "-" + json.results[i].oper_name;
						arr[5] = json.results[i].inout_create;
						arr[6] = json.results[i].inout_amount_real;
						arr[7] = json.results[i].inout_commission;
						arr[8] = json.results[i].inout_amount;
						arr[9] = "";
						if(json.results[i].inout_flow != 0 ){
							arr[9] = json.results[i].inout_end;
						}
						arr[10] = json.results[i].inout_note;
						arr[11] = json.results[i].inout_no;
						高级表格1.添加行(false,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(4,false,"驳回");
					高级表格1.添加操作栏按钮(2,false,"通过");
					高级表格1.添加操作栏按钮(1,false,"查看提现信息");
					高级表格1.初始化("auto",true,true,false,true);
				}else{

				}



			}




		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	m_post = 公用模块.生成提交数据(inout_flow, "inout_info_cash", value, "" , 1, 0);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}

function 按钮_底部_被单击(){
	m_post = 公用模块.生成提交数据(inout_flow, "inout_info_cash", value, "" , page+1, 0);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_inout_flow_2__被单击(){
	inout_flow = -2;
}
function div_div_inout_flow_1__被单击(){
	inout_flow = -1;
}
function div_inout_flow_0_被单击(){
	inout_flow = 0;
}
function div_inout_flow_1_被单击(){
	inout_flow = 1;
}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
		case 0 :
			cash_id = _id;
			div_fail_popover.显示();
		break;
		case 1 :
			if(HPtools1.询问框("是否审核通过当前提现申请？") == true ){
				m_post = 公用模块.生成提交数据(_id, "inout_info_cash", "", "pass" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/cash", m_password);
				美化等待框1.默认等待框("正在交互","正在审核请求,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}

		break;
		case 2 :
			m_post = 公用模块.生成提交数据(_id, "inout_info_cash", "", "rebate" , 0, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/cash", m_password);
			美化等待框1.默认等待框("正在交互","正在获取,请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
		break;
	}
}
function div_fail_btn_被单击(){
	if(cash_id < 1 ){
		仔仔弹出对话框1.错误("请操作有效的数据");
		return;
	}
	div_fail_note.置内容(文本操作.删首尾空(div_fail_note.取内容()));
	if(div_fail_note.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入驳回理由");
		return;
	}
	var json= {}
	json.ID = cash_id;
	json.inout_note = div_fail_note.取内容();
	m_post = 公用模块.生成提交数据(0, "inout_info_cash", "", "reject" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/cash", m_password);
	美化等待框1.默认等待框("正在交互","正在驳回请求,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}