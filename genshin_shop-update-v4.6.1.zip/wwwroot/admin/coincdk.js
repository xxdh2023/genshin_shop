mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 自由面板1 = new 自由面板("自由面板1","95px");
var 自由面板_标签 = new 标签("自由面板_标签",null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var 标签1 = new 标签("标签1",null);
var div_cdk_isuse_1_ = new 单选框("div_cdk_isuse_1_",div_cdk_isuse_1__被单击);
var div_cdk_isuse_0 = new 单选框("div_cdk_isuse_0",div_cdk_isuse_0_被单击);
var div_cdk_isuse_1 = new 单选框("div_cdk_isuse_1",div_cdk_isuse_1_被单击);
var div_cdk_popover = new 弹出面板("div_cdk_popover",null,null);
var div_cdk_lable = new 标签("div_cdk_lable",null);
var div_cdk_par = new 编辑框("div_cdk_par",null,null,null,null,null);
var div_cdk_num = new 编辑框("div_cdk_num",null,null,null,null,null);
var div_cdk_btns = new 按钮组("div_cdk_btns",div_cdk_btns_被单击);
var div_cdk_show = new 标签("div_cdk_show",null);
var div_cdk_proportion = new 编辑框("div_cdk_proportion",null,null,null,null,null);
var div_cdk_btn = new 按钮("div_cdk_btn",div_cdk_btn_被单击,null,null);
var div_cdk_next_popover = new 弹出面板("div_cdk_next_popover",null,null);
var div_cdk_next_lable = new 标签("div_cdk_next_lable",null);
var div_cdk_next_ids = new 编辑框("div_cdk_next_ids",null,null,null,null,null);
var div_cdk_next_btn = new 按钮("div_cdk_next_btn",div_cdk_next_btn_被单击,null,null);
var div_batch_del_popover = new 弹出面板("div_batch_del_popover",null,null);
var div_batch_del_label_1 = new 标签("div_batch_del_label_1",null);
var div_batch_del_date = new 按钮("div_batch_del_date",div_batch_del_date_被单击,null,null);
var div_batch_del_label_2 = new 标签("div_batch_del_label_2",null);
var div_batch_del_panel = new 面板("div_batch_del_panel");
var div_batch_del_isuse_0 = new 复选框("div_batch_del_isuse_0",null);
var div_batch_del_isuse_2 = new 复选框("div_batch_del_isuse_2",null);
var div_batch_del_label_3 = new 标签("div_batch_del_label_3",null);
var div_batch_del_btn = new 按钮("div_batch_del_btn",div_batch_del_btn_被单击,null,null);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
if(mui.os.plus){
    mui.plusReady(function() {
        平台币CDK_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        平台币CDK_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var cdk_isuse= -1;
var cdk_agent= 0;
function 平台币CDK_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password异常,请重新登陆！"),"");
		return;
	}
	根地址 = HPtools1.取URL();
	调整组件尺寸();
	高级表格初始化();
	div_cdk_isuse_1_.置选中状态(true);
	CYS日期时间选择器1.初始化(1, 2023, 2099);
	查询数据();
}
function 调整组件尺寸(){
	var width= 窗口操作.取窗口宽度();
	公用模块.自由面板_调整("自由面板_标签", 110, 100, 800,width);
	公用模块.自由面板_调整("自由面板_编辑框_条件", 214, 400, 800,width);
	公用模块.自由面板_调整("自由面板_按钮_查询", 622, 100, 800,width);

	var rect = 公用模块.弹出面板初始化计算(50, 300, false);
	div_cdk_popover.初始化(rect[0], rect[1], rect[2], rect[3]);
	div_cdk_popover.添加组件("div_cdk_lable");
	div_cdk_popover.添加组件("div_cdk_par");
	div_cdk_popover.添加组件("div_cdk_num");
	div_cdk_popover.添加组件("div_cdk_btns");
	div_cdk_popover.添加组件("div_cdk_show");
	div_cdk_popover.添加组件("div_cdk_proportion");
	div_cdk_popover.添加组件("div_cdk_btn");
	div_cdk_btns.置样式(0,"mui-btn mui-btn-primary");
	var rect = 公用模块.弹出面板初始化计算(50, 310, false);
	div_cdk_next_popover.初始化(rect[0], rect[1], rect[2], rect[3]);
	div_cdk_next_popover.添加组件("div_cdk_next_lable");
	div_cdk_next_popover.添加组件("div_cdk_next_ids");
	div_cdk_next_popover.添加组件("div_cdk_next_btn");

	var rect = 公用模块.弹出面板初始化计算(50, 260, false);
	div_batch_del_popover.初始化(rect[0], rect[1], rect[2], rect[3]);
	div_batch_del_popover.添加组件("div_batch_del_label_1");
	div_batch_del_popover.添加组件("div_batch_del_date");
	div_batch_del_popover.添加组件("div_batch_del_label_2");
	div_batch_del_panel.添加组件("div_batch_del_isuse_0", "1");
	div_batch_del_panel.添加组件("div_batch_del_isuse_2", "1");
	div_batch_del_popover.添加组件("div_batch_del_panel");
	div_batch_del_popover.添加组件("div_batch_del_label_3");
	div_batch_del_popover.添加组件("div_batch_del_btn");

}

function 高级表格初始化(){
	高级表格1.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",60,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("cdk_isuse","状态",80,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("cdk_id","CDK",300,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("cdk_agent","参与返佣",80,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("cdk_par","面值(RMB)",100,false,false,false,false,false,true,"面值(RMB)",false,false);
	高级表格1.添加列("cdk_proportion","冲赠比(绑定会员后才有效)",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("cdk_par_coin","兑换金额(平台币)",150,false,false,false,false,false,true,"兑换金额(平台币)",false,false);
	高级表格1.添加列("oper_login","兑换账号",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("create_time","生成时间",150,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("use_time","兑换时间",150,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"批量生成CDK");


	高级表格1.添加工具栏按钮(4,false,"批量删除");
	高级表格1.初始化("auto",true,true,true,true);
}


function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "cdk_info_coin" ){
				if(json.model == "delete" ){
					高级表格1.删除行(转换操作.到数值(json.comm));
					高级表格1.初始化("auto",true,true,true,true);
					仔仔弹出对话框1.成功("删除成功！");
				}else{

				}
			}else if(json.table == "cdk_info_coin_batch" ){
				div_batch_del_popover.隐藏();
				仔仔弹出对话框1.成功("批量删除成功,请重新查询！");

			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "cdk_info_coin" ){
				if(json.model != "insert" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "";
						var num = 3;
						arr[num] = "未使用";
						if(json.results[i].cdk_isuse == 1 ){
							arr[num] = "正在核销";
						}else if(json.results[i].cdk_isuse == 2 ){
							arr[num] = "已兑换";
						}
						num ++
						arr[num] = json.results[i].cdk_id;
						num ++
						arr[num] = "是";
						if(json.results[i].cdk_agent > 0 ){
							arr[num] = "否";
						}
						num ++
						arr[num] = json.results[i].cdk_par;
						num ++
						arr[num] = json.results[i].cdk_proportion;
						num ++
						arr[num] = json.results[i].cdk_par * 转换操作.到数值(json.results[i].invest_scale) * json.results[i].cdk_proportion;
						num ++
						arr[num] = json.results[i].oper_login;
						num ++
						arr[num] = json.results[i].create_time;
						num ++
						arr[num] = "";
						if(json.results[i].cdk_isuse > 0 ){
							arr[num] = json.results[i].use_time;
						}
						高级表格1.添加行(false,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(4,false,"删除");
					高级表格1.初始化("auto",true,true,true,true);
				}else{
					div_cdk_popover.隐藏();
					div_cdk_next_ids.置内容("");
					var ids= "";
					while(i < json.results.length){
						ids = ids + json.results[i] + "\r\n";
						i++
					}
					div_cdk_next_ids.置内容(ids);
					div_cdk_next_popover.显示();
				}



			}




		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	m_post = 公用模块.生成提交数据(cdk_isuse, "cdk_info_coin", value, "" , 1, 0);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}

function 按钮_底部_被单击(){
	m_post = 公用模块.生成提交数据(cdk_isuse, "cdk_info_coin", value, "" , page+1, 0);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	时钟1.开始执行(200,false);
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
		case 0 :

			if(HPtools1.询问框("是否删除？\n\n注意！无论是否兑换过的都可以被删除！") == true ){
				var json= {}
				json.cdk_id = 行数据["cdk_id"];
				m_post = 公用模块.生成提交数据(_id, "cdk_info_coin", ""+行索引, "delete" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
				美化等待框1.默认等待框("正在交互","正在删除,请稍等......");
				时钟1.开始执行(200,false);
			}

		break;
	}

}
function 高级表格1_工具栏按钮被单击(按钮索引){
	if(按钮索引 == 0 ){
		div_cdk_popover.显示();
	}else if(按钮索引 == 1 ){
		div_batch_del_popover.显示();
	}
}
function div_cdk_isuse_1__被单击(){
	cdk_isuse = -1;
}
function div_cdk_isuse_0_被单击(){
	cdk_isuse = 0;
}
function div_cdk_isuse_1_被单击(){
	cdk_isuse = 1;
}
function div_cdk_btn_被单击(){
	div_cdk_par.置内容(文本操作.删首尾空(div_cdk_par.取内容()));
	div_cdk_num.置内容(文本操作.删首尾空(div_cdk_num.取内容()));
	var cdk_par= 转换操作.到数值(div_cdk_par.取内容());
	var num= 转换操作.到数值(div_cdk_num.取内容());
	if(cdk_par <= 0 ){
		仔仔弹出对话框1.错误("面值必须大于0！");
		return;
	}
	if(num < 1 ){
		仔仔弹出对话框1.错误("生成数量必须大于0！");
		return;
	}
	div_cdk_proportion.置内容(文本操作.删首尾空(div_cdk_proportion.取内容()));
	if(div_cdk_proportion.取内容() == "" ){
		div_cdk_proportion.置内容("1");
	}
	var json= {}
	json.cdk_par = cdk_par;
	json.cdk_agent = cdk_agent;
	json.cdk_proportion = 转换操作.到数值(div_cdk_proportion.取内容());
	m_post = 公用模块.生成提交数据(0, "cdk_info_coin", "", "insert" , num, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	美化等待框1.默认等待框("正在交互","正在生成,请稍等......");
	时钟1.开始执行(200,false);
}
function div_cdk_next_btn_被单击(){
	HPtools1.置剪贴板内容(div_cdk_next_ids.取内容());
	仔仔弹出对话框1.提示("已尝试复制！");
}
function div_cdk_btns_被单击(按钮索引){
	cdk_agent = 按钮索引;
	div_cdk_btns.置样式(0,"mui-btn");
	div_cdk_btns.置样式(1,"mui-btn");
	div_cdk_btns.置样式(按钮索引,"mui-btn mui-btn-primary");
}
function div_batch_del_date_被单击(){
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	div_batch_del_date.置标题(res);
}
function div_batch_del_btn_被单击(){
	var del_model = 0;
	var msg = "指定删除时间：" + div_batch_del_date.取标题() + "\n\n删除模式：";
	if(div_batch_del_isuse_0.取选中状态() == true ){
		msg += "删除未使用";
		del_model = 1;
	}
	if(div_batch_del_isuse_2.取选中状态() == true ){
		if(del_model > 0 ){
			msg += "、";
		}
		msg += "删除已兑换";
		del_model += 2;
	}
	if(del_model < 1 ){
		仔仔弹出对话框1.错误("请勾选删除模式！");
		return;
	}
	if(HPtools1.询问框(msg += "\n\n是否开始批量删除？") == false ){
		return;
	}
	var json= {}
	json.del_model=del_model;
	json.del_date = div_batch_del_date.取标题();
	m_post = 公用模块.生成提交数据(0, "cdk_info_coin_batch", "", "delete" , 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在生成,请稍等......");
	时钟1.开始执行(200,false);
}