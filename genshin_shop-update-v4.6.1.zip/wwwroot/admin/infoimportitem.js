mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 标签1 = new 标签("标签1",null);
var 标签2 = new 标签("标签2",null);
var 编辑框1 = new 编辑框("编辑框1",null,null,null,null,null);
var 标签5 = new 标签("标签5",null);
var 编辑框2 = new 编辑框("编辑框2",null,null,null,null,null);
var 标签6 = new 标签("标签6",null);
var 自由面板1 = new 自由面板("自由面板1","154px");
var div_item_model_0 = new 单选框("div_item_model_0",null);
var div_item_model_1 = new 单选框("div_item_model_1",null);
var div_item_model_2 = new 单选框("div_item_model_2",null);
var div_item_model_3 = new 单选框("div_item_model_3",null);
var div_item_model_4 = new 单选框("div_item_model_4",null);
var div_item_model_5 = new 单选框("div_item_model_5",null);
var div_item_model_6 = new 单选框("div_item_model_6",null);
var div_item_model_7 = new 单选框("div_item_model_7",null);
var div_item_model_8 = new 单选框("div_item_model_8",null);
var div_item_model_9 = new 单选框("div_item_model_9",null);
var 自由面板_下拉框 = new 下拉框("自由面板_下拉框",自由面板_下拉框_表项被单击);
var 自由面板_按钮_刷新 = new 按钮("自由面板_按钮_刷新",自由面板_按钮_刷新_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var 标签3 = new 标签("标签3",null);
var 标签4 = new 标签("标签4",null);
var 按钮组1 = new 按钮组("按钮组1",按钮组1_被单击);
var 图片框1 = new 图片框("图片框1",null);
if(mui.os.plus){
    mui.plusReady(function() {
        批量导入资源档案_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        批量导入资源档案_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var m_model= 0;
var class_name= "";
var isPA= false;


function 批量导入资源档案_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		仔仔弹出对话框1.错误("password异常,请关闭本页面！");
		return;
	}

	根地址 = HPtools1.取URL();
	按钮组1.置样式(0,"mui-btn mui-btn-danger");
	m_post = "";
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/isPA");
	美化等待框1.默认等待框("正在交互","正在校验,请稍等......");
	时钟1.开始执行(200,false);

}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "isPA" ){
				isPA = json.msg;
				if(isPA == true ){
					按钮组1.置可视(true);
					刷新类别();
				}else{
					仔仔弹出对话框1.错误("未绑定会员时不能导入！");
				}
			}else if(json.table == "item_class_info" ){
				仔仔弹出对话框1.成功("添加成功,请刷新！");
			}else{
				仔仔弹出对话框1.成功("已导入成功！备注：导入时会自动跳过格式不对的文本行");
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "item_class_info" ){
				class_name = "";
				自由面板_下拉框.清空项目();
				自由面板_下拉框.添加项目("请选择类别......","");
				while(i < json.results.length){
					自由面板_下拉框.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
			}
		}
	}
}


function 按钮组1_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否清空内容？") == true ){
				m_model = 0;
				编辑框1.置内容("");
			}
		break;
		case 1 :
			编辑框1.置内容(文本操作.删首尾空(编辑框1.取内容()));
			if(编辑框1.取内容() == "" ){
				仔仔弹出对话框1.错误("请粘贴要导入的文本");
				return;
			}
			if(编辑框2.取内容() == "" ){
				仔仔弹出对话框1.错误("请输入分隔符");
				return;
			}
			var item_model= 0;
			var item_control= 0;
			if(div_item_model_0.取选中状态() == true ){
				item_control = 1;
			}else if(div_item_model_1.取选中状态() == true ){
				item_model = 1;
				item_control = 1;
			}else if(div_item_model_2.取选中状态() == true ){
				item_model = 2;
			}else if(div_item_model_3.取选中状态() == true ){
				item_model = 3;
			}else if(div_item_model_4.取选中状态() == true ){
				item_model = 4;
			}else if(div_item_model_5.取选中状态() == true ){
				item_model = 5;
			}else if(div_item_model_6.取选中状态() == true ){
				item_model = 6;
			}else if(div_item_model_7.取选中状态() == true ){
				item_model = 7;





			}else{
				仔仔弹出对话框1.错误("必须选择一种档案类型！");
				return;
			}
			if(class_name == "" ){
				仔仔弹出对话框1.错误("必须选择一种档案类别！");
				return;
			}
			if(HPtools1.询问框("是否导入？注意！不校验是否重复,不校验是否正确！") == false ){
				return;
			}
			var json= {}
			var txt= 加密操作1.base64加密(编辑框1.取内容());
			txt = ""+txt;
			json.txt = txt;
			json.sep = 编辑框2.取内容();
			json.item_model = item_model;
			json.class_name = class_name;
			json.item_control = item_control;
			m_post = 公用模块.生成提交数据(0, "item_item_info", "", "" , 1, 0,json);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/import", m_password);
			美化等待框1.默认等待框("正在交互","正在导入,请稍等......");
			时钟1.开始执行(200,false);
		break;
	}
}

function 刷新类别(){
	m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
	时钟1.开始执行(200,false);
}
function 自由面板_按钮_刷新_被单击(){
	if(isPA == false ){
		仔仔弹出对话框1.错误("未绑定会员时不能刷新！");
		return;
	}
	刷新类别();
}
function 自由面板_按钮_添加_被单击(){
	if(isPA == false ){
		仔仔弹出对话框1.错误("未绑定会员时不能添加！");
		return;
	}
	var class_name= 文本操作.删首尾空(HPtools1.输入框("新的类别名称",""));
	if(class_name != "" ){
		var json= {}
		json.class_name = class_name;
		m_post = 公用模块.生成提交数据(ID, "item_class_info", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加类别,请稍等......");
		时钟1.开始执行(200,false);
	}
}
function 自由面板_下拉框_表项被单击(项目索引,项目标题,项目标记){
	class_name = 项目标记;
}