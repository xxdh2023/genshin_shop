    function 顶部选项卡(name,event,event2){   
		/*作者：CYS。  QQ：649812788
		  有BUG请反馈,谢谢！
		  类库定制请联系
		*/
        this.名称 = name;
        
        //组件命令：
        this.置可视 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称);
                div.style.display="block";//显示	                
            }else{
                var div = document.getElementById(this.名称);
                div.style.display="none"; //不占位隐藏               
            }
        } 
        
        //组件命令：
        this.置可视2 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称);
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称);
                div.style.visibility="hidden"; //占位隐藏               
            }
        } 

		/*------------------------【命令】-------------------------*/
		this.添加子卡 = function(标题,是否激活){
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = document.createElement('a');
			var newClassName = 'mui-control-item';
			var itemCount = 取子卡数();
			
			if(是否激活==null) 是否激活=false;
			if(是否激活==true){
				if(itemCount!=0){
					撤销其他子卡激活();
				}
				newClassName += ' mui-active';
			}else{
				if(itemCount==0) newClassName += ' mui-active';
			}
			oa.className = newClassName;
			oa.href = '#';
			oa.innerHTML = 标题;
			oa.index = itemCount;
			odiv2.appendChild(oa);
		}
		
		this.取子卡数 = function(){
			return 取子卡数();
		}
		
		this.删除子卡 = function(子卡索引){
			var itemCount = 取子卡数();
			if(子卡索引<0 || itemCount-1<子卡索引) return false;
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = odiv2.getElementsByClassName('mui-control-item');
			var isActive = oa[子卡索引].className.indexOf('mui-active');
			
			odiv2.removeChild(oa[子卡索引]);
			if(isActive!=-1 && 1<itemCount){//被删除子卡之前为激活状态,且子卡数大于1
				oa[0].className += ' mui-active';
			}
			//刷新索引
			for(var i=0;i<itemCount-1;i++){
				oa[i].index = i;
			}
			return true;
		}
		
		this.清空子卡 = function(){
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			odiv2.innerHTML = '';
		}
		
		this.置标题 = function(子卡索引,标题){
			var itemCount = 取子卡数();
			if(子卡索引<0 || itemCount-1<子卡索引) return;
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = odiv2.getElementsByClassName('mui-control-item');
			oa[子卡索引].innerHTML = 标题;
		}
		
		this.取标题 = function(子卡索引){
			var itemCount = 取子卡数();
			if(子卡索引<0 || itemCount-1<子卡索引) return '';
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = odiv2.getElementsByClassName('mui-control-item');
			return oa[子卡索引].innerHTML;
		}
		
		this.置样式 = function(样式){//0:蓝色 1:绿色 2:红色
			var newClassName = 'mui-segmented-control';
			switch(样式){
				case 0:
					newClassName += ' mui-segmented-control-primary';
					break;
				case 1:
					newClassName += ' mui-segmented-control-positive';
					break;
				case 2:
					newClassName += ' mui-segmented-control-negative';
					break;
			}
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			odiv2.className = newClassName;
		}
		
		this.取激活子卡 = function(){
			return 取被激活子卡索引();
		}
		
		this.置激活子卡 = function(子卡索引){
			var itemCount = 取子卡数();
			if(子卡索引<0 || itemCount-1<子卡索引) return false;
			撤销其他子卡激活();
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = odiv2.getElementsByClassName('mui-control-item');
			oa[子卡索引].className += ' mui-active';
			return true;
		}
		
		/*------------------------【子程序】-------------------------*/
		function 取子卡数(){
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = odiv2.getElementsByClassName('mui-control-item');
			return oa.length;
		}
		
		function 撤销其他子卡激活(){
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = odiv2.getElementsByClassName('mui-control-item');
			var ret;
			for(var i=0;i<oa.length;i++){
				ret = oa[i].className.indexOf('mui-active');
				if(ret!=-1){
					//console.log(i);
					oa[i].className = 'mui-control-item';
					break;
				}
			}
		}
		
		function 取被激活子卡索引(){
			var odiv = document.getElementById(name);
			var odiv2 = odiv.getElementsByClassName('mui-segmented-control')[0];
			var oa = odiv2.getElementsByClassName('mui-control-item');
			var ret;
			for(var i=0;i<oa.length;i++){
				ret = oa[i].className.indexOf('mui-active');
				if(ret!=-1){
					//console.log(i);
					return i;
					break;
				}
			}
			return -1;
		}
        //组件事件
        if(event!=null){
 			/*document.getElementById(this.名称).addEventListener("tap", function () {
                event();//触发组件的相关事件，这里演示的是被单击事件
            });*/
			mui("#" + name + " .mui-segmented-control").on('tap','.mui-control-item',function(){
				event(this.index);
			});
        }
		
		if(event2!=null){
			mui("#" + name + " .mui-segmented-control").on('tap','.mui-control-item',function(){
				var isActive = this.className.indexOf('mui-active');//是否激活
				if(isActive==-1){
					var oldIndex = 取被激活子卡索引();
					event2(oldIndex,this.index);
				}
			});
		}
    }