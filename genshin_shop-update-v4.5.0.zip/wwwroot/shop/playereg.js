mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var div_head_panel = new 面板("div_head_panel");
var div_register_title = new 标签("div_register_title",null);
var div_register_close = new 图片框("div_register_close",div_register_close_被单击);
var div_reg_lable_1 = new 标签("div_reg_lable_1",null);
var div_reg_login = new 编辑框("div_reg_login",null,null,null,null,null);
var div_reg_lable_2 = new 标签("div_reg_lable_2",null);
var div_reg_name = new 编辑框("div_reg_name",null,null,null,null,null);
var div_reg_password = new 编辑框("div_reg_password",null,null,null,null,null);
var div_reg_password_ = new 编辑框("div_reg_password_",null,null,null,null,null);
var 面板1 = new 面板("面板1");
var 单选框_0 = new 单选框("单选框_0",单选框_0_被单击);
var 单选框_1 = new 单选框("单选框_1",单选框_1_被单击);
var div_reg_lable_3 = new 标签("div_reg_lable_3",null);
var div_reg_email = new 编辑框("div_reg_email",null,null,null,null,null);
var div_reg_lable_4 = new 标签("div_reg_lable_4",null);
var div_reg_dropbox = new 下拉框("div_reg_dropbox",div_reg_dropbox_表项被单击);
var div_reg_answer = new 编辑框("div_reg_answer",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var 面板2 = new 面板("面板2");
var 单选框0 = new 单选框("单选框0",单选框0_被单击);
var 单选框1 = new 单选框("单选框1",单选框1_被单击);
var div_reg_game_account = new 编辑框("div_reg_game_account",null,null,null,null,null);
var div_reg_lable_5 = new 标签("div_reg_lable_5",null);
var 标签3 = new 标签("标签3",null);
var div_reg_code = new 标签("div_reg_code",null);
var 自由面板1 = new 自由面板("自由面板1","60px");
var 面板3 = new 面板("面板3");
var div_reg_code_edit = new 编辑框("div_reg_code_edit",null,null,null,null,null);
var div_reg_btn = new 按钮("div_reg_btn",div_reg_btn_被单击,null,null);
var div_reg_lable_6 = new 标签("div_reg_lable_6",null);
var div_reg_pic = new 图片框("div_reg_pic",div_reg_pic_被单击);
var 标签1 = new 标签("标签1",null);
var HK蓝鸟1 = new HK蓝鸟("HK蓝鸟1");
if(mui.os.plus){
    mui.plusReady(function() {
        商城注册_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        商城注册_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var agent= "";
var agid= 0;
var reg= "";
var question_reg="";
var mast_shop= 0;

function 商城注册_创建完毕(){
	根地址 = HPtools1.取URL();
	agent = 文本操作.删首尾空(窗口操作.取当前页面参数("agid"));
	if(agent == "" ){
		agid = 0;
	}else{
		agid = 数学操作.取整数(转换操作.到数值(agent));
	}
	agent = 文本操作.删首尾空(窗口操作.取当前页面参数("agent"));
	生成界面();
	登陆界面初始化();
	获取验证码();
	window.parent.关闭注册遮罩及等待框();
}
function 登陆界面初始化(){
	div_reg_dropbox.添加项目("请选择重置密码问题......","");
	div_reg_dropbox.添加项目("您所在的城市","您所在的城市");
	div_reg_dropbox.添加项目("您所在的国家","您所在的国家");
	div_reg_dropbox.添加项目("您最难忘的事是什么","您最难忘的事是什么");
	div_reg_dropbox.添加项目("您最难忘的是哪句话","您最难忘的是哪句话");
	面板1.添加组件("单选框_0","1");
	面板1.添加组件("单选框_1","1");
	单选框_0.置选中状态(true);
	单选框_0.置分组("A");
	单选框_1.置分组("A");
	面板2.添加组件("单选框0", "1");
	面板2.添加组件("单选框1", "1");
	单选框0.置选中状态(true);
	单选框0.置分组("B");
	单选框1.置分组("B");
	面板2.置可视(false);
	面板3.添加组件("div_reg_code_edit","1");
	面板3.添加组件("div_reg_btn","1");
}
function 生成界面(){
	var 窗口宽度= 窗口操作.取窗口宽度();
	div_head_panel.置高度("40px");
	div_head_panel.添加组件("div_register_title","100%");
	HK蓝鸟1.设置属性("div_register_title","[定位:绝对定位]");
	div_head_panel.添加组件("div_register_close","24px");

	HK蓝鸟1.设置属性("div_register_close","[定位:绝对定位][左边:"+转换操作.到文本(窗口宽度-10-50)+"px][顶边:8px]");
	div_register_close.置圆角("6px");
}
function div_reg_pic_被单击(){
	获取验证码();
}

function 获取验证码(){
	m_post = "";
	m_url = 公用模块.生成访问链接(根地址,"api/shop/code?captchaId=" + div_reg_code.取标题(), "");
	显示等待框();
	时钟1.开始执行(20,false);
}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){
	关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == 0 ){
			if(json.table == "code" ){
				mast_shop = json.mast_shop;
				标签3.置可视(json.only_bind);
				绑定显示();
				return;
			}else{
				获取验证码();
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info" ){
				if(json.model == "reg" ){
					window.parent.显示提示消息("注册成功",true);
					window.parent.postMessage("close_register", window.location.origin);
					return;
				}
			}else if(json.table == "code" ){
				div_reg_code.置标题(json.comm);
				div_reg_pic.置图片(json.msg);
				mast_shop = json.mast_shop;
				标签3.置可视(json.only_bind);
				绑定显示();
				return;
			}
			获取验证码();
			仔仔弹出对话框1.成功(json.msg);

		}else if(json.static == 2 ){
			var i= 0;
		}
	}
}

function div_register_close_被单击(){
	window.parent.postMessage("close_register", window.location.origin);
}
function 绑定显示(){
	if(mast_shop < 1 ){
		标签2.置标题("游戏账号：");
		面板2.置可视(true);
	}else{
		标签2.置标题("游戏账号：与商城账号一致！");
		面板2.置可视(false);
		单选框0.置选中状态(true);
		单选框1.置选中状态(false);
	}
}
function div_reg_dropbox_表项被单击(项目索引,项目标题,项目标记){
	question_reg = 项目标记;
}

function div_reg_btn_被单击(){
	div_reg_login.置内容(文本操作.删首尾空(div_reg_login.取内容()));
	if(文本操作.取文本长度(div_reg_login.取内容()) < 4 ){
		仔仔弹出对话框1.错误("账号长度不能小于4");
		return;
	}





	div_reg_password.置内容(文本操作.删首尾空(div_reg_password.取内容()));
	div_reg_password_.置内容(文本操作.删首尾空(div_reg_password_.取内容()));
	if(div_reg_password.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入密码");
		return;
	}
	if(div_reg_password.取内容() != div_reg_password_.取内容() ){
		仔仔弹出对话框1.错误("两次密码输入不一致");
		return;
	}
	var oper_password= 加密操作1.取md5值(div_reg_password.取内容());
	oper_password = "" + oper_password;
	var reg_email= "";
	if(单选框_1.取选中状态() == true ){
		div_reg_email.置内容(文本操作.删首尾空(div_reg_email.取内容()));
		if(div_reg_email.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入邮箱");
			return;
		}
		var bool= CCS类库1.验证_邮箱(div_reg_email.取内容());
		if(bool != "正确" ){
			仔仔弹出对话框1.错误("输入的邮箱格式不对");
			return;
		}
		reg_email = div_reg_email.取内容();
	}
	if(question_reg == "" ){
		仔仔弹出对话框1.错误("请选择问题");
		return;
	}
	div_reg_answer.置内容(文本操作.删首尾空(div_reg_answer.取内容()));
	if(div_reg_answer.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入答案");
		return;
	}
	div_reg_game_account.置内容(div_reg_game_account.取内容());
	if(mast_shop < 1 && 单选框1.取选中状态() == true ){
		if(div_reg_game_account.取内容() == "" ){
			仔仔弹出对话框1.错误("请输入游戏准确的账号");
			return;
		}
	}
	div_reg_code_edit.置内容(文本操作.删首尾空(div_reg_code_edit.取内容()));
	if(div_reg_code_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入验证码");
		return;
	}
	var json= {}

	json.oper_email = reg_email;
	json.oper_question = question_reg;
	json.oper_answer = div_reg_answer.取内容();
	if(mast_shop > 0 || 单选框0.取选中状态() == true ){
		json.game_account_username = div_reg_login.取内容();
	}else{
		json.game_account_username = div_reg_game_account.取内容();
	}
	json.timestamp = div_reg_code.取标题();
	json.code = div_reg_code_edit.取内容();
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "reg" , 0, 0, json, div_reg_login.取内容(), oper_password);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login?agent=" + agent+"&agid="+String(agid), "");
	显示等待框();
	时钟1.开始执行(200,false);
}

function 显示等待框(){
	公用模块.showMask("页面遮罩");
	HPtools1.显示等待框("请稍等......");

}

function 关闭等待框(){

	公用模块.hideMask("页面遮罩");
	HPtools1.关闭等待框();
}
function 单选框_0_被单击(){
	div_reg_email.置可视(false);
}
function 单选框_1_被单击(){
	div_reg_email.置可视(true);
}
function 单选框0_被单击(){
	div_reg_game_account.置可视(false);
	div_reg_game_account.置内容("");
	div_reg_lable_5.置可视(false);
}
function 单选框1_被单击(){
	div_reg_game_account.置可视(true);
	div_reg_lable_5.置可视(true);
}