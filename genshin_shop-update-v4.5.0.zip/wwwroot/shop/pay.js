mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 编辑框1 = new 编辑框("编辑框1",null,null,null,null,null);
var 按钮1 = new 按钮("按钮1",按钮1_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        直充支付_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        直充支付_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";





function 直充支付_创建完毕(){





	根地址 = HPtools1.取URL();

	标题栏美化1.去标题栏阴影();
	pay_id = 文本操作.删首尾空(窗口操作.取当前页面参数("pay_id"));
	pay_amount = 转换操作.到数值(窗口操作.取当前页面参数("pay_amount"));
	pay_name = 文本操作.删首尾空(窗口操作.取当前页面参数("pay_name"));
	if(pay_name != "" ){
		pay_name = 加密操作1.url解码(pay_name);
	}
	pay_type = 文本操作.删首尾空(窗口操作.取当前页面参数("pay_type"));
	if(pay_id == "" || pay_amount <=0 || pay_name == "" ){
		仔仔弹出对话框1.错误("调用异常,无法发起支付");
		return;
	}
	编辑框1.置可视(false);
	编辑框1.置只读模式(true);
	if(pay_name == "test-coin" ){
		var str= "当前为测试模式：\n充值商品名称："+pay_name+"\n充值金额："+转换操作.到文本(pay_amount);
		str = str+"\n充值模式："+pay_type+"\n内部直充档案编码："+pay_id+"\n重点！！回调URL："+根地址;
		编辑框1.置内容(str);
		编辑框1.置可视(true);
		按钮1.置可视(true);
	}
	var res = 公用模块.组装直充请求(pay_id, pay_amount, pay_name, 根地址, pay_type, m_token);
	m_post = res[0];
	m_url = res[1];
	if(pay_name != "test-coin" ){
		美化等待框1.默认等待框("正在交互","正在发起充值,请稍等......");
		时钟1.开始执行(200,false);
	}
}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "user_pay" && json.model == "pay" ){
				if(json._id.submit == "" ){
					仔仔弹出对话框1.错误("当前平台未授权开放充值平台！");
					return;
				}
				if(json._id.method == "POST" ){
					公用模块.发起POST表单(json);
				}else{
					json.msg.name = 加密操作1.url编码(json.msg.name);
					if(json._id.pay_model == 2 ){
						json.msg.sitename = 加密操作1.url编码(json.msg.sitename);
					}
					公用模块.发起GET充值(json);
				}
			}
		}
	}
}


function 按钮1_被单击(){
	美化等待框1.默认等待框("正在交互","正在发起充值,请稍等......");
	时钟1.开始执行(200,false);
}