mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 顶部选项卡1 = new 顶部选项卡("顶部选项卡1",顶部选项卡1_子卡被单击,null);
var 标签1 = new 标签("标签1",null);
var div_sign_lable_1 = new 标签("div_sign_lable_1",null);
var div_sign_clear = new 按钮("div_sign_clear",div_sign_clear_被单击,null,null);
var div_sign_lable_2 = new 标签("div_sign_lable_2",null);
var div_sign_grid = new 高级列表框("div_sign_grid",false,true,false,null);
var div_sign_btn = new 按钮("div_sign_btn",div_sign_btn_被单击,null,null);
var div_clear_popover = new 弹出面板("div_clear_popover",null,null);
var div_clear_lable_1 = new 标签("div_clear_lable_1",null);
var div_clear_lable_2 = new 标签("div_clear_lable_2",null);
var div_clear_edit = new 编辑框("div_clear_edit",null,null,null,null,null);
var div_clear_btn = new 按钮("div_clear_btn",div_clear_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        平台福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        平台福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 导航索引= 0;
function 平台福利_创建完毕(){





	根地址 = HPtools1.取URL();
	导航栏初始化(2);

	标题栏美化1.去标题栏阴影();
	弹出面板初始化();
	顶部选项卡初始化(1);
	m_post = 公用模块.生成提交数据(0, "sign_welfare", "", "select" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/welfare", m_token);
	美化等待框1.默认等待框("正在交互","正在获取中,请稍等......");
	时钟1.开始执行(200,false);
}
function 导航栏初始化(激活项目){
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-cart","商城","0",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-grech","抽奖","1",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-gift","福利","2",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-express","仓库","3",0);
	导航栏1.添加项目("mui-icon", "mui-icon-contact","我的","4",0);
	导航栏1.添加完毕();
	导航栏1.置激活项目背景色("#F2F2F2");
	导航栏1.置项目激活状态(0,false);
	导航栏1.置项目激活状态(1,false);
	导航栏1.置项目激活状态(2,false);
	导航栏1.置项目激活状态(3,false);
	导航栏1.置项目激活状态(4,false);
	导航栏1.置项目激活状态(激活项目,true);
	导航索引 = 激活项目;
}
function 导航栏1_项目被单击(项目标题,目标名称){
	var arr = ["shop","lottery","welfare","warehouse","user"];
	var 子卡索引=转换操作.到数值(目标名称);
	if(子卡索引 == 导航索引 ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(arr[子卡索引]+".html","");
	}
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_clear_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_clear_popover.添加组件("div_clear_lable_1");
	div_clear_popover.添加组件("div_clear_lable_2");
	div_clear_popover.添加组件("div_clear_edit");
	div_clear_popover.添加组件("div_clear_btn");
}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			if(json.table == "sign_welfare" && json.model == "select" ){
				if(文本操作.寻找文本(json.msg,"重新登陆") > -1 ){
					窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
				}else{
					仔仔弹出对话框1.错误(json.msg);
				}

			}else{
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
			}
		}else if(json.static == 0 ){
			if(json.table == "sign_welfare" && json.model == "select" ){
				if(json._id > 0 ){
					div_sign_lable_1.置可视(true);
					div_sign_clear.置可视(true);
					标签1.置可视(false);
				}
				仔仔弹出对话框1.错误(json.msg);
			}else{
				仔仔弹出对话框1.错误(json.msg);
			}
		}else if(json.static == 1 ){
			if(json.table == "sign_welfare" && json.model == "select" ){
				标签1.置可视(false);
				if(json._id.sign_clear == 1 ){
					div_sign_lable_1.置可视(true);
					div_sign_clear.置可视(true);
				}
				var i= 0;
				div_sign_lable_2.置可视(true);
				while(i<json.msg.length){
					div_sign_grid.添加项目("",json.msg[i].sign_value,"","");
					i++
				}
				div_sign_grid.置可视(true);
				div_sign_btn.置可视(true);
				if(json._id.inout_num < 1 ){
					div_sign_btn.置标题("领取今日份福利");
					div_sign_btn.置样式("mui-btn mui-btn-success");
				}else{
					div_sign_btn.置标题("已领取过");
					div_sign_btn.置样式("mui-btn mui-btn-danger");
				}
			}else if(json.table == "sign_welfare" && json.model == "draw" ){
				div_sign_btn.置标题("已领取过");
				div_sign_btn.置样式("mui-btn mui-btn-danger");
				仔仔弹出对话框1.提示("已领取,请在仓库中提取资源");
			}else if(json.table == "sign_welfare" && json.model == "clear" ){
				div_clear_popover.隐藏();
				仔仔弹出对话框1.提示("已尝试清理,请在游戏的背包中查看结果");
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}
	}
}
function div_sign_clear_被单击(){
	div_clear_popover.显示();
}
function div_sign_btn_被单击(){
	if(div_sign_btn.取标题() == "已领取过" ){
		仔仔弹出对话框1.错误("今日已领取过,不能重复领取");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "sign_welfare", "", "draw" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/welfare", m_token);
	美化等待框1.默认等待框("正在交互","正在领取,请稍等......");
	时钟1.开始执行(200,false);
}
function div_clear_btn_被单击(){
	div_clear_edit.置内容(文本操作.删首尾空(div_clear_edit.取内容()));
	if(div_clear_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入关键词");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "sign_welfare", div_clear_edit.取内容(), "clear" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/welfare", m_token);
	美化等待框1.默认等待框("正在交互","正在清理,请稍等......");
	时钟1.开始执行(200,false);
}
function 顶部选项卡初始化(当前页){
	顶部选项卡1.清空子卡();
	顶部选项卡1.添加子卡("免费商城", false);
	顶部选项卡1.添加子卡("平台福利", false);
	顶部选项卡1.添加子卡("累充福利", false);
	顶部选项卡1.置激活子卡(当前页);
}
function 顶部选项卡1_子卡被单击(子卡索引){
	var arr = ["freeshop","welfare","benefits"];
	窗口操作.切换窗口(arr[子卡索引]+".html","");
}