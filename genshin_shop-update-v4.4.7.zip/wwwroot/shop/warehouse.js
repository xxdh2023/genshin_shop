mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var CYS超级列表框1 = new CYS超级列表框("CYS超级列表框1",null,CYS超级列表框1_按钮被单击);
var 标签1 = new 标签("标签1",null);
var 按钮组_发送 = new 按钮组("按钮组_发送",按钮组_发送_被单击);
var 高级列表框1 = new 高级列表框("高级列表框1",true,true,false,高级列表框1_表项被单击);
var 按钮组_更多 = new 按钮组("按钮组_更多",按钮组_更多_被单击);
var div_warehouse_popover = new 弹出面板("div_warehouse_popover",null,null);
var div_warehouse_lable_1 = new 标签("div_warehouse_lable_1",null);
var div_warehouse_inout_no = new 编辑框("div_warehouse_inout_no",null,null,null,null,null);
var div_warehouse_time = new 标签("div_warehouse_time",null);
var div_warehouse_sku = new 标签("div_warehouse_sku",null);
var div_warehouse_lable_2 = new 标签("div_warehouse_lable_2",null);
var div_warehouse_oper_note = new 编辑框("div_warehouse_oper_note",null,null,null,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        仓库_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        仓库_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 导航索引= 0;
var warehouse_num1= 0;
var page= 0;
var m_json= {}
var agent_oper= "";
var warehouse_num= 20;
var 提取确认= true;
var agid= 0;
function 仓库_创建完毕(){





	根地址 = HPtools1.取URL();
	导航栏初始化(3);

	标题栏美化1.去标题栏阴影();
	div_warehouse_inout_no.置只读模式(true);
	div_warehouse_oper_note.置只读模式(true);
	弹出面板初始化();
	获取仓库状态();
}
function 导航栏初始化(激活项目){
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-cart","商城","0",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-grech","抽奖","1",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-gift","福利","2",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-express","仓库","3",0);
	导航栏1.添加项目("mui-icon", "mui-icon-contact","我的","4",0);
	导航栏1.添加完毕();
	导航栏1.置激活项目背景色("#F2F2F2");
	导航栏1.置项目激活状态(0,false);
	导航栏1.置项目激活状态(1,false);
	导航栏1.置项目激活状态(2,false);
	导航栏1.置项目激活状态(3,false);
	导航栏1.置项目激活状态(4,false);
	导航栏1.置项目激活状态(激活项目,true);
	导航索引 = 激活项目;
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_warehouse_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_warehouse_popover.添加组件("div_warehouse_lable_1");
	div_warehouse_popover.添加组件("div_warehouse_inout_no");
	div_warehouse_popover.添加组件("div_warehouse_time");
	div_warehouse_popover.添加组件("div_warehouse_sku");
	div_warehouse_popover.添加组件("div_warehouse_lable_2");
	div_warehouse_popover.添加组件("div_warehouse_oper_note");
}
function 获取仓库状态(){
	m_post = 公用模块.生成提交数据(0, "warehouse_info", "", "state" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/warehouse", m_token);
	美化等待框1.默认等待框("正在交互","正在获取仓库数据,请稍等......");
	时钟1.开始执行(200,false);
}
function 导航栏1_项目被单击(项目标题,目标名称){
	var arr = ["shop","lottery","welfare","warehouse","user"];
	var 子卡索引=转换操作.到数值(目标名称);
	if(子卡索引 == 导航索引 ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(arr[子卡索引]+".html","");
	}
}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "warehouse_info" && json.model == "state" ){
				warehouse_num = json._id;
				if(warehouse_num <= 0 ){
					warehouse_num = 20;
				}else if(warehouse_num < 3 ){
					warehouse_num = 3;
				}
				按钮组_发送.置标题(0, "提取"+String(warehouse_num)+"条资源");
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			var str= "";
			if(json.table == "warehouse_info" && json.model == "state" ){
				warehouse_num = json._id;
				if(warehouse_num <= 0 ){
					warehouse_num = 20;
				}else if(warehouse_num < 3 ){
					warehouse_num = 3;
				}
				按钮组_发送.置标题(0, "提取"+String(warehouse_num)+"条资源");
				CYS超级列表框1.清空项目();
				var ss= "";
				if(json.results.production == 1 ){
					str = "当前系统为正式模式";
					ss = "server";
				}else{
					str = "当前系统为测试模式";
					ss = "不能领取资源";
				}
				agent_oper = json.results.agent_oper;
				agid = json.results.agid;
				CYS超级列表框1.添加项目(str,ss,1,"","");
				CYS超级列表框1.添加项目(json.results.game_uid,"绑定UID",1,"","game_uid");
				CYS超级列表框1.添加项目(json.results.server_name,"当前登陆服务器",1,"","server_name");
				if(json.results.gmapi == 1 ){
					str = "游戏服务器参数完整";
					ss = "game";
				}else{
					str = "游戏服务器参数缺失";
					ss = "不能领取资源";
				}
				CYS超级列表框1.添加项目(str,ss,1,"","");
				CYS超级列表框1.添加项目("切换游戏服务器","重新登陆",4,"mui-btn-red","login-out");
				warehouse_num1 = json.results.warehouse_num1;
				if(warehouse_num1 > 0 && json.results.gmapi == 1 && json.results.production == 1 ){
					按钮组_发送.置可视(true);
				}else{
					按钮组_发送.置可视(false);
				}
				CYS超级列表框1.添加项目("仓库中暂存了"+转换操作.到文本(warehouse_num1)+"条资源","重新查询",4,"mui-btn-green","warehouse_info");
				if(json.results.warehouse_num2 > 0 ){
					CYS超级列表框1.添加项目("当前正在发送"+转换操作.到文本(json.results.warehouse_num2)+"条资源","重新查询",4,"mui-btn-green","warehouse_info");
				}
				高级列表框1.清空项目();
				按钮组_更多.置可视(false);
			}else if(json.table == "warehouse_info" && json.model == "send" ){
				获取仓库状态();
				仔仔弹出对话框1.提示(json.msg);
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "warehouse_info" && json.model == "select" ){
				var old_num= 0;
				if(json.page < 2 ){
					m_json = json;
				}else{
					m_json.total = json.total;
					m_json.page = json.page;
					old_num = m_json.results.length;
				}
				var str= "";
				while(i < json.results.length){
					if(json.results[i].oper_static < 1 ){
						str ="暂存仓库";
					}else if(json.results[i].oper_static == 1 ){
						str ="正在领取";
					}else{
						str ="已领取";
					}
					高级列表框1.添加项目2("", json.results[i].value, "状态："+str +" ，所属：" + json.results[i].oper_note,转换操作.到文本(old_num + i));

					if(json.page > 1 ){
						m_json.results[old_num + i] = json.results[i];
					}
					i++
				}
				if(json.page < json.total ){
					按钮组_更多.置可视(true);
				}else{
					按钮组_更多.置可视(false);
				}





			}
		}
	}
}
function CYS超级列表框1_按钮被单击(项目索引){
	var 标记= CYS超级列表框1.取项目标记(项目索引);
	if(标记 == "warehouse_info" ){
		获取仓库状态();
	}
	if(标记 == "login-out" ){
		if(HPtools1.询问框("是否重新登陆？") == true ){
			if(agid < 1 && agent_oper == "" ){
				窗口操作.切换窗口("index.html");
			}else if(agid > 0 ){
				窗口操作.切换窗口("index.html?agid=" + String(agid));
			}else if(agent_oper != "" ){
				窗口操作.切换窗口("index.html?agent=" + agent_oper);
			}
			return;
		}
	}
}
function 按钮组_发送_被单击(按钮索引){
	if(按钮索引 < 1 ){
		if(提取确认 == true ){
			if(HPtools1.询问框("是否提取"+String(warehouse_num)+"条游戏资源？") == false ){
				return;
			}
		}
		m_post = 公用模块.生成提交数据(0, "warehouse_info", "", "send" , 0, 0);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/warehouse", m_token);
		美化等待框1.默认等待框("正在交互","正在发送到游戏中,请稍等......");
		时钟1.开始执行(200,false);
	}else{
		m_post = 公用模块.生成提交数据(0, "warehouse_info", "", "select" , 1, 0);
		高级列表框1.清空项目();
		按钮组_更多.置可视(false);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/warehouse", m_token);
		美化等待框1.默认等待框("正在交互","正在获取资源列表,请稍等......");
		时钟1.开始执行(200,false);
	}
}
function 按钮组_更多_被单击(按钮索引){
	if(按钮索引 < 1 ){
		if(m_json.page < m_json.total ){
			m_post = 公用模块.生成提交数据(0, "warehouse_info", "", "select" , m_json.page+1, 0);
			m_url = 公用模块.生成访问链接(根地址,"api/shop/warehouse", m_token);
			美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
			时钟1.开始执行(200,false);
		}else{
			仔仔弹出对话框1.成功("已全部加载！");
		}
	}else{
		窗口操作.滚动到顶部();
	}
}
function 高级列表框1_表项被单击(项目索引,项目图片,项目标题,项目信息,项目标记){
	var num= 转换操作.到数值(项目标记);
	div_warehouse_inout_no.置内容(m_json.results[num].inout_no);
	div_warehouse_time.置标题("操作时间：" + m_json.results[num].oper_time);
	div_warehouse_sku.置标题("对应SKU/编码："+m_json.results[num].info_no);
	div_warehouse_oper_note.置内容(m_json.results[num].oper_note);
	div_warehouse_popover.显示();
}