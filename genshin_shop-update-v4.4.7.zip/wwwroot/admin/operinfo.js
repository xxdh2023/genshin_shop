mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 自由面板1 = new 自由面板("自由面板1","145px");
var 自由面板_标签 = new 标签("自由面板_标签",null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var 标签1 = new 标签("标签1",null);
var div_oper_static_1_ = new 单选框("div_oper_static_1_",div_oper_static_1__被单击);
var div_oper_static_0 = new 单选框("div_oper_static_0",div_oper_static_0_被单击);
var div_oper_static_1 = new 单选框("div_oper_static_1",div_oper_static_1_被单击);
var 标签2 = new 标签("标签2",null);
var div_oper_model_1_ = new 单选框("div_oper_model_1_",div_oper_model_1__被单击);
var div_oper_model_0 = new 单选框("div_oper_model_0",div_oper_model_0_被单击);
var div_oper_model_1 = new 单选框("div_oper_model_1",div_oper_model_1_被单击);
var div_rebate_popover = new 弹出面板("div_rebate_popover",null,null);
var div_rebate_lable_1 = new 标签("div_rebate_lable_1",null);
var div_rebate_realname = new 编辑框("div_rebate_realname",null,null,null,null,null);
var div_rebate_dropbox = new 下拉框("div_rebate_dropbox",div_rebate_dropbox_表项被单击);
var div_rebate_lable_2 = new 标签("div_rebate_lable_2",null);
var div_rebate_account = new 编辑框("div_rebate_account",null,null,null,null,null);
var div_rebate_btn = new 按钮("div_rebate_btn",div_rebate_btn_被单击,null,null);
var div_rebate_lable_3 = new 标签("div_rebate_lable_3",null);
var div_rebate_pic = new 图片框("div_rebate_pic",div_rebate_pic_被单击);
var div_rebate_pic_base64 = new 标签("div_rebate_pic_base64",null);
var 文件选择器1 = new 文件选择器("文件选择器1",文件选择器1_选择完毕,文件选择器1_读入完毕,null);
var div_oper_id = new 标签("div_oper_id",null);
var div_static_popover = new 弹出面板("div_static_popover",null,null);
var div_static_lable = new 标签("div_static_lable",null);
var div_static_sbox = new 复选框("div_static_sbox",null);
var div_static_edit = new 编辑框("div_static_edit",null,null,null,null,null);
var div_static_btn = new 按钮("div_static_btn",div_static_btn_被单击,null,null);
var div_static_show = new 标签("div_static_show",null);
var div_vip_popover = new 弹出面板("div_vip_popover",null,null);
var div_vip_lable = new 标签("div_vip_lable",null);
var div_vip_dropbox = new 下拉框("div_vip_dropbox",div_vip_dropbox_表项被单击);
var div_vip_btn = new 按钮("div_vip_btn",div_vip_btn_被单击,null,null);
var div_agent_popover = new 弹出面板("div_agent_popover",null,null);
var div_agent_lable = new 标签("div_agent_lable",null);
var div_agent_value = new 编辑框("div_agent_value",null,null,null,null,null);
var div_agent_select = new 按钮("div_agent_select",div_agent_select_被单击,null,null);
var div_agent_dropbox = new 下拉框("div_agent_dropbox",div_agent_dropbox_表项被单击);
var div_agent_btn = new 按钮("div_agent_btn",div_agent_btn_被单击,null,null);
var div_uid_popover = new 弹出面板("div_uid_popover",null,null);
var div_uid_lable = new 标签("div_uid_lable",null);
var div_uid_uid = new 编辑框("div_uid_uid",null,null,null,null,null);
var div_uid_day = new 编辑框("div_uid_day",null,null,null,null,null);
var div_uid_btn = new 按钮("div_uid_btn",div_uid_btn_被单击,null,null);
var div_uid_show = new 标签("div_uid_show",null);
var div_oper_popover = new 弹出面板("div_oper_popover",null,null);
var div_oper_lable = new 标签("div_oper_lable",null);
var div_oper_email = new 编辑框("div_oper_email",null,null,null,null,null);
var div_oper_dropbox = new 下拉框("div_oper_dropbox",div_oper_dropbox_表项被单击);
var div_oper_answer = new 编辑框("div_oper_answer",null,null,null,null,null);
var div_oper_btn = new 按钮("div_oper_btn",div_oper_btn_被单击,null,null);
var div_warehouse_popover = new 弹出面板("div_warehouse_popover",null,null);
var div_warehouse_lable = new 标签("div_warehouse_lable",null);
var div_warehouse_oper_login = new 编辑框("div_warehouse_oper_login",null,null,null,null,null);
var div_warehouse_select = new 按钮("div_warehouse_select",div_warehouse_select_被单击,null,null);
var div_warehouse_msg = new 编辑框("div_warehouse_msg",null,null,null,null,null);
var div_warehouse_btn = new 按钮("div_warehouse_btn",div_warehouse_btn_被单击,null,null);
var div_warehouse_show = new 标签("div_warehouse_show",null);
var div_reset_popover = new 弹出面板("div_reset_popover",null,null);
var div_reset_lable_1 = new 标签("div_reset_lable_1",null);
var div_reset_oper_login = new 编辑框("div_reset_oper_login",null,null,null,null,null);
var div_reset_lable_2 = new 标签("div_reset_lable_2",null);
var div_reset_password = new 编辑框("div_reset_password",null,null,null,null,null);
var div_reset_btns = new 按钮组("div_reset_btns",div_reset_btns_被单击);
var 仔仔1 = new 仔仔("仔仔1",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null);
var div_invest_zero_popover = new 弹出面板("div_invest_zero_popover",null,null);
var div_invest_zero_lable_1 = new 标签("div_invest_zero_lable_1",null);
var div_invest_zero_login = new 编辑框("div_invest_zero_login",null,null,null,null,null);
var div_invest_zero_lable_2 = new 标签("div_invest_zero_lable_2",null);
var div_invest_zero_num = new 编辑框("div_invest_zero_num",null,null,null,null,null);
var div_invest_zero_btn = new 按钮("div_invest_zero_btn",div_invest_zero_btn_被单击,null,null);
var div_ware_info_popover = new 弹出面板("div_ware_info_popover",null,null);
var div_ware_info_lable_1 = new 标签("div_ware_info_lable_1",null);
var div_ware_info_game_user = new 编辑框("div_ware_info_game_user",null,null,null,null,null);
var div_ware_info_lable_2 = new 标签("div_ware_info_lable_2",null);
var div_ware_info_send_time = new 按钮("div_ware_info_send_time",div_ware_info_send_time_被单击,null,null);
var div_ware_info_btn = new 按钮("div_ware_info_btn",div_ware_info_btn_被单击,null,null);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
if(mui.os.plus){
    mui.plusReady(function() {
        用户管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        用户管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var oper_static= -1;
var oper_model= -1;
var 表格数据 = new Array();
var rebate_model= 0;
var vip_grade_id= "";
var agent_login= "";
var oper_question= "";
var invest_zero= 0;
function 用户管理_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password异常,请重新登陆！"),"");
		return;
	}
	根地址 = HPtools1.取URL();
	调整组件尺寸();
	高级表格初始化();
	弹出面板初始化();
	CYS日期时间选择器1.初始化(0, 2024, 2099);
	m_post = "";
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/invest_zero", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}

function 调整组件尺寸(){
	var width= 窗口操作.取窗口宽度();
	公用模块.自由面板_调整("自由面板_标签", 166, 100, 941,width);
	公用模块.自由面板_调整("自由面板_编辑框_条件", 265, 469, 941,width);
	公用模块.自由面板_调整("自由面板_按钮_查询", 740, 100, 941,width);
	公用模块.自由面板_调整("自由面板_按钮_添加", 6, 160, 941,width);
	div_oper_static_1_.置选中状态(true);
	div_oper_static_1_.置分组("A");
	div_oper_static_0.置分组("A");
	div_oper_static_1.置分组("A");
	div_oper_model_1_.置选中状态(true);
	div_oper_model_1_.置分组("B");
	div_oper_model_0.置分组("B");
	div_oper_model_1.置分组("B");
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_rebate_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_rebate_popover.添加组件("div_rebate_lable_1");
	div_rebate_popover.添加组件("div_rebate_realname");
	div_rebate_popover.添加组件("div_rebate_dropbox");
	div_rebate_popover.添加组件("div_rebate_lable_2");
	div_rebate_popover.添加组件("div_rebate_account");
	div_rebate_popover.添加组件("div_rebate_btn");
	div_rebate_popover.添加组件("div_rebate_lable_3");
	div_rebate_popover.添加组件("div_rebate_pic");
	div_rebate_dropbox.清空项目();
	div_rebate_dropbox.添加项目("支付宝","0");
	div_rebate_dropbox.添加项目("微信","1");
	div_rebate_dropbox.置现行选中项(0);
	var rect = 公用模块.弹出面板初始化计算(50, 240, false);
	div_static_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_static_popover.添加组件("div_static_lable");
	div_static_popover.添加组件("div_static_sbox");
	div_static_popover.添加组件("div_static_edit");
	div_static_popover.添加组件("div_static_btn");
	div_static_popover.添加组件("div_static_show");
	var rect = 公用模块.弹出面板初始化计算(50, 120, false);
	div_vip_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_vip_popover.添加组件("div_vip_lable");
	div_vip_popover.添加组件("div_vip_dropbox");
	div_vip_popover.添加组件("div_vip_btn");
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_agent_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_agent_popover.添加组件("div_agent_lable");
	div_agent_popover.添加组件("div_agent_value");
	div_agent_popover.添加组件("div_agent_select");
	div_agent_popover.添加组件("div_agent_dropbox");
	div_agent_popover.添加组件("div_agent_btn");
	var rect = 公用模块.弹出面板初始化计算(50, 220, false);
	div_uid_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_uid_popover.添加组件("div_uid_lable");
	div_uid_popover.添加组件("div_uid_uid");
	div_uid_popover.添加组件("div_uid_day");
	div_uid_popover.添加组件("div_uid_btn");
	div_uid_popover.添加组件("div_uid_show");
	var rect = 公用模块.弹出面板初始化计算(50, 220, false);
	div_oper_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_oper_popover.添加组件("div_oper_lable");
	div_oper_popover.添加组件("div_oper_email");
	div_oper_popover.添加组件("div_oper_dropbox");
	div_oper_popover.添加组件("div_oper_answer");
	div_oper_popover.添加组件("div_oper_btn");
	div_oper_dropbox.添加项目("请选择重置密码问题......","");
	div_oper_dropbox.添加项目("您所在的城市","您所在的城市");
	div_oper_dropbox.添加项目("您所在的国家","您所在的国家");
	div_oper_dropbox.添加项目("您最难忘的事是什么","您最难忘的事是什么");
	div_oper_dropbox.添加项目("您最难忘的是哪句话","您最难忘的是哪句话");
	var rect = 公用模块.弹出面板初始化计算(50, 260, false);
	div_warehouse_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_warehouse_popover.添加组件("div_warehouse_lable");
	div_warehouse_popover.添加组件("div_warehouse_oper_login");
	div_warehouse_popover.添加组件("div_warehouse_select");
	div_warehouse_popover.添加组件("div_warehouse_msg");
	div_warehouse_popover.添加组件("div_warehouse_btn");
	div_warehouse_popover.添加组件("div_warehouse_show");
	div_warehouse_msg.置只读模式(true);
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_reset_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_reset_popover.添加组件("div_reset_lable_1");
	div_reset_popover.添加组件("div_reset_oper_login");
	div_reset_popover.添加组件("div_reset_lable_2");
	div_reset_popover.添加组件("div_reset_password");
	div_reset_popover.添加组件("div_reset_btns");
	div_reset_btns.置样式(0,"mui-btn mui-btn-success");
	var rect = 公用模块.弹出面板初始化计算(50, 240, false);
	div_invest_zero_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_invest_zero_popover.添加组件("div_invest_zero_lable_1");
	div_invest_zero_popover.添加组件("div_invest_zero_login");
	div_invest_zero_popover.添加组件("div_invest_zero_lable_2");
	div_invest_zero_popover.添加组件("div_invest_zero_num");
	div_invest_zero_popover.添加组件("div_invest_zero_btn");

	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_ware_info_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_ware_info_popover.添加组件("div_ware_info_lable_1");
	div_ware_info_popover.添加组件("div_ware_info_game_user");
	div_ware_info_popover.添加组件("div_ware_info_lable_2");
	div_ware_info_popover.添加组件("div_ware_info_send_time");
	div_ware_info_popover.添加组件("div_ware_info_btn");



}
function 高级表格初始化(){
	高级表格1.添加列("xz","",0,false,false,false,false,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",440,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("oper_login","账号",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_name","昵称",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_static","状态",100,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_model","类型",100,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("agent_re_scale","返佣比例",80,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("agent_oper","上级代理",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("coin_sum_all","剩余平台币",100,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("coin_sum_ava","可用/提现平台币",130,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("coin_sum_freeze","冻结平台币",100,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("coin_sum_in","历史总充值平台币",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("agent_level","代理等级",100,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("game_uid","绑定UID",80,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("create_time","注册时间",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("login_time","最后登陆时间",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("band_time","封禁时间",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("vip","VIP等级",250,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_email","电子邮箱",180,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_question","重置密码问题",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("oper_answer","重置密码答案",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("rebate_realname","提现真实姓名",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("rebate_model","提现类型",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("rebate_account","提现支付宝/微信账号",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(4,false,"封禁游戏UID");
	高级表格1.添加工具栏按钮(2,false,"解封游戏UID");
	高级表格1.添加工具栏按钮(1,false,"清空指定玩家仓库资源");
	高级表格1.添加工具栏按钮(3,false,"重置用户密码");
	高级表格1.添加工具栏按钮(1,true,"重置玩家仓库资源状态");

	高级表格1.初始化("auto",true,true,false,true);
}


function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info" && json.model == "delete" ){
				高级表格1.删除行(转换操作.到数值(json.comm));
				高级表格1.初始化("auto",true,true,false,true);
				仔仔弹出对话框1.成功("删除成功！");
			}else if(json.table == "oper_login_info_static" ){
				div_static_popover.隐藏();
				仔仔弹出对话框1.成功("调整成功,请重新查询！");
			}else if(json.table == "oper_login_info_agent" ){
				div_agent_popover.隐藏();
				仔仔弹出对话框1.成功("调整成功,请重新查询！");
			}else if(json.table == "oper_login_info_vip" ){
				div_vip_popover.隐藏();
				仔仔弹出对话框1.成功("调整成功,请重新查询！");
			}else if(json.table == "oper_login_info_other" ){
				div_oper_popover.隐藏();
				仔仔弹出对话框1.成功("修改成功,请重新查询！");
			}else if(json.table == "warehouse_info_static_0" ){
				div_warehouse_popover.隐藏();
				仔仔弹出对话框1.成功("已完成清理操作！");
			}else if(json.table == "invest_zero" ){
				高级表格1.清空工具栏按钮();
				高级表格1.添加工具栏按钮(4,false,"封禁游戏UID");
				高级表格1.添加工具栏按钮(2,false,"解封游戏UID");
				高级表格1.添加工具栏按钮(1,false,"清空指定玩家仓库资源");
				高级表格1.添加工具栏按钮(3,false,"重置用户密码");
				高级表格1.添加工具栏按钮(1,true,"重置玩家仓库资源状态");
				if(json.msg == 1 ){
					高级表格1.添加工具栏按钮(2,false,"重置玩家累充计算");
				}
				invest_zero = json.msg;
				高级表格1.初始化("auto",true,true,false,true);
				查询数据();
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}


		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "oper_login_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "";
						arr[3] = json.results[i].oper_login;
						arr[4] = json.results[i].oper_name;
						arr[5] = "正常";
						if(json.results[i].oper_static < 1 ){
							arr[5] = "已被封禁";
						}
						arr[6] = "玩家账号";
						arr[7] = "-";
						if(json.results[i].oper_model > 0 ){
							arr[6] = "代理账号";
							arr[7] = ""+json.results[i].agent_re_scale+"%";
						}
						arr[8] = "-";
						if(json.results[i].agent_oper != "" ){
							arr[8] = json.results[i].agent_oper + " :: " + json.results[i].agent_name;
						}
						arr[9] = json.results[i].coin_sum_all;
						arr[10] = json.results[i].coin_sum_ava;
						arr[11] = json.results[i].coin_sum_freeze;
						arr[12] = json.results[i].coin_sum_in;
						arr[13] = "-";
						arr[14] = json.results[i].game_uid;
						if(json.results[i].oper_model > 0 ){
							arr[13] = ""+json.results[i].agent_level+"级代理";
							arr[14] = "-";
						}
						arr[15] = json.results[i].create_time;
						arr[16] = json.results[i].login_time;
						arr[17] = "-";
						if(json.results[i].oper_static < 1 ){
							arr[17] = json.results[i].band_time;
						}
						arr[18] = "-";
						if(json.results[i].oper_model < 1 && json.results[i].vip_id != "" ){
							arr[18] = json.results[i].vip_id+" :: "+json.results[i].vip_name;
						}
						arr[19] = json.results[i].oper_email;
						arr[20] = json.results[i].oper_question;
						arr[21] = json.results[i].oper_answer;
						arr[22] = "";
						arr[23] = "";
						arr[24] = "";
						if(json.results[i].oper_model > 0 ){
							arr[22] = json.results[i].rebate_realname;
							arr[23] = "支付宝";
							if(json.results[i].rebate_model > 0 ){
								arr[23] = "微信";
							}
							arr[24] = json.results[i].rebate_account;
						}
						高级表格1.添加行(true,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(2,false,"修改");
					高级表格1.添加操作栏按钮(3,false,"修改提现设置");
					高级表格1.添加操作栏按钮(1,false,"解封");
					高级表格1.添加操作栏按钮(4,false,"封禁");
					高级表格1.添加操作栏按钮(2,false,"调整VIP等级");
					高级表格1.添加操作栏按钮(1,false,"调整上级代理");
					高级表格1.初始化("auto",true,true,false,true);
				}
			}else if(json.table == "oper_login_info_cash" ){
				div_rebate_realname.置内容(json.results[0].rebate_realname);
				div_rebate_account.置内容(json.results[0].rebate_account);
				div_rebate_dropbox.置现行选中项(json.results[0].rebate_model);
				rebate_model = json.results[0].rebate_model;
				if(json.results[0].rebate_pic == "" ){
					div_rebate_pic.置图片("images/setpic.jpg");
				}else{
					div_rebate_pic.置图片(json.results[0].rebate_pic);
				}
				div_rebate_popover.显示();
			}else if(json.table == "vip_grade_info_all" ){
				vip_grade_id = "";
				div_vip_dropbox.清空项目();
				div_vip_dropbox.添加项目("请选择要修改的VIP......", "");
				while(i < json.results.length){
					div_vip_dropbox.添加项目(json.results[i].vip_id+" :: "+json.results[i].vip_name, json.results[i].vip_id);
					i++
				}
				div_vip_popover.显示();
			}else if(json.table == "oper_login_info_agent" ){
				agent_login = "";
				div_agent_dropbox.清空项目();
				div_agent_dropbox.添加项目("请选择要调整的上级代理......", "");
				var str= "";
				while(i < json.results.length){
					str = "[顶级代理]";
					if(json.results[i].agent_oper != "" ){
							str = "[上级代理："+json.results[i].agent_oper+" :: "+json.results[i].agent_name+"]";
					}
					div_agent_dropbox.添加项目(json.results[i].oper_login+" :: "+json.results[i].oper_login+str, json.results[i].oper_login);
					i++
				}

			}else if(json.table == "warehouse_info_static_0" ){
				if(json.results[0].oper_model > 0 ){
					仔仔弹出对话框1.错误("代理账号不能进行此操作！");
				}else{
					var str= "玩家昵称："+ json.results[0].oper_name;
					if(json.results[0].num < 1 ){
						仔仔弹出对话框1.错误("当前玩家无需清理平台仓库");
						return;
					}
					div_warehouse_msg.置内容(str+"\n当前仓库内可清理的资源数量："+转换操作.到文本(json.results[0].num));
				}

			}




		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	var json= {}
	json.oper_static = oper_static;
	json.oper_model = oper_model;
	m_post = 公用模块.生成提交数据(0, "oper_login_info", value, "" , 1, 0, json);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}
function div_oper_static_1__被单击(){
	oper_static = -1;
}
function div_oper_static_0_被单击(){
	oper_static = 0;
}
function div_oper_static_1_被单击(){
	oper_static = 1;
}
function div_oper_model_1__被单击(){
	oper_model = -1;
}
function div_oper_model_0_被单击(){
	oper_model = 0;
}
function div_oper_model_1_被单击(){
	oper_model = 1;
}
function 按钮_底部_被单击(){
	var json= {}
	json.oper_static = oper_static;
	json.oper_model = oper_model;
	m_post = 公用模块.生成提交数据(0, "oper_login_info", value, "" , page+1, 0, json);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	时钟1.开始执行(200,false);
}
function 自由面板_按钮_添加_被单击(){
	公用模块.居中打开小窗口("operinfone.html?password="+m_password+"&ID=0", 1000, 700);
}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
	case 0 :
		div_oper_id.置标题(""+_id);
		div_oper_email.置内容("");
		div_oper_answer.置内容("");
		oper_question = "";
		div_oper_dropbox.置现行选中项(0);
		div_oper_popover.显示();
	break;
	case 1 :


		if(行数据["oper_model"] == "玩家账号" ){
			仔仔弹出对话框1.错误("玩家账号不能进行此设置");
			return;
		}
		div_oper_id.置标题(""+_id);
		m_post = 公用模块.生成提交数据(_id, "oper_login_info_cash", "", "select" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		时钟1.开始执行(200,false);
	break;
	case 2 :

		if(HPtools1.询问框("是否进行解封操作？") == true ){
			var json= {}
			json.oper_static = 1;
			json.band_game = 1;
			json.band_day = 0;
			json.id = _id;
			m_post = 公用模块.生成提交数据(0, "oper_login_info_static", "", "update" , 1, 0, json);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
			美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
			时钟1.开始执行(200,false);
		}
	break;
	case 3 :

		if(行数据["oper_model"] != "玩家账号" ){
			if(HPtools1.询问框("是否进行封禁操作？") == true ){
				var json= {}
				json.oper_static = 0;
				json.id = _id;
				m_post = 公用模块.生成提交数据(0, "oper_login_info_static", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
				时钟1.开始执行(200,false);
			}
		}else{
			div_oper_id.置标题(""+_id);
			div_static_popover.显示();

		}

	break;
	case 4 :

		if(行数据["oper_model"] != "玩家账号" ){
			仔仔弹出对话框1.错误("代理账号不能进行此设置");
			return;
		}
		div_oper_id.置标题(""+_id);
		m_post = 公用模块.生成提交数据(0, "vip_grade_info_all", "", "" , 0, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在交互,请稍等......");
		时钟1.开始执行(200,false);
	break;
	case 5 :

		if(行数据["oper_model"] != "玩家账号" ){
			仔仔弹出对话框1.错误("代理账号不能进行此设置");
			return;
		}
		div_oper_id.置标题(""+_id);
		div_agent_popover.显示();





		break;
	}
}
function div_rebate_dropbox_表项被单击(项目索引,项目标题,项目标记){
	rebate_model = 转换操作.到数值(项目标记);
}
function div_rebate_pic_被单击(){
	文件选择器1.限制类型("image/jpeg,image/png,image/bmp");
	文件选择器1.开始选择();
}
function 文件选择器1_选择完毕(文件路径,文件对象){
	文件选择器1.读入文件(文件对象,2);
}
function 文件选择器1_读入完毕(结果,内容){
	div_rebate_pic.置图片(内容);
	var data= "";
	var i= 文本操作.倒找文本(内容,",");
	if(i > -1 ){
		data = 文本操作.取文本右边(内容,文本操作.取文本长度(内容) - i - 1);
	}else{
		data = 内容;
	}
	div_rebate_pic_base64.置标题(data);
}
function div_rebate_btn_被单击(){
	div_rebate_realname.置内容(文本操作.删首尾空(div_rebate_realname.取内容()));
	if(div_rebate_realname.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写真实姓名");
		return;
	}
	div_rebate_account.置内容(文本操作.删首尾空(div_rebate_account.取内容()));
	if(div_rebate_account.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写支付宝/微信账号");
		return;
	}
	if(div_rebate_pic_base64.取标题() == "" ){
		仔仔弹出对话框1.错误("请添加收款二维码");
		return;
	}
	var json= {}
	json.id = 转换操作.到数值(div_oper_id.取标题());
	json.rebate_realname = div_rebate_realname.取内容();
	json.rebate_model = rebate_model;
	json.rebate_account = div_rebate_account.取内容();
	json.rebate_pic = div_rebate_pic_base64.取标题();
	m_post = 公用模块.生成提交数据(0, "oper_login_info_cash", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
	时钟1.开始执行(200,false);
}
function div_static_btn_被单击(){
	div_static_edit.置内容(文本操作.删首尾空(div_static_edit.取内容()));
	var band_game= 0;
	if(div_static_sbox.取选中状态() == true ){
		band_game = 1;
	}
	var band_day= 转换操作.到数值(div_static_edit.取内容());
	if(band_game == 1 ){
		if(div_static_edit.取内容() == "" ){
			仔仔弹出对话框1.错误("请设置封禁天数！");
			return;
		}
		if(band_day < 1 ){
			仔仔弹出对话框1.错误("封禁天数必须大于0！");
			return;
		}
	}
	var json= {}
	json.oper_static = 0;
	json.id = 转换操作.到数值(div_oper_id.取标题());
	json.band_game = band_game;
	json.band_day = band_day;
	m_post = 公用模块.生成提交数据(0, "oper_login_info_static", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
	时钟1.开始执行(200,false);
}
function div_vip_dropbox_表项被单击(项目索引,项目标题,项目标记){
	vip_grade_id = 项目标记;
}
function div_vip_btn_被单击(){
	if(vip_grade_id == "" ){
		仔仔弹出对话框1.错误("请选择新的VIP等级！");
		return;
	}
	var json= {}
	json.vip = vip_grade_id;
	json.id = 转换操作.到数值(div_oper_id.取标题());
	m_post = 公用模块.生成提交数据(0, "oper_login_info_vip", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
	时钟1.开始执行(200,false);
}


function div_agent_btn_被单击(){
	if(agent_login == "" ){
		仔仔弹出对话框1.错误("请选择新的上级代理！");
		return;
	}
	var json= {}
	json.agent = agent_login;
	json.id = 转换操作.到数值(div_oper_id.取标题());
	m_post = 公用模块.生成提交数据(0, "oper_login_info_agent", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
	时钟1.开始执行(200,false);
}
function div_agent_dropbox_表项被单击(项目索引,项目标题,项目标记){
	agent_login = 项目标记;
}
function 高级表格1_工具栏按钮被单击(按钮索引){
	switch(按钮索引){
		case 0 :

			div_uid_popover.显示();
		break;
		case 1 :

			var str= HPtools1.输入框("请输入要解封的游戏UID：");
			str = 文本操作.删首尾空(str);
			if(str == "" ){
				return;
			}
			str = 转换操作.到数值(str);
			if(str < 1 ){
				仔仔弹出对话框1.错误("请输入有效的游戏UID");
				return;
			}
			var json= {}
			json.uid = str;
			json.day = 0;
			m_post = 公用模块.生成提交数据(0, "config", "", "unband" , 1, 0, json);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/uid_band", m_password);
			美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
			时钟1.开始执行(200,false);
		break;
		case 2 :
			div_warehouse_msg.置内容("");
			div_warehouse_oper_login.置内容("");
			div_warehouse_popover.显示();
		break;
		case 3 :
			div_reset_oper_login.置内容("");
			div_reset_password.置内容("");
			div_reset_popover.显示();
		break;
		case 4 :
			div_ware_info_game_user.置内容("");
			div_ware_info_popover.显示();
		break;
		case 5 :
			if(invest_zero != 1 ){
				return;
			}
			div_invest_zero_popover.显示();
		break;
	}
}
function div_uid_btn_被单击(){
	div_uid_uid.置内容(文本操作.删首尾空(div_uid_uid.取内容()));
	div_uid_day.置内容(文本操作.删首尾空(div_uid_day.取内容()));
	if(div_uid_uid.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入游戏UID");
		return;
	}
	var uid= 转换操作.到数值(div_uid_uid.取内容());
	if(uid < 1 ){
		仔仔弹出对话框1.错误("输入的游戏UID无效");
		return;
	}
	if(div_uid_day.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入封禁天数");
		return;
	}
	var day= 转换操作.到数值(div_uid_day.取内容());
	if(day < 1 ){
		仔仔弹出对话框1.错误("输入的封禁天数无效");
		return;
	}
	var json= {}
	json.uid = uid;
	json.day = day;
	m_post = 公用模块.生成提交数据(0, "config", "", "band" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/uid_band", m_password);
	美化等待框1.默认等待框("正在交互","正在调整,请稍等......");
	时钟1.开始执行(200,false);
}
function div_oper_dropbox_表项被单击(项目索引,项目标题,项目标记){
	oper_question = 项目标记;
}
function div_oper_btn_被单击(){
	div_oper_email.置内容(文本操作.删首尾空(div_oper_email.取内容()));
	if(div_oper_email.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入电子邮箱");
		return;
	}
	if(oper_question == "" ){
		仔仔弹出对话框1.错误("请选择重置密码的问题");
		return;
	}
	div_oper_answer.置内容(文本操作.删首尾空(div_oper_answer.取内容()));
	if(div_oper_answer.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入重置密码的答案");
		return;
	}

	var json= {}
	json.id = 转换操作.到数值(div_oper_id.取标题());
	json.email = div_oper_email.取内容();
	json.question = oper_question;
	json.answer = div_oper_answer.取内容();
	m_post = 公用模块.生成提交数据(0, "oper_login_info_other", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在更新,请稍等......");
	时钟1.开始执行(200,false);

}
function div_warehouse_select_被单击(){
	div_warehouse_oper_login.置内容(文本操作.删首尾空(div_warehouse_oper_login.取内容()));
	if(div_warehouse_oper_login.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入玩家平台账号");
		return;
	}
	div_warehouse_msg.置内容("");
	var json= {}
	json.oper_login = div_warehouse_oper_login.取内容();
	m_post = 公用模块.生成提交数据(0, "warehouse_info_static_0", "", "select" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}
function div_warehouse_btn_被单击(){
	div_warehouse_oper_login.置内容(文本操作.删首尾空(div_warehouse_oper_login.取内容()));
	if(div_warehouse_oper_login.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入玩家平台账号");
		return;
	}
	if(div_warehouse_msg.取内容() == "" ){
		仔仔弹出对话框1.错误("请先进行查询");
		return;
	}
	var json= {}
	json.oper_login = div_warehouse_oper_login.取内容();
	m_post = 公用模块.生成提交数据(0, "warehouse_info_static_0", "", "update" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在清理,请稍等......");
	时钟1.开始执行(200,false);
}
function div_reset_btns_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			div_reset_password.置内容(""+仔仔1.命令_取随机数6(6));
		break;
		case 1 :
			div_reset_oper_login.置内容(文本操作.删首尾空(div_reset_oper_login.取内容()));
			div_reset_password.置内容(文本操作.删首尾空(div_reset_password.取内容()));
			if(div_reset_oper_login.取内容() == "" ){
				仔仔弹出对话框1.错误("请输入平台账号");
				return;
			}
			if(div_reset_password.取内容() == "" ){
				仔仔弹出对话框1.错误("请输入新密码");
				return;
			}
			var str= 加密操作1.取md5值(div_reset_password.取内容());
			m_post = 公用模块.生成提交数据(0,"oper_reset_pwd", "","update",0,0,"",div_reset_oper_login.取内容(),""+str);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
			美化等待框1.默认等待框("正在交互","正在修改,请稍等......");
			时钟1.开始执行(200,false);
		break;
	}
}
function div_invest_zero_btn_被单击(){
	div_invest_zero_login.置内容(文本操作.删首尾空(div_invest_zero_login.取内容()));
	div_invest_zero_num.置内容(文本操作.删首尾空(div_invest_zero_num.取内容()));
	if(div_invest_zero_login.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入平台游戏账号");
		return;
	}
	if(div_invest_zero_num.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入重置需要减少的平台币数量");
		return;
	}
	var num= 转换操作.到数值(div_invest_zero_num.取内容());
	if(num < 1 ){
		仔仔弹出对话框1.错误("请输入重置需要减少的平台币数量");
		return;
	}
	if(HPtools1.询问框("是否重置？请谨慎操作！") == false ){
		return;
	}
	var json= {}
	json.invest_zero = num;
	var str= 加密操作1.取md5值(div_reset_password.取内容());
	m_post = 公用模块.生成提交数据(0,"invest_zero_ded", "","update",0,0,json,div_invest_zero_login.取内容());
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在处理,请稍等......");
	时钟1.开始执行(200,false);
}
function div_agent_select_被单击(){
	div_agent_value.置内容(文本操作.删首尾空(div_agent_value.取内容()));
	m_post = 公用模块.生成提交数据(0, "oper_login_info_agent", div_agent_value.取内容(), "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在交互,请稍等......");
	时钟1.开始执行(200,false);
}
function div_ware_info_send_time_被单击(){
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(时);
	if(时 < 10 ){
		m = "0" + m;
	}
	res = res +" "+ m;
	m = 转换操作.到文本(分);
	if(分 < 10 ){
		m = "0" + m;
	}
	res = res +":"+ m+":00";
	div_ware_info_send_time.置标题(res);
}
function div_ware_info_btn_被单击(){
	div_ware_info_game_user.置内容(文本操作.删首尾空(div_ware_info_game_user.取内容()));
	if(div_ware_info_game_user.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入玩家账号！");
		return;
	}
	if(div_ware_info_send_time.取标题() == "0000-00-00 00:00:00" ){
		仔仔弹出对话框1.错误("请指定时间！");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "warehouse_info_reset", div_ware_info_send_time.取标题(), "update", 0, 0, "", div_ware_info_game_user.取内容());
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","正在交互,请稍等......");
	时钟1.开始执行(200,false);

}