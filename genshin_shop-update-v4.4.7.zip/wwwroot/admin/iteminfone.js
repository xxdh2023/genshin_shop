mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var div_item_id_edit = new 编辑框("div_item_id_edit",null,null,null,null,null);
var 标签1 = new 标签("标签1",null);
var div_item_name_edit = new 编辑框("div_item_name_edit",null,null,null,null,null);
var 标签2 = new 标签("标签2",null);
var 自由面板1 = new 自由面板("自由面板1","176px");
var div_item_model_0 = new 单选框("div_item_model_0",null);
var div_item_model_1 = new 单选框("div_item_model_1",null);
var div_item_model_2 = new 单选框("div_item_model_2",null);
var div_item_model_3 = new 单选框("div_item_model_3",null);
var div_item_model_4 = new 单选框("div_item_model_4",null);
var div_item_model_5 = new 单选框("div_item_model_5",null);
var div_item_model_6 = new 单选框("div_item_model_6",null);
var div_item_model_7 = new 单选框("div_item_model_7",null);
var div_item_model_8 = new 单选框("div_item_model_8",null);
var div_item_model_9 = new 单选框("div_item_model_9",null);
var 自由面板_下拉框 = new 下拉框("自由面板_下拉框",自由面板_下拉框_表项被单击);
var 自由面板_按钮_刷新 = new 按钮("自由面板_按钮_刷新",自由面板_按钮_刷新_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
var div_item_maxnum_edit = new 编辑框("div_item_maxnum_edit",null,null,null,null,null);
var 按钮组_操作 = new 按钮组("按钮组_操作",按钮组_操作_被单击);
var 标签3 = new 标签("标签3",null);
if(mui.os.plus){
    mui.plusReady(function() {
        资源档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        资源档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var class_name= "";
var ID= 0;

function 资源档案窗口_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	ID = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("ID")));
	if(m_password == "" ){
		仔仔弹出对话框1.错误("password异常,请关闭后重试！");
		return;
	}
	根地址 = HPtools1.取URL();

	刷新类别();
	按钮组_操作.置样式(0,"mui-btn");
	按钮组_操作.置样式(2,"mui-btn mui-btn-danger");
}
function 调整组件尺寸(){
	var width= 窗口操作.取窗口宽度();

	var rect = new Array();
	rect = 公用模块.自由面板_坐标生成(4, 120, 634,width);

	组件置左边和宽度("div_item_model_0", rect);
	组件置左边和宽度("div_item_model_5", rect);
	rect = 公用模块.自由面板_坐标生成(128, 120, 634,width);
	组件置左边和宽度("div_item_model_1", rect);
	组件置左边和宽度("div_item_model_6", rect);
	rect = 公用模块.自由面板_坐标生成(252, 120, 634,width);
	组件置左边和宽度("div_item_model_2", rect);
	组件置左边和宽度("div_item_model_7", rect);
	rect = 公用模块.自由面板_坐标生成(376, 120, 634,width);
	组件置左边和宽度("div_item_model_3", rect);
	组件置左边和宽度("div_item_model_8", rect);
	rect = 公用模块.自由面板_坐标生成(500, 120, 634,width);
	组件置左边和宽度("div_item_model_4", rect);
	组件置左边和宽度("div_item_model_9", rect);
	rect = 公用模块.自由面板_坐标生成(4, 388, 634,width);
	组件置左边和宽度("自由面板_下拉框", rect);
	rect = 公用模块.自由面板_坐标生成(400, 100, 634,width);
	组件置左边和宽度("自由面板_按钮_刷新", rect);
	rect = 公用模块.自由面板_坐标生成(504, 100, 634,width);
	组件置左边和宽度("自由面板_按钮_添加", rect);
}
function 组件置左边和宽度(自由面板组件名称, rect){
	窗口操作.置组件左边(自由面板组件名称,rect[0]);
	窗口操作.置组件宽度(自由面板组件名称,rect[1]);
}
function 刷新类别(){
	m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
	时钟1.开始执行(200,false);
}
function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "item_item_info" ){
				if(json.model == "insert" ){
					ID = 转换操作.到数值(json.msg);
					div_item_id_edit.置只读模式(true);
					仔仔弹出对话框1.成功("添加成功！");
				}else if(json.model == "update" ){
					仔仔弹出对话框1.成功("更新成功！");
				}else if(json.model == "delete" ){
					档案新增();
					仔仔弹出对话框1.成功("删除成功！");
				}



			}else{
				仔仔弹出对话框1.成功("执行成功！");
			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "item_class_info" ){
				class_name = "";
				自由面板_下拉框.清空项目();
				自由面板_下拉框.添加项目("请选择类别......","");
				while(i < json.results.length){
					自由面板_下拉框.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
				if(ID > 0 ){
					m_post = 公用模块.生成提交数据(ID, "item_item_info", "", "read" , 1, 0);
					m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
					美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
					时钟1.开始执行(200,false);
				}
			}else if(json.table == "item_item_info" ){
				档案新增();
				ID = json.results.ID;
				div_item_id_edit.置内容(json.results.item_id);
				div_item_id_edit.置只读模式(true);
				div_item_name_edit.置内容(json.results.item_name);
				while(i < 自由面板_下拉框.取项目总数()){
					if(自由面板_下拉框.取项目标记(i) == json.results.item_class ){
						class_name = json.results.item_class;
						自由面板_下拉框.置现行选中项(i);
						break;
					}
					i++
				}
				switch(json.results.item_model){
					case 0 :
						div_item_model_0.置选中状态(true);
					break;
					case 1 :
						div_item_model_1.置选中状态(true);
					break;
					case 2 :
						div_item_model_2.置选中状态(true);
					break;
					case 3 :
						div_item_model_3.置选中状态(true);
					break;
					case 4 :
						div_item_model_4.置选中状态(true);
					break;
					case 5 :
						div_item_model_5.置选中状态(true);
					break;
					case 6 :
						div_item_model_6.置选中状态(true);
					break;
					case 7 :
						div_item_model_7.置选中状态(true);
					break;
					case 8 :
						div_item_model_8.置选中状态(true);
					break;
					case 9 :
						div_item_model_9.置选中状态(true);
					break;
				}
				if(json.results.item_model == 0 || json.results.item_model == 1 || json.results.item_model == 9 ){
					div_item_maxnum_edit.置可视(true);
					div_item_maxnum_edit.置内容(""+json.results.item_maxnum);
				}

			}




		}
	}
}

function 档案新增(){
	ID = 0;
	div_item_id_edit.置只读模式(false);
	div_item_id_edit.置内容("");
	div_item_name_edit.置内容("");
	div_item_maxnum_edit.置内容("");
	div_item_maxnum_edit.置可视(false);
	div_item_model_0.置选中状态(false);
	div_item_model_1.置选中状态(false);
	div_item_model_2.置选中状态(false);
	div_item_model_3.置选中状态(false);
	div_item_model_4.置选中状态(false);
	div_item_model_5.置选中状态(false);
	div_item_model_6.置选中状态(false);
	div_item_model_7.置选中状态(false);
	div_item_model_8.置选中状态(false);
	div_item_model_9.置选中状态(false);
}

function 自由面板_按钮_刷新_被单击(){
	刷新类别();
}

function 自由面板_按钮_添加_被单击(){
	var class_name= 文本操作.删首尾空(HPtools1.输入框("新的类别名称",""));
	if(class_name != "" ){
		var json= {}
		json.class_name = class_name;
		m_post = 公用模块.生成提交数据(ID, "item_class_info", "", "insert" , 1, 0, json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
		美化等待框1.默认等待框("正在交互","正在添加类别,请稍等......");
		时钟1.开始执行(200,false);



	}
}

function 按钮组_操作_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否新增？") == true ){
				档案新增();
			}
		break;
		case 1 :
			div_item_id_edit.置内容(文本操作.删首尾空(div_item_id_edit.取内容()));
			if(div_item_id_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("档案编码/命令/坐标不能为空！");
				return;
			}
			div_item_name_edit.置内容(文本操作.删首尾空(div_item_name_edit.取内容()));
			if(div_item_name_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("档案名称不能为空！");
				return;
			}
			var item_model= 0;
			var item_control= 0;
			if(div_item_model_0.取选中状态() == true ){
				item_control = 1;
			}else if(div_item_model_1.取选中状态() == true ){
				item_model = 1;
				item_control = 1;
			}else if(div_item_model_2.取选中状态() == true ){
				item_model = 2;
			}else if(div_item_model_3.取选中状态() == true ){
				item_model = 3;
			}else if(div_item_model_4.取选中状态() == true ){
				item_model = 4;
			}else if(div_item_model_5.取选中状态() == true ){
				item_model = 5;
			}else if(div_item_model_6.取选中状态() == true ){
				item_model = 6;
			}else if(div_item_model_7.取选中状态() == true ){
				item_model = 7;
			}else if(div_item_model_8.取选中状态() == true ){
				item_model = 8;
			}else if(div_item_model_9.取选中状态() == true ){
				item_model = 9;
				item_control = 1;
			}else{
				if(ID < 1 ){
					仔仔弹出对话框1.错误("必须选择一种档案类型！");
					return;
				}
			}
			if(class_name == "" ){
				if(ID < 1 ){
					仔仔弹出对话框1.错误("必须选择一种档案类别！");
					return;
				}
			}
			var item_maxnum= 0;
			div_item_maxnum_edit.置内容(文本操作.删首尾空(div_item_maxnum_edit.取内容()));
			if(div_item_maxnum_edit.取内容() == "" ){
				div_item_maxnum_edit.置内容("0");
			}
			item_maxnum = 转换操作.到数值(div_item_maxnum_edit.取内容());
			var json= {}
			json.item_id = div_item_id_edit.取内容();
			json.item_name = div_item_name_edit.取内容();
			json.item_model = item_model;
			json.item_control = item_control;
			json.item_static = 1;
			json.item_maxnum = item_maxnum;
			json.item_class = class_name;
			if(ID < 1 ){
				m_post = 公用模块.生成提交数据(ID, "item_item_info", "", "insert" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
				美化等待框1.默认等待框("正在交互","正在添加档案,请稍等......");
			}else{
				m_post = 公用模块.生成提交数据(ID, "item_item_info", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在更新档案,请稍等......");
			}
			时钟1.开始执行(200,false);

		break;
		case 2 :
			if(ID > 0 ){
				if(HPtools1.询问框("是否删除？") == true ){
					var json= {}
					json.item_id = div_item_id_edit.取内容();
					m_post = 公用模块.生成提交数据(ID, "item_item_info", "", "delete" , 1, 0, json);
					m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
					美化等待框1.默认等待框("正在交互","正在删除档案,请稍等......");
					时钟1.开始执行(200,false);
				}
			}
		break;
	}
}

function 自由面板_下拉框_表项被单击(项目索引,项目标题,项目标记){
	class_name = 项目标记;
}