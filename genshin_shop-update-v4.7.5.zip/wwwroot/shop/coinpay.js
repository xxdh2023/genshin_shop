mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var div_head_panel = new 面板("div_head_panel");
var div_register_title = new 标签("div_register_title",null);
var div_register_close = new 图片框("div_register_close",div_register_close_被单击);
var div_pay_lable_1 = new 标签("div_pay_lable_1",null);
var div_pay_model = new 按钮组("div_pay_model",div_pay_model_被单击);
var div_pay_lable_2 = new 标签("div_pay_lable_2",null);
var div_pay_btns_1 = new 按钮组("div_pay_btns_1",div_pay_btns_1_被单击);
var div_pay_btns_2 = new 按钮组("div_pay_btns_2",div_pay_btns_2_被单击);
var div_pay_btns_3 = new 按钮组("div_pay_btns_3",div_pay_btns_3_被单击);
var div_pay_btns_4 = new 按钮组("div_pay_btns_4",div_pay_btns_4_被单击);
var div_pay_btn_cdk = new 按钮("div_pay_btn_cdk",div_pay_btn_cdk_被单击,null,null);
var div_pay_test_btn = new 按钮("div_pay_test_btn",div_pay_test_btn_被单击,null,null);
var div_pay_test_btn2 = new 按钮("div_pay_test_btn2",div_pay_test_btn2_被单击,null,null);
var div_pay_id = new 标签("div_pay_id",null);
var HK蓝鸟1 = new HK蓝鸟("HK蓝鸟1");
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 按钮1 = new 按钮("按钮1",按钮1_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        平台币充值_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        平台币充值_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var pay_model="alipay";
var is_test= false;
var invest_scale= 1;
var pay_proportion= 1;
var pay_id= "";
var mask_id= "coinpay";
var pay_json= {}
function 平台币充值_创建完毕(){
	根地址 = HPtools1.取URL();
	var int= 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("test")));
	if(int == 1 ){
		is_test = true;
	}
	生成界面();
	弹出面板初始化();
	invest_scale = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("invest")));
	pay_proportion = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("proportion")));
	if(invest_scale <= 0 || pay_proportion <= 0 ){
		window.parent.显示提示消息("非法调用",false);
		window.parent.关闭充值遮罩及等待框();
		关闭本窗口();
	}
	发起后渲染充值按钮();
	if (!window.parent.我的信息查询) {div_pay_lable_1.置标题("<br>您的平台币不足！"+div_pay_lable_1.取标题())}
	window.parent.关闭充值遮罩及等待框();
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_pay_model.置样式(0,"mui-btn mui-btn-success");

	if(is_test == true ){
		div_pay_test_btn.置可视(true);
		div_pay_test_btn2.置可视(true);
	}
	var rect = 公用模块.弹出面板初始化计算(-140, 70, false);
	弹出面板1.初始化(rect[0], rect[1], rect[2], rect[3]);
	弹出面板1.添加组件("按钮1");
}
function 生成界面(){
	var 窗口宽度= 窗口操作.取窗口宽度();
	div_head_panel.置高度("40px");
	div_head_panel.添加组件("div_register_title","100%");
	HK蓝鸟1.设置属性("div_register_title","[定位:绝对定位]");
	div_head_panel.添加组件("div_register_close","24px");

	HK蓝鸟1.设置属性("div_register_close","[定位:绝对定位][左边:"+转换操作.到文本(窗口宽度-10-50)+"px][顶边:8px]");
	div_register_close.置圆角("6px");
}
function 发起后渲染充值按钮(){
	if(pay_proportion < 1 ){
		pay_proportion = 1;
	}
	var str= "";
	if(pay_proportion > 1 ){
		str = "[限时优惠：充赠比"+转换操作.到文本(pay_proportion)+"倍]";
	}
	div_pay_lable_2.置标题("确认要充值的金额：" + str);
	div_pay_btns_1.置标题(0, "充值6元 → "+转换操作.到文本(6*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_1.置标题(1, "充值18元 → "+转换操作.到文本(18*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_2.置标题(0, "充值58元 → "+转换操作.到文本(58*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_2.置标题(1, "充值98元 → "+转换操作.到文本(98*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_3.置标题(0, "充值198元 → "+转换操作.到文本(198*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_3.置标题(1, "充值328元 → "+转换操作.到文本(328*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_4.置标题(0, "充值648元 → "+转换操作.到文本(648*pay_proportion*invest_scale)+"平台币");
	div_pay_btns_4.置标题(1, "充值1000元 → "+转换操作.到文本(1000*pay_proportion*invest_scale)+"平台币");
}

function div_pay_model_被单击(按钮索引){
	div_pay_model.置样式(0,"mui-btn");
	div_pay_model.置样式(1,"mui-btn");
	div_pay_model.置样式(2,"mui-btn");
	div_pay_model.置样式(按钮索引,"mui-btn mui-btn-success");
	pay_model = "alipay";
	if(按钮索引 == 1 ){
		pay_model = "wxpay";
	}else if(按钮索引 == 2 ){
		pay_model = "";
	}
}

function div_pay_btns_1_被单击(按钮索引){
	var amount= 6;
	if(按钮索引 > 0 ){
		amount = 18;
	}
	通用发起真实充值(amount);
}
function div_pay_btns_2_被单击(按钮索引){
	var amount= 58;
	if(按钮索引 > 0 ){
		amount = 98;
	}
	通用发起真实充值(amount);
}
function div_pay_btns_3_被单击(按钮索引){
	var amount= 198;
	if(按钮索引 > 0 ){
		amount = 328;
	}
	通用发起真实充值(amount);
}
function div_pay_btns_4_被单击(按钮索引){
	var amount= 648;
	if(按钮索引 > 0 ){
		amount = 1000;
	}
	通用发起真实充值(amount);
}
function div_pay_btn_cdk_被单击(){
	window.parent.延时_打开兑换窗口(100);
	关闭本窗口();
}

function div_pay_test_btn_被单击(){
	通用发起真实充值(0.1);
}
function div_pay_test_btn2_被单击(){
	var str= HPtools1.输入框("请输入要充值的金额");
	str = 文本操作.删首尾空(str);
	if(str == "" ){
		return;
	}
	var num= 转换操作.到数值(str);
	if(num <= 0 ){
		仔仔弹出对话框1.错误("充值金额不能为0！");
		return;
	}
	通用发起真实充值(num);
}
function 通用发起真实充值(amount){
	var json= {"pay_amount": amount}
	m_post = 公用模块.生成提交数据(0, "user_pay", "", "start" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/pay/start", m_token);
	显示等待框();
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 发起最终充值调用(amount, submit_model, pay_id){
	pay_json.amount = amount;
	pay_json.submit_model = submit_model;
	pay_json.pay_id = pay_id;
	弹出面板1.显示();
}

function 底层_充值调用(){
	pay_json;
	发起真实充值操作(pay_json.amount, pay_json.submit_model, pay_json.pay_id);
	if (window.parent.我的信息查询) {window.parent.显示提示消息("付款成功后,刷新本页面查看余额.",true)}
	else {window.parent.显示提示消息("付款成功后,请继续操作.",true)}

	关闭本窗口();
}
function 关闭本窗口(){
	window.parent.postMessage("close_" + mask_id, window.location.origin);
}
function div_register_close_被单击(){
	关闭本窗口();
}

function 显示等待框(){
	公用模块.showMask("页面遮罩");
	HPtools1.显示等待框("请稍等......");

}

function 关闭等待框(){

	公用模块.hideMask("页面遮罩");
	HPtools1.关闭等待框();
}

function 发起真实充值操作(amount, submit_model, pay_id){
	if(submit_model < 2 ){
		直接发起支付跳转(pay_id, amount, 加密操作1.url编码("平台币充值"), pay_model);
	}else if(submit_model == 2 ){
		直接发起支付跳转2(pay_id, amount, "invest-coin", "japay");
	}
	仔仔弹出对话框1.成功("已发起充值,充值后刷新本页面即可");
}

function 直接发起支付跳转(pay_id, pay_amount, pay_name_url_encoding, pay_type){
	var url= "pay.html?pay_id="+pay_id+"&pay_amount="+pay_amount.toString()+"&pay_name="+pay_name_url_encoding+"&pay_type="+pay_type;
	window.open(url);
}

function 直接发起支付跳转2(pay_id, pay_amount, pay_name_url_encoding, pay_type){
	var url= "pay1.html?pay_id="+pay_id+"&pay_amount="+pay_amount.toString()+"&pay_name="+pay_name_url_encoding+"&pay_type="+pay_type;
	window.open(url);
}

function 网络操作1_发送完毕(发送结果,返回信息){
	关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			发起最终充值调用(json.pay_amount, json.pay_model, json.msg);
		}
	}
}
function 按钮1_被单击(){
	底层_充值调用();
}