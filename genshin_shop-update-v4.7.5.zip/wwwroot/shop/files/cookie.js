(function (){
window["MyCookie"] = {}  // 本行代码为了后续可以快速的使用本js文件

//JS代码区域
    function setCookie(name, value, expires, sameSite) {
        // 动态获取当前子域名（如 aaa.expay.com 或 bbb.expay.com）
        const currentDomain = window.location.hostname;
        // 设置 Cookie
        const date = new Date();
        date.setTime(date.getTime() + (expires*1000));
        if (typeof sameSite === 'string') { sameSite = sameSite.trim() } else { sameSite = ''}
        if (sameSite === '') { sameSite = 'Lax'}
        console.log('currentDomain', currentDomain)
        document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}; expires=${date.toUTCString()}; Domain=${currentDomain}; Path=/; SameSite=${sameSite}`;
    }

//JS代码区域

window["MyCookie"]["setCookie"]=setCookie;
})();
