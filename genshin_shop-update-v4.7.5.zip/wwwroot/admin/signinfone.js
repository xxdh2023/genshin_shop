mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var div_sign_id_edit = new 编辑框("div_sign_id_edit",null,null,null,null,null);
var div_sign_name_edit = new 编辑框("div_sign_name_edit",null,null,null,null,null);
var div_sign_type_0 = new 单选框("div_sign_type_0",null);
var div_sign_type_1 = new 单选框("div_sign_type_1",null);
var div_sign_type_2 = new 单选框("div_sign_type_2",null);
var 自由面板1 = new 自由面板("自由面板1","46px");
var div_sign_note_edit = new 编辑框("div_sign_note_edit",null,null,null,null,null);
var 按钮组_操作 = new 按钮组("按钮组_操作",按钮组_操作_被单击);
var 标签1 = new 标签("标签1",null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var div_add_popover = new 弹出面板("div_add_popover",null,null);
var div_add_edit = new 编辑框("div_add_edit",null,null,null,null,null);
var div_add_dropbox = new 下拉框("div_add_dropbox",div_add_dropbox_表项被单击);
var div_add_btn = new 按钮("div_add_btn",div_add_btn_被单击,null,null);
var div_add_grid = new 列表框("div_add_grid",false,null,div_add_grid_按钮被单击);
var div_add_btns = new 按钮组("div_add_btns",div_add_btns_被单击);
var div_add_next_popover = new 弹出面板("div_add_next_popover",null,null);
var div_add_next_dropbox = new 下拉框("div_add_next_dropbox",div_add_next_dropbox_表项被单击);
var div_add_next_num_edit = new 编辑框("div_add_next_num_edit",null,null,null,null,null);
var div_add_next_level_edit = new 编辑框("div_add_next_level_edit",null,null,null,null,null);
var div_add_next_accept = new 单选框("div_add_next_accept",null);
var div_add_next_finish = new 单选框("div_add_next_finish",null);
var div_add_next_btn = new 按钮("div_add_next_btn",div_add_next_btn_被单击,null,null);
var div_sign_free = new 复选框("div_sign_free",div_sign_free_被单击);
var div_sign_clear = new 复选框("div_sign_clear",null);
if(mui.os.plus){
    mui.plusReady(function() {
        签到奖励档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        签到奖励档案窗口_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var ID= 0;
var class_name= "";
var value="";
var page= 0;
var m_json= {}
var sign_day= 0;



function 签到奖励档案窗口_创建完毕(){
	ID = 转换操作.到数值(文本操作.删首尾空(窗口操作.取当前页面参数("ID")));
	根地址 = HPtools1.取URL();
	按钮组_操作.置样式(0,"mui-btn");
	按钮组_操作.置样式(2,"mui-btn mui-btn-danger");
	div_sign_id_edit.置只读模式(true);
	div_add_btns.置样式(0,"mui-btn mui-btn-danger");
	div_sign_type_0.置分组("A");
	div_sign_type_1.置分组("A");
	div_sign_type_2.置分组("A");
	div_add_next_accept.置分组("B");
	div_add_next_finish.置分组("B");
	高级表格初始化();
	添加初始化();
	档案查询();
}
function 高级表格初始化(){
	高级表格1.添加列("xh","序号",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",80,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("sign_day","日期",150,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("sign_value","显示名称",400,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("sign_detail","内部脚本",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(1,false,"添加单条脚本");
	高级表格1.添加工具栏按钮(2,false,"自定义批量导入");
	高级表格1.初始化("auto",true,true,false,true);
}
function 添加初始化(){
	var rect = 公用模块.弹出面板初始化计算(50,80, true);
	div_add_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_popover.添加组件("div_add_edit" );
	div_add_popover.添加组件("div_add_dropbox");
	div_add_popover.添加组件("div_add_btn");
	div_add_popover.添加组件("div_add_grid");
	div_add_popover.添加组件("div_add_btns");



	var rect = 公用模块.弹出面板初始化计算(50,140, false);
	div_add_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_next_popover.添加组件("div_add_next_dropbox" );
	div_add_next_popover.添加组件("div_add_next_num_edit" );
	div_add_next_popover.添加组件("div_add_next_level_edit" );
	div_add_next_popover.添加组件("div_add_next_accept" );
	div_add_next_popover.添加组件("div_add_next_finish" );
	div_add_next_popover.添加组件("div_add_next_btn" );
	div_add_next_dropbox.清空项目();
	div_add_next_dropbox.添加项目("请选择日期......","0");
	var i= 1;
	while(i < 32){
		div_add_next_dropbox.添加项目(公用模块.签到日期转换(i),""+i);
		i++
	}
}
function 档案查询(){
	if(ID > 0 ){
		m_post = 公用模块.生成提交数据(ID, "item_sign_info", "", "read" , 1, 0);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
		美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
		公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
	}
}


function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "item_sign_info" ){
				if(json.model == "insert" ){
					ID = 转换操作.到数值(json.msg);
					div_sign_id_edit.置内容(json._id);
					仔仔弹出对话框1.成功("添加成功！");
				}else if(json.model == "update" ){
					仔仔弹出对话框1.成功("更新成功！");
				}else if(json.model == "delete" ){
					档案新增();
					仔仔弹出对话框1.成功("删除成功！");
				}
			}else if(json.table == "item_sign_info_detail" ){
				if(json.model == "insert" ){
					div_add_popover.隐藏();
					div_add_next_popover.隐藏();
				}
				仔仔弹出对话框1.成功("执行成功！");
				档案查询();
			}else{
				仔仔弹出对话框1.成功("执行成功！");
			}

		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "item_sign_info" ){
				档案新增();
				ID = json.results.ID;
				div_sign_id_edit.置内容(json.results.sign_id);
				div_sign_name_edit.置内容(json.results.sign_name);
				div_sign_note_edit.置内容(json.results.sign_note);
				switch(json.results.sign_type){
					case 0 :
						div_sign_type_0.置选中状态(true);
					break;
					case 1 :
						div_sign_type_1.置选中状态(true);
					break;
					case 2 :
						div_sign_type_2.置选中状态(true);
					break;
				}
				if(json.results.sign_free > 0 ){
					div_sign_free.置选中状态(true);
					div_sign_clear.置可视(true);
					div_sign_clear.置选中状态(false);
					if(json.results.sign_clear > 0 ){
						div_sign_clear.置选中状态(true);
					}
				}
				var arr = new Array();
				while(i < json.results.detail.length){
					arr[0] = "";
					arr[1] = json.results.detail[i].ID;
					arr[2] = "删除";
					arr[3] = 公用模块.签到日期转换(json.results.detail[i].sign_day);
					arr[4] = json.results.detail[i].sign_value;
					arr[5] = json.results.detail[i].sign_detail;
					高级表格1.添加行(false,arr);
					i++
				}
				高级表格1.清空操作栏按钮();
				高级表格1.添加操作栏按钮(4,false,"删除");
				高级表格1.初始化("auto",true,true,false,true);
			}else if(json.table == "item_class_info" ){
				class_name = "";
				div_add_dropbox.清空项目();
				div_add_dropbox.添加项目("请选择类别......","");
				while(i < json.results.length){
					div_add_dropbox.添加项目(json.results[i].class_name,json.results[i].class_name);
					i++
				}
				div_add_popover.显示();

			}else if(json.table == "item_item_info" ){
				if(json.model != "read" ){
					if(json.page == 1 ){
						div_add_grid.清空项目();
					}
					page = json.page;
					if(json.total > json.page ){
						div_add_btns.置可视(true);
					}
					while(i < json.results.length){
						div_add_grid.添加项目(json.results[i].item_id+" :: "+json.results[i].item_name, ""+json.results[i].item_model+","+json.results[i].item_maxnum,"mui-btn mui-btn-primary","添加");
						i++
					}
				}
			}



		}
	}
}

function 档案新增(){
	ID = 0;
	div_sign_id_edit.置内容("");
	div_sign_name_edit.置内容("");
	div_sign_note_edit.置内容("");
	div_sign_type_0.置选中状态(false);
	div_sign_type_1.置选中状态(false);
	div_sign_type_2.置选中状态(false);
	div_sign_free.置选中状态(false);
	div_sign_clear.置可视(false);
	div_sign_clear.置选中状态(false);
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
}

function 按钮组_操作_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(HPtools1.询问框("是否新增？") == true ){
				档案新增();
			}
		break;
		case 1 :
			div_sign_name_edit.置内容(文本操作.删首尾空(div_sign_name_edit.取内容()));
			if(div_sign_name_edit.取内容() == "" ){
				仔仔弹出对话框1.错误("签到奖励名称不能为空！");
				return;
			}
			var sign_type= -1;
			if(div_sign_type_0.取选中状态()  == true ){
				sign_type = 0;
			}
			if(div_sign_type_1.取选中状态()  == true ){
				sign_type = 1;
			}
			if(div_sign_type_2.取选中状态()  == true ){
				sign_type = 2;
			}
			if(sign_type < 0 ){
				仔仔弹出对话框1.错误("请选择签到类型(每天/周/月)！");
				return;
			}
			div_sign_note_edit.置内容(文本操作.删首尾空(div_sign_note_edit.取内容()));
			var json= {}
			json.sign_id = div_sign_id_edit.取内容();
			json.sign_name = div_sign_name_edit.取内容();
			json.sign_note = div_sign_note_edit.取内容();
			json.sign_pic = "";
			json.sign_static = 1;
			json.sign_type = sign_type;
			var sign_free= 0;
			if(div_sign_free.取选中状态() == true ){
				sign_free = 1;
			}
			json.sign_free = sign_free;
			json.sign_clear = 0;
			if(json.sign_free > 0 && div_sign_clear.取选中状态() == true ){
				json.sign_clear = 1;
			}
			if(ID < 1 ){
				m_post = 公用模块.生成提交数据(ID, "item_sign_info", "", "insert" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
				美化等待框1.默认等待框("正在交互","正在添加档案,请稍等......");
			}else{
				m_post = 公用模块.生成提交数据(ID, "item_sign_info", "", "update" , 1, 0, json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在更新档案,请稍等......");
			}
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);

		break;
		case 2 :
			if(ID > 0 ){
				if(HPtools1.询问框("是否删除？") == true ){
					var json= {}
					json.sign_id = div_sign_id_edit.取内容();
					m_post = 公用模块.生成提交数据(ID, "item_sign_info", "", "delete" , 1, 0, json);
					m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
					美化等待框1.默认等待框("正在交互","正在删除档案,请稍等......");
					公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
				}
			}
		break;
	}
}

function 高级表格1_工具栏按钮被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存签到奖励！");
				return;
			}
			if(div_add_dropbox.取项目总数() < 1 ){
				m_post = 公用模块.生成提交数据(0, "item_class_info", "", "" , 0, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
				美化等待框1.默认等待框("正在交互","正在刷新,请稍等......");
				公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
			}else{
				div_add_popover.显示();
			}

		break;
		case 1 :
			if(ID < 1 ){
				仔仔弹出对话框1.错误("请先保存签到奖励！");
				return;
			}
			var url= "infoimport.html?table=item_sign_info_detail&item_id="+div_sign_id_edit.取内容();
			公用模块.居中打开小窗口(url, 900, 650);

		break;
	}
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	m_post = 公用模块.生成提交数据(_id, "item_sign_info_detail", "", "delete" , 1, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
	美化等待框1.默认等待框("正在交互","正在删除脚本明细,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function div_add_dropbox_表项被单击(项目索引,项目标题,项目标记){
	class_name = 项目标记;
}

function div_add_btn_被单击(){
	div_add_edit.置内容(文本操作.删首尾空(div_add_edit.取内容()));
	value = div_add_edit.取内容();
	if(class_name == "" ){
		仔仔弹出对话框1.错误("请选择要查询的类别！");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name , 1, 0);
	page = 1;
	div_add_btns.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}

function div_add_btns_被单击(按钮索引){
	switch(按钮索引){
		case 0 :
			m_post = 公用模块.生成提交数据(0, "item_item_info", value, class_name , page+1, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
			美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
		break;
		case 1 :
			div_add_popover.滚动条到顶部();

		break;
	}
}

function div_add_grid_按钮被单击(项目索引){
	var res = 文本操作.分割文本(div_add_grid.取项目标记(项目索引),",");
	var item_model= 转换操作.到数值(res[0]);
	var item_maxnum= 转换操作.到数值(res[1]);
	res = 公用模块.取编码和名称(div_add_grid.取项目标题(项目索引),"::");
	var item_id= res[0];
	var item_name= res[1];
	m_json = {}
	m_json.item_model = item_model;
	m_json.item_id = item_id;
	m_json.item_name = item_name;
	m_json.item_maxnum = item_maxnum;
	div_add_next_num_edit.置可视(false);
	div_add_next_level_edit.置可视(false);
	div_add_next_accept.置可视(false);
	div_add_next_finish.置可视(false);
	var h= 0;
	var 提示内容= "";
	if(item_model == 0 || item_model == 1 || item_model == 9 ){
		div_add_next_num_edit.置可视(true);
		if(item_model == 9 ){
			提示内容 = "请输入等级";
		}else{
			提示内容 = "请输入数量";
		}
		if(m_json.item_maxnum > 0 ){
			提示内容 = 提示内容 + ",最大不能超过：" + 转换操作.到文本(m_json.item_maxnum);
		}
		div_add_next_num_edit.置提示内容(提示内容);
		h++
	}else if(item_model == 7 ){
		m_json.item_maxnum = 14;
		div_add_next_num_edit.置可视(true);
		div_add_next_num_edit.置提示内容("请输入怪物数量,最大不能超过：14");
		div_add_next_level_edit.置可视(true);
		div_add_next_level_edit.置提示内容("请输入怪物等级，最大200级");
		h=h+2;
	}else if(item_model == 5 ){
		div_add_next_accept.置可视(true);
		div_add_next_finish.置可视(true);
		h=h+2;
	}else if(item_model == 2 ){
		m_json.item_maxnum = 6;
		div_add_next_num_edit.置可视(true);
		div_add_next_num_edit.置提示内容("请输入武器突破等级,最大不能超过：6");
		div_add_next_level_edit.置可视(true);
		div_add_next_level_edit.置提示内容("请输入武器精炼等阶,最大不能超过：5");
		h=h+2;
	}
	var rect = 公用模块.弹出面板初始化计算(50,120+h*40, false);
	div_add_next_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_add_next_num_edit.置内容("");
	div_add_next_level_edit.置内容("");
	div_add_next_popover.显示();

}


function div_add_next_btn_被单击(){
	if(sign_day < 1 ){
		仔仔弹出对话框1.错误("请选择日期！");
		return;
	}
	div_add_next_num_edit.置内容(文本操作.删首尾空(div_add_next_num_edit.取内容()));
	div_add_next_level_edit.置内容(文本操作.删首尾空(div_add_next_level_edit.取内容()));
	var num= 转换操作.到数值(div_add_next_num_edit.取内容());
	if(m_json.item_model == 0 || m_json.item_model == 1 || m_json.item_model == 9 || m_json.item_model == 7 ){
		if(num < 1 ){
			仔仔弹出对话框1.错误("请输入大于0的数量！");
			return;
		}
		if(num > m_json.item_maxnum && m_json.item_maxnum > 0 ){
			仔仔弹出对话框1.错误("输入的数量不能大于："+转换操作.到文本(m_json.item_maxnum));
			return;
		}
	}else if(m_json.item_model == 5 ){
		num = -1;
		if(div_add_next_accept.取选中状态() == true ){
			num = 1;
		}
		if(div_add_next_finish.取选中状态() == true ){
			num = 0;
		}
		if(num < 0 ){
			仔仔弹出对话框1.错误("请确认任务类型：接受/完成");
			return;
		}
	}
	var level= 转换操作.到数值(div_add_next_level_edit.取内容());
	if(m_json.item_model == 7  && level > 200 ){
		仔仔弹出对话框1.错误("怪物等级不能超过200！");
		return;
	}
	if(m_json.item_model == 2 && level > 5 ){
		仔仔弹出对话框1.错误("武器精炼等阶不能超过5！");
		return;
	}
	if(m_json.item_model == 2 && level > 1 && num < 1 ){
		仔仔弹出对话框1.错误("请输入大于0的武器突破等级！");
		return;
	}
	res = 公用模块.生成脚本内容及显示名称(m_json.item_model, m_json.item_id, m_json.item_name,num,level);
	var json= {}
	json.sign_id = div_sign_id_edit.取内容();
	json.sign_value = res[1];
	json.sign_detail = res[0];
	json.sign_day = sign_day;
	m_post = 公用模块.生成提交数据(ID, "item_sign_info_detail", "", "insert" , 1, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	美化等待框1.默认等待框("正在交互","正在添加脚本明细,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 200);
}
function div_add_next_dropbox_表项被单击(项目索引,项目标题,项目标记){
	sign_day = 转换操作.到数值(项目标记);
}
function div_sign_free_被单击(){
	if(div_sign_free.取选中状态() == true ){
		div_sign_clear.置可视(false);
	}else{
		div_sign_clear.置可视(true);
	}

}