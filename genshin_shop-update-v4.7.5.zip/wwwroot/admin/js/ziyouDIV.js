function 自由DIV组(name,event1){   
	//name表示组件在被创建时的名称，event表示组件拥有的事件
	//如果组件有多个事件，可以在后面继续填写这些事件名称
	//例如：function 自由DIV组(name,event1,event2,event3){
		
		//组件内部属性，仅供组件内部使用：
		this.名称 = name;
		this.项目总数 = 0;
		this.数据量 = 0;
		this.卡片总数 = 0;
		
		//组件命令：
		this.创建顶部DIV = function (跳转页面,框架高度,框架宽度,边框大小,边框颜色,边框距离,边框圆角,标题字体大小,标题字体名称,标题距离顶部,标题颜色,标题内容,副标题字体大小,副标题字体名称,副标题距离顶部,副标题颜色,副标题内容){
			var div = document.createElement("a");
			div.id = "zzydiv"+this.项目总数;
			div.className = "zzydiv";
			div.setAttribute("index",""+this.项目总数);
			this.项目总数 = this.项目总数+1;
			div.innerHTML = "<a href=\""+跳转页面+"\" style=\"text-decoration: none; \">\n"+
			"                <div style=\"height: "+框架高度+"; width: "+框架宽度+"; border:"+边框大小+" solid "+边框颜色+"; display:inline-block; margin: "+边框距离+"; border-radius:"+边框圆角+"\">\n"+
			"                     <div style=\"font-size: "+标题字体大小+"; font-family: "+标题字体名称+"; margin-top: "+标题距离顶部+"; color: "+标题颜色+";\">"+标题内容+"</div>\n"+
			"                     <div style=\"font-size: "+副标题字体大小+"; font-family: "+副标题字体名称+"; margin-top: "+副标题距离顶部+"; color: "+副标题颜色+";\">"+副标题内容+"</div>\n"+
			"			           </div></a>"
			var root = document.getElementById(this.名称);
			root.appendChild(div);
		}
		
		this.清空顶部DIV项目 = function(){
			var root = document.getElementById(this.名称);
			while(root.hasChildNodes()){
				root.removeChild(root.firstChild);
			}
			this.项目总数 = 0;
			this.数据量 = 0;
		}
		
		//组件命令：
		this.创建栏目卡片 = function (){
			var div = document.createElement("a");
			div.id = "lmkpdiv"+this.卡片总数;
			div.className = "lmkpdiv";
			div.setAttribute("index",""+this.卡片总数);
			this.卡片总数 = this.卡片总数+1;
			div.innerHTML = "		<div style=\"display:inline-block;width: 100%; height: 250px;background-color: #FFFFFF;\">\n"+
			"							<div style=\"height: 30px; width: 5px; background-color: #0080FF;border-radius:20%;\"><div style=\"margin-left: 10px; margin-top: 0px; font-size: 18px; width: 200px;text-align: left;line-height:34px;\">公告：</div></div>\n"+
			"							<div style=\" margin-left: 10px;width: 95%;\"><hr></div>\n"+
			"							<p class=\"mui-h5\" style=\"margin-left: 10px;display:inline-block;\">用户名：银河网络软件<div style=\"border-radius:5px;height: 24px; width: 80px;border: #EC971F solid 1px;display:inline-block;text-align: center; font-size: 12px; color: #EC971F;\">普通会员</div></p>\n"+
			"						</div>"
			var root = document.getElementById(this.名称+"kapian");
			root.appendChild(div);
		}
		
		//组件命令：
		this.置可视 = function (value){
			if(value==true){
				var div = document.getElementById(this.名称).parentNode;
				div.style.display="block";//显示	                
				}else{
				var div = document.getElementById(this.名称).parentNode;
				div.style.display="none"; //不占位隐藏               
			}
		} 
		
		//组件命令：
		this.置可视2 = function (value){
			if(value==true){
				var div = document.getElementById(this.名称).parentNode;
				div.style.visibility="visible";//显示	                
				}else{
				var div = document.getElementById(this.名称).parentNode;
				div.style.visibility="hidden"; //占位隐藏               
			}
		} 
		
		if(event1!=null){
			//mui("#"+组件ID).on(事件名称, 标签名称或类名称, function() {
				mui("#"+this.名称).on("tap", ".zzydiv", function() {
					var index1 = this.parentNode.parentNode.getAttribute("index");
					var index2 = this.getAttribute("index");
					event1(Number(index2));//触发组件的相关事件，这里的是"表项按钮被单击"事件
				});
			}
			
		}																																																	