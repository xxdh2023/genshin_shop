    function 美化等待框(name,event){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 美化等待框(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;
        
		this.默认等待框 = function (标题,描述){
		    $('body').loading({
			   loadingWidth:200,
			   title:标题,
			   name:this.名称,
			   discription:描述,
			   direction:'column',
			   type:'origin',
			   // originBg:'#71EA71',
			   originDivWidth:40,
			   originDivHeight:40,
			   originWidth:6,
			   originHeight:6,
			   smallLoading:false,
			   loadingMaskBg:'rgba(0,0,0,0.2)'
		    });
		}
        //组件命令：
        this.自定义等待框 = function (方向,类型,标题,描述,标题颜色,描述文本颜色,等待框宽度,等待框背景颜色,背景遮罩层颜色,圆形旋转宽度,圆形旋转高度,小圆点宽度,小圆点高度,小圆点背景色,是否显示小的loading,图片地址,图片宽度,图片高度){
            var newDirection;
			var newType;
			if (方向 == 0){
				     //纵向
					 newDirection = "column";
				 }else {
				     //横向
					 newDirection = "row";
				       }
			if(类型 == 0){
				     //默认效果
					 newType = "origin";
				}else {
				     //图片效果
					 newType = "pic";
				 }
			$('body').loading({
			     direction:newDirection,
				 type:     newType,
				 title:     标题,
				 discription:描述,
				 titleColor:标题颜色,
				 discColor:描述文本颜色,
				 loadingWidth:等待框宽度,
				 loadingBg:等待框背景颜色,
				 loadingMaskBg:背景遮罩层颜色,
				 originDivWidth:圆形旋转宽度,
				 originDivHeight:圆形旋转高度,
				 originWidth:小圆点宽度,
				 originHeight:小圆点高度,
				 originBg:小圆点背景色,
				 smallLoading:是否显示小的loading,
				 imgSrc:图片地址,
				 imgDivWidth:图片宽度,
				 imgDivHeight:图片高度,
				 name:this.名称
			});
        } 
        
        //组件命令：
        this.关闭等待框 = function (){
           removeLoading(this.名称);
        }  
        
        //组件事件
        if(event!=null){
 		document.getElementById(this.名称).addEventListener("tap", function () {
                event();//触发组件的相关事件，这里演示的是被单击事件
            });       	
        }
    }