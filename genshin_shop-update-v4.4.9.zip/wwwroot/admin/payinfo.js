mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 自由面板1 = new 自由面板("自由面板1","95px");
var 自由面板_标签 = new 标签("自由面板_标签",null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",null,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var 标签2 = new 标签("标签2",null);
var 标签1 = new 标签("标签1",null);
var div_pay_static_1_ = new 单选框("div_pay_static_1_",div_pay_static_1__被单击);
var div_pay_static_0 = new 单选框("div_pay_static_0",div_pay_static_0_被单击);
var div_pay_static_1 = new 单选框("div_pay_static_1",div_pay_static_1_被单击);
var div_pay_popover = new 弹出面板("div_pay_popover",null,null);
var div_pay_ID = new 标签("div_pay_ID",null);
var div_pay_lable = new 标签("div_pay_lable",null);
var div_pay_id = new 编辑框("div_pay_id",null,null,null,null,null);
var div_pay_platform = new 编辑框("div_pay_platform",null,null,null,null,null);
var div_pay_key = new 编辑框("div_pay_key",null,null,null,null,null);
var div_pay_pid = new 编辑框("div_pay_pid",null,null,null,null,null);
var div_pay_show = new 标签("div_pay_show",null);
var div_pay_proportion = new 编辑框("div_pay_proportion",null,null,null,null,null);
var div_pay_btn = new 按钮("div_pay_btn",div_pay_btn_被单击,null,null);
var 自由面板_按钮_添加 = new 按钮("自由面板_按钮_添加",自由面板_按钮_添加_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        在线直充管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        在线直充管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var pay_static= -1;





function 在线直充管理_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password异常,请重新登陆！"),"");
		return;
	}
	根地址 = HPtools1.取URL();
	调整组件尺寸();
	高级表格初始化();
	div_pay_static_1_.置选中状态(true);
	div_pay_id.置只读模式(true);
	查询数据();

}
function 调整组件尺寸(){
	var width= 窗口操作.取窗口宽度();
	公用模块.自由面板_调整("自由面板_标签", 110, 100, 800,width);
	公用模块.自由面板_调整("自由面板_编辑框_条件", 214, 400, 800,width);
	公用模块.自由面板_调整("自由面板_按钮_查询", 622, 100, 800,width);
	公用模块.自由面板_调整("自由面板_按钮_添加", 6, 100, 800,width);
	var rect = 公用模块.弹出面板初始化计算(50, 340, false);
	div_pay_popover.初始化(rect[0], rect[1], rect[2], rect[3]);
	div_pay_popover.添加组件("div_pay_ID");
	div_pay_popover.添加组件("div_pay_lable");
	div_pay_popover.添加组件("div_pay_id");
	div_pay_id.置只读模式(true);
	div_pay_popover.添加组件("div_pay_platform");
	div_pay_popover.添加组件("div_pay_key");
	div_pay_popover.添加组件("div_pay_pid");
	div_pay_popover.添加组件("div_pay_show");
	div_pay_popover.添加组件("div_pay_proportion");
	div_pay_popover.添加组件("div_pay_btn");
}

function 高级表格初始化(){
	高级表格1.添加列("xh","",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",220,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("pay_static","状态",80,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_id","编码",160,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_key","商户秘钥",300,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_pid","商户ID",100,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_proportion","充赠比(仅永久授权有效)",180,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("pay_platform","支付通道名称",500,false,false,false,false,false,false,"",false,false);




	高级表格1.初始化("auto",true,true,false,true);
}


function 时钟1_周期事件(){


	底层_发送网络请求(20000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "pay_api_info" ){
				if(json.model == "delete" ){
					高级表格1.删除行(转换操作.到数值(json.comm));
					高级表格1.初始化("auto",true,true,false,true);
					仔仔弹出对话框1.成功("删除成功！");
				}else if(json.model == "insert" ){
					div_pay_ID.置标题(json.msg);
					div_pay_id.置内容(json._id);
					div_pay_popover.隐藏();
					仔仔弹出对话框1.成功("添加成功！");
				}else if(json.model == "update" ){
					div_pay_popover.隐藏();
					仔仔弹出对话框1.成功("更新成功！");
				}
			}else if(json.table == "pay_api_info_static" ){
				仔仔弹出对话框1.成功("调整成功,请重新查询！");
			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "pay_api_info" ){
				if(json.model == "read" ){
					div_pay_ID.置标题(""+json.results.ID);
					div_pay_id.置内容(json.results.pay_id);
					div_pay_platform.置内容(json.results.pay_platform);
					div_pay_key.置内容(json.results.pay_key);
					div_pay_pid.置内容(json.results.pay_pid);
					div_pay_proportion.置内容(""+json.results.pay_proportion);
					div_pay_popover.显示();
				}else if(json.model != "read" ){
					if(json.page == 1 ){
						高级表格1.清空行();
					}
					page = json.page;
					if(json.total > json.page ){
						按钮_底部.置可视(true);
					}
					var arr = new Array();
					while(i < json.results.length){
						arr[0] = "";
						arr[1] = json.results[i].ID;
						arr[2] = "";
						arr[3] = "已停用";
						if(json.results[i].pay_static > 0 ){
							arr[3] = "正常";
						}
						arr[4] = json.results[i].pay_id;
						arr[5] = json.results[i].pay_key;
						arr[6] = json.results[i].pay_pid;
						arr[7] = json.results[i].pay_proportion;
						arr[8] = json.results[i].pay_platform;
						高级表格1.添加行(false,arr);
						i++
					}
					高级表格1.清空操作栏按钮();
					高级表格1.添加操作栏按钮(2,false,"编辑");
					高级表格1.添加操作栏按钮(3,false,"停用");
					高级表格1.添加操作栏按钮(2,false,"启用");
					高级表格1.添加操作栏按钮(4,false,"删除");
					高级表格1.初始化("auto",true,true,false,true);
				}else{

				}



			}




		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	m_post = 公用模块.生成提交数据(pay_static, "pay_api_info", value, "" , 1, 0);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}

function 按钮_底部_被单击(){
	m_post = 公用模块.生成提交数据(pay_static, "pay_api_info", value, "" , page+1, 0);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	时钟1.开始执行(200,false);
}

function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 行数据["id"];
	switch(按钮索引){
		case 0 :

			m_post = 公用模块.生成提交数据(_id, "pay_api_info", "", "read" , 1, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
			美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
			时钟1.开始执行(200,false);
		break;
		case 1 :

			if(HPtools1.询问框("是否停用？") == true ){
				var json= {}
				json.pay_static = 0;
				m_post = 公用模块.生成提交数据(_id, "pay_api_info_static", "", "update" , 1, 0,json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
				时钟1.开始执行(200,false);
			}
		break;
		case 2 :

			if(HPtools1.询问框("是否启用？") == true ){
				var json= {}
				json.pay_static = 1;
				m_post = 公用模块.生成提交数据(_id, "pay_api_info_static", "", "update" , 1, 0,json);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
				美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
				时钟1.开始执行(200,false);
			}
		break;
		case 3 :

			if(HPtools1.询问框("是否删除？") == true ){
				m_post = 公用模块.生成提交数据(_id, "pay_api_info", ""+行索引, "delete" , 1, 0);
				m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
				美化等待框1.默认等待框("正在交互","正在删除,请稍等......");
				时钟1.开始执行(200,false);
			}
		break;
	}

}

function div_pay_static_1__被单击(){
	pay_static = -1;
}
function div_pay_static_0_被单击(){
	pay_static = 0;
}
function div_pay_static_1_被单击(){
	pay_static = 1;
}
function 自由面板_按钮_添加_被单击(){
	div_pay_ID.置标题("0");
	div_pay_id.置内容("");
	div_pay_platform.置内容("本系统支持对接在线直充渠道，您准备好直充渠道后，可联系我进行接入.");
	div_pay_pid.置内容("");
	div_pay_key.置内容("");
	div_pay_popover.显示();
}
function div_pay_btn_被单击(){
	div_pay_platform.置内容(文本操作.删首尾空(div_pay_platform.取内容()));
	if(div_pay_platform.取内容() == "" ){
		div_pay_platform.置内容("本系统支持对接在线直充渠道，您准备好直充渠道后，可联系我进行接入.");
	}

	div_pay_key.置内容(文本操作.删首尾空(div_pay_key.取内容()));
	if(div_pay_key.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入商户秘钥");
		return;
	}
	div_pay_pid.置内容(文本操作.删首尾空(div_pay_pid.取内容()));
	if(div_pay_pid.取内容() == "" ){
		仔仔弹出对话框1.错误("请输入商户ID");
		return;
	}
	div_pay_proportion.置内容(文本操作.删首尾空(div_pay_proportion.取内容()));
	if(div_pay_proportion.取内容() == "" ){
		div_pay_proportion.置内容("1");
	}
	var json= {}
	json.pay_platform = div_pay_platform.取内容();
	json.pay_key = div_pay_key.取内容();
	json.pay_pid = div_pay_pid.取内容();
	json.pay_proportion = 转换操作.到数值(div_pay_proportion.取内容());
	if(转换操作.到数值(div_pay_ID.取标题()) < 1 ){
		m_post = 公用模块.生成提交数据(0, "pay_api_info", "", "insert" , 0, 0,json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/insert", m_password);
	}else{
		m_post = 公用模块.生成提交数据(转换操作.到数值(div_pay_ID.取标题()), "pay_api_info", "", "update" , 0, 0,json);
		m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	}
	美化等待框1.默认等待框("正在交互","正在保存,请稍等......");
	时钟1.开始执行(200,false);
}