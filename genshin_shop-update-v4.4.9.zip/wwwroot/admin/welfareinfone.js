mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",null);
var 时钟1 = new 时钟("时钟1",null);
var div_gm_id_edit = new 编辑框("div_gm_id_edit",null,null,null,null,null);
var div_gm_name_edit = new 编辑框("div_gm_name_edit",null,null,null,null,null);
var div_gm_note_edit = new 编辑框("div_gm_note_edit",null,null,null,null,null);
var 按钮组_操作 = new 按钮组("按钮组_操作",null);
var 标签1 = new 标签("标签1",null);
var 高级表格1 = new 高级表格("高级表格1",null,null,null,null,null,null,null,null);
var div_add_popover = new 弹出面板("div_add_popover",null,null);
var div_add_edit = new 编辑框("div_add_edit",null,null,null,null,null);
var div_add_dropbox = new 下拉框("div_add_dropbox",null);
var div_add_btn = new 按钮("div_add_btn",null,null,null);
var div_add_grid = new 列表框("div_add_grid",false,null,null);
var div_add_btns = new 按钮组("div_add_btns",null);
var CYS特效弹窗1 = new CYS特效弹窗("CYS特效弹窗1",null);
var div_add_next_popover = new 弹出面板("div_add_next_popover",null,null);
var div_add_next_num_edit = new 编辑框("div_add_next_num_edit",null,null,null,null,null);
var div_add_next_level_edit = new 编辑框("div_add_next_level_edit",null,null,null,null,null);
var div_add_next_btn = new 按钮("div_add_next_btn",null,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

