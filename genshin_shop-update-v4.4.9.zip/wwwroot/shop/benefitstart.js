mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 标签1 = new 标签("标签1",null);
var CYS索引列表框1 = new CYS索引列表框("CYS索引列表框1",CYS索引列表框1_项目被单击);
var 按钮_领取 = new 按钮("按钮_领取",按钮_领取_被单击,null,null);
var 标签2 = new 标签("标签2",null);
var div_detail_popover = new 弹出面板("div_detail_popover",null,null);
var div_detail_lable = new 标签("div_detail_lable",null);
var div_detail_show = new 标签("div_detail_show",null);
var div_detail_grid = new CYS选择列表框("div_detail_grid",null);
var div_detail_btn = new 按钮("div_detail_btn",div_detail_btn_被单击,null,null);
var div_detail_json = new 标签("div_detail_json",null);
if(mui.os.plus){
    mui.plusReady(function() {
        领取累充福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        领取累充福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var m_vip_id= "";
var 导航索引= 0;
var 集_表格数据= {}
var 集_福利名称= "";
var 集_分组索引= -1;
function 领取累充福利_创建完毕(){





	根地址 = HPtools1.取URL();
	m_vip_id = 文本操作.删首尾空(窗口操作.取当前页面参数("vip_id"));
	if(m_vip_id == "" ){
		仔仔弹出对话框1.错误("数据无效,请关闭页面");
		return;
	}

	标题栏美化1.去标题栏阴影();
	弹出面板初始化();
	var json= {}
	json.vip_id = m_vip_id;
	m_post = 公用模块.生成提交数据(0, "vip_grade_info_benefits", "", "get-one" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/welfare", m_token);
	美化等待框1.默认等待框("正在交互","正在获取累充福利,请稍等......");
	时钟1.开始执行(200,false);
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 80, true);
	div_detail_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_detail_popover.添加组件("div_detail_show");
	div_detail_popover.添加组件("div_detail_lable");
	div_detail_popover.添加组件("div_detail_grid");
	div_detail_popover.添加组件("div_detail_btn");

}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			标签2.置可视(true);
			仔仔弹出对话框1.错误("数据无效,请关闭页面");
		}else if(json.static == 0 ){
			if(json.table == "vip_grade_info_benefits" && json.model == "draw" ){

			}else{
				标签2.置可视(true);
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){

			仔仔弹出对话框1.提示("已领取,请在仓库中提取资源");
			按钮_领取.置标题("已领取");
			按钮_领取.置样式("mui-btn");
		}else if(json.static == 2 ){
			var i= 0;
			标题栏1.置标题("领取【"+json.results.vip_name+"】累充福利");
			标签1.置标题("<br>累充："+转换操作.到文本(json.results.vip_monetary)+"平台币即可领取.<br>&nbsp;");
			标签1.置可视(true);
			集_表格数据 = {}
			var v= 0;
			while(i < json.results.benefits.length){
				集_表格数据[json.results.benefits[i].ben_name] = {}
				集_表格数据[json.results.benefits[i].ben_name]["ben_num"] = json.results.benefits[i].ben_num;
				集_表格数据[json.results.benefits[i].ben_name]["detail"] = [];
				CYS索引列表框1.添加分组("累充福利: "+json.results.benefits[i].ben_name+" , 自选："+转换操作.到文本(json.results.benefits[i].num)+"选"+转换操作.到文本(json.results.benefits[i].ben_num));
				v=0;
				var num= 0;
				while(v < json.results.detail.length){
					if(json.results.detail[v].ben_name == json.results.benefits[i].ben_name ){
						num = 集_表格数据[json.results.detail[v].ben_name]["detail"].length;
						集_表格数据[json.results.detail[v].ben_name]["detail"][num] = {"ID": json.results.detail[v].ID, "check": false, "ben_value": json.results.detail[v].ben_value}
					}
					v++
				}
				CYS索引列表框1.添加项目(i, "点我选择");
				i++
			}
			标签2.置可视(false);
			按钮_领取.置可视(true);
		}
	}
}

function CYS索引列表框1_项目被单击(分组索引,项目索引){
	集_福利名称 = CYS索引列表框1.取分组标题(分组索引);
	集_福利名称 =  公用模块.文本_取中间文本(集_福利名称, ": ", " ,");
	if(按钮_领取.取标题() != "领取福利" ){
		return;
	}
	div_detail_json.置标题(集_福利名称);
	div_detail_lable.置标题("福利: " + 集_福利名称 +"明细,"+转换操作.到文本(集_表格数据[集_福利名称]["detail"].length)+"选"+转换操作.到文本(集_表格数据[集_福利名称]["ben_num"]));
	div_detail_grid.清空项目();
	var i= 0;
	while(i < 集_表格数据[集_福利名称]["detail"].length){
		div_detail_grid.添加项目(集_表格数据[集_福利名称]["detail"][i].ben_value, 集_表格数据[集_福利名称]["detail"][i].check, 集_表格数据[集_福利名称]["detail"][i].ID);
		i++
	}
	if(div_detail_grid.取项目数() < 1 ){
		仔仔弹出对话框1.错误("未设置福利明细,无法设置");
	}else{
		集_分组索引 = 分组索引;
		div_detail_popover.滚动条到顶部();
		div_detail_popover.显示();
	}
}
function div_detail_btn_被单击(){
	var i= 0;
	var num= 0;
	while(i < div_detail_grid.取项目数()){
		if(div_detail_grid.取项目状态(i) == true ){
			num++
		}
		i++
	}
	if(num != 集_表格数据[集_福利名称]["ben_num"] ){
		仔仔弹出对话框1.错误("您必须选择"+转换操作.到文本(集_表格数据[集_福利名称]["ben_num"])+"个资源！");
		return;
	}
	i=0;
	var str= "";
	while(i < div_detail_grid.取项目数()){
		集_表格数据[集_福利名称]["detail"][i].check = div_detail_grid.取项目状态(i);
		if(div_detail_grid.取项目状态(i) == true ){
			if(str != "" ){
				str = str + ",";
			}
			str = str + div_detail_grid.取项目标题(i);
		}
		i++
	}
	div_detail_popover.隐藏();
	CYS索引列表框1.清空项目(集_分组索引);
	CYS索引列表框1.添加项目(集_分组索引, str);
}
function 按钮_领取_被单击(){
	if(按钮_领取.取标题() != "领取福利" ){
		return;
	}
	var json= {}
	json.detail = 集_表格数据;
	json.vip_id = m_vip_id;
	m_post = 公用模块.生成提交数据(0, "vip_grade_info_benefits", "", "draw" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/welfare", m_token);
	美化等待框1.默认等待框("正在交互","正在领取累充福利,请稍等......");
	时钟1.开始执行(200,false);
}