(function (){ 
window["popup"] = {}
window.addEventListener("message", function(event) {
	if (event.origin === window.location.origin) {  // || 1===1
                var arr = event.data.split("_");
		if (arr.length > 1) {
			if (arr[0] === "close") {
				hideIframeB(arr[1]);
			}
		}
	} else { alert("非法调用！"); }
}, false);
function showIframeB(iframe,src,left,top,width,height) {
    var iframeB = document.getElementById(iframe);
    iframeB.style.display = "block";
    iframeB.style.position = "fixed";
    if (typeof top === "number") {if (top <= 0) {top="0px"}else{top=String(top)+"px"}};  //else{top = Math.floor(top / 2)}
    if (typeof left === "number") {if (left <= 0) {left="0px"}else{left=String(left)+"px"}};  //else{left = Math.floor(left / 2)}
    if (typeof width === "number") {width=String(width)+"px"};
    if (typeof height === "number") {height=String(height)+"px"};
    iframeB.style.top = top;
    iframeB.style.left = left;
    iframeB.style.width = width;
    iframeB.style.height = height;

    iframeB.style.zIndex = "10000";
    iframeB.src = src;
    iframeB.style.overflow = 'auto'; // 显示滚动条
    document.getElementById("mask").style.display = "block";
    iframeB.style.display = "block";
}

function hideIframeB(iframe) {
    var iframeB = document.getElementById(iframe);
    iframeB.src = "";
    document.getElementById("mask").style.display = "none";
    iframeB.style.display = "none";
}

function toclose(iframe) {
	var str = "close_" + iframe;
	window.parent.postMessage(str, window.location.origin);
}

function Ishow(iframe) {
    var iframeB = document.getElementById(iframe);
	if (iframeB.style.display === "none") {return false;} else {return true;}
}
window["popup"]["showIframeB"]=showIframeB;
window["popup"]["hideIframeB"]=hideIframeB;
window["popup"]["toclose"]=toclose;
window["popup"]["Ishow"]=Ishow;
})();