mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 导航栏1 = new 导航栏("导航栏1",导航栏1_项目被单击,null,null);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var CCS类库1 = new CCS类库("CCS类库1");
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 顶部选项卡1 = new 顶部选项卡("顶部选项卡1",顶部选项卡1_子卡被单击,null);
var div_coin_show = new 标签("div_coin_show",null);
var 自由面板1 = new 自由面板("自由面板1","90px");
var div_draw_grid = new 自由列表框("div_draw_grid",null,div_draw_grid_按钮被单击);
var div_draw_grid_note = new 标签("div_draw_grid_note",null);
var div_draw_grid_title = new 标签("div_draw_grid_title",null);
var div_draw_grid_btn = new 按钮("div_draw_grid_btn",null,null,null);
var div_draw_grid_id = new 标签("div_draw_grid_id",null);
var div_open_popover = new 弹出面板("div_open_popover",null,null);
var div_open_btn = new 按钮("div_open_btn",div_open_btn_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        累充福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        累充福利_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var 导航索引= 0;
var draw_url= "";
function 累充福利_创建完毕(){





	根地址 = HPtools1.取URL();
	导航栏初始化(2);

	标题栏美化1.去标题栏阴影();
	自由面板1.置可视(false);
	弹出面板初始化();
	顶部选项卡初始化(2);
	调整组件尺寸();
	m_post = 公用模块.生成提交数据(0, "oper_login_info", "", "vip_draw" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	时钟1.开始执行(200,false);
}
function 导航栏初始化(激活项目){
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-cart","商城","0",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-grech","抽奖","1",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-gift","福利","2",0);
	导航栏1.添加项目("mui-icon-extra", "mui-icon-extra-express","仓库","3",0);
	导航栏1.添加项目("mui-icon", "mui-icon-contact","我的","4",0);
	导航栏1.添加完毕();
	导航栏1.置激活项目背景色("#F2F2F2");
	导航栏1.置项目激活状态(0,false);
	导航栏1.置项目激活状态(1,false);
	导航栏1.置项目激活状态(2,false);
	导航栏1.置项目激活状态(3,false);
	导航栏1.置项目激活状态(4,false);
	导航栏1.置项目激活状态(激活项目,true);
	导航索引 = 激活项目;
}
function 导航栏1_项目被单击(项目标题,目标名称){
	var arr = ["shop","lottery","welfare","warehouse","user"];
	var 子卡索引=转换操作.到数值(目标名称);
	if(子卡索引 == 导航索引 ){
		HPtools1.弹出提示("已是当前页");
	}else{
		窗口操作.切换窗口(arr[子卡索引]+".html","");
	}
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 60, false);
	div_open_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_open_popover.添加组件("div_open_btn");
}
function 调整组件尺寸(){

	var width= 窗口操作.取窗口宽度();


	窗口操作.置组件宽度("div_draw_grid_title","" + 转换操作.到文本(width -20- 64 - 24) + "px");
	窗口操作.置组件宽度("div_draw_grid_note","" + 转换操作.到文本(width -20- 64 - 24)+ "px");
	窗口操作.置组件左边("div_draw_grid_btn","" + 转换操作.到文本(width -20- 64-20) + "px");

}
function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			if(json.table == "sign_welfare" && json.model == "select" ){
				if(文本操作.寻找文本(json.msg,"重新登陆") > -1 ){
					窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
				}else{
					仔仔弹出对话框1.错误(json.msg);
				}

			}else{
				窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
			}
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "oper_login_info_vip_draw" ){
				仔仔弹出对话框1.成功("已领取,请在仓库中提取资源");
			}else if(json.table == "oper_login_info_vip_benefits" ){
				if(窗口操作.是否在苹果内运行() == false ){
					HPtools1.打开网页("benefitstart.html?vip_id="+json.msg);
				}else{
					draw_url = "benefitstart.html?vip_id="+json.msg;
					div_open_popover.显示();
				}

			}else{
				仔仔弹出对话框1.成功(json.msg);
			}
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "oper_login_info" && json.model == "vip_draw" ){
				div_coin_show.置标题("您账户中有效的累充平台币为："+转换操作.到文本(json.msg.coin - json.msg.invest_zero));

				while(i < json.results.length){
					var title= "【 "+json.results[i].vip_name+" 】";
					title = title + "累充"+转换操作.到文本(json.results[i].vip_monetary)+"平台币可领取";
					var btn= "领取";
					var 按钮样式= "mui-btn mui-btn-success";
					if(json.results[i].is_receive > 0 ){
						btn = "已领<br>取过";
						按钮样式 = "mui-btn mui-btn-danger";
					}else if(json.results[i].vip_monetary > json.msg.coin - json.msg.invest_zero ){
						btn = "累充<br>不足";
						按钮样式 = "mui-btn mui-btn-royal";
					}
					var note= json.results[i].vip_note;
					if(note == "" ){
						note = title;
					}
					div_draw_grid_添加项目(title, note, btn, 按钮样式, json.results[i].vip_id);
					i++
				}
			}
		}
	}
}

function 顶部选项卡初始化(当前页){
	顶部选项卡1.清空子卡();
	顶部选项卡1.添加子卡("免费商城", false);
	顶部选项卡1.添加子卡("平台福利", false);
	顶部选项卡1.添加子卡("累充福利", false);
	顶部选项卡1.置激活子卡(当前页);
}
function 顶部选项卡1_子卡被单击(子卡索引){
	var arr = ["freeshop","welfare","benefits"];
	窗口操作.切换窗口(arr[子卡索引]+".html","");
}
function div_draw_grid_添加项目(项目标题, 项目内容, 按钮标题, 按钮样式, 项目标记){
	div_draw_grid_title.置标题(项目标题);
	div_draw_grid_note.置标题(项目内容);
	div_draw_grid_btn.置标题(按钮标题);
	div_draw_grid_btn.置样式(按钮样式);
	div_draw_grid_id.置标题(项目标记);
	div_draw_grid.添加项目("自由面板1",true,项目标记);
}

function div_draw_grid_按钮被单击(项目索引,按钮名称){
	var vip_id= div_draw_grid.取项目标记(项目索引);
	按钮标题 = div_draw_grid.取按钮标题(项目索引, 按钮名称);

	draw_url = "";
	if(按钮标题 == "领取" ){
		var json= {}
		json.vip_id = vip_id;
		m_post = 公用模块.生成提交数据(0, "oper_login_info_vip_draw", "", "" , 0, 0,json);
		m_url = 公用模块.生成访问链接(根地址,"api/shop/login", m_token);
		美化等待框1.默认等待框("正在交互","正在领取,请稍等......");
		时钟1.开始执行(200,false);
	}else if(按钮标题 == "已领<br>取过" ){
		仔仔弹出对话框1.提示("您已领取过");
	}else{
		仔仔弹出对话框1.提示("您的累充不足");
	}
}
function div_open_btn_被单击(){
	div_open_popover.隐藏();
	if(draw_url == "" ){
		仔仔弹出对话框1.错误("返回链接不完整,不能领取！");
		return;
	}
	HPtools1.打开网页(draw_url);
}