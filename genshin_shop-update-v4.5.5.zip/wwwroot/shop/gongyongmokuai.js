(function (){ 
window["公用模块"] = {}
function 延时发起访问请求(网络操作, post, url, 毫秒延时, 超时时长, 增强协议头){
	var mypost = post;
	var myurl = url;
	var timeout = 0;
	var type= typeof 超时时长;
	if(type != "number" ){
		timeout = 50000;
	}else{
		timeout = 超时时长;
		if(timeout < 50000 ){
			timeout = 50000;
		}
	}
	if(毫秒延时 < 5 ){
		毫秒延时 = 5;
	}
	var method="post";
	if(mypost == "" ){
		method="get";
	}
	if(增强协议头 == true ){
		网络操作.置附加请求头({"Content-Type":"application/json","Content-Length":  "10000000"});
		网络操作.置附加请求头();
	}else{
		网络操作.置附加请求头({"Content-Type":"application/json"});
	}
	setTimeout(function() {
		网络操作.发送网络请求(myurl,method,"text",mypost,timeout);
	}, 毫秒延时);
}
function 文本显示处理(待处理的文本, 显示颜色, 字体大小){
	var 类型= typeof 字体大小;
	if(类型 == "number" ){
		if(字体大小 < 1 ){
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+";\">"+待处理的文本+"</p>";
		}else if(字体大小 < 5 ){
			字体大小 = 数学操作.取整数(9 + 字体大小 * 2);
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+"; font-size:"+String(字体大小)+"px;\">"+待处理的文本+"</p>";
		}else{
			return "<p class=\"inline_block\" style=\"color:"+显示颜色+"; font-size:"+String(字体大小)+"px;\">"+待处理的文本+"</p>";
		}
	}else{
		return "<p class=\"inline_block\" style=\"color:"+显示颜色+";\">"+待处理的文本+"</p>";
	}

}


function 生成访问链接(url,api_key, token){
	url = 文本操作.删首尾空(url);
	api_key = 文本操作.删首尾空(api_key);
	token = 文本操作.删首尾空(token);
	if(url == "" || api_key == "" ){
		return "";
	}
	if(文本操作.取文本右边(url,1) != "/" && 文本操作.取文本左边(api_key,1) != "/" ){
		url = url + "/";
	}
	if(token == "" ){
		str= url + api_key;
	}else{
		str= url + api_key + "?token="+token;
	}
	return str;
}

function 弹出面板初始化计算(左边, 顶边或高度, 真高度动态假顶边动态){




	var 窗口高度= 窗口操作.取窗口高度();
	var 窗口宽度= 窗口操作.取窗口宽度();
	if(左边 < 0 ){
		窗口宽度 = 数学操作.取绝对值(左边);
		if(窗口宽度 > 窗口操作.取窗口宽度() ){
			窗口宽度 = 窗口操作.取窗口宽度();
		}
		左边 = (窗口操作.取窗口宽度() - 窗口宽度)/2;
	}else{
		窗口宽度 = 窗口操作.取窗口宽度()-左边*2;
	}
	var 顶边= 0;
	if(真高度动态假顶边动态 == true ){
		顶边 = 顶边或高度;
		窗口高度 = 窗口高度-顶边或高度 * 2;

	}else{
		顶边 = 窗口高度/2 - 顶边或高度/2;
		窗口高度 = 顶边或高度;
	}


	var ret = new Array();
	ret[0] = ""+左边+"px";
	ret[1] = ""+顶边+"px";
	ret[2] = ""+窗口宽度+"px";
	ret[3] = ""+窗口高度+"px";
	return ret;
}

function 生成提交数据(static, table, comm, model, num, level, 外部传入的数据, oper_login, oper_password){

	var 类型= typeof 外部传入的数据;
	var json= {}
	if(类型 == "string" ){
		外部传入的数据 = 文本操作.删首尾空(外部传入的数据);
		if(外部传入的数据 != "" ){
			if(文本操作.取文本左边(外部传入的数据,1) == "{" && 文本操作.取文本右边(外部传入的数据,1) == "}" ){
				json = 转换操作.文本转json(外部传入的数据);
			}else if(文本操作.取文本左边(外部传入的数据,1) == "[" && 文本操作.取文本右边(外部传入的数据,1) == "]" ){
				json = 转换操作.文本转json(外部传入的数据);
			}
		}
	}else if(类型 == "object" ){
		json = 转换操作.文本转json(转换操作.json转文本(外部传入的数据));
	}
	类型 = typeof json;
	if(类型 != "object" ){
		json = {}
	}


	json.static = static;
	json.table = table;
	json.comm = comm;
	json.model = model;
	json.num = num;
	json.level = level;
	类型 = typeof oper_login;
	if(类型 == "string" ){
		oper_login = 文本操作.删首尾空(oper_login);
		if(oper_login != "" ){
			json.oper_login = oper_login;
		}
	}
	类型 = typeof oper_password;
	if(类型 == "string" ){
		oper_password = 文本操作.删首尾空(oper_password);
		if(oper_password != "" ){
			json.oper_password = oper_password;
		}
	}
	return 转换操作.json转文本(json);
}

function 取空格文本(空格数量){
	var i= 0;
	var ret="";
	while(i <  空格数量){
		ret = ret + "&nbsp;";
		i++
	}
	return ret;
}

function 键代码是回车键(键代码){
	if(键代码 == 13 ){
		return true;
	}else{
		return false;
	}
}

function 打开小窗口(url, title, left, top, width, height){
	var feat= "height="+转换操作.到文本(height)+", width="+转换操作.到文本(width)+", top="+转换操作.到文本(top)+", left="+转换操作.到文本(left)+", toolbar=no, menubar=no,scrollbars=yes,resizable=no, location=no, status=no";
	var me= window.open(url, title, feat);
	return me;
}

function 居中打开小窗口(url, width, height){
	var w= 窗口操作.取窗口宽度();
	var h= 窗口操作.取窗口高度();
	if(width > w ){
		width = w;
	}
	if(height > h ){
		height = h;
	}
	var left= 0;
	var top= 0;
	if(w > width ){
		left = (w - width) / 2;
	}
	if(h > height ){
		top = (h - height) / 2;
	}
	var me= 打开小窗口(url,"",left, top, width, height);
	return me;
}

function 自由面板_调整(自由面板内组件名称, 组件左边, 组件宽度,设计时宽度, 实际窗口宽度){
	var arr = new Array();
	arr = 自由面板_坐标生成(组件左边,组件宽度,设计时宽度,实际窗口宽度);
	窗口操作.置组件左边(自由面板内组件名称,arr[0]);
	窗口操作.置组件宽度(自由面板内组件名称,arr[1]);
}


function 自由面板_坐标生成(组件左边, 组件宽度, 设计时宽度, 实际窗口宽度){
	var 系数 = 0;
	系数 = 组件左边 / 设计时宽度;
	var 实际左边="" + 数学操作.四舍五入(实际窗口宽度 * 系数, 0) + "px";
	系数 = 组件宽度 / 设计时宽度;
	var 实际宽度="" + 数学操作.四舍五入(实际窗口宽度 * 系数, 0) + "px";
	var arr = new Array();
	arr[0] = 实际左边;
	arr[1] = 实际宽度;
	return arr;
}

function 取编码和名称(待处理的文本, 分隔符号){
	var res = new Array();
	待处理的文本 = 文本操作.删首尾空(待处理的文本);
	res[0] = "";
	res[1] = "";
	if(待处理的文本 != "" ){
		var i= 文本操作.寻找文本(待处理的文本, 分隔符号);
		if(i < 1 ){
			res[1] = 待处理的文本;
		}else{
			res[0] = 文本操作.删首尾空(文本操作.取文本左边(待处理的文本, i));
			res[1] = 文本操作.删首尾空(文本操作.取文本右边(待处理的文本, 文本操作.取文本长度(待处理的文本)-i-文本操作.取文本长度(分隔符号)));
		}
	}
	return res;
}

function 生成脚本内容及显示名称(item_model, 原编码值, 原显示名称, num, level){
	var res = new Array();
	res[0] = "";
	res[1] = "";
	原编码值 = 文本操作.删首尾空(原编码值);
	原显示名称 = 文本操作.删首尾空(原显示名称);
	if(item_model == 7 ){
		if(num > 14 ){
			num = 14;
		}
		if(level > 200 ){
			level = 200;
		}
	}

	var 数量= 转换操作.到文本(num);
	var 等级= 转换操作.到文本(level);

	switch(item_model){
		case 0 :
			res[0] = "item add " + 原编码值 +" "+ 数量;
			res[1] = 原显示名称 + " +"+ 数量;
		break;
		case 1 :
			if(原编码值 == "203" ){
				res[0] = "mcoin " + 数量;
			}else{
				res[0] = "item add " + 原编码值 +" "+ 数量;
			}
			res[1] = 原显示名称 + " +"+ 数量;
		break;
		case 2 :
			res[0] = "equip add " + 原编码值;
			res[1] = 原显示名称 + " +1";
		break;
		case 3 :
			res[0] = "avatar add " + 原编码值;
			res[1] = 原显示名称 + " <!>";
		break;
		case 4 :
			res[0] = "goto " + 原编码值;
			res[1] = "传送到："+原显示名称;
		break;
		case 5 :
			if(num > 0 ){
				res[0] = "quest accept " + 原编码值;
				res[1] = "接受任务："+原显示名称;
			}else{
				res[0] = "quest finish " + 原编码值;
				res[1] = "完成任务："+原显示名称;
			}
		break;
		case 6 :
			res[0] = "jump " + 原编码值;
			res[1] = "移动到："+原显示名称;
		break;
		case 7 :
			res[0] = "monster " + 原编码值 +" "+ 数量+" "+等级;
			res[1] = 原显示名称 + "["+等级+"级] +"+ 数量;
		break;
		case 8 :
			res[0] = 原编码值;
			res[1] = 原显示名称;
		break;
		case 9 :
			res[0] = 原编码值 +" "+ 数量;
			res[1] = 原显示名称 + " +"+ 数量;
		break;
	}
	return res;
}

function 生成明细查看摘要(password,model, table_id, table_value, table, table_colm, table_title, 补充查询条件){
	var res= "detail.html?password="+password+"&model="+转换操作.到文本(model)+"&table_id="+table_id+"&table_value="+table_value;
	return res + "&table="+table + "&table_colm="+table_colm + "&table_title="+table_title+"&select_value="+补充查询条件;
}

function 签到日期转换(sign_day){
	switch(sign_day){
	case 0 :
		return "";
	break;
	case 1 :
		return "每月1号/周一/每天";
	break;
	case 2 :
		return "每月2号/周二";
	break;
	case 3 :
		return "每月3号/周三";
	break;
	case 4 :
		return "每月4号/周四";
	break;
	case 5 :
		return "每月5号/周五";
	break;
	case 6 :
		return "每月6号/周六";
	break;
	case 7 :
		return "每月7号/周日";
	break;
	default :
		return "每月" + 转换操作.到文本(sign_day)+"号";
		break;
	}
}

function 高级表格_快速生成(是选择框, 隐藏列, 显示操作栏, 固定在左边){
	var arr = new Array();
	arr[0] = 是选择框;
	arr[1] = false;
	arr[2] = 显示操作栏;
	arr[3] = 固定在左边;
	arr[4] = 隐藏列;
	arr[5] = false;
	arr[6] = "";
	arr[7] = false;
	arr[8] = false;
	return arr;
}

function 是否为整数文本(待判断的文本, 允许负数, 允许首位是零){
	待判断的文本 = 文本操作.删首尾空(待判断的文本);
	if(待判断的文本 == "" ){
		return false;
	}
	var num= 文本操作.取文本长度(待判断的文本);
	var i= 0;
	while(i < num){
		var s1= 文本操作.取文本中间(待判断的文本,i,1);
		if(s1 == "1" || s1 == "2" || s1 == "3" || s1 == "4" || s1 == "5" || s1 == "6" || s1 == "7" || s1 == "8" || s1 == "9" ){

		}else{
			if(i < 1 ){
				if(s1 != "-" && s1 != "0" ){
					return false;
				}else if(s1 == "-" && 允许负数 == false ){
					return false;
				}else if(s1 == "0" && 允许首位是零 == false ){
					return false;
				}
			}else{
				if(s1 != "0" ){
					return false;
				}
			}
		}
		i++
	}
	return true;
}

function 交易状态_设置(原显示内容,限购数量, 已购数量){
	if(原显示内容 == "库存充足" ){
		return "库存充足";
	}else{
		var str= "限购 "+转换操作.到文本(限购数量)+" 已购 "+转换操作.到文本(已购数量);
		return str;
	}
}

function 交易状态_可否购买(原显示内容){
	原显示内容 = 文本操作.删首尾空(原显示内容);
	if(原显示内容 == "库存充足" || 原显示内容 == "" ){
		return true;
	}
	var str= 文本操作.子文本替换(原显示内容, "限购","");
	str = 文本操作.子文本替换(str, "已购","");
	str = 文本操作.子文本替换(str, "  "," ");
	str = 文本操作.子文本替换(str, "  "," ");
	str=文本操作.删首尾空(str);
	var arr = 文本操作.分割文本(str, " ");
	if(数组操作.取成员数(arr) != 2 ){
		return false;
	}else{
		if(转换操作.到数值(arr[0]) <= 转换操作.到数值(arr[1]) ){
			return false;
		}else{
			return true;
		}
	}
}

function 限时状态_可否购买(原显示内容){
	原显示内容 = 文本操作.删首尾空(原显示内容);
	if(原显示内容 == "" ){
		return 0;
	}
	var str= 文本操作.子文本替换(原显示内容, "限时销售","");
	str = 文本操作.子文本替换(str, "：","");
	str = 文本操作.子文本替换(str, ":","");
	str = 文本操作.子文本替换(str, "  "," ");
	str = 文本操作.子文本替换(str, "  "," ");
	str=文本操作.删首尾空(str);
	var arr = 文本操作.分割文本(str, "-");
	if(数组操作.取成员数(arr) != 2 ){
		return -1;
	}else{
		var start= 时间操作.到日期时间2(文本操作.删首尾空(arr[0]));
		var end= 时间操作.到日期时间2(文本操作.删首尾空(arr[1]));
		var now= 时间操作.取当前日期时间();



		if(now < start ){
			return -1;
		}else if(now > end ){
			return 1;
		}else{
			return 0;
		}
	}
}

function 网络错误翻译(返回信息){
	var str= 文本操作.删首尾空(返回信息);
	str = 文本操作.到小写(返回信息);
	if(str == "abort" ){
		return "server.fail";
	}else if(str == "error" ){
		return "ajax.fail";
	}else if(str == "timeout" ){
		return "ajax.timeout";
	}else{
		return 返回信息;
	}
}

function 组装直充请求(pay_id, pay_amount,pay_name,根地址,pay_type, token){
	var res = new Array();
	var json= {}
	json.pay_amount = pay_amount;
	json.pay_name = pay_name;
	json.root_url = 根地址;

	json.pay_type = pay_type;
	json.pay_id = pay_id;
	res[0] = 公用模块.生成提交数据(0, "user_pay", "", "pay" , 0, 0,json);
	res[1] = 公用模块.生成访问链接(根地址,"api/pay/start", token);
	return res;
}
function 发起POST表单(返回数据){
	var form = document.createElement("form");
	form.action = 返回数据.submit.submit;
	form.method = "POST";

	var money = document.createElement("input");
	money.type = "hidden";
	money.name = "money";
	money.value = 返回数据.msg.money;
    form.appendChild(money);

	var name = document.createElement("input");
	name.type = "hidden";
	name.name = "name";
	name.value = 返回数据.msg.name;
    form.appendChild(name);

	var notify_url = document.createElement("input");
	notify_url.type = "hidden";
	notify_url.name = "notify_url";
	notify_url.value = 返回数据.msg.notify_url;
    form.appendChild(notify_url);

	var out_trade_no = document.createElement("input");
	out_trade_no.type = "hidden";
	out_trade_no.name = "out_trade_no";
	out_trade_no.value = 返回数据.msg.out_trade_no;
    form.appendChild(out_trade_no);

	var pid = document.createElement("input");
	pid.type = "hidden";
	pid.name = "pid";
	pid.value = 返回数据.msg.pid;
    form.appendChild(pid);

	var return_url = document.createElement("input");
	return_url.type = "hidden";
	return_url.name = "return_url";
	return_url.value = 返回数据.msg.return_url;
    form.appendChild(return_url);

	if(返回数据.submit.pay_model == 1 ){
		var return_url = document.createElement("input");
		return_url.type = "hidden";
		return_url.name = "sitename";
		return_url.value = 返回数据.msg.sitename;
		form.appendChild(return_url);
	}

	var type1 = document.createElement("input");
	type1.type = "hidden";
	type1.name = "type";
	type1.value = 返回数据.msg.type;
    form.appendChild(type1);

	var sign = document.createElement("input");
	sign.type = "hidden";
	sign.name = "sign";
	sign.value = 返回数据.msg.sign;
    form.appendChild(sign);

	var sign_type = document.createElement("input");
	sign_type.type = "hidden";
	sign_type.name = "sign_type";
	sign_type.value = 返回数据.msg.sign_type;
    form.appendChild(sign_type);

	document.body.appendChild(form);
	form.submit();

}
function 发起GET充值(返回数据){
	var submit= 返回数据.submit.submit+"?pid="+返回数据.msg.pid+"&type="+返回数据.msg.type+"&out_trade_no="+返回数据.msg.out_trade_no;
	submit = submit + "&notify_url="+返回数据.msg.notify_url + "&return_url="+返回数据.msg.return_url;
	submit = submit + "&name="+返回数据.msg.name + "&money="+转换操作.到文本(返回数据.msg.money);
	if(返回数据.submit.pay_model == 1 ){
		submit = submit + "&sitename="+返回数据.msg.sitename;
	}
	submit = submit + "&sign="+返回数据.msg.sign + "&sign_type="+返回数据.msg.sign_type;
	window.location.href = submit;
}


function 文本_取中间文本(待处理的文本, 左边文本, 右边文本){
	待处理的文本 = 文本操作.删首尾空(待处理的文本);
	if(待处理的文本 == "" ){
		return "";
	}
	var left= 文本操作.寻找文本(待处理的文本, 左边文本);
	var len_l= 文本操作.取文本长度(左边文本);
	if(left < 0 ){
		return "";
	}
	var right= 文本操作.寻找文本(待处理的文本, 右边文本, left+len_l);
	if(right < 0 ){
		return "";
	}
	return 文本操作.取文本中间(待处理的文本,left+len_l,right-left-len_l);
}

function 打开网页2(url){
	setTimeout(() => window.open(url, "_blank"));
}
function 打开网页3(url){
	let a = document.createElement("a");
	a.setAttribute("href", url);
	a.setAttribute("target", "_blank");
	document.body.appendChild(a);
	a.click();
	a.remove();
}




function 动态加载脚本(url, callback, 关联函数){
	var script = document.createElement("script");
	script.src = url;
	if(typeof 关联函数 != "undefined" ){
		script.onload = function() {callback(关联函数);};
	}else{
		script.onload = callback;
	}
	document.head.appendChild(script);
}
function createMask(mask_id, zIndex){
	var mask = document.createElement("div");
    mask.id = mask_id;
    mask.style.display = "none";
    mask.style.position = "fixed";
    mask.style.top = "0";
    mask.style.left = "0";
    mask.style.width = "100%";
    mask.style.height = "100%";
    mask.style.background = "rgba(0,0,0,0.3)";
	if(typeof zIndex != "number" ){
		mask.style.zIndex = "99999999";
	}else if(Math.floor(zIndex) < 1 ){
		mask.style.zIndex = "99999999";
	}else{
		mask.style.zIndex = String(Math.floor(zIndex));
	}
    document.body.appendChild(mask);
}

function showMask(mask_id){
    var mask = document.getElementById(mask_id);
    if (!mask) {
        createMask(mask_id);
    }
    document.getElementById(mask_id).style.display = "block";
}


function hideMask(mask_id){
	var mask = document.getElementById(mask_id);
    if (mask) {
        mask.style.display = "none";
    }
}

function 在指定元素上创建遮罩及等待框(指定元素的ID, 等待框标题){
	var iframe = document.getElementById(指定元素的ID);
	var iframeRect = iframe.getBoundingClientRect();
    var overlay = document.createElement("div");
    overlay.id = "overlay_" + 指定元素的ID + "_mask";
    overlay.style.position = "fixed";
    overlay.style.top = iframeRect.top + "px";
    overlay.style.left = iframeRect.left + "px";
    overlay.style.width = iframe.offsetWidth + "px";
    overlay.style.height = iframe.offsetHeight + "px";
    overlay.style.backgroundColor = "rgba(0, 0, 0, 0.5)";
    overlay.style.zIndex = "99999999";

    var loading = document.createElement("div");
    loading.textContent = 等待框标题;
    loading.style.position = "absolute";
    loading.style.top = "50%";
    loading.style.left = "50%";
    loading.style.transform = "translate(-50%, -50%)";
    loading.style.color = "#fff";

    overlay.appendChild(loading);
    document.body.appendChild(overlay);
}
function 在指定元素上移除遮罩及等待框(指定元素的ID){
	var overlay = document.getElementById("overlay_" + 指定元素的ID + "_mask");
	if (overlay) { overlay.remove(); }
}
window["公用模块"]["延时发起访问请求"]=延时发起访问请求;
window["公用模块"]["文本显示处理"]=文本显示处理;
window["公用模块"]["生成访问链接"]=生成访问链接;
window["公用模块"]["弹出面板初始化计算"]=弹出面板初始化计算;
window["公用模块"]["生成提交数据"]=生成提交数据;
window["公用模块"]["取空格文本"]=取空格文本;
window["公用模块"]["键代码是回车键"]=键代码是回车键;
window["公用模块"]["打开小窗口"]=打开小窗口;
window["公用模块"]["居中打开小窗口"]=居中打开小窗口;
window["公用模块"]["自由面板_调整"]=自由面板_调整;
window["公用模块"]["自由面板_坐标生成"]=自由面板_坐标生成;
window["公用模块"]["取编码和名称"]=取编码和名称;
window["公用模块"]["生成脚本内容及显示名称"]=生成脚本内容及显示名称;
window["公用模块"]["生成明细查看摘要"]=生成明细查看摘要;
window["公用模块"]["签到日期转换"]=签到日期转换;
window["公用模块"]["高级表格_快速生成"]=高级表格_快速生成;
window["公用模块"]["是否为整数文本"]=是否为整数文本;
window["公用模块"]["交易状态_设置"]=交易状态_设置;
window["公用模块"]["交易状态_可否购买"]=交易状态_可否购买;
window["公用模块"]["限时状态_可否购买"]=限时状态_可否购买;
window["公用模块"]["网络错误翻译"]=网络错误翻译;
window["公用模块"]["组装直充请求"]=组装直充请求;
window["公用模块"]["发起POST表单"]=发起POST表单;
window["公用模块"]["发起GET充值"]=发起GET充值;
window["公用模块"]["文本_取中间文本"]=文本_取中间文本;
window["公用模块"]["打开网页2"]=打开网页2;
window["公用模块"]["打开网页3"]=打开网页3;
window["公用模块"]["动态加载脚本"]=动态加载脚本;
window["公用模块"]["createMask"]=createMask;
window["公用模块"]["showMask"]=showMask;
window["公用模块"]["hideMask"]=hideMask;
window["公用模块"]["在指定元素上创建遮罩及等待框"]=在指定元素上创建遮罩及等待框;
window["公用模块"]["在指定元素上移除遮罩及等待框"]=在指定元素上移除遮罩及等待框;
})();