﻿    function CYS滚动选择器(name,event){
		/*
			作者：CYS
			QQ：649812788
		*/
		var userPicker = new mui.PopPicker();
		var jsonArr = [];
        this.名称 = name; 
		
		this.添加项目 = function(text,value){
			var txt = "{value:'" + value + "',text:'" + text + "'}";
			var arr = eval('('+txt+')');
			jsonArr.push(arr);
			userPicker.setData(jsonArr);
		};
                this.清空项目 = function(){
	jsonArr.splice(0,jsonArr.length);
	userPicker.setData(jsonArr);
}
		
		this.弹出 = function(){
			if(jsonArr.length==0) return;
			userPicker.show(function(items){
				if(event!=null){
					event(items[0].text,items[0].value);
				};
			});
		};
		
		this.置样式 = function(val){//0 默认样式  1 白色样式
			var popPickerHeader = document.getElementsByClassName("mui-poppicker-header")[0];
			var popPickerBody = document.getElementsByClassName("mui-poppicker-body")[0];
			var picker = popPickerBody.getElementsByClassName("mui-picker")[0];
			var btnOk = popPickerHeader.getElementsByClassName("mui-poppicker-btn-ok")[0];
			var btnCancle = popPickerHeader.getElementsByClassName("mui-poppicker-btn-cancel")[0];
			
			if(val==0){
				picker.style.background = "#ddd";
				popPickerHeader.style.background = "#eee";
				popPickerBody.style.borderTop = "1px solid #ddd";
				btnOk.style.border = "1px solid #007AFF";
				btnOk.style.background = "#007AFF";
				btnOk.style.color = "#fff";
				btnCancle.style.border = "1px solid #ccc";
				btnCancle.style.color = "#000";
			}else if(val==1){
				picker.style.background = "#fff";
				popPickerHeader.style.background = "#fff";
				popPickerBody.style.borderTop = "none";
				btnOk.style.border = "1px solid #fff";
				btnOk.style.background = "#fff";
				btnOk.style.color = "#007AFF";
				btnCancle.style.border = "1px solid #fff";
				btnCancle.style.color = "#007AFF";
			}
		}
		
    }