mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 时钟1 = new 时钟("时钟1",时钟1_周期事件);
var 标签1 = new 标签("标签1",null);
var 自由DIV组_今日 = new 自由DIV组("自由DIV组_今日",null);
var 标签2 = new 标签("标签2",null);
var 自由DIV组_昨日 = new 自由DIV组("自由DIV组_昨日",null);
var 标签3 = new 标签("标签3",null);
var 自由DIV组_本周 = new 自由DIV组("自由DIV组_本周",null);
var 标签4 = new 标签("标签4",null);
var 自由DIV组_本月 = new 自由DIV组("自由DIV组_本月",null);
var 标签5 = new 标签("标签5",null);
var 自由DIV组_7日 = new 自由DIV组("自由DIV组_7日",null);
var 标签6 = new 标签("标签6",null);
var 自由DIV组_30日 = new 自由DIV组("自由DIV组_30日",null);
var 历史总营收统计 = new 标签("历史总营收统计",null);
var 自由DIV组_历史 = new 自由DIV组("自由DIV组_历史",null);
var 按钮_加载 = new 按钮("按钮_加载",按钮_加载_被单击,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        综合营收_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        综合营收_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var m_model= 0;
function 综合营收_创建完毕(){
	m_password = 文本操作.删首尾空(窗口操作.取当前页面参数("password"));
	if(m_password == "" ){
		窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码("password异常,请重新登陆！"),"");
		return;
	}
	根地址 = HPtools1.取URL();
	var json= {}
	json.start_time = "";
	json.end_time = "";
	m_post = 公用模块.生成提交数据(0, "comprehensive", "", "sum" , 0, 0,json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/report", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	时钟1.开始执行(200,false);
}

function 时钟1_周期事件(){


	底层_发送网络请求(50000);
}
function 底层_发送网络请求(超时时长){
	var 请求类型="post";
	if(m_post == "" ){
		请求类型="get";
	}
	网络操作1.置附加请求头({"Content-Type":"application/json"});
	if(超时时长 < 5000 ){
		超时时长 = 5000;
	}
	网络操作1.发送网络请求(m_url,请求类型,"text",m_post,超时时长);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	按钮_加载.置可视(true);
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			自由DIV组_今日.创建顶部DIV("#","150px","150px","2px","#FF00FF","20px","100%","16px","Microsoft YaHei","40px","#FF00FF","CDK充值金额","20px","SimHei","20px","#FF00FF",金额转换(json,0)+"(实)<br>"+金额转换(json,28)+"(赠)");
			自由DIV组_今日.创建顶部DIV("#","150px","150px","2px","#FF00FF","20px","100%","16px","Microsoft YaHei","40px","#FF00FF","在线直充金额","20px","SimHei","20px","#FF00FF",金额转换(json,1)+"(实)<br>"+金额转换(json,29)+"(赠)");
			自由DIV组_今日.创建顶部DIV("#","150px","150px","2px","#FF00FF","20px","100%","16px","Microsoft YaHei","40px","#FF00FF","商城营业额","20px","SimHei","20px","#FF00FF",金额转换(json,2)+"<br>&nbsp;");
			自由DIV组_今日.创建顶部DIV("#","150px","150px","2px","#FF00FF","20px","100%","16px","Microsoft YaHei","40px","#FF00FF","抽奖营业额","20px","SimHei","20px","#FF00FF",金额转换(json,3)+"<br>&nbsp;");

			自由DIV组_昨日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","CDK充值金额","20px","SimHei","20px","#9000FF",金额转换(json,4)+"(实)<br>"+金额转换(json,30)+"(赠)");
			自由DIV组_昨日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","在线直充金额","20px","SimHei","20px","#9000FF",金额转换(json,5)+"(实)<br>"+金额转换(json,31)+"(赠)");
			自由DIV组_昨日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","商城营业额","20px","SimHei","20px","#9000FF",金额转换(json,6)+"<br>&nbsp;");
			自由DIV组_昨日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","抽奖营业额","20px","SimHei","20px","#9000FF",金额转换(json,7)+"<br>&nbsp;");

			自由DIV组_本周.创建顶部DIV("#","150px","150px","2px","#0088FF","20px","100%","16px","Microsoft YaHei","40px","#0088FF","CDK充值金额","20px","SimHei","20px","#0088FF",金额转换(json,8)+"(实)<br>"+金额转换(json,32)+"(赠)");
			自由DIV组_本周.创建顶部DIV("#","150px","150px","2px","#0088FF","20px","100%","16px","Microsoft YaHei","40px","#0088FF","在线直充金额","20px","SimHei","20px","#0088FF",金额转换(json,9)+"(实)<br>"+金额转换(json,33)+"(赠)");
			自由DIV组_本周.创建顶部DIV("#","150px","150px","2px","#0088FF","20px","100%","16px","Microsoft YaHei","40px","#0088FF","商城营业额","20px","SimHei","20px","#0088FF",金额转换(json,10)+"<br>&nbsp;");
			自由DIV组_本周.创建顶部DIV("#","150px","150px","2px","#0088FF","20px","100%","16px","Microsoft YaHei","40px","#0088FF","抽奖营业额","20px","SimHei","20px","#0088FF",金额转换(json,11)+"<br>&nbsp;");

			自由DIV组_本月.创建顶部DIV("#","150px","150px","2px","#0000FF","20px","100%","16px","Microsoft YaHei","40px","#0000FF","CDK充值金额","20px","SimHei","20px","#0000FF",金额转换(json,12)+"(实)<br>"+金额转换(json,34)+"(赠)");
			自由DIV组_本月.创建顶部DIV("#","150px","150px","2px","#0000FF","20px","100%","16px","Microsoft YaHei","40px","#0000FF","在线直充金额","20px","SimHei","20px","#0000FF",金额转换(json,13)+"(实)<br>"+金额转换(json,35)+"(赠)");
			自由DIV组_本月.创建顶部DIV("#","150px","150px","2px","#0000FF","20px","100%","16px","Microsoft YaHei","40px","#0000FF","商城营业额","20px","SimHei","20px","#0000FF",金额转换(json,14)+"<br>&nbsp;");
			自由DIV组_本月.创建顶部DIV("#","150px","150px","2px","#0000FF","20px","100%","16px","Microsoft YaHei","40px","#0000FF","抽奖营业额","20px","SimHei","20px","#0000FF",金额转换(json,15)+"<br>&nbsp;");

			自由DIV组_7日.创建顶部DIV("#","150px","150px","2px","#C06000","20px","100%","16px","Microsoft YaHei","40px","#C06000","CDK充值金额","20px","SimHei","20px","#C06000",金额转换(json,16)+"(实)<br>"+金额转换(json,36)+"(赠)");
			自由DIV组_7日.创建顶部DIV("#","150px","150px","2px","#C06000","20px","100%","16px","Microsoft YaHei","40px","#C06000","在线直充金额","20px","SimHei","20px","#C06000",金额转换(json,17)+"(实)<br>"+金额转换(json,37)+"(赠)");
			自由DIV组_7日.创建顶部DIV("#","150px","150px","2px","#C06000","20px","100%","16px","Microsoft YaHei","40px","#C06000","商城营业额","20px","SimHei","20px","#C06000",金额转换(json,18)+"<br>&nbsp;");
			自由DIV组_7日.创建顶部DIV("#","150px","150px","2px","#C06000","20px","100%","16px","Microsoft YaHei","40px","#C06000","抽奖营业额","20px","SimHei","20px","#C06000",金额转换(json,19)+"<br>&nbsp;");

			自由DIV组_30日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","CDK充值金额","20px","SimHei","20px","#9000FF",金额转换(json,20)+"(实)<br>"+金额转换(json,38)+"(赠)");
			自由DIV组_30日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","在线直充金额","20px","SimHei","20px","#9000FF",金额转换(json,21)+"(实)<br>"+金额转换(json,39)+"(赠)");
			自由DIV组_30日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","商城营业额","20px","SimHei","20px","#9000FF",金额转换(json,22)+"<br>&nbsp;");
			自由DIV组_30日.创建顶部DIV("#","150px","150px","2px","#9000FF","20px","100%","16px","Microsoft YaHei","40px","#9000FF","抽奖营业额","20px","SimHei","20px","#9000FF",金额转换(json,23)+"<br>&nbsp;");

			自由DIV组_历史.创建顶部DIV("#","150px","150px","2px","#FF0000","20px","100%","16px","Microsoft YaHei","40px","#FF0000","CDK充值金额","20px","SimHei","20px","#FF0000",金额转换(json,24)+"(实)<br>"+金额转换(json,40)+"(赠)");
			自由DIV组_历史.创建顶部DIV("#","150px","150px","2px","#FF0000","20px","100%","16px","Microsoft YaHei","40px","#FF0000","在线直充金额","20px","SimHei","20px","#FF0000",金额转换(json,25)+"(实)<br>"+金额转换(json,41)+"(赠)");
			自由DIV组_历史.创建顶部DIV("#","150px","150px","2px","#FF0000","20px","100%","16px","Microsoft YaHei","40px","#FF0000","商城营业额","20px","SimHei","20px","#FF0000",金额转换(json,26)+"<br>&nbsp;");
			自由DIV组_历史.创建顶部DIV("#","150px","150px","2px","#FF0000","20px","100%","16px","Microsoft YaHei","40px","#FF0000","抽奖营业额","20px","SimHei","20px","#FF0000",金额转换(json,27)+"<br>&nbsp;");

		}
	}
}


function 金额转换(json, num){
	var rmb= 转换操作.到文本(数学操作.取绝对值(json.results[num].coin / json.msg));
	return rmb;
}
function 按钮_加载_被单击(){
	var json= {}
	json.start_time = "";
	json.end_time = "";
	自由DIV组_今日.清空顶部DIV项目();
	自由DIV组_昨日.清空顶部DIV项目();
	自由DIV组_本周.清空顶部DIV项目();
	自由DIV组_本月.清空顶部DIV项目();
	自由DIV组_7日.清空顶部DIV项目();
	自由DIV组_30日.清空顶部DIV项目();
	自由DIV组_历史.清空顶部DIV项目();
	m_post = 公用模块.生成提交数据(0, "comprehensive", "", "sum" , 0, 0,json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/report", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	时钟1.开始执行(200,false);
}
