mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 标题栏美化1 = new 标题栏美化("标题栏美化1",null,null,null);
var 面板1 = new 面板("面板1");
var 编辑框_条件 = new 编辑框("编辑框_条件",null,null,null,null,null);
var 按钮_查询 = new 按钮("按钮_查询",按钮_查询_被单击,null,null);
var 面板2 = new 面板("面板2");
var 按钮_提取 = new 按钮("按钮_提取",按钮_提取_被单击,null,null);
var 按钮_取消选择 = new 按钮("按钮_取消选择",按钮_取消选择_被单击,null,null);
var 标签_提示 = new 标签("标签_提示",null);
var div_warehouse_grid = new CYS选择列表框("div_warehouse_grid",null);
var 按钮_加载 = new 按钮("按钮_加载",按钮_加载_被单击,null,null);
var 悬浮按钮1 = new 悬浮按钮("悬浮按钮1",悬浮按钮1_被单击);
var div_warehouse_popover = new 弹出面板("div_warehouse_popover",null,null);
var div_warehouse_lable_1 = new 标签("div_warehouse_lable_1",null);
var div_warehouse_inout_no = new 编辑框("div_warehouse_inout_no",null,null,null,null,null);
var div_warehouse_time = new 标签("div_warehouse_time",null);
var div_warehouse_sku = new 标签("div_warehouse_sku",null);
var div_warehouse_lable_2 = new 标签("div_warehouse_lable_2",null);
var div_warehouse_oper_note = new 编辑框("div_warehouse_oper_note",null,null,null,null,null);
if(mui.os.plus){
    mui.plusReady(function() {
        暂存资源_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        暂存资源_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_token= "";
var m_value= "";
var page= 0;
var warehouse_num= 0;
function 暂存资源_创建完毕(){
	根地址 = HPtools1.取URL();
	标题栏美化1.去标题栏阴影();
	生成界面();
	弹出面板初始化();
	获取仓库状态();
}

function 生成界面(){
	面板1.添加组件("编辑框_条件", "3");
	面板1.添加组件("按钮_查询", "1");
	面板2.添加组件("按钮_提取", "200px");
	面板2.添加组件("按钮_取消选择", "100px");
	面板2.添加组件("标签_提示", "300px");
	悬浮按钮1.置可视(true);
	悬浮按钮1.置标题("TOP");
	悬浮按钮1.置按钮颜色("#007aff");
	悬浮按钮1.置按钮圆角("80%");
	悬浮按钮1.置按钮透明度("1");
	悬浮按钮1.置按钮宽高("60px","60px");

	悬浮按钮1.置按钮位置("10px","20px");
	document.getElementById("悬浮按钮1").style.color = "#FFFFFF";
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(50, 200, false);
	div_warehouse_popover.初始化(rect[0],rect[1],rect[2],rect[3]);
	div_warehouse_popover.添加组件("div_warehouse_lable_1");
	div_warehouse_popover.添加组件("div_warehouse_inout_no");
	div_warehouse_popover.添加组件("div_warehouse_time");
	div_warehouse_popover.添加组件("div_warehouse_sku");
	div_warehouse_popover.添加组件("div_warehouse_lable_2");
	div_warehouse_popover.添加组件("div_warehouse_oper_note");
}
function 获取仓库列表(查询页号){
	if(查询页号 < 2 ){
		查询页号 = 1;
		编辑框_条件.置内容(文本操作.删首尾空(编辑框_条件.取内容()));
		m_value = 编辑框_条件.取内容();
		按钮_加载.置可视(false);
		div_warehouse_grid.清空项目();
	}
	m_post = 公用模块.生成提交数据(0, "warehouse_info", m_value, "more" , 查询页号, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/more", m_token);
	美化等待框1.默认等待框("正在交互","正在获取资源列表,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 按钮_查询_被单击(){
	获取仓库列表(1);
}
function 按钮_加载_被单击(){
	获取仓库列表(page+1);
}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static < 0 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			if(json.table == "warehouse_info" && json.model == "state" ){
				warehouse_num = json._id;
				if(warehouse_num <= 0 ){
					warehouse_num = 20;
				}else if(warehouse_num < 3 ){
					warehouse_num = 3;
				}
				标签_提示.置标题("&nbsp;&nbsp;&nbsp;&nbsp;单次最多可提取："+String(warehouse_num)+"条！");
			}
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table == "warehouse_info" && json.model == "state" ){
				warehouse_num = json._id;
				if(warehouse_num <= 0 ){
					warehouse_num = 20;
				}else if(warehouse_num < 3 ){
					warehouse_num = 3;
				}
				标签_提示.置标题("&nbsp;&nbsp;&nbsp;&nbsp;单次最多可提取："+String(warehouse_num)+"条！");
				return;
			}
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			var i= 0;
			if(json.table == "warehouse_info" && json.model == "more" ){
				var old_num= 0;
				if(json.page < 2 ){
					div_warehouse_grid.清空项目();
				}
				page = json.page;
				按钮_加载.置可视(true);
				while(i < json.results.length){
					添加列表(json.results[i]);
					i++
				}
			}
			if(json.table == "warehouse_info" && json.model == "state" ){
				warehouse_num = json._id;
				if(warehouse_num <= 0 ){
					warehouse_num = 20;
				}else if(warehouse_num < 3 ){
					warehouse_num = 3;
				}
				标签_提示.置标题("&nbsp;&nbsp;&nbsp;&nbsp;单次最多可提取："+String(warehouse_num)+"条！");
			}
		}
	}
}

function 添加列表(results){
	var str= "";
	if(results.oper_static < 1 ){
		str ="暂存仓库";
	}else if(results.oper_static == 1 ){
		str ="正在领取";
	}else{
		str ="已领取";
	}
	str = 公用模块.文本显示处理(results.value, "#000000", 2) + 公用模块.文本显示处理("状态："+str +" ，所属：" + results.oper_note, "#576B95", 2);
	div_warehouse_grid.添加项目(str, false, 转换操作.json转文本(results));

}

function 悬浮按钮1_被单击(){
	窗口操作.滚动到顶部();
}
function 按钮_提取_被单击(){
	if(div_warehouse_grid.取项目数() < 1 ){
		return;
	}
	var ids = [];
	var i=0;
	var str = "";
	while(i<div_warehouse_grid.取项目数()){
		if(div_warehouse_grid.取项目状态(i) == true ){
			str = div_warehouse_grid.取项目标记(i);
			str = 转换操作.文本转json(str);
			if(str.oper_static > 0 ){
				仔仔弹出对话框1.错误("只能提取暂存仓库的资源,请重新选择！");
				return;
			}
			ids.push(str.ID);
		}
		i++
	}
	if(ids.length < 1 ){
		仔仔弹出对话框1.错误("请先选中要提取的资源！");
		return;
	}
	if(ids.length > warehouse_num ){
		仔仔弹出对话框1.错误("最多可提取："+String(warehouse_num)+"条资源,请重新选择！");
		return;
	}
	var json = {"ids": ids}
	m_post = 公用模块.生成提交数据(0, "warehouse_info", "", "send" , 0, 0, json);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/more", m_token);
	美化等待框1.默认等待框("正在交互","正在发送到游戏中,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}









function 获取仓库状态(){
	m_post = 公用模块.生成提交数据(0, "warehouse_info", "", "state" , 0, 0);
	m_url = 公用模块.生成访问链接(根地址,"api/shop/warehouse", m_token);
	美化等待框1.默认等待框("正在交互","正在获取仓库数据,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 按钮_取消选择_被单击(){
	if(div_warehouse_grid.取项目数() < 1 ){
		return;
	}
	div_warehouse_grid.取消全选();
}