mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签1 = new 标签("标签1",null);
var 面板1 = new 面板("面板1");
var 编辑框_密码 = new 编辑框("编辑框_密码",null,null,null,null,null);
var 按钮_修改 = new 按钮("按钮_修改",按钮_修改_被单击,null,null);
var 按钮_刷新 = new 按钮("按钮_刷新",按钮_刷新_被单击,null,null);
var 标签2 = new 标签("标签2",null);
var 列表框1 = new 列表框("列表框1",false,null,列表框1_按钮被单击);
if(mui.os.plus){
    mui.plusReady(function() {
        计划任务_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        计划任务_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
function 计划任务_创建完毕(){
	根地址 = HPtools1.取URL();
	面板1.添加组件("编辑框_密码", "150px");
	面板1.添加组件("按钮_修改", "100px");
	面板1.添加组件("按钮_刷新", "80px");
	查询密码();


}

function 查询密码(){
	列表框1.清空项目();
	m_post = 公用模块.生成提交数据(0, "system_info_task_key", "", "select", 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			编辑框_密码.置内容(json.msg);
			生成计划任务(json.msg);
			仔仔弹出对话框1.成功("success");
		}else if(json.static == 2 ){
			var i= 0;
		}
	}
}
function 生成计划任务(task_key){
	列表框1.清空项目();
	生成单条计划任务(task_key, "推送邮件", "本计划任务每5秒执行一次,参数【retry】是指邮件发送失败的重试次数,默认3", "/api/task/game-mail", "retry=3");
	生成单条计划任务(task_key, "重载接口限流文件：ratelimitconfig.json", "请手动调用,不要设置计划任务", "/reload/rate-limit-config", "");
}

function 生成单条计划任务(task_key, name, note, api, params){
	var str = 公用模块.文本显示处理("任务名称：" + name, "#FF00FF", 3) + "<br>";
	str = str + 公用模块.文本显示处理("任务说明：" + note, "#0000FF", 3) + "<br>";
	params = 文本操作.删首尾空(params);
	if(params != "" ){
		if(文本操作.取文本左边(params, 1) != "&" ){
			params = "&" + params;
		}

	}
	var url = 根地址 + api + "?key=" + task_key + params;
	str = str + 公用模块.文本显示处理("API-URL：" + url, "#000000", 3);
	列表框1.添加项目2(str, url, "mui-btn mui-btn-primary", "复制：API-URL");
}
function 列表框1_按钮被单击(项目索引){
	var url = 列表框1.取项目标记(项目索引);
	HPtools1.置剪贴板内容(url);
	HPtools1.弹出提示("已尝试复制！");
}
function 按钮_修改_被单击(){
	编辑框_密码.置内容(文本操作.删首尾空(编辑框_密码.取内容()));
	if(文本操作.取文本长度(编辑框_密码.取内容()) < 4 ){
		仔仔弹出对话框1.错误("约定密码长度必须大于等于4位！");
		return;
	}
	m_post = 公用模块.生成提交数据(0, "system_info_task_key", 编辑框_密码.取内容(), "update", 0, 0);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}
function 按钮_刷新_被单击(){
	查询密码();
}