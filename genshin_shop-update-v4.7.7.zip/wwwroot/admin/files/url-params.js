(function (){
window["UrlParams"] = {}  // 本行代码为了后续可以快速的使用本js文件

//JS代码区域

    function getUrlParams(url) {
        // 创建一个空对象来存储参数
        const params = {};

        // 如果没有提供url，则使用当前页面的URL
        if (!url) {
            url = window.location.href;
        }

        // 获取查询字符串部分（?之后的内容）
        const queryString = url.includes('?') ? url.split('?')[1] : '';

        if (!queryString) {
            return params;
        }

        // 将查询字符串分割成键值对数组
        const pairs = queryString.split('&');

        // 遍历每个键值对
        for (let i = 0; i < pairs.length; i++) {
            const pair = pairs[i];
            // 跳过空字符串
            if (!pair) continue;

            // 分割键和值
            let [key, value] = pair.split('=');

            // 解码键和值
            key = decodeURIComponent(key || '');
            value = decodeURIComponent(value || '');

            // 如果键已存在，转换为数组
            if (key in params) {
                if (!Array.isArray(params[key])) {
                    params[key] = [params[key]];
                }
                params[key].push(value);
            } else {
                params[key] = value;
            }
        }

        return params;
    }

//JS代码区域

window["UrlParams"]["get"]=getUrlParams;
})();
