mui.init({swipeBack: false
,gestureConfig: {tap:true,doubletap:true,longtap:true,hold:true,release:true}});

var 标题栏1 = new 标题栏("标题栏1",null,null,null);
var HPtools1 = new HPtools("HPtools1");
var 仔仔弹出对话框1 = new 仔仔弹出对话框("仔仔弹出对话框1");
var 美化等待框1 = new 美化等待框("美化等待框1");
var 加密操作1 = new 加密操作("加密操作1");
var 网络操作1 = new 网络操作("网络操作1",网络操作1_发送完毕);
var 标签3 = new 标签("标签3",null);
var 自由面板1 = new 自由面板("自由面板1","96px");
var 自由面板_标签 = new 标签("自由面板_标签",null);
var 自由面板_编辑框_条件 = new 编辑框("自由面板_编辑框_条件",null,自由面板_编辑框_条件_按下某键,null,null,null);
var 自由面板_按钮_查询 = new 按钮("自由面板_按钮_查询",自由面板_按钮_查询_被单击,null,null);
var 高级表格1 = new 高级表格("高级表格1",高级表格1_工具栏按钮被单击,高级表格1_操作栏按钮被单击,null,null,null,null,null,null);
var 按钮_底部 = new 按钮("按钮_底部",按钮_底部_被单击,null,null);
var 标签1 = new 标签("标签1",null);
var CYS日期时间选择器1 = new CYS日期时间选择器("CYS日期时间选择器1",CYS日期时间选择器1_日期被选择);
var div_start_time = new 按钮("div_start_time",div_start_time_被单击,null,null);
var 标签2 = new 标签("标签2",null);
var div_end_time = new 按钮("div_end_time",div_end_time_被单击,null,null);
var 自由面板_下拉框 = new 下拉框("自由面板_下拉框",null);
var 自由面板_复选框 = new 复选框("自由面板_复选框",null);
var 弹出面板1 = new 弹出面板("弹出面板1",null,null);
var 面板1 = new 面板("面板1");
var 标签4 = new 标签("标签4",null);
var 标签5 = new 标签("标签5",null);
var 面板2 = new 面板("面板2");
var div_num_edit = new 编辑框("div_num_edit",null,null,null,null,null);
var div_timeout_edit = new 编辑框("div_timeout_edit",null,null,null,null,null);
var 按钮_保存 = new 按钮("按钮_保存",按钮_保存_被单击,null,null);
var 标签6 = new 标签("标签6",null);
var div_thread_row = new 标签("div_thread_row",null);
if(mui.os.plus){
    mui.plusReady(function() {
        游戏邮件管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    });
}else{
    window.onload=function(){ 
        游戏邮件管理_创建完毕();
        document.getElementsByClassName("mui-content")[0].style.display="";
    }
}

var m_url="";
var m_post="";
var 根地址= "";
var m_password= "";
var page= 0;
var value= "";
var start_time= "";
var end_time= "";
var m_model= 0;
var m_mail_static= "all";
var select_time= false;
function 游戏邮件管理_创建完毕(){
	根地址 = HPtools1.取URL();
	CYS日期时间选择器1.初始化(1, 2023, 2099);
	div_start_time.置标题(公用模块.取当前日期年月日(时间操作.取当前日期时间()));
	div_end_time.置标题(公用模块.取当前日期年月日(时间操作.取当前日期时间()));
	高级表格初始化();
	弹出面板初始化();
	自由面板_下拉框.清空项目();
	自由面板_下拉框.添加项目("所有类型", "all");
	自由面板_下拉框.添加项目("已上线", "1");
	自由面板_下拉框.添加项目("下线", 0);
	自由面板_下拉框.置现行选中项(0);



}
function 高级表格初始化(){
	高级表格1.添加列("xz","",0,false,false,false,false,true,false,"",false,false);
	高级表格1.添加列("id","ID",0,false,false,false,true,true,false,"",false,false);
	高级表格1.添加列("oper","操作",280,false,false,true,true,false,false,"",false,false);
	高级表格1.添加列("game_name","发送区服",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_static","状态",90,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_time","到期时间",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_title","邮件标题",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_content","邮件内容",350,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_item","物品清单",200,false,false,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_sender","发件人",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("add_time","基准时间",180,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_type","邮件类型",120,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_one","单人邮件账号",200,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_all","全服邮件模式",150,false,true,false,false,false,false,"",false,false);
	高级表格1.添加列("mail_send_msg","邮件发送情况",300,false,true,false,false,false,false,"",false,false);
	高级表格1.添加工具栏按钮(2,false,"添加新邮件");
	高级表格1.初始化("auto",true,true,false,true);
}
function 弹出面板初始化(){
	var rect = 公用模块.弹出面板初始化计算(20, 80, true);
	弹出面板1.初始化(rect[0],rect[1],rect[2],rect[3]);
	面板1.添加组件("标签4", "1");
	面板1.添加组件("标签5", "1");
	弹出面板1.添加组件("面板1");
	面板2.添加组件("div_num_edit","1");
	面板2.添加组件("div_timeout_edit", "1");
	弹出面板1.添加组件("面板2");
	弹出面板1.添加组件("按钮_保存");
	弹出面板1.添加组件("标签6");

}
function 网络操作1_发送完毕(发送结果,返回信息){

	美化等待框1.关闭等待框();
	if(发送结果 != true ){
		仔仔弹出对话框1.错误(公用模块.网络错误翻译(返回信息));
	}else{

		var json=转换操作.文本转json(返回信息);
		if(json.static == -1 ){
			窗口操作.切换窗口("index.html?msg=" + 加密操作1.url编码(json.msg),"");
		}else if(json.static == 0 ){
			仔仔弹出对话框1.错误(json.msg);
		}else if(json.static == 1 ){
			if(json.table != "game_mail_info_thread" ){
				高级表格1.清空行();
				高级表格1.初始化("auto",true,true,false,true);
				查询数据();
			}
			仔仔弹出对话框1.成功(json.msg);
		}else if(json.static == 2 ){
			if(json.table == "game_mail_info_thread" ){
				div_num_edit.置内容("");
				div_timeout_edit.置内容("");
				if(json.resutls.thread_num > 0 ){
					div_num_edit.置内容(""+json.resutls.thread_num);
				}
				if(json.resutls.thread_timeout > 0 ){
					div_timeout_edit.置内容(""+json.resutls.thread_timeout);
				}
				div_thread_row.置标题(""+json.row);
				弹出面板1.滚动条到顶部();
				弹出面板1.显示();

				return;
			}
			var i= 0;
			if(json.page == 1 ){
				高级表格1.清空行();
			}
			page = json.page;
			if(json.total > json.page ){
				按钮_底部.置可视(true);
			}
			var arr = new Array();
			arr[0] = "";
			arr[1] = "";
			arr[2] = "";
			while(i < json.results.length){
				arr[1] = json.results[i].ID;
				arr[3] = json.results[i].game_name;
				arr[4] = "下线";
				if(json.results[i].mail_static > 0 ){
					arr[4] = "已上线";
				}
				arr[5] = json.results[i].mail_time;
				arr[6] = json.results[i].mail_title;
				arr[7] = json.results[i].mail_content;
				arr[8] = json.results[i].mail_item;
				arr[9] = json.results[i].mail_sender;
				arr[10] = json.results[i].add_time;
				arr[11] = "[????]：" + json.results[i].mail_one_account;
				if(json.results[i].mail_type < 1 ){
					arr[11] = "单人邮件";
					if(json.results[i].mail_one_model == "shop" ){
						arr[12] = "[商城账号]：" + json.results[i].mail_one_account;
					}else if(json.results[i].mail_one_model == "game" ){
						arr[12] = "[游戏账号]：" + json.results[i].mail_one_account;
					}else if(json.results[i].mail_one_model == "uid" ){
						arr[12] = "[游戏UID]：" + json.results[i].mail_one_account;
					}
					arr[13] = "-";
				}else{
					arr[11] = "全服邮件";
					arr[12] = "-";
					arr[13] = "-";
					if(json.results[i].mail_all_model < 1 ){
						arr[13] = "仅老玩家";
					}else if(json.results[i].mail_all_model == 1 ){
						arr[13] = "仅新玩家";
					}else{
						arr[13] = "所有玩家";
					}

				}
				arr[14] = json.results[i].mail_send_msg;

				高级表格1.添加行(true,arr);
				i++
			}
			高级表格1.清空操作栏按钮();
			高级表格1.添加操作栏按钮(2,false,"修改");
			高级表格1.添加操作栏按钮(1,false,"上线");
			高级表格1.添加操作栏按钮(3,false,"下线");
			高级表格1.添加操作栏按钮(4,false,"删除");
			高级表格1.添加操作栏按钮(1,false,"线程数量");
			高级表格1.初始化("auto",true,true,false,true);
		}
	}
}

function 自由面板_按钮_查询_被单击(){
	高级表格1.清空行();
	高级表格1.初始化("auto",true,true,false,true);
	查询数据();
}

function 查询数据(){
	自由面板_编辑框_条件.置内容(文本操作.删首尾空(自由面板_编辑框_条件.取内容()));
	value = 自由面板_编辑框_条件.取内容();
	var json= {}
	start_time = div_start_time.取标题();
	end_time = div_end_time.取标题();
	json.start_time = start_time;
	json.end_time = end_time;
	select_time = 自由面板_复选框.取选中状态();
	json.select_time = select_time;
	m_mail_static = 自由面板_下拉框.取项目标记(自由面板_下拉框.取现行选中项());
	m_post = 公用模块.生成提交数据(0, "game_mail_info", value, m_mail_static, 1, 0, json);
	page = 1;
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/report", m_password);
	美化等待框1.默认等待框("正在交互","正在查询,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function 自由面板_编辑框_条件_按下某键(键代码){
	if(公用模块.键代码是回车键(键代码) == true ){
		高级表格1.清空行();
		高级表格1.初始化("auto",true,true,false,true);
		查询数据();
	}
}


function 按钮_底部_被单击(){
	var json= {}
	json.start_time = start_time;
	json.end_time = end_time;
	json.select_time = select_time;
	m_post = 公用模块.生成提交数据(0, "game_mail_info", value, m_mail_static, page+1, 0, json);
	按钮_底部.置可视(false);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/report", m_password);
	美化等待框1.默认等待框("正在交互","正在加载,请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
}

function div_start_time_被单击(){
	m_model = 0;
	CYS日期时间选择器1.弹出();
}
function div_end_time_被单击(){
	m_model = 1;
	CYS日期时间选择器1.弹出();
}
function CYS日期时间选择器1_日期被选择(年,月,日,时,分){
	var res= 转换操作.到文本(年);
	var m= 转换操作.到文本(月);
	if(月 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	m = 转换操作.到文本(日);
	if(日 < 10 ){
		m = "0" + m;
	}
	res = res +"-"+ m;
	if(m_model < 1 ){
		div_start_time.置标题(res);
	}else{
		div_end_time.置标题(res);
	}
}
function 高级表格1_工具栏按钮被单击(按钮索引){
	if(按钮索引 < 1 ){
		公用模块.居中打开小窗口("mailinfone.html?ID=0", 1000, 700);
	}
}
function 高级表格1_操作栏按钮被单击(按钮索引,行索引,行数据){
	var _id= 转换操作.到数值(行数据["id"]);
	if(_id < 1 ){
		仔仔弹出对话框1.错误("列表异常,请刷新后重试！");
		return;
	}
	switch(按钮索引){
		case 0 :
			公用模块.居中打开小窗口("mailinfone.html?ID="+String(_id), 1000, 700);
		break;
		case 1 :
			if(HPtools1.询问框("是否进行上线操作？\n\n注：上线操作会修改基准时间！") == false ){
				return;
			}
			m_post = 公用模块.生成提交数据(_id, "game_mail_info_static", "", "update", 1, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
			美化等待框1.默认等待框("正在交互","请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
		break;
		case 2 :
			if(HPtools1.询问框("是否进行下线操作？") == false ){
				return;
			}
			m_post = 公用模块.生成提交数据(_id, "game_mail_info_static", "", "update", 0, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
			美化等待框1.默认等待框("正在交互","请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
		break;
		case 3 :
			if(HPtools1.询问框("是否进行删除操作？") == false ){
				return;
			}
			m_post = 公用模块.生成提交数据(_id, "game_mail_info", "", "delete", 0, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/delete", m_password);
			美化等待框1.默认等待框("正在交互","请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
		break;
		case 4 :
			m_post = 公用模块.生成提交数据(_id, "game_mail_info_thread", "", "select", 0, 0);
			m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/select", m_password);
			美化等待框1.默认等待框("正在交互","请稍等......");
			公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);
		break;
	}
}

function 按钮_保存_被单击(){
	var _id= 数学操作.取整数(转换操作.到数值(div_thread_row.取标题()));
	if(_id < 1 ){
		仔仔弹出对话框1.错误("关键ID缺失,请刷新后重试！");
		return;
	}
	div_num_edit.置内容(文本操作.删首尾空(div_num_edit.取内容()));
	if(div_num_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写：线程数量！");
		return;
	}
	thread_num = 数学操作.取整数(转换操作.到数值(div_num_edit.取内容()));
	if(thread_num < 2 || thread_num > 999 ){
		仔仔弹出对话框1.错误("线程数量范围：2~999");
		return;
	}
	div_timeout_edit.置内容(文本操作.删首尾空(div_timeout_edit.取内容()));
	if(div_timeout_edit.取内容() == "" ){
		仔仔弹出对话框1.错误("请填写：超时时间！");
		return;
	}
	thread_timeout = 数学操作.取整数(转换操作.到数值(div_timeout_edit.取内容()));
	if(thread_timeout < 3 || thread_timeout >15 ){
		仔仔弹出对话框1.错误("超时时间范围：3~15(秒)");
		return;
	}
	var json = {"thread_num": thread_num, "thread_timeout": thread_timeout}
	m_post = 公用模块.生成提交数据(_id, "game_mail_info_thread", "", "update", 0, 0, json);
	m_url = 公用模块.生成访问链接_后端(根地址,"api/admin/update", m_password);
	弹出面板1.隐藏();
	美化等待框1.默认等待框("正在交互","请稍等......");
	公用模块.延时发起访问请求(网络操作1, m_post, m_url, 100);



}