    function CCS类库(name,event){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function CCS类库(name,event1,event2,event3){
		
		//注意：js目录中引入了一个功能所需的js库,bluebird_jiami.js
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;
        
		
		//************************************************
	
	    //返回用于组合URL的参数和待MD5加密的文本
        this.开放平台_淘宝URL获取 = function (server_ip,AppSecret,up_array){
			//1.将当前日期时间加入到数组结尾
			up_array.push("timestamp=" + this.获取_当前日期时间())
			//2.排序数组
			up_array.sort();
			//3.把所有参数名和参数值串在一起 【去除参数名和参数值中的等号】
			var 连接成员1,连接成员2,按顺序拼接好的参数名与参数值;
			连接成员1 = up_array.join("");	//用于生成签名
			连接成员2 = up_array.join("&");	//用于组合URL
			//4.创建正则RegExp对象  
			var reg=new RegExp("=","g");
			按顺序拼接好的参数名与参数值 = 连接成员1.replace(reg,"");	//去除参数名和参数值中的等号
			//5.组合需签名的字段 【格式为：AppSecret + 按顺序拼接好的参数名与参数值 + AppSecret】
			var 待签名文本;
			待签名文本 = AppSecret + 按顺序拼接好的参数名与参数值 + AppSecret;
			//6.生成签名 【利用MD5加密】
			var md5签名;
			md5签名 = CryptoJS.MD5(待签名文本);	//md5签名 = 加密操作1.取md5值(待签名文本)
			md5签名 = md5签名 + "";	//因为js时弱类型的，所以，它不知道你给他的是数字还是字符串，然后就出错了。所以md5签名 += ""; 字符串化就没事了
			md5签名 = md5签名.toUpperCase();	//转换成大写

			//7.执行下一个函数返回具体的URL
			return create_url(server_ip,连接成员2,md5签名);
        }

		//创建URL地址并返回
		function create_url(服务地址,连接成员,md5签名){
			var 编码url;
			var 替换时间;
			var 替换逗号;
			var 组合url;
			
			//1.连接成员转换成url编码
			编码url = encodeURI(连接成员);
			//2.替换时间段中的空格和冒号
			var reg1=new RegExp("%20","g");	//创建正则RegExp对象
			var reg2=new RegExp(":","g");	//创建正则RegExp对象
			替换时间 = 编码url.replace(reg1,"+");	//编码url后空格变成了"%20",需把这个替换成"+"
			替换时间 = 替换时间.replace(reg2,"%3A");	//编码url后冒号还是":",需替换成"%3A"
			//3.替换连接成员中的逗号
			var reg3=new RegExp(",","g");	//创建正则RegExp对象
			替换逗号 = 替换时间.replace(reg3,"%2C");	//编码url后逗号还是",",需替换成"%2C"
			//4.返回URL
			组合url = 服务地址 + "?sign=" + md5签名 + "&" + 替换逗号;
			return 组合url;
		}
		//==================================================================================================
		
		
		//检查身份证号码
		this.验证_身份证号码 = function checkIdcard(idcard)
		{
			var Errors=new Array(
			"验证通过!",
			"身份证号码位数不对!",
			"身份证号码出生日期超出范围或含有非法字符!",
			"身份证号码校验错误!",
			"身份证地区非法!"
			);
			var area={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外"}
			var idcard,Y,JYM;
			var S,M;
			var idcard_array = new Array();
			idcard_array = idcard.split("");
			//地区检验
			if(area[parseInt(idcard.substr(0,2))]==null) return Errors[4];
			//身份号码位数及格式检验
			switch(idcard.length){
				case 15:
					if ( (parseInt(idcard.substr(6,2))+1900) % 4 == 0 || ((parseInt(idcard.substr(6,2))+1900) % 100 == 0 && (parseInt(idcard.substr(6,2))+1900) % 4 == 0 )){
						ereg=/^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/;//测试出生日期的合法性
					} else {
						ereg=/^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/;//测试出生日期的合法性
					}
					if(ereg.test(idcard)) return Errors[0];
					else return Errors[2];
					break;
				case 18:
				//18位身份号码检测
				//出生日期的合法性检查
				//闰年月日:((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))
				//平年月日:((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))
				if ( parseInt(idcard.substr(6,4)) % 4 == 0 || (parseInt(idcard.substr(6,4)) % 100 == 0 && parseInt(idcard.substr(6,4))%4 == 0 )){
					ereg=/^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/;//闰年出生日期的合法性正则表达式
				} else {
					ereg=/^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/;//平年出生日期的合法性正则表达式
				}
				if(ereg.test(idcard)){//测试出生日期的合法性
				//计算校验位
				S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7
					+ (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9
					+ (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10
					+ (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5
					+ (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8
					+ (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4
					+ (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2
					+ parseInt(idcard_array[7]) * 1
					+ parseInt(idcard_array[8]) * 6
					+ parseInt(idcard_array[9]) * 3 ;
				Y = S % 11;
				M = "F";
				JYM = "10X98765432";
				M = JYM.substr(Y,1);//判断校验位
				if(M == idcard_array[17]) return Errors[0]; //检测ID的校验位
				else return Errors[3];
				}
				else return Errors[2];
				break;
			default:
				return Errors[1];
				break;
			}
		}
		
		//验证规则：字母、数字、下划线组成，字母开头，6-16位。
        this.验证_规则 = function checkUser(str){
  			var re = /^[a-zA-z]\w{5,15}$/;
 			if(re.test(str)){
    			return "正确";
  			}else{
   				return "错误";
  			}     
		}
		
		//验证规则：11位数字，以1开头。
		this.验证_手机号码 = function checkMobile(str){
  			var re = /^1\d{10}$/;
  			if (re.test(str)) {
    			return "正确";
  			} else {
    			return "错误";
 			}
		}
		
		//验证规则：区号+号码，区号以0开头，3位或4位
		//号码由7位或8位数字组成
		//区号与号码之间可以无连接符，也可以“-”连接
		//如01088888888,010-88888888,0955-7777777
		this.验证_电话号码 = function checkPhone(str){
  			var re = /^0\d{2,3}-?\d{7,8}$/;
  				if(re.test(str)){
    				return "正确";
  				}else{
    				return "错误";
  				}
		}
		
		//验证规则：姑且把邮箱地址分成“第一部分@第二部分”这样
		//第一部分：由字母、数字、下划线、短线“-”、点号“.”组成，
		//第二部分：为一个域名，域名由字母、数字、短线“-”、域名后缀组成，
		//而域名后缀一般为.xxx或.xxx.xx，一区的域名后缀一般为2-4位，如cn,com,net，现在域名有的也会大于4位
		this.验证_邮箱 = function checkEmail(str){
 			var re = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/;
  			if(re.test(str)){
    			return "正确";
  			}else{
    			return "错误";
  			}
		}
		
		this.验证_名字输入 = function checkName(str){  
   			//正则匹配 
   			var result=str.match(/[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im);  
   			if(result!=null) {    
		    	return "名称不能含有非法字符!";
			}else{
				return "正确";
   			}   
  		}
		//************************************************
		
		
		
		
		
		
		
		
		
		//获取当前日期时间“yyyy-MM-dd HH:MM:SS”
		this.获取_当前日期时间 = function getNowFormatDate() {
    		var date = new Date();
    		var seperator1 = "-";
    		var seperator2 = ":";
    		var month = date.getMonth() + 1;
    		var strDate = date.getDate();
			var strhours = date.getHours();
			var strminutes = date.getMinutes();
			var strseconds = date.getSeconds();
			//月日
    		if (month >= 1 && month <= 9) {
        		month = "0" + month;
    		}
    		if (strDate >= 0 && strDate <= 9) {
        		strDate = "0" + strDate;
    		}
			//时分秒
			if (strhours >= 0 && strhours <= 9) {
        		strhours = "0" + strhours;
    		}
			if (strminutes >= 0 && strminutes <= 9) {
        		strminutes = "0" + strminutes;
    		}
			if (strseconds >= 0 && strseconds <= 9) {
        		strseconds = "0" + strseconds;
    		}
    		var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            				+ " " + strhours + seperator2 + strminutes + seperator2 + strseconds;
    		return currentdate;
		}
		//************************************************
		//获取天数， 如昨天，今天，近1星期，近14天
		this.获取_任意天日期 = function GetDateStr(AddDayCount) { 
    		var dd = new Date(); 
    		dd.setDate(dd.getDate()+AddDayCount);//获取AddDayCount天后的日期 
    		var y = dd.getFullYear(); 
    		var m = dd.getMonth()+1;//获取当前月份的日期 
    		var d = dd.getDate(); 
    		//判断 月
    		if(m < 10){
      			m = "0" + m;
    		}else{
      			m = m;
    		}
    		//判断 日n     
    		if(d < 10){//如果天数<10
      			d = "0" + d;
    		}else{
      			d = d;
    		}
    		return y+"-"+m+"-"+d; 
  		}
		//************************************************
		//获取月份 ，如1个月前，3个月前，6个月前
		this.获取_任意月日期 = function GetMonthStr(AddMonthCount) { 
    		var dd = new Date(); 
    		dd.setMonth(dd.getMonth()+AddMonthCount);//获取AddMonthCount月后的日期 
    		var y = dd.getFullYear(); 
    		var m = dd.getMonth()+1;//获取当前月份的日期 
    		var d = dd.getDate(); 
    		//判断 月
    		if(m < 10){
      			m = "0" + m;
    		}else{
      			m = m;
    		}
    		//判断 日n     
    		if(d < 10){//如果天数<10
     			d = "0" + d;
    		}else{
      			d = d;
    		}
    		return y+"-"+m+"-"+d; 
  		} 
		//************************************************
		//获取年 如1个年前
		this.获取_任意年日期 = function GetYearStr(AddYearCount) { 
    		var dd = new Date(); 
    		dd.setYear(dd.getFullYear()+AddYearCount);//获取AddMonthCount月后的日期 
    		var y = dd.getFullYear(); 
    		var m = dd.getMonth()+1;//获取当前月份的日期 
    		var d = dd.getDate(); 
    		//判断 月
    		if(m < 10){
      			m = "0" + m;
    		}else{
      			m = m;
    		}
    		//判断 日n     
    		if(d < 10){//如果天数<10
      			d = "0" + d;
    		}else{
      			d = d;
    		}
    		return y+"-"+m+"-"+d; 
  		}		
		//===================================================================================================
		
		
		
		
		
		
		
		
		//组件命令：
        this.编码_取md5值 = function(str){
            if(str!=null){
				var 加密;
				加密 = CryptoJS.MD5(str) + "";
				加密 = 加密.toUpperCase();
				return 加密;
			}else{
				return "";
			}
        } 
		
		//组件命令：
		this.编码_取sha1值 = function (str){
		   return CryptoJS.SHA1(str);
        }
       
        //组件命令：
        this.编码_url编码=function(str){
		     if(str!=null){
			      return encodeURI(str);
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_url解码=function(str){
		     if(str!=null){
			      return decodeURI(str);
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_rc4加密=function(str,key){
		     if(str!=null){
			      return CryptoJS.RC4.encrypt(str,key);
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_rc4解密=function(str,key){
		     if(str!=null){
			 	  var result = CryptoJS.RC4.decrypt(str,key).toString(CryptoJS.enc.Utf8);
			      return result;
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_aes加密=function(str,key){
		     if(str!=null){
			      return CryptoJS.AES.encrypt(str,key);
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_aes解密=function(str,key){
		     if(str!=null){
			 	  var result = CryptoJS.AES.decrypt(str,key).toString(CryptoJS.enc.Utf8);
			      return result;
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_des加密=function(str,key){
		     if(str!=null){
			      return CryptoJS.DES.encrypt(str,key);
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_des解密=function(str,key){
		     if(str!=null){
			 	  var result = CryptoJS.DES.decrypt(str,key).toString(CryptoJS.enc.Utf8);
			      return result;
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_base64加密=function(str){
		     if(str!=null){
				var str2 = CryptoJS.enc.Utf8.parse(str);
		    	return CryptoJS.enc.Base64.stringify(str2);
			 }else{
				  return "";
			 }
		}

        //组件命令：
        this.编码_base64解密=function(str,key){
		     if(str!=null){
			 	  var result = CryptoJS.enc.Base64.parse(str,key).toString(CryptoJS.enc.Utf8);
			      return result;
			 }else{
				  return "";
			 }
		}

		//组件命令：
		this.编码_usc2转ansi = function (str){
			//return str.replace(/(\\u)(\w{4}|\w{2})/gi);
			return unescape(str.replace(/\\u/g,"%u"));
		}
		
		//组件命令：
		this.编码_ansi转usc2 = function (str){
			var temp = "",rs = "";  
			for( var i=0 , len = str.length; i < len; i++ ){  
   			 temp = str.charCodeAt(i).toString(16);  
   			 rs  += "\\u"+ new Array(5-temp.length).join("0") + temp;  
			}  
			return rs;
		}
		
		//************************************************
		
		
		
		
		
		
		
		
		
		
        this.其他_小写金额转大写金额 = function MoneyToUpper(value){ 
    		var str1 = "零,壹,贰,叁,肆,伍,陆,柒,捌,玖,"; 
        	var str2 = "元,拾,佰,仟,万,拾,佰,仟,亿,拾,佰,仟,万,角,分,整,零角,零分,零零,零元,零万,零亿,亿万"; 
    		var charList1 = str1.split(","); 
    		var charList2 = str2.split(","); 
    		var Num=value; 
            var isminus = false; //是否负金额 
    		//非法格式处理 
    		for( i = Num.length-1;i>=0;i--){ 
                Num = Num.replace(",","") //替换tomoney()中的“,”
                Num = Num.replace(" ","") //替换tomoney()中的空格 
        	} 
        	Num = Num.replace("￥",""); //替换掉可能出现的￥字符 

        	//验证输入的字符是否为数字 
        	if(isNaN(Num)) { 
                return "输入数据必须为数字!"; 
        	}
			
        	//转化为标准格式（100.00） 
            if(!Num || isNaN(Num)){ 
            	return Num; 
            }                                 
            if(Num < 0 ){ 
            	isminus = true; 
                Num = 0 - Num; 
            } 
            Num = parseFloat(Num)+"";                           
            var m = Num.split("."); 
            if(m.length >= 2){//既有整数部分也有小数部分 
            	if(m[1].length >=2){ 
                	m[1] = m[1].substr(0,2); 
                } 
                else{ 
                    m[1] = m[1]+"0"; 
                  } 
                } 
            else{//只有整数部分，没有小数部分 
            	m.push("00"); 
            }         
            Num = m[0]+"."+m[1]; 
        	//---字符处理完毕，开始转换，转换采用前后两部分分别转换--- 
        	var part = String(Num).split("."); 
            //若数量超过万亿单位，提示 
            if(part[0].length > 13){ 
                return "输入数据小数点前最大长度为13位!"; 
            }         
        	var newchar = "";   
        	//小数点前进行转化 
        	for(i = 0 ; part[0].length - i >0 ;  i++){ 
                var tmpnewchar = ""; 
                var perchar = part[0].charAt(i); 
                tmpnewchar= tmpnewchar + charList1[perchar]; 
                if(perchar != '0' || i == part[0].length-1 || part[0].length-i-1==4 || part[0].length-i-1==8){     
                	var indx = part[0].length-i-1; 
                    tmpnewchar = tmpnewchar + charList2[indx]; 
                } 
                newchar = newchar + tmpnewchar; 
        	} 

        	//小数点之后进行转化 
    		if( String(Num).indexOf(".") != -1){ 
                if(part[1].length > 2) { 
                        part[1] = part[1].substr(0,2); 
                } 
                for(i=0;i<part[1].length;i++){ 
                        tmpnewchar = "" 
                        perchar = part[1].charAt(i) 
                        tmpnewchar = charList1[perchar] + tmpnewchar;               
                        if(i==0)tmpnewchar =tmpnewchar + charList2[13];  //角 
                        if(i==1)tmpnewchar = tmpnewchar + charList2[14]; //分 
                        newchar = newchar + tmpnewchar; 
                } 
	        } 
    	    newchar = newchar + charList2[15];   

        	//替换零零 为 零         
        	while(newchar.search(charList2[18]) != -1){ 
                newchar = newchar.replace(charList2[18], charList1[0]);  //零零 to 零         
        	} 
            newchar = newchar.replace(charList2[20], "万");    //"零万" to "万"         
            newchar = newchar.replace(charList2[21], "亿");    //"零亿" to "亿" 
            newchar = newchar.replace(charList2[22], "亿");    //"亿万" to "亿"                                                                 
   			if(newchar.search(charList2[16]) != -1 && newchar.search(charList2[17]) != -1)//当小数部分为零时 
    		{             
                newchar = newchar.replace(charList2[16], "");    //"零角" to "" 
                newchar = newchar.replace(charList2[17], "");    //"零分" to ""         
                newchar = newchar.replace(charList2[19], charList2[0]);    //"零元" to "元"                                     
    		}else { 
                newchar = newchar.replace(charList2[15], "");   
                newchar = newchar.replace(charList2[16], "零");    //"零角" to "零" 
                newchar = newchar.replace(charList2[17], "");    //"零分" to ""   
                newchar = newchar.replace(charList2[19], "元零");    //"零元" to "元"                                                     
    		} 
        	//替换零零 为 零     
        	while(newchar.search(charList2[18]) != -1){ 
                newchar = newchar.replace(charList2[18], charList1[0]);  //零零 to 零         
        	}     
        	if(newchar.indexOf(charList2[0]) == 0){                                   
                 newchar = newchar.replace(charList2[0],""); 
                 newchar = newchar.replace(charList1[0],"");                 
        	} 
        	if(newchar == charList2[15]){ 
                 newchar = charList2[19] + newchar; 
        	} 
        	if(isminus == true){ 
                return "(负)"+newchar; 
        	}else{ 
            	return newchar; 
        	} 
		} 
		//************************************************
    }