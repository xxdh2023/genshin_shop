    function 抽奖转盘(name,event1,event2){   
        //name表示组件在被创建时的名称，event表示组件拥有的事件
        //如果组件有多个事件，可以在后面继续填写这些事件名称
        //例如：function 抽奖转盘(name,event1,event2,event3){
        
        //组件内部属性，仅供组件内部使用：
        this.名称 = name;

		this.width="300px";
		this.height="300px";
		this.blocks={padding:"0px",background:"#FFFFFF",imgs:{src:"",top:"0px",width:"0px",height:"0px",rotate:false}};
		this.fontStyle={background:"#FFFFFF",top:"0px",fontColor:"#000000",fontSize:"20px",fontStyle:"sans-serif",fontWeight:"400",lineHeight:"20px",wordWrap:true,lenghtLimit:"90%",lineClamp:1};
		this.imgStyle={top:"0px",width:"0px",height:"0px"};
		this.btnStyle={radius:"0px",pointer:false,background:"#000000"};
		this.btnFontStyle={text:"",top:"0px",fontColor:"#000000",fontSize:"20px",fontStyle:"sans-serif",fontWeight:"400",lineHeight:"20px"};
		this.btnImgStyle={src:"",top:"0px",width:"0px",height:"0px"};
		this.prizes=[];
		var myLucky;
		const that=this;
		
		//组件命令：
        this.置抽奖转盘大小 = function (大小){
            that.width=大小;
			that.height=大小;
        } 
		
		//组件命令：
        this.置转盘背景样式 = function (内边距,背景颜色,背景图片路径,背景图片位置,背景图片宽度,背景图片高度,背景图片是否跟随旋转){
            that.blocks.padding=内边距;
			that.blocks.background=背景颜色;
			that.blocks.imgs.src=背景图片路径;
			that.blocks.imgs.top=背景图片位置;
			that.blocks.imgs.width=背景图片宽度;
			that.blocks.imgs.height=背景图片高度;
			that.blocks.imgs.rotate=背景图片是否跟随旋转;
        } 
        
        //组件命令：
        this.置奖品文字样式 = function (文字位置,字体颜色,字体大小,字体样式,字体粗细,字体行高,文字是否自动换行,换行宽度范围,是否单行文字){
		   that.fontStyle.top=文字位置;
		   that.fontStyle.fontColor=字体颜色;
		   that.fontStyle.fontSize=字体大小;
		   that.fontStyle.fontStyle=字体样式;
		   that.fontStyle.fontWeight=字体粗细;
		   that.fontStyle.lineHeight=字体行高;
		   that.fontStyle.wordWrap=文字是否自动换行;
		   that.fontStyle.lenghtLimit=换行宽度范围;
		   that.fontStyle.lineClamp=是否单行文字?1:0;
        }  
		
		//组件命令：
        this.置奖品图片样式 = function (图片位置,图片宽度,图片高度){
           that.imgStyle.top=图片位置;
		   that.imgStyle.width=图片宽度;
		   that.imgStyle.height=图片高度;
        }  
		
		//组件命令：
        this.置抽奖按钮样式 = function (按钮半径,是否显示指针,按钮背景颜色){
		   that.btnStyle.radius=按钮半径;
		   that.btnStyle.pointer=是否显示指针;
		   that.btnStyle.background=按钮背景颜色;
        }  
		
		//组件命令：
        this.置按钮文字样式 = function (按钮文字,文字位置,字体颜色,字体大小,字体样式,字体粗细,字体行高){
		   that.btnFontStyle.text=按钮文字;
		   that.btnFontStyle.top=文字位置;
		   that.btnFontStyle.fontColor=字体颜色;
		   that.btnFontStyle.fontSize=字体大小;
		   that.btnFontStyle.fontStyle=字体样式;
		   that.btnFontStyle.fontWeight=字体粗细;
		   that.btnFontStyle.lineHeight=字体行高;
        }  
		
		//组件命令：
        this.置按钮图片样式 = function (图片地址,图片位置,图片宽度,图片高度){
		   that.btnImgStyle.src=图片地址;
		   that.btnImgStyle.top=图片位置;
		   that.btnImgStyle.width=图片宽度;
		   that.btnImgStyle.height=图片高度;
        } 
		
		//组件命令：
        this.添加奖品 = function (扇形背景颜色,中奖概率,奖品文字,奖品图片){
		   var prize={};
		   prize["range"]=中奖概率;
		   prize["background"]=扇形背景颜色;
		   prize["fonts"]=[{
		      text:奖品文字,
			  top:that.fontStyle.top,
			  fontColor:that.fontStyle.fontColor,
			  fontSize:that.fontStyle.fontSize,
			  fontStyle:that.fontStyle.fontStyle,
			  fontWeight:that.fontStyle.fontWeight,
			  lineHeight:that.fontStyle.lineHeight,
			  wordWrap:that.fontStyle.wordWrap,
			  lenghtLimit:that.fontStyle.lenghtLimit,
			  lineClamp:that.fontStyle.lineClamp 
		   }];
		   prize["imgs"]=[{
		      src:奖品图片,
			  top:that.imgStyle.top,
			  width:that.imgStyle.width,
			  height:that.imgStyle.height
		   }];
		   that.prizes.push(prize);
        }  
		
		//组件命令：
        this.渲染转盘 = function (){
			var params={}
			params["width"]=that.width;
			params["height"]=that.height;
			params["blocks"]=[{
			    padding:that.blocks.padding,
			    background:that.blocks.background,
			    imgs:that.blocks.imgs.src==""?null:[{
				     src:that.blocks.imgs.src,
					 top:that.blocks.imgs.top,
					 width:that.blocks.imgs.width,
					 height:that.blocks.imgs.height,
					 rotate:that.blocks.imgs.rotate
				}]
			}];
			var prizesItems=[];
			for(let i=0;i<that.prizes.length;i++){
			   let item=that.prizes[i];
			   prizesItems.push({
			      range:item.range,
				  background:item.background,
				  fonts:item.fonts,
				  imgs:item.imgs
			   })
			}
			params["prizes"]=prizesItems;
			params["buttons"]=[{
			   radius:that.btnStyle.radius,
			   pointer:that.btnStyle.pointer,
			   background:that.btnStyle.background,
			   fonts:that.btnFontStyle.text==""?null:[{
			     text:that.btnFontStyle.text,
		         top:that.btnFontStyle.top,
		         fontColor:that.btnFontStyle.fontColor,
		         fontSize:that.btnFontStyle.fontSize,
		         fontStyle:that.btnFontStyle.fontStyle,
		         fontWeight:that.btnFontStyle.fontWeight,
		         lineHeight:that.btnFontStyle.lineHeight
			   }],
			   imgs:that.btnImgStyle.src==""?null:[{
			      src:that.btnImgStyle.src,
		          top:that.btnImgStyle.top,
		          width:that.btnImgStyle.width,
		          height:that.btnImgStyle.height
			   }]
			}];
			params["start"]=function(){
			   if(event1!=null){
                  event1();      	
               }
			};
			params["end"]=function(){
			   if(event2!=null){
                  event2();      	
               }
			};
            myLucky = new LuckyCanvas.LuckyWheel("#"+that.名称,params)
        } 
		
		//组件命令：
        this.开始抽奖 = function (){
            myLucky.play();
        } 
		
		//组件命令：
        this.结束抽奖 = function (中奖索引){
            myLucky.stop(中奖索引);
        } 
		
		
		//组件命令：
        this.重置抽奖 = function (){
            myLucky.init();
        }
        
        //组件命令：
        this.置可视 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="";//显示，也可以设置为block	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.display="none"; //不占位隐藏               
            }
        } 
        
        //组件命令：
        this.置可视2 = function (value){
            if(value==true){
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="visible";//显示	                
            }else{
                var div = document.getElementById(this.名称).parentNode;
                div.style.visibility="hidden"; //占位隐藏               
            }
        } 
    }